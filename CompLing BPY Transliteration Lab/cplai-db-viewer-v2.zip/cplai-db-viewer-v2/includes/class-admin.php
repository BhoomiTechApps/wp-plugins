<?php
/**
 * Admin menu and page output for CPLAI DB Viewer.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPLAI_DBV_Admin {

	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
	}

	public static function register_menu(): void {
		add_menu_page(
			'Compiling AI DB',
			'CPLAI DB',
			'manage_options',
			'cplai-db-viewer',
			array( __CLASS__, 'render_page' ),
			'dashicons-database',
			81
		);
	}

	public static function enqueue( string $hook ): void {
		if ( 'toplevel_page_cplai-db-viewer' !== $hook ) {
			return;
		}
		wp_enqueue_style(
			'cplai-dbv-style',
			CPLAI_DBV_URL . 'assets/style.css',
			array(),
			CPLAI_DBV_VERSION
		);
		wp_enqueue_script(
			'cplai-dbv-script',
			CPLAI_DBV_URL . 'assets/script.js',
			array( 'jquery' ),
			CPLAI_DBV_VERSION,
			true
		);
		wp_localize_script(
			'cplai-dbv-script',
			'cplaiDbv',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'cplai_dbv_nonce' ),
			)
		);
	}

	// ── Page ──────────────────────────────────────────────────────────────────

	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Not allowed.', 'cplai-dbv' ) );
		}

		global $wpdb;

		// Check parent plugin tables exist.
		$tables = array(
			'maps'            => $wpdb->prefix . 'cplai_maps',
			'sessions'        => $wpdb->prefix . 'cplai_sessions',
			'snippets'        => $wpdb->prefix . 'cplai_snippets',
			'user_snippets'   => $wpdb->prefix . 'cplai_user_snippets',
			'user_fwd_lexicon' => $wpdb->prefix . 'cplai_user_fwd_lexicon',
			'user_rev_lexicon' => $wpdb->prefix . 'cplai_user_rev_lexicon',
		);

		$missing = array();
		foreach ( $tables as $key => $tbl ) {
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $tbl ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			if ( ! $exists ) {
				$missing[] = $tbl;
			}
		}

		if ( $missing ) {
			echo '<div class="wrap"><div class="notice notice-error"><p>';
			echo '<strong>Compiling AI DB Viewer:</strong> The following tables were not found. Make sure the Compiling AI plugin is installed and activated:<br>';
			echo esc_html( implode( ', ', $missing ) );
			echo '</p></div></div>';
			return;
		}

		// Active tab.
		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'maps'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! array_key_exists( $active_tab, $tables ) ) {
			$active_tab = 'maps';
		}

		?>
		<div class="wrap cplai-dbv-wrap">
			<h1>Compiling AI — Database Viewer</h1>

			<nav class="nav-tab-wrapper">
				<?php foreach ( array_keys( $tables ) as $tab ) : ?>
					<a href="<?php echo esc_url( add_query_arg( 'tab', $tab ) ); ?>"
					   class="nav-tab <?php echo $active_tab === $tab ? 'nav-tab-active' : ''; ?>">
						<?php echo esc_html( ucfirst( $tab ) ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="cplai-dbv-content">
				<?php
				switch ( $active_tab ) {
					case 'maps':
						self::render_maps_tab( $tables['maps'] );
						break;
					case 'sessions':
						self::render_sessions_tab( $tables['sessions'] );
						break;
					case 'snippets':
						self::render_snippets_tab( $tables['snippets'] );
						break;
					case 'user_snippets':
						self::render_user_snippets_tab( $tables['user_snippets'] );
						break;
					case 'user_fwd_lexicon':
						self::render_user_fwd_lexicon_tab( $tables['user_fwd_lexicon'] );
						break;
					case 'user_rev_lexicon':
						self::render_user_rev_lexicon_tab( $tables['user_rev_lexicon'] );
						break;
				}
				?>
			</div>
		</div>

		<!-- Edit Modal -->
		<div id="cplai-dbv-modal" class="cplai-dbv-modal" style="display:none;" aria-modal="true" role="dialog">
			<div class="cplai-dbv-modal-inner">
				<div class="cplai-dbv-modal-header">
					<h2 id="cplai-dbv-modal-title">Edit Row</h2>
					<button class="cplai-dbv-modal-close" aria-label="Close">&times;</button>
				</div>
				<div id="cplai-dbv-modal-body" class="cplai-dbv-modal-body"></div>
				<div class="cplai-dbv-modal-footer">
					<button class="button button-primary" id="cplai-dbv-save-btn">Save Changes</button>
					<button class="button cplai-dbv-modal-close">Cancel</button>
					<span class="cplai-dbv-status"></span>
				</div>
			</div>
		</div>
		<div id="cplai-dbv-overlay" class="cplai-dbv-overlay" style="display:none;"></div>

		<!-- Confirm Delete Modal -->
		<div id="cplai-dbv-confirm" class="cplai-dbv-modal" style="display:none;" role="dialog">
			<div class="cplai-dbv-modal-inner cplai-dbv-confirm-inner">
				<p>Are you sure you want to delete this row? This cannot be undone.</p>
				<div class="cplai-dbv-modal-footer">
					<button class="button button-link-delete" id="cplai-dbv-confirm-yes">Yes, delete</button>
					<button class="button" id="cplai-dbv-confirm-no">Cancel</button>
					<span class="cplai-dbv-status"></span>
				</div>
			</div>
		</div>
		<?php
	}

	// ── Maps tab ──────────────────────────────────────────────────────────────

	private static function render_maps_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, map_type, label, source, is_active, created_at, updated_at FROM `{$table}` ORDER BY id DESC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>Maps <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="maps" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>Type</th><th>Label</th><th>Source</th><th>Active</th><th>Created</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><span class="badge badge-<?php echo esc_attr( $r['map_type'] ); ?>"><?php echo esc_html( $r['map_type'] ); ?></span></td>
						<td><?php echo esc_html( $r['label'] ); ?></td>
						<td><?php echo esc_html( $r['source'] ); ?></td>
						<td><?php echo $r['is_active'] ? '<span class="badge badge-active">Yes</span>' : '<span class="badge badge-inactive">No</span>'; ?></td>
						<td><?php echo esc_html( $r['created_at'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="maps" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="maps" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}

	// ── Sessions tab ──────────────────────────────────────────────────────────

	private static function render_sessions_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, session_key, direction, status, created_at, updated_at FROM `{$table}` ORDER BY id DESC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>Sessions <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="sessions" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>Session Key</th><th>Direction</th><th>Status</th><th>Created</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><code><?php echo esc_html( $r['session_key'] ); ?></code></td>
						<td><?php echo esc_html( $r['direction'] ); ?></td>
						<td><span class="badge badge-<?php echo esc_attr( $r['status'] ); ?>"><?php echo esc_html( $r['status'] ); ?></span></td>
						<td><?php echo esc_html( $r['created_at'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="sessions" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="sessions" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}

	// ── Snippets tab ──────────────────────────────────────────────────────────

	private static function render_snippets_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, snippet_key, label, direction, hook_stage, sort_order, is_active, source, created_at, updated_at FROM `{$table}` ORDER BY sort_order ASC, id ASC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>Snippets <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="snippets" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>Key</th><th>Label</th><th>Direction</th><th>Stage</th><th>Order</th><th>Active</th><th>Source</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><code><?php echo esc_html( $r['snippet_key'] ); ?></code></td>
						<td><?php echo esc_html( $r['label'] ); ?></td>
						<td><?php echo esc_html( $r['direction'] ); ?></td>
						<td><?php echo esc_html( $r['hook_stage'] ); ?></td>
						<td><?php echo esc_html( $r['sort_order'] ); ?></td>
						<td><?php echo $r['is_active'] ? '<span class="badge badge-active">Yes</span>' : '<span class="badge badge-inactive">No</span>'; ?></td>
						<td><?php echo esc_html( $r['source'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="snippets" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="snippets" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}

	// ── User Snippets tab ─────────────────────────────────────────────────────

	private static function render_user_snippets_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, user_id, snippet_key, label, direction, hook_stage, sort_order, is_active, source, created_at, updated_at FROM `{$table}` ORDER BY user_id ASC, sort_order ASC, id ASC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>User Snippets <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="user_snippets" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>User ID</th><th>Key</th><th>Label</th><th>Direction</th><th>Stage</th><th>Order</th><th>Active</th><th>Source</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><?php echo esc_html( $r['user_id'] ); ?></td>
						<td><code><?php echo esc_html( $r['snippet_key'] ); ?></code></td>
						<td><?php echo esc_html( $r['label'] ); ?></td>
						<td><?php echo esc_html( $r['direction'] ); ?></td>
						<td><?php echo esc_html( $r['hook_stage'] ); ?></td>
						<td><?php echo esc_html( $r['sort_order'] ); ?></td>
						<td><?php echo $r['is_active'] ? '<span class="badge badge-active">Yes</span>' : '<span class="badge badge-inactive">No</span>'; ?></td>
						<td><?php echo esc_html( $r['source'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="user_snippets" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="user_snippets" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}

	// ── User Forward Lexicon tab ───────────────────────────────────────────────

	private static function render_user_fwd_lexicon_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, user_id, roman_key, bpm_value, created_at, updated_at FROM `{$table}` ORDER BY user_id ASC, roman_key ASC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>User Forward Lexicon <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="user_fwd_lexicon" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>User ID</th><th>Roman Key</th><th>BPM Value</th><th>Created</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><?php echo esc_html( $r['user_id'] ); ?></td>
						<td><code><?php echo esc_html( $r['roman_key'] ); ?></code></td>
						<td><?php echo esc_html( $r['bpm_value'] ); ?></td>
						<td><?php echo esc_html( $r['created_at'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="user_fwd_lexicon" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="user_fwd_lexicon" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}

	// ── User Reverse Lexicon tab ───────────────────────────────────────────────

	private static function render_user_rev_lexicon_tab( string $table ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results( "SELECT id, user_id, bpm_key, roman_value, created_at, updated_at FROM `{$table}` ORDER BY user_id ASC, bpm_key ASC", ARRAY_A ); // nosemgrep
		?>
		<div class="cplai-dbv-table-header">
			<h2>User Reverse Lexicon <span class="cplai-dbv-count"><?php echo count( $rows ); ?> rows</span></h2>
			<button class="button button-primary" data-table="user_rev_lexicon" data-action="add">+ Add Row</button>
		</div>
		<?php if ( empty( $rows ) ) : ?>
			<p>No rows found.</p>
		<?php else : ?>
		<div class="cplai-dbv-table-wrap">
			<table class="widefat striped cplai-dbv-table">
				<thead>
					<tr>
						<th>ID</th><th>User ID</th><th>BPM Key</th><th>Roman Value</th><th>Created</th><th>Updated</th><th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $rows as $r ) : ?>
					<tr data-id="<?php echo esc_attr( $r['id'] ); ?>">
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><?php echo esc_html( $r['user_id'] ); ?></td>
						<td><code><?php echo esc_html( $r['bpm_key'] ); ?></code></td>
						<td><?php echo esc_html( $r['roman_value'] ); ?></td>
						<td><?php echo esc_html( $r['created_at'] ); ?></td>
						<td><?php echo esc_html( $r['updated_at'] ); ?></td>
						<td class="row-actions-cell">
							<button class="button button-small cplai-edit-btn" data-table="user_rev_lexicon" data-id="<?php echo esc_attr( $r['id'] ); ?>">Edit</button>
							<button class="button button-small cplai-delete-btn" data-table="user_rev_lexicon" data-id="<?php echo esc_attr( $r['id'] ); ?>">Delete</button>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php endif;
	}
}
