<?php
/**
 * AJAX endpoints: fetch row, save row, delete row.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CPLAI_DBV_Ajax {

	// Table -> column definitions used for building edit forms.
	private static array $schema = array(
		'maps'     => array(
			'map_type'  => array( 'type' => 'select', 'options' => array( 'forward', 'reverse' ), 'label' => 'Map Type', 'required' => true ),
			'label'     => array( 'type' => 'text',   'label' => 'Label', 'required' => true ),
			'source'    => array( 'type' => 'select', 'options' => array( 'default', 'user' ), 'label' => 'Source' ),
			'is_active' => array( 'type' => 'toggle', 'label' => 'Active' ),
			'json_data' => array( 'type' => 'textarea', 'label' => 'JSON Data', 'required' => true, 'code' => true ),
		),
		'sessions' => array(
			'session_key'  => array( 'type' => 'text',     'label' => 'Session Key', 'required' => true ),
			'direction'    => array( 'type' => 'select',   'options' => array( 'forward', 'reverse', 'both' ), 'label' => 'Direction' ),
			'prompt_text'  => array( 'type' => 'textarea', 'label' => 'Prompt Text', 'code' => false ),
			'gen_code'     => array( 'type' => 'textarea', 'label' => 'Generated Code', 'code' => true ),
			'status'       => array( 'type' => 'select',   'options' => array( 'generated', 'saved', 'error' ), 'label' => 'Status' ),
		),
		'snippets' => array(
			'snippet_key'       => array( 'type' => 'text',     'label' => 'Snippet Key', 'required' => true ),
			'label'             => array( 'type' => 'text',     'label' => 'Label', 'required' => true ),
			'direction'         => array( 'type' => 'select',   'options' => array( 'forward', 'reverse', 'both' ), 'label' => 'Direction' ),
			'hook_stage'        => array( 'type' => 'select',   'options' => array( 'pre', 'loop', 'post' ), 'label' => 'Hook Stage' ),
			'logic_description' => array( 'type' => 'textarea', 'label' => 'Logic Description', 'code' => false ),
			'js_body'           => array( 'type' => 'textarea', 'label' => 'JS Body', 'code' => true ),
			'php_body'          => array( 'type' => 'textarea', 'label' => 'PHP Body', 'code' => true ),
			'sort_order'        => array( 'type' => 'number',   'label' => 'Sort Order' ),
			'is_active'         => array( 'type' => 'toggle',   'label' => 'Active' ),
			'source'            => array( 'type' => 'select',   'options' => array( 'default', 'user', 'ai_generated' ), 'label' => 'Source' ),
		),
		'user_snippets' => array(
			'user_id'           => array( 'type' => 'number',   'label' => 'User ID', 'required' => true ),
			'snippet_key'       => array( 'type' => 'text',     'label' => 'Snippet Key', 'required' => true ),
			'label'             => array( 'type' => 'text',     'label' => 'Label', 'required' => true ),
			'direction'         => array( 'type' => 'select',   'options' => array( 'forward', 'reverse', 'both' ), 'label' => 'Direction' ),
			'hook_stage'        => array( 'type' => 'select',   'options' => array( 'pre', 'loop', 'post' ), 'label' => 'Hook Stage' ),
			'logic_description' => array( 'type' => 'textarea', 'label' => 'Logic Description', 'code' => false ),
			'js_body'           => array( 'type' => 'textarea', 'label' => 'JS Body', 'code' => true ),
			'php_body'          => array( 'type' => 'textarea', 'label' => 'PHP Body', 'code' => true ),
			'sort_order'        => array( 'type' => 'number',   'label' => 'Sort Order' ),
			'is_active'         => array( 'type' => 'toggle',   'label' => 'Active' ),
			'source'            => array( 'type' => 'select',   'options' => array( 'default', 'user', 'ai_generated' ), 'label' => 'Source' ),
		),
		'user_fwd_lexicon' => array(
			'user_id'   => array( 'type' => 'number', 'label' => 'User ID',   'required' => true ),
			'roman_key' => array( 'type' => 'text',   'label' => 'Roman Key', 'required' => true ),
			'bpm_value' => array( 'type' => 'text',   'label' => 'BPM Value', 'required' => true ),
		),
		'user_rev_lexicon' => array(
			'user_id'     => array( 'type' => 'number', 'label' => 'User ID',     'required' => true ),
			'bpm_key'     => array( 'type' => 'text',   'label' => 'BPM Key',     'required' => true ),
			'roman_value' => array( 'type' => 'text',   'label' => 'Roman Value', 'required' => true ),
		),
	);

	public static function init(): void {
		add_action( 'wp_ajax_cplai_dbv_fetch',  array( __CLASS__, 'handle_fetch' ) );
		add_action( 'wp_ajax_cplai_dbv_save',   array( __CLASS__, 'handle_save' ) );
		add_action( 'wp_ajax_cplai_dbv_delete', array( __CLASS__, 'handle_delete' ) );
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private static function verify(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Permission denied.', 403 );
		}
		check_ajax_referer( 'cplai_dbv_nonce', 'nonce' );
	}

	private static function resolve_table( string $key ): string {
		global $wpdb;
		$map = array(
			'maps'             => $wpdb->prefix . 'cplai_maps',
			'sessions'         => $wpdb->prefix . 'cplai_sessions',
			'snippets'         => $wpdb->prefix . 'cplai_snippets',
			'user_snippets'    => $wpdb->prefix . 'cplai_user_snippets',
			'user_fwd_lexicon' => $wpdb->prefix . 'cplai_user_fwd_lexicon',
			'user_rev_lexicon' => $wpdb->prefix . 'cplai_user_rev_lexicon',
		);
		if ( ! isset( $map[ $key ] ) ) {
			wp_send_json_error( 'Invalid table.', 400 );
		}
		return $map[ $key ];
	}

	// ── Fetch (load one row for the edit form) ────────────────────────────────

	public static function handle_fetch(): void {
		self::verify();
		$table_key = sanitize_key( $_POST['table'] ?? '' );
		$id        = absint( $_POST['id'] ?? 0 );
		$table     = self::resolve_table( $table_key );
		global $wpdb;

		if ( $id ) {
			// Edit existing.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ), ARRAY_A ); // nosemgrep
			if ( ! $row ) {
				wp_send_json_error( 'Row not found.' );
			}
		} else {
			// New row — return empty defaults.
			$row = array_fill_keys( array_keys( self::$schema[ $table_key ] ), '' );
			$row['id'] = 0;
		}

		wp_send_json_success( array(
			'row'    => $row,
			'schema' => self::$schema[ $table_key ],
			'table'  => $table_key,
			'id'     => $id,
		) );
	}

	// ── Save (insert or update) ───────────────────────────────────────────────

	public static function handle_save(): void {
		self::verify();
		$table_key = sanitize_key( $_POST['table'] ?? '' );
		$id        = absint( $_POST['id'] ?? 0 );
		$table     = self::resolve_table( $table_key );
		$schema    = self::$schema[ $table_key ];
		global $wpdb;

		$data   = array();
		$format = array();

		foreach ( $schema as $col => $def ) {
			if ( ! isset( $_POST[ $col ] ) ) {
				continue;
			}

			$val = $_POST[ $col ];

			switch ( $def['type'] ) {
				case 'toggle':
					$val    = $val ? 1 : 0;
					$format[] = '%d';
					break;
				case 'number':
					$val    = (int) $val;
					$format[] = '%d';
					break;
				default:
					$val    = wp_unslash( $val );
					$format[] = '%s';
			}

			$data[ $col ] = $val;
		}

		if ( empty( $data ) ) {
			wp_send_json_error( 'No data to save.' );
		}

		if ( $id ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$result = $wpdb->update( $table, $data, array( 'id' => $id ), $format, array( '%d' ) );
			if ( false === $result ) {
				wp_send_json_error( 'DB update failed: ' . $wpdb->last_error );
			}
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$result = $wpdb->insert( $table, $data, $format );
			if ( false === $result ) {
				wp_send_json_error( 'DB insert failed: ' . $wpdb->last_error );
			}
			$id = $wpdb->insert_id;
		}

		wp_send_json_success( array( 'id' => $id, 'message' => 'Saved successfully.' ) );
	}

	// ── Delete ────────────────────────────────────────────────────────────────

	public static function handle_delete(): void {
		self::verify();
		$table_key = sanitize_key( $_POST['table'] ?? '' );
		$id        = absint( $_POST['id'] ?? 0 );
		$table     = self::resolve_table( $table_key );
		global $wpdb;

		if ( ! $id ) {
			wp_send_json_error( 'Invalid ID.' );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$result = $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
		if ( false === $result ) {
			wp_send_json_error( 'DB delete failed: ' . $wpdb->last_error );
		}

		wp_send_json_success( array( 'message' => 'Deleted.' ) );
	}
}
