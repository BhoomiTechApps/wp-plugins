<?php
/**
 * Plugin Name: Compiling AI — DB Viewer
 * Description: View and edit the three database tables created by the Compiling AI plugin (cplai_maps, cplai_sessions, cplai_snippets).
 * Version:     1.0.0
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author:      Site Admin
 * License:     GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CPLAI_DBV_VERSION', '1.0.0' );
define( 'CPLAI_DBV_DIR', plugin_dir_path( __FILE__ ) );
define( 'CPLAI_DBV_URL', plugin_dir_url( __FILE__ ) );

require_once CPLAI_DBV_DIR . 'includes/class-admin.php';
require_once CPLAI_DBV_DIR . 'includes/class-ajax.php';

add_action( 'plugins_loaded', array( 'CPLAI_DBV_Admin', 'init' ) );
add_action( 'plugins_loaded', array( 'CPLAI_DBV_Ajax', 'init' ) );
