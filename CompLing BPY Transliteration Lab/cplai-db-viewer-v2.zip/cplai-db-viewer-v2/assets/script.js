/* global cplaiDbv, jQuery */
(function ($) {
	'use strict';

	const { ajaxUrl, nonce } = cplaiDbv;

	// ── DOM refs ────────────────────────────────────────────────────────────
	const $modal    = $('#cplai-dbv-modal');
	const $overlay  = $('#cplai-dbv-overlay');
	const $body     = $('#cplai-dbv-modal-body');
	const $title    = $('#cplai-dbv-modal-title');
	const $saveBtn  = $('#cplai-dbv-save-btn');
	const $status   = $modal.find('.cplai-dbv-status');
	const $confirm  = $('#cplai-dbv-confirm');
	const $confirmStatus = $confirm.find('.cplai-dbv-status');

	let pendingDelete = null; // { table, id, $row }

	// ── Open / Close modal ──────────────────────────────────────────────────
	function openModal() {
		$overlay.show();
		$modal.show().css('display', 'flex');
	}
	function closeModal() {
		$modal.hide();
		$overlay.hide();
		$body.empty();
		setStatus('', '');
	}

	$(document).on('click', '.cplai-dbv-modal-close', closeModal);
	$overlay.on('click', function (e) {
		if ($modal.is(':visible')) closeModal();
		if ($confirm.is(':visible')) closeConfirm();
	});
	$(document).on('keydown', function (e) {
		if (e.key === 'Escape') { closeModal(); closeConfirm(); }
	});

	function setStatus(msg, type) {
		$status.text(msg).removeClass('success error').addClass(type || '');
	}

	// ── Edit button ─────────────────────────────────────────────────────────
	$(document).on('click', '.cplai-edit-btn', function () {
		const table = $(this).data('table');
		const id    = $(this).data('id');
		fetchRow(table, id);
	});

	// ── Add button ──────────────────────────────────────────────────────────
	$(document).on('click', '[data-action="add"]', function () {
		const table = $(this).data('table');
		fetchRow(table, 0);
	});

	function fetchRow(table, id) {
		setStatus('Loading…', '');
		openModal();
		$title.text(id ? 'Edit Row — ' + table : 'Add Row — ' + table);
		$body.html('<p style="padding:10px;">Loading…</p>');

		$.post(ajaxUrl, { action: 'cplai_dbv_fetch', nonce, table, id })
			.done(function (res) {
				if (!res.success) { setStatus(res.data || 'Error loading row.', 'error'); return; }
				renderForm(res.data);
				setStatus('', '');
			})
			.fail(function () { setStatus('Network error.', 'error'); });
	}

	// ── Build form ──────────────────────────────────────────────────────────
	function renderForm(data) {
		const { row, schema, table, id } = data;
		let html = `<input type="hidden" id="cplai-field-_table" value="${escAttr(table)}">
		            <input type="hidden" id="cplai-field-_id"    value="${escAttr(id)}">`;

		for (const [col, def] of Object.entries(schema)) {
			const val     = row[col] ?? '';
			const fieldId = 'cplai-field-' + col;
			const req     = def.required ? ' <span style="color:red">*</span>' : '';

			html += `<div class="cplai-field-row">`;
			html += `<label for="${escAttr(fieldId)}">${escHtml(def.label)}${req}</label>`;

			switch (def.type) {
				case 'toggle': {
					const chk = parseInt(val, 10) ? 'checked' : '';
					html += `<div class="cplai-toggle-wrap">
						<label class="cplai-toggle">
							<input type="checkbox" id="${escAttr(fieldId)}" data-col="${escAttr(col)}" ${chk}>
							<span class="cplai-toggle-slider"></span>
						</label>
						<span>${val ? 'Enabled' : 'Disabled'}</span>
					</div>`;
					break;
				}
				case 'select': {
					html += `<select id="${escAttr(fieldId)}" data-col="${escAttr(col)}">`;
					for (const opt of def.options) {
						const sel = opt === val ? 'selected' : '';
						html += `<option value="${escAttr(opt)}" ${sel}>${escHtml(opt)}</option>`;
					}
					html += `</select>`;
					break;
				}
				case 'number': {
					html += `<input type="number" id="${escAttr(fieldId)}" data-col="${escAttr(col)}" value="${escAttr(val)}">`;
					break;
				}
				case 'textarea': {
					const cls = def.code ? ' code-textarea' : '';
					const rows = def.code ? 10 : 5;
					html += `<textarea id="${escAttr(fieldId)}" data-col="${escAttr(col)}" class="${cls}" rows="${rows}">${escHtml(val)}</textarea>`;
					break;
				}
				default: {
					html += `<input type="text" id="${escAttr(fieldId)}" data-col="${escAttr(col)}" value="${escAttr(val)}">`;
				}
			}

			html += `</div>`;
		}

		$body.html(html);

		// Update toggle label on change.
		$body.find('input[type="checkbox"]').on('change', function () {
			$(this).closest('.cplai-toggle-wrap').find('span:last').text(this.checked ? 'Enabled' : 'Disabled');
		});
	}

	// ── Save ────────────────────────────────────────────────────────────────
	$saveBtn.on('click', function () {
		const table = $('#cplai-field-_table').val();
		const id    = $('#cplai-field-_id').val();

		const payload = { action: 'cplai_dbv_save', nonce, table, id };

		$body.find('[data-col]').each(function () {
			const col = $(this).data('col');
			if ($(this).is(':checkbox')) {
				payload[col] = this.checked ? 1 : 0;
			} else {
				payload[col] = $(this).val();
			}
		});

		setStatus('Saving…', '');
		$saveBtn.prop('disabled', true);

		$.post(ajaxUrl, payload)
			.done(function (res) {
				if (!res.success) {
					setStatus(res.data || 'Save failed.', 'error');
				} else {
					setStatus('Saved! Reloading…', 'success');
					setTimeout(() => location.reload(), 800);
				}
			})
			.fail(function () { setStatus('Network error.', 'error'); })
			.always(function () { $saveBtn.prop('disabled', false); });
	});

	// ── Delete ──────────────────────────────────────────────────────────────
	$(document).on('click', '.cplai-delete-btn', function () {
		pendingDelete = {
			table: $(this).data('table'),
			id:    $(this).data('id'),
			$row:  $(this).closest('tr'),
		};
		$overlay.show();
		$confirm.show().css('display', 'flex');
	});

	function closeConfirm() {
		$confirm.hide();
		$overlay.hide();
		pendingDelete = null;
		$confirmStatus.text('');
	}

	$('#cplai-dbv-confirm-no').on('click', closeConfirm);

	$('#cplai-dbv-confirm-yes').on('click', function () {
		if (!pendingDelete) return;
		const { table, id, $row } = pendingDelete;
		$confirmStatus.text('Deleting…').removeClass('success error');

		$.post(ajaxUrl, { action: 'cplai_dbv_delete', nonce, table, id })
			.done(function (res) {
				if (!res.success) {
					$confirmStatus.text(res.data || 'Delete failed.').addClass('error');
				} else {
					$row.fadeOut(300, function () { $(this).remove(); });
					closeConfirm();
				}
			})
			.fail(function () { $confirmStatus.text('Network error.').addClass('error'); });
	});

	// ── Helpers ─────────────────────────────────────────────────────────────
	function escHtml(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}
	function escAttr(str) { return escHtml(str); }

}(jQuery));
