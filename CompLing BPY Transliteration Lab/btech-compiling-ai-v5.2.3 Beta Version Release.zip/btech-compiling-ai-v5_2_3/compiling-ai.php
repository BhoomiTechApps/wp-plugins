<?php
/**
 * Plugin Name:       CompLing AI — BPM Transliteration Lab
 * Plugin URI:        https://bhoomitechfoundation.org/apps/bmime/
 * Description:       Computational linguistics research plugin for Bishnupriya Manipuri (BPM). Fixed hook-based JS/PHP transliteration engine with a snippet registry — AI generates and tests snippet logic only. Includes forward/reverse engines, JSON-driven map sets, live test console, and lexicon editor.
 * Version:           5.2.3
 * Requires at least: 6.4
 * Requires PHP:      8.1
 * Author:            BhoomiTech Heritage and Development Foundation
 * Author URI:        https://bhoomitechfoundation.org/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       compiling-ai
 * Domain Path:       /languages
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// ── Constants ─────────────────────────────────────────────────────────────────
define( 'CPLAI_VERSION',      '5.2.3' );
define( 'CPLAI_MIN_WP',       '6.4' );
define( 'CPLAI_MIN_PHP',      '8.1' );
define( 'CPLAI_FILE',         __FILE__ );
define( 'CPLAI_DIR',          plugin_dir_path( __FILE__ ) );
define( 'CPLAI_URL',          plugin_dir_url( __FILE__ ) );
define( 'CPLAI_DATA_DIR',     CPLAI_DIR . 'data/' );
define( 'CPLAI_SNIPPETS_DIR', CPLAI_DIR . 'data/snippets/' );

// ── Environment check ─────────────────────────────────────────────────────────
if ( version_compare( PHP_VERSION, CPLAI_MIN_PHP, '<' ) ) {
	add_action( 'admin_notices', function () {
		printf(
			'<div class="notice notice-error"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: 1: required PHP version, 2: current PHP version */
					__( 'CompLing AI requires PHP %1$s or higher. You are running PHP %2$s. Please upgrade.', 'compiling-ai' ),
					CPLAI_MIN_PHP,
					PHP_VERSION
				)
			)
		);
	} );
	return;
}

// ── Autoloader ────────────────────────────────────────────────────────────────
spl_autoload_register( function ( $class ) {
	if ( strpos( $class, 'CPLAI_' ) !== 0 ) {
		return;
	}
	$slug = strtolower( str_replace( array( 'CPLAI_', '_' ), array( '', '-' ), $class ) );
	$file = CPLAI_DIR . "includes/class-{$slug}.php";
	if ( file_exists( $file ) ) {
		require_once $file;
	}
} );

// ── Core dependencies (not autoloaded — needed for hooks) ─────────────────────
require_once CPLAI_DIR . 'includes/class-installer.php';

// ── Boot ──────────────────────────────────────────────────────────────────────
add_action(
	'plugins_loaded',
	function () {
		// i18n.
		load_plugin_textdomain( 'compiling-ai', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

		// Run DB migration if version changed.
		if ( get_option( 'cplai_db_version' ) !== CPLAI_VERSION ) {
			CPLAI_Installer::activate();
		}

		CPLAI_Core::init();
	}
);

register_activation_hook( __FILE__, array( 'CPLAI_Installer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'CPLAI_Installer', 'deactivate' ) );
