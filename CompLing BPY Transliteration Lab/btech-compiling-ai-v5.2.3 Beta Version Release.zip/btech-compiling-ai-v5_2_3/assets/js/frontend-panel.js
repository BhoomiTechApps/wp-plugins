/**
 * BPM Frontend Panel — Public Frontend JS
 *
 * Drives the panel section rendered by [bpm_transliterator] for logged-in
 * cplai_transliterator / manage_options users.
 *
 * Tabs:
 * Snippets — full CRUD against /user/snippets  + Load Defaults seeding
 * Lexicon  — full CRUD against /user/lexicon   + Load Defaults seeding
 *
 * REST base : CPLAI_FrontendPanel.rest_url  (e.g. /wp-json/cplai/v1/)
 * Nonce     : CPLAI_FrontendPanel.nonce
 *
 * @package CompilingAI
 */
/* global CPLAI_FrontendPanel */
( function () {
	'use strict';

	const CFG   = window.CPLAI_FrontendPanel || {};
	const BASE  = ( CFG.rest_url || '' ).replace( /\/$/, '' ) + '/';
	const NONCE = CFG.nonce || '';
	const DEBUG = CFG.debug === '1';

	// ── Helpers ───────────────────────────────────────────────────────────────

	function apiReq( method, path, body ) {
		const opts = {
			method:  method,
			headers: { 'X-WP-Nonce': NONCE },
		};
		if ( body !== undefined ) {
			opts.headers[ 'Content-Type' ] = 'application/json';
			opts.body = JSON.stringify( body );
		}
		return fetch( BASE + path, opts ).then( r => {
			if ( ! r.ok ) {
				return r.json().catch( () => null ).then( j => {
					const msg = j && j.message ? j.message : 'HTTP ' + r.status;
					throw new Error( msg );
				} );
			}
			return r.json();
		} );
	}

	const apiGet    = ( path )        => apiReq( 'GET',    path );
	const apiPost   = ( path, body )  => apiReq( 'POST',   path, body );
	const apiPut    = ( path, body )  => apiReq( 'PUT',    path, body );
	const apiDelete = ( path )        => apiReq( 'DELETE', path );

	function esc( v ) {
		return String( v ?? '' )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' );
	}

	function el( id ) { return document.getElementById( id ); }

	function showMsg( text, type ) {
		const bar = el( 'bpm-fp-msg' );
		if ( ! bar ) return;
		bar.textContent   = text;
		bar.className     = 'bpm-fp-msg ' + ( type || 'info' );
		bar.style.display = 'block';
		setTimeout( () => { bar.style.display = 'none'; }, 5000 );
	}

	// ── Tab switching ─────────────────────────────────────────────────────────

	const tabLoaded = {};

	document.querySelectorAll( '.bpm-fp-tab' ).forEach( btn => {
		btn.addEventListener( 'click', () => {
			document.querySelectorAll( '.bpm-fp-tab' ).forEach( b => {
				b.classList.remove( 'active' );
				b.setAttribute( 'aria-selected', 'false' );
			} );
			document.querySelectorAll( '.bpm-fp-panel' ).forEach( p => {
				p.classList.remove( 'active' );
			} );

			btn.classList.add( 'active' );
			btn.setAttribute( 'aria-selected', 'true' );

			const tabName = btn.dataset.tab;
			const panel   = el( 'bpm-fp-tab-' + tabName );
			if ( panel ) panel.classList.add( 'active' );

			// Auto-load on first visit.
			if ( tabName === 'snippets' && ! tabLoaded.snippets ) {
				tabLoaded.snippets = true;
				loadSnippets();
			}
			if ( tabName === 'lexicon' && ! tabLoaded.lexicon ) {
				tabLoaded.lexicon = true;
				loadLexicon();
			}
			// Sync direction selector when switching back to transliterator tab.
			if ( tabName === 'transliterator' ) {
				const w = document.querySelector( '.bpm-transliterator-widget' );
				const ds = el( 'bpm-fp-active-direction' );
				if ( w && ds ) ds.value = w.dataset.direction || 'forward';
			}
		} );
	} );

	// ── ──────────────────────────────────────────────────────────────────── ──
	// SNIPPETS TAB
	// ── ──────────────────────────────────────────────────────────────────── ──

	function renderSnippetRow( s ) {
		const tr      = document.createElement( 'tr' );
		tr.dataset.id = s.id;
		const checked = parseInt( s.is_active, 10 ) === 1 ? 'checked' : '';

		tr.innerHTML =
			'<td><code>' + esc( s.snippet_key ) + '</code></td>' +
			'<td>' + esc( s.label ) + '</td>' +
			'<td>' + esc( s.direction ) + '</td>' +
			'<td>' + esc( s.hook_stage ) + '</td>' +
			'<td><span class="bpm-fp-source-badge source-' + esc( s.source ) + '">' + esc( s.source ) + '</span></td>' +
			'<td>' +
				'<label class="bpm-fp-toggle" title="Toggle active">' +
					'<input type="checkbox" class="bpm-fp-snip-toggle" data-id="' + esc( s.id ) + '" ' + checked + ' />' +
					'<span class="bpm-fp-toggle-slider"></span>' +
				'</label>' +
			'</td>' +
			'<td class="bpm-fp-actions">' +
				'<button class="bpm-fp-btn-icon bpm-fp-snip-edit" data-id="' + esc( s.id ) + '" title="Edit">✏️</button>' +
				'<button class="bpm-fp-btn-icon bpm-fp-snip-delete" data-id="' + esc( s.id ) + '" title="Delete">🗑️</button>' +
			'</td>';

		return tr;
	}

	async function loadSnippets() {
		const btn   = el( 'bpm-fp-btn-load-snippets' );
		const tbody = el( 'bpm-fp-snip-tbody' );
		if ( ! tbody ) return;
		if ( btn ) btn.disabled = true;

		const dir   = el( 'bpm-fp-snip-dir' )?.value   || '';
		const stage = el( 'bpm-fp-snip-stage' )?.value || '';
		let   path  = 'user/snippets';
		const parts = [];
		if ( dir )   parts.push( 'direction='  + encodeURIComponent( dir ) );
		if ( stage ) parts.push( 'hook_stage=' + encodeURIComponent( stage ) );
		if ( parts.length ) path += '?' + parts.join( '&' );

		try {
			const data = await apiGet( path );
			const list = data.snippets || ( Array.isArray( data ) ? data : [] );

			tbody.innerHTML = '';

			if ( ! list.length ) {
				tbody.innerHTML = '<tr><td colspan="7" class="bpm-fp-placeholder">No snippets yet. Use "Load Defaults" to seed from the main database.</td></tr>';
				return;
			}

			list.forEach( s => tbody.appendChild( renderSnippetRow( s ) ) );
			attachSnippetHandlers( tbody );

			if ( DEBUG ) console.log( '[CPLAI FrontendPanel] Snippets loaded:', list.length );
		} catch ( err ) {
			tbody.innerHTML = '<tr><td colspan="7" class="bpm-fp-placeholder">Failed to load snippets.</td></tr>';
			showMsg( 'Failed to load snippets: ' + err.message, 'error' );
			if ( DEBUG ) console.error( '[CPLAI FrontendPanel] Snippets error:', err );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}

	function attachSnippetHandlers( tbody ) {
		// Toggle active.
		tbody.querySelectorAll( '.bpm-fp-snip-toggle' ).forEach( chk => {
			chk.addEventListener( 'change', async () => {
				const id     = chk.dataset.id;
				chk.disabled = true;
				try {
					await apiPost( 'user/snippets/' + id + '/toggle', {} );
				} catch ( e ) {
					showMsg( 'Toggle failed: ' + e.message, 'error' );
					chk.checked = ! chk.checked; // revert UI
				} finally {
					chk.disabled = false;
				}
			} );
		} );

		// Edit button — open modal.
		tbody.querySelectorAll( '.bpm-fp-snip-edit' ).forEach( btn => {
			btn.addEventListener( 'click', async () => {
				const id = btn.dataset.id;
				try {
					const s = await apiGet( 'user/snippets/' + id );
					// Fixed nesting mismatch: extract the nested .snippet object if present
					if ( s && s.snippet ) {
						openSnippetModal( s.snippet );
					} else {
						openSnippetModal( s );
					}
				} catch ( e ) {
					showMsg( 'Could not load snippet: ' + e.message, 'error' );
				}
			} );
		} );

		// Delete button.
		tbody.querySelectorAll( '.bpm-fp-snip-delete' ).forEach( btn => {
			btn.addEventListener( 'click', async () => {
				const id = btn.dataset.id;
				if ( ! confirm( 'Delete this snippet?' ) ) return;
				btn.disabled = true;
				try {
					await apiDelete( 'user/snippets/' + id );
					const row = btn.closest( 'tr' );
					if ( row ) row.remove();
					showMsg( 'Snippet deleted.', 'success' );
				} catch ( e ) {
					showMsg( 'Delete failed: ' + e.message, 'error' );
					btn.disabled = false;
				}
			} );
		} );
	}

	// Load button.
	const btnLoadSnippets = el( 'bpm-fp-btn-load-snippets' );
	if ( btnLoadSnippets ) {
		btnLoadSnippets.addEventListener( 'click', () => loadSnippets() );
	}

	// Filter re-load.
	[ 'bpm-fp-snip-dir', 'bpm-fp-snip-stage' ].forEach( id => {
		const sel = el( id );
		if ( sel ) sel.addEventListener( 'change', () => { if ( tabLoaded.snippets ) loadSnippets(); } );
	} );

	// Add Snippet button — open empty modal.
	const btnAddSnippet = el( 'bpm-fp-btn-add-snippet' );
	if ( btnAddSnippet ) {
		btnAddSnippet.addEventListener( 'click', () => openSnippetModal( null ) );
	}

	// Seed defaults button.
	const btnSeedSnippets = el( 'bpm-fp-btn-seed-snippets' );
	if ( btnSeedSnippets ) {
		btnSeedSnippets.addEventListener( 'click', async () => {
			const dir = el( 'bpm-fp-snip-dir' )?.value || '';
			const msg = dir
				? 'Load default ' + dir + ' snippets (and generic "both" snippets) into your workspace?'
				: 'Load all default snippets into your workspace? Existing entries will be skipped.';
			if ( ! confirm( msg ) ) return;
			btnSeedSnippets.disabled = true;
			try {
				const body = dir ? { direction: dir } : {};
				const res  = await apiPost( 'user/snippets/seed', body );
				showMsg(
					'Seeded: ' + ( res.seeded ?? 0 ) + ' added, ' + ( res.skipped ?? 0 ) + ' skipped.',
					'success'
				);
				loadSnippets();
			} catch ( e ) {
				showMsg( 'Seeding failed: ' + e.message, 'error' );
			} finally {
				btnSeedSnippets.disabled = false;
			}
		} );
	}

	// ── ──────────────────────────────────────────────────────────────────── ──
	// TRANSLITERATOR TAB — direction control
	// ── ──────────────────────────────────────────────────────────────────── ──

	/**
	 * Returns the first .bpm-transliterator-widget on the page (there is usually only one).
	 */
	function getWidget() {
		return document.querySelector( '.bpm-transliterator-widget' );
	}

	/**
	 * Applies `dir` to the widget and re-fires transliteration if there is input.
	 */
	function applyWidgetDirection( dir ) {
		const widget = getWidget();
		if ( ! widget ) return;

		// Update the data attribute the widget JS reads for every transliterate call.
		widget.dataset.direction = dir;

		// Update the visible direction badge / toggle label if present.
		const dirLabel = widget.querySelector( '.bpm-tr-dir-label' );
		if ( dirLabel ) {
			dirLabel.textContent = dir === 'forward' ? 'Roman → BPM' : 'BPM → Roman';
		}

		// Flip the divider arrow.
		const arrowEl = widget.querySelector( '.bpm-tr-arrow' );
		if ( arrowEl ) {
			arrowEl.className = dir === 'forward'
				? 'bpm-tr-arrow dashicons dashicons-arrow-right-alt'
				: 'bpm-tr-arrow dashicons dashicons-arrow-left-alt';
		}

		// Re-transliterate existing input so output updates immediately.
		const inputEl = widget.querySelector( '.bpm-tr-input' );
		if ( inputEl && inputEl.value.trim() ) {
			inputEl.dispatchEvent( new Event( 'input' ) );
		}
	}

	// Direction selector.
	const dirSelect = el( 'bpm-fp-active-direction' );
	if ( dirSelect ) {
		// Initialise selector to match the widget's current direction.
		const widget = getWidget();
		if ( widget ) dirSelect.value = widget.dataset.direction || 'forward';

		dirSelect.addEventListener( 'change', () => {
			applyWidgetDirection( dirSelect.value );
		} );
	}

	// Swap button.
	const btnSwapDir = el( 'bpm-fp-btn-swap-dir' );
	if ( btnSwapDir ) {
		btnSwapDir.addEventListener( 'click', () => {
			const current = dirSelect ? dirSelect.value : ( getWidget()?.dataset.direction || 'forward' );
			const next    = current === 'forward' ? 'reverse' : 'forward';
			if ( dirSelect ) dirSelect.value = next;
			applyWidgetDirection( next );
		} );
	}

	// Snippets and Lexicon auto-load only when their tabs are first visited.
	// (Transliterator tab starts active; no REST calls needed for it.)

	// ── Snippet modal ─────────────────────────────────────────────────────────

	function openSnippetModal( s ) {
		const modal = el( 'bpm-fp-snip-modal' );
		if ( ! modal ) return;

		el( 'bpm-fp-modal-snip-id' ).value    = s ? s.id    : '';
		el( 'bpm-fp-modal-snip-key' ).value   = s ? ( s.snippet_key || '' ) : '';
		el( 'bpm-fp-modal-snip-label' ).value = s ? ( s.label || '' ) : '';
		el( 'bpm-fp-modal-snip-dir' ).value   = s ? ( s.direction  || 'both' ) : 'both';
		el( 'bpm-fp-modal-snip-stage' ).value = s ? ( s.hook_stage || 'loop' ) : 'loop';
	
		// FIXING THE MISMATCHES HERE:
		el( 'bpm-fp-modal-snip-desc' ).value  = s ? ( s.logic_description || '' ) : '';
		el( 'bpm-fp-modal-snip-js' ).value    = s ? ( s.js_body || '' ) : '';
		el( 'bpm-fp-modal-snip-php' ).value   = s ? ( s.php_body || '' ) : '';

		// Key field: disable editing on existing snippets to prevent confusion.
		el( 'bpm-fp-modal-snip-key' ).readOnly = !! ( s && s.id );

		el( 'bpm-fp-modal-title' ).textContent = s ? 'Edit Snippet' : 'Add Snippet';
		modal.style.display = 'flex';
		el( 'bpm-fp-modal-snip-label' ).focus();
	}

	function closeSnippetModal() {
		const modal = el( 'bpm-fp-snip-modal' );
		if ( modal ) modal.style.display = 'none';
	}

	el( 'bpm-fp-modal-close' )?.addEventListener( 'click', closeSnippetModal );
	el( 'bpm-fp-modal-cancel' )?.addEventListener( 'click', closeSnippetModal );

	el( 'bpm-fp-snip-modal' )?.addEventListener( 'click', e => {
		if ( e.target === el( 'bpm-fp-snip-modal' ) ) closeSnippetModal();
	} );

	el( 'bpm-fp-modal-save' )?.addEventListener( 'click', async () => {
		const id    = el( 'bpm-fp-modal-snip-id' ).value;
		const key   = el( 'bpm-fp-modal-snip-key' ).value.trim();
		const label = el( 'bpm-fp-modal-snip-label' ).value.trim();

		if ( ! label ) { showMsg( 'Label is required.', 'error' ); return; }
		if ( ! id && ! key ) { showMsg( 'Key is required for new snippets.', 'error' ); return; }

		// FIXING THE PAYLOAD KEYS TO MATCH THE REST API SCHEMA:
		const payload = {
			label:             label,
			direction:         el( 'bpm-fp-modal-snip-dir' ).value,
			hook_stage:        el( 'bpm-fp-modal-snip-stage' ).value,
			logic_description: el( 'bpm-fp-modal-snip-desc' ).value, // matched to 'logic_description'
			js_body:           el( 'bpm-fp-modal-snip-js' ).value,   // matched to 'js_body'
			php_body:          el( 'bpm-fp-modal-snip-php' ).value,  // matched to 'php_body'
		};
		if ( ! id ) payload.snippet_key = key;

		const saveBtn = el( 'bpm-fp-modal-save' );
		saveBtn.disabled = true;

		try {
			if ( id ) {
				await apiPut( 'user/snippets/' + id, payload );
				showMsg( 'Snippet updated.', 'success' );
			} else {
				await apiPost( 'user/snippets', payload );
				showMsg( 'Snippet added.', 'success' );
			}
			closeSnippetModal();
			loadSnippets();
		} catch ( e ) {
			showMsg( 'Save failed: ' + e.message, 'error' );
		} finally {
			saveBtn.disabled = false;
		}
	} );

	// ── ──────────────────────────────────────────────────────────────────── ──
	// LEXICON TAB
	// ── ──────────────────────────────────────────────────────────────────── ──

	function currentLexDir() {
		return el( 'bpm-fp-lex-dir' )?.value || 'forward';
	}

	function renderLexiconRow( entry ) {
		const tr      = document.createElement( 'tr' );
		tr.dataset.id = entry.id;

		const from = entry.lex_from ?? '';
		const to   = entry.lex_to   ?? '';

		tr.innerHTML =
			'<td><code>' + esc( from ) + '</code></td>' +
			'<td class="bpm-fp-bpm-script">' + esc( to ) + '</td>' +
			'<td class="bpm-fp-actions">' +
				'<button class="bpm-fp-btn-icon bpm-fp-lex-edit" data-id="' + esc( entry.id ) + '" title="Edit">✏️</button>' +
				'<button class="bpm-fp-btn-icon bpm-fp-lex-delete" data-id="' + esc( entry.id ) + '" title="Delete">🗑️</button>' +
			'</td>';

		return tr;
	}

	async function loadLexicon() {
		const btn   = el( 'bpm-fp-btn-load-lexicon' );
		const tbody = el( 'bpm-fp-lex-tbody' );
		if ( ! tbody ) return;
		if ( btn ) btn.disabled = true;

		const dir    = currentLexDir();
		const search = ( el( 'bpm-fp-lex-search' )?.value || '' ).toLowerCase();

		let path = 'user/lexicon?direction=' + encodeURIComponent( dir );
		if ( search ) path += '&search=' + encodeURIComponent( search );

		try {
			const data    = await apiGet( path );
			const entries = data.entries || ( Array.isArray( data ) ? data : [] );

			tbody.innerHTML = '';

			if ( ! entries.length ) {
				tbody.innerHTML = '<tr><td colspan="3" class="bpm-fp-placeholder">No entries yet. Use "Load Defaults" to seed from the main lexicon.</td></tr>';
				return;
			}

			const frag = document.createDocumentFragment();
			entries.forEach( e => frag.appendChild( renderLexiconRow( e ) ) );
			tbody.appendChild( frag );
			attachLexiconHandlers( tbody );

			if ( DEBUG ) console.log( '[CPLAI FrontendPanel] Lexicon loaded:', entries.length, 'entries' );
		} catch ( err ) {
			tbody.innerHTML = '<tr><td colspan="3" class="bpm-fp-placeholder">Failed to load lexicon.</td></tr>';
			showMsg( 'Failed to load lexicon: ' + err.message, 'error' );
			if ( DEBUG ) console.error( '[CPLAI FrontendPanel] Lexicon error:', err );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}

	function attachLexiconHandlers( tbody ) {
		// Edit button.
		tbody.querySelectorAll( '.bpm-fp-lex-edit' ).forEach( btn => {
			btn.addEventListener( 'click', async () => {
				const id  = btn.dataset.id;
				const dir = currentLexDir();
				try {
					const res = await apiGet( 'user/lexicon/' + id + '?direction=' + encodeURIComponent( dir ) );
					openLexModal( res.entry ?? res, dir );
				} catch ( e ) {
					showMsg( 'Could not load entry: ' + e.message, 'error' );
				}
			} );
		} );

		// Delete button.
		tbody.querySelectorAll( '.bpm-fp-lex-delete' ).forEach( btn => {
			btn.addEventListener( 'click', async () => {
				const id  = btn.dataset.id;
				const dir = currentLexDir();
				if ( ! confirm( 'Delete this lexicon entry?' ) ) return;
				btn.disabled = true;
				try {
					await apiDelete( 'user/lexicon/' + id + '?direction=' + encodeURIComponent( dir ) );
					btn.closest( 'tr' )?.remove();
					showMsg( 'Entry deleted.', 'success' );
				} catch ( e ) {
					showMsg( 'Delete failed: ' + e.message, 'error' );
					btn.disabled = false;
				}
			} );
		} );
	}

	// Load button.
	const btnLoadLexicon = el( 'bpm-fp-btn-load-lexicon' );
	if ( btnLoadLexicon ) {
		btnLoadLexicon.addEventListener( 'click', () => loadLexicon() );
	}

	// Direction change re-loads.
	el( 'bpm-fp-lex-dir' )?.addEventListener( 'change', () => {
		if ( tabLoaded.lexicon ) loadLexicon();
	} );

	// Live search filter (re-fetch with server-side filter).
	let lexSearchTimer;
	el( 'bpm-fp-lex-search' )?.addEventListener( 'input', () => {
		clearTimeout( lexSearchTimer );
		lexSearchTimer = setTimeout( () => { if ( tabLoaded.lexicon ) loadLexicon(); }, 300 );
	} );

	// Add Entry button.
	const btnAddLex = el( 'bpm-fp-btn-add-lex' );
	if ( btnAddLex ) {
		btnAddLex.addEventListener( 'click', () => openLexModal( null, currentLexDir() ) );
	}

	// Seed lexicon defaults.
	const btnSeedLexicon = el( 'bpm-fp-btn-seed-lexicon' );
	if ( btnSeedLexicon ) {
		btnSeedLexicon.addEventListener( 'click', async () => {
			const dir = currentLexDir();
			if ( ! confirm( 'Load default ' + dir + ' lexicon entries into your workspace? Existing entries will be skipped.' ) ) return;
			btnSeedLexicon.disabled = true;
			try {
				const res = await apiPost( 'user/lexicon/seed', { direction: dir } );
				showMsg(
					'Seeded: ' + ( res.seeded ?? 0 ) + ' added, ' + ( res.skipped ?? 0 ) + ' skipped.',
					'success'
				);
				loadLexicon();
			} catch ( e ) {
				showMsg( 'Seeding failed: ' + e.message, 'error' );
			} finally {
				btnSeedLexicon.disabled = false;
			}
		} );
	}

	// ── Lexicon modal ─────────────────────────────────────────────────────────

	function openLexModal( entry, dir ) {
		const modal = el( 'bpm-fp-lex-modal' );
		if ( ! modal ) return;

		const isForward = dir !== 'reverse';
		const fromLabel = isForward ? 'Roman (from)' : 'BPM (from)';
		const toLabel   = isForward ? 'BPM (to)'     : 'Roman (to)';

		el( 'bpm-fp-lex-modal-title' ).textContent = entry ? 'Edit Entry' : 'Add Entry';

		const fromEl = el( 'bpm-fp-lex-modal-from' );
		const toEl   = el( 'bpm-fp-lex-modal-to' );

		// Update labels dynamically.
		const fromLabel$ = fromEl?.previousElementSibling;
		const toLabel$   = toEl?.previousElementSibling;
		if ( fromLabel$ ) fromLabel$.textContent = fromLabel;
		if ( toLabel$ )   toLabel$.textContent   = toLabel;

		el( 'bpm-fp-lex-modal-id' ).value   = entry ? entry.id : '';
		fromEl.value = entry ? ( entry.lex_from ?? '' ) : '';
		toEl.value   = entry ? ( entry.lex_to   ?? '' ) : '';

		// Store current direction for save.
		modal.dataset.dir = dir;

		modal.style.display = 'flex';
		fromEl.focus();
	}

	function closeLexModal() {
		const modal = el( 'bpm-fp-lex-modal' );
		if ( modal ) modal.style.display = 'none';
	}

	el( 'bpm-fp-lex-modal-close' )?.addEventListener( 'click', closeLexModal );
	el( 'bpm-fp-lex-modal-cancel' )?.addEventListener( 'click', closeLexModal );

	el( 'bpm-fp-lex-modal' )?.addEventListener( 'click', e => {
		if ( e.target === el( 'bpm-fp-lex-modal' ) ) closeLexModal();
	} );

	el( 'bpm-fp-lex-modal-save' )?.addEventListener( 'click', async () => {
		const id   = el( 'bpm-fp-lex-modal-id' ).value;
		const from = el( 'bpm-fp-lex-modal-from' ).value.trim();
		const to   = el( 'bpm-fp-lex-modal-to' ).value.trim();
		const dir  = el( 'bpm-fp-lex-modal' ).dataset.dir || 'forward';

		if ( ! from || ! to ) {
			showMsg( 'Both fields are required.', 'error' );
			return;
		}

		const payload   = {
			direction: dir,
			lex_from:  from,
			lex_to:    to,
		};

		const saveBtn = el( 'bpm-fp-lex-modal-save' );
		saveBtn.disabled = true;

		try {
			if ( id ) {
				await apiPut( 'user/lexicon/' + id, payload );
				showMsg( 'Entry updated.', 'success' );
			} else {
				await apiPost( 'user/lexicon', payload );
				showMsg( 'Entry added.', 'success' );
			}
			closeLexModal();
			loadLexicon();
		} catch ( e ) {
			showMsg( 'Save failed: ' + e.message, 'error' );
		} finally {
			saveBtn.disabled = false;
		}
	} );

	// ── Keyboard: close modals on Escape ─────────────────────────────────────

	document.addEventListener( 'keydown', e => {
		if ( e.key !== 'Escape' ) return;
		closeSnippetModal();
		closeLexModal();
	} );

} )();
