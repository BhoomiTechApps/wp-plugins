/**
 * CompLing AI — BPM Fixed Transliteration Engine
 *
 * Version:   4.0.0-beta
 * Package:   CompilingAI
 * Author:    BhoomiTech Heritage and Development Foundation
 * License:   GPL-2.0-or-later
 *
 * This is the FIXED engine. It is never AI-generated.
 * AI only generates snippet hook functions (js_body) which plug into the
 * pre / loop / post hook slots defined here.
 *
 * Hook contract (state object):
 *   state.input    {string}  — full original input string
 *   state.output   {string}  — accumulated output
 *   state.pos      {number}  — current position in input (loop stage)
 *   state.prev     {object}  — { token, was_consonant, was_matra } — previous token metadata
 *   state.log      {Array}   — push strings to append log entries
 *   state.handled  {boolean} — set true in a loop hook to claim the token
 *                              and block the default match for this position
 *
 * config object passed to every hook:
 *   config.maps           — { forward: {...}, reverse: {...} } active maps
 *   config.virama         — virama character (U+09CD)
 *   config.inherent_vowel — inherent vowel roman token ('o')
 *   config.direction      — 'forward' | 'reverse'
 *   config.consonants_set — Set of consonant keys for active direction
 *   config.matras_set     — Set of matra keys for active direction
 */

/* global CPLAI_ENGINE */
( function ( window ) {
	'use strict';

	// ── Constants ─────────────────────────────────────────────────────────────
	const VIRAMA         = '\u09CD'; // ্
	const INHERENT_VOWEL = 'o';
	const SECTION_ORDER  = [ 'special', 'consonants', 'matras', 'independent_vowels', 'digits', 'punctuation' ];

	// ── Map helpers ───────────────────────────────────────────────────────────

	/**
	 * Detect whether a map section is v2 (ordered pairs) or v1 (plain object).
	 *
	 * @param {*} raw
	 * @return {boolean}
	 */
	function isPairsArray( raw ) {
		return Array.isArray( raw ) && raw.length > 0 && Array.isArray( raw[ 0 ] );
	}

	/**
	 * Flatten all sections of a directional map into a single lookup array,
	 * sorted longest-key-first, then by original array order within same length.
	 *
	 * @param {Object} map
	 * @return {Array<[string, string]>}  [ [from, to], … ]
	 */
	function flattenMap( map ) {
		const items = [];
		let pos = 0;

		for ( const section of SECTION_ORDER ) {
			const raw = map[ section ];
			if ( ! raw ) continue;

			if ( isPairsArray( raw ) ) {
				for ( const pair of raw ) {
					if ( Array.isArray( pair ) && pair[ 0 ] !== '_meta' ) {
						items.push( { from: String( pair[ 0 ] ), to: String( pair[ 1 ] ), pos: pos++ } );
					}
				}
			} else {
				for ( const [ k, v ] of Object.entries( raw ) ) {
					if ( k !== '_meta' ) {
						items.push( { from: String( k ), to: String( v ), pos: pos++ } );
					}
				}
			}
		}

		items.sort( ( a, b ) => {
			const lenDiff = b.from.length - a.from.length;
			return lenDiff !== 0 ? lenDiff : a.pos - b.pos;
		} );

		// Deduplicate (first occurrence wins after sort).
		const seen   = new Set();
		const result = [];
		for ( const item of items ) {
			if ( ! seen.has( item.from ) ) {
				seen.add( item.from );
				result.push( [ item.from, item.to ] );
			}
		}
		return result;
	}

	/**
	 * Build a Set of keys from a single map section.
	 *
	 * @param {Object} map
	 * @param {string} section
	 * @return {Set<string>}
	 */
	function sectionKeySet( map, section ) {
		const raw  = map[ section ];
		const keys = new Set();
		if ( ! raw ) return keys;

		if ( isPairsArray( raw ) ) {
			for ( const pair of raw ) {
				if ( Array.isArray( pair ) && pair[ 0 ] !== '_meta' ) keys.add( String( pair[ 0 ] ) );
			}
		} else {
			for ( const k of Object.keys( raw ) ) {
				if ( k !== '_meta' ) keys.add( k );
			}
		}
		return keys;
	}

	// ── State factory ─────────────────────────────────────────────────────────

	/**
	 * Create a fresh engine state object.
	 *
	 * @param {string} input
	 * @return {Object}
	 */
	function makeState( input ) {
		return {
			input:   input,
			output:  '',
			pos:     0,
			prev:    { token: '', was_consonant: false, was_matra: false },
			log:     [],
			handled: false,
		};
	}

	// ── Core forward loop ─────────────────────────────────────────────────────

	/**
	 * Forward transliteration core loop.
	 * Calls loop hooks at every position; default longest-match runs only if
	 * no hook sets state.handled = true.
	 *
	 * @param {Object}   state
	 * @param {Object}   config
	 * @param {Array}    lookup        — flattenMap output
	 * @param {Function[]} loopHooks
	 * @return {Object}  state
	 */
	function forwardLoop( state, config, lookup, loopHooks ) {
		const len = state.input.length;

		while ( state.pos < len ) {
			state.handled = false;

			// ── Loop hooks (snippets with upper hand) ─────────────────────────
			for ( const fn of loopHooks ) {
				try {
					state = fn( state, config );
				} catch ( e ) {
					state.log.push( '[SNIPPET ERROR] ' + fn.name + ': ' + e.message );
				}
				if ( state.handled ) break;
			}

			if ( state.handled ) {
				state.handled = false;
				continue;
			}

			// ── Default longest-match ─────────────────────────────────────────
			let matched = false;

			for ( const [ roman, bpm ] of lookup ) {
				const chunk = state.input.substr( state.pos, roman.length );
				if ( chunk !== roman ) continue;

				const isConsonant = config.consonants_set.has( roman );
				const isMatra     = config.matras_set.has( roman );

				if ( state.prev.was_consonant && isConsonant ) {
					state.output += config.virama;
					state.log.push( '[VIRAMA] before \'' + roman + '\'' );
				}

				state.output      += bpm;
				state.log.push( '[MATCH] \'' + roman + '\' → \'' + bpm + '\' (pos ' + state.pos + ')' );
				state.pos         += roman.length;
				state.prev         = { token: roman, was_consonant: isConsonant && ! isMatra, was_matra: isMatra };
				matched            = true;
				break;
			}

			if ( ! matched ) {
				const ch       = state.input[ state.pos ];
				state.output  += ch;
				state.log.push( '[PASS] \'' + ch + '\' (pos ' + state.pos + ')' );
				state.pos++;
				state.prev = { token: ch, was_consonant: false, was_matra: false };
			}
		}

		return state;
	}

	// ── Core reverse loop ─────────────────────────────────────────────────────

	/**
	 * Reverse transliteration core loop.
	 *
	 * @param {Object}   state
	 * @param {Object}   config
	 * @param {Array}    lookup
	 * @param {Function[]} loopHooks
	 * @return {Object}  state
	 */
	function reverseLoop( state, config, lookup, loopHooks ) {
		// Split input into Unicode-safe character array.
		const chars = [ ...state.input ];
		const total = chars.length;
		state.pos   = 0;

		while ( state.pos < total ) {
			state.handled = false;

			// ── Loop hooks ────────────────────────────────────────────────────
			for ( const fn of loopHooks ) {
				try {
					state = fn( state, config );
				} catch ( e ) {
					state.log.push( '[SNIPPET ERROR] ' + fn.name + ': ' + e.message );
				}
				if ( state.handled ) break;
			}

			if ( state.handled ) {
				state.handled = false;
				continue;
			}

			// ── Default longest-match ─────────────────────────────────────────
			let matched = false;

			for ( const [ bpm, roman ] of lookup ) {
				const slice = chars.slice( state.pos, state.pos + bpm.length ).join( '' );
				if ( slice !== bpm ) continue;

				const isConsonant = config.consonants_set.has( bpm );
				state.output     += roman;

				if ( isConsonant ) {
					const nextChar    = chars[ state.pos + bpm.length ] ?? '';
					const isMatra     = config.matras_set.has( nextChar );
					const isVirama    = nextChar === config.virama;
					if ( ! isMatra && ! isVirama ) {
						state.output += config.inherent_vowel;
						state.log.push( '[INHERENT] after \'' + bpm + '\'' );
					}
				}

				state.log.push( '[MATCH] \'' + bpm + '\' → \'' + roman + '\' (pos ' + state.pos + ')' );
				state.pos        += bpm.length;
				state.prev        = { token: bpm, was_consonant: isConsonant, was_matra: config.matras_set.has( bpm ) };
				matched           = true;
				break;
			}

			if ( ! matched ) {
				state.output += chars[ state.pos ];
				state.log.push( '[PASS] \'' + chars[ state.pos ] + '\' (pos ' + state.pos + ')' );
				state.pos++;
				state.prev = { token: chars[ state.pos - 1 ] || '', was_consonant: false, was_matra: false };
			}
		}

		return state;
	}

	// ── Public engine entry point ─────────────────────────────────────────────

	/**
	 * Run the full transliteration pipeline for a single direction.
	 *
	 * @param {string}     input
	 * @param {string}     direction   'forward' | 'reverse'
	 * @param {Object}     maps        { forward: {…}, reverse: {…} }
	 * @param {Function[]} preHooks    — snippet functions for pre stage
	 * @param {Function[]} loopHooks   — snippet functions for loop stage
	 * @param {Function[]} postHooks   — snippet functions for post stage
	 * @return {{ output: string, log: string[] }}
	 */
	function bpmTransliterate( input, direction, maps, preHooks, loopHooks, postHooks ) {
		preHooks  = Array.isArray( preHooks )  ? preHooks  : [];
		loopHooks = Array.isArray( loopHooks ) ? loopHooks : [];
		postHooks = Array.isArray( postHooks ) ? postHooks : [];

		const activeMap      = direction === 'forward' ? maps.forward : maps.reverse;
		const lookup         = flattenMap( activeMap );
		const consonants_set = sectionKeySet( activeMap, 'consonants' );
		const matras_set     = sectionKeySet( activeMap, 'matras' );

		const config = {
			maps,
			virama:         VIRAMA,
			inherent_vowel: INHERENT_VOWEL,
			direction,
			consonants_set,
			matras_set,
		};

		let state = makeState( input );

		// NFC normalise for reverse direction (defensive).
		if ( direction === 'reverse' && typeof input === 'string' ) {
			state.input = input.normalize( 'NFC' );
		}

		// ── Pre hooks ─────────────────────────────────────────────────────────
		for ( const fn of preHooks ) {
			try {
				state = fn( state, config );
			} catch ( e ) {
				state.log.push( '[SNIPPET ERROR pre] ' + fn.name + ': ' + e.message );
			}
		}

		// ── Main loop ─────────────────────────────────────────────────────────
		state = direction === 'forward'
			? forwardLoop( state, config, lookup, loopHooks )
			: reverseLoop( state, config, lookup, loopHooks );

		// ── Post hooks ────────────────────────────────────────────────────────
		for ( const fn of postHooks ) {
			try {
				state = fn( state, config );
			} catch ( e ) {
				state.log.push( '[SNIPPET ERROR post] ' + fn.name + ': ' + e.message );
			}
		}

		return { output: state.output, log: state.log };
	}

	// ── Expose via global namespace ───────────────────────────────────────────
	window.CPLAI_ENGINE = {
		bpmTransliterate,
		flattenMap,
		sectionKeySet,
		makeState,
		VIRAMA,
		INHERENT_VOWEL,
	};

} )( window );