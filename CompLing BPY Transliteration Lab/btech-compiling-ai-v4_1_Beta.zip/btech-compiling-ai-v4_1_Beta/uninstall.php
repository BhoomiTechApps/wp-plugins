<?php
/**
 * Uninstall handler — runs automatically when the plugin is deleted from WP admin.
 *
 * Removes all custom DB tables and plugin options created by CompLing AI.
 * The legacy cplai_injected_code table (v2/v3) is also cleaned up here in case
 * a user deletes without having activated v4 (which drops it on activate).
 *
 * @package CompilingAI
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// ── Drop all plugin tables ────────────────────────────────────────────────────

$tables = array(
	$wpdb->prefix . 'cplai_maps',
	$wpdb->prefix . 'cplai_sessions',
	$wpdb->prefix . 'cplai_snippets',
	$wpdb->prefix . 'cplai_injected_code', // legacy v2/v3 — safe to include.
);

foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" );
}

// ── Remove all plugin options ─────────────────────────────────────────────────

$options = array(
	'cplai_db_version',
	'cplai_anthropic_key',
	'cplai_gemini_key',
	'cplai_openai_key',
	'cplai_grok_key',
	'cplai_model',
	'cplai_ai_provider',
);

foreach ( $options as $opt ) {
	delete_option( $opt );
}

// ── Multisite: clean per-site data ────────────────────────────────────────────

if ( is_multisite() ) {
	$sites = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	foreach ( $sites as $site_id ) {
		switch_to_blog( $site_id );
		foreach ( $options as $opt ) {
			delete_option( $opt );
		}
		restore_current_blog();
	}
}
