<?php
/**
 * PHP-side rule-based transliteration engine.
 *
 * v4.2 changes:
 *  - Pre/post snippet hooks wired via DB (is_active snippets with php_body).
 *  - Loop-stage snippet hooks now fully supported: run_php_snippet_hooks() is
 *    invoked inside the while loop at every position, receiving $state and
 *    $config. Loop-stage php_body payloads are fetched and executed identically
 *    to pre/post stages.
 *  - Bare local loop variables ($pos, $output, $prev_was_consonant) replaced
 *    with a proper $state array matching the JS engine's state contract.
 *  - $state['handled'] flag allows loop-stage snippet hooks to mark a position
 *    as fully consumed, bypassing the core map lookup for that position.
 *  - apply_processing_rules() extended: loop-stage rules may carry optional
 *    context keys (context_output_ends_with, context_next_token_in) evaluated
 *    against the live $state. Pre/post rules continue to work exactly as before.
 *  - virama and inherent_vowel are hardcoded constants.
 *
 * Map section format support:
 *   v2 (preferred): ordered array of [from, to] pairs → [["k","ক"],["kh","খ"],…]
 *   v1 (legacy):    plain associative object           → {"k":"ক","kh":"খ",…}
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PHP transliteration engine with pre/loop/post hook support.
 */
class CPLAI_Engine {

	// ── Map storage ───────────────────────────────────────────────────────────

	/** @var array<string,mixed> */
	private array $forward_map = array();

	/** @var array<string,mixed> */
	private array $reverse_map = array();

	// ── Engine constants ──────────────────────────────────────────────────────

	/** Bengali virama U+09CD. */
	private string $virama = '্';

	/** Inherent vowel Roman token for reverse direction. */
	private string $inherent_vowel = 'o';

	// ── Constructor ───────────────────────────────────────────────────────────

	public function __construct() {
		$this->load_active_maps();
	}

	// ── Map loader ────────────────────────────────────────────────────────────

	private function load_active_maps(): void {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT map_type, json_data FROM `{$table}` WHERE is_active = 1" );

		foreach ( $rows as $row ) {
			$data = json_decode( $row->json_data, true );
			switch ( $row->map_type ) {
				case 'forward':
					$this->forward_map = $data;
					break;
				case 'reverse':
					$this->reverse_map = $data;
					break;
			}
		}

		// File-based fallbacks if DB rows are missing.
		$fallbacks = array(
			'forward_map' => 'forwardMap.json',
			'reverse_map' => 'reverseMap.json',
		);
		foreach ( $fallbacks as $prop => $file ) {
			if ( empty( $this->$prop ) ) {
				$path = CPLAI_DATA_DIR . $file;
				if ( file_exists( $path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$this->$prop = json_decode( file_get_contents( $path ), true ) ?? array();
				}
			}
		}
	}

	// ── Snippet hook loader ───────────────────────────────────────────────────

	/**
	 * Fetch active PHP snippets for a given direction and hook stage.
	 * Returns an array of php_body strings (JSON rule arrays).
	 *
	 * Supports all three hook stages: 'pre', 'loop', and 'post'.
	 *
	 * @param string $direction  'forward'|'reverse'
	 * @param string $hook_stage 'pre'|'loop'|'post'
	 * @return array<int,string>
	 */
	private function get_php_snippets( string $direction, string $hook_stage ): array {
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT php_body FROM `{$table}`
				 WHERE is_active = 1
				   AND hook_stage = %s
				   AND ( direction = %s OR direction = 'both' )
				   AND php_body IS NOT NULL
				   AND php_body != ''
				 ORDER BY sort_order ASC, id ASC",
				$hook_stage,
				$direction
			)
		);

		return array_column( (array) $rows, 'php_body' );
	}

	/**
	 * Run pre/post snippet hooks: apply JSON rule arrays against a plain string.
	 *
	 * @param string   $text
	 * @param string   $direction
	 * @param string   $hook_stage 'pre'|'post'
	 * @param string[] &$log
	 * @return string
	 */
	private function run_php_snippet_hooks( string $text, string $direction, string $hook_stage, array &$log ): string {
		$snippets = $this->get_php_snippets( $direction, $hook_stage );
		foreach ( $snippets as $php_body ) {
			$decoded = json_decode( $php_body, true );
			if ( is_array( $decoded ) ) {
				$text = $this->apply_processing_rules( $text, $decoded, $log );
			}
			// Non-JSON php_body values are reserved for future use.
		}
		return $text;
	}

	/**
	 * Run loop-stage snippet hooks at a single input position.
	 *
	 * Each active loop-stage php_body is a JSON-encoded array of context-aware
	 * rules. Rules are evaluated against the live $state (output so far, current
	 * position, remaining input) and may set $state['handled'] = true to signal
	 * that the current position has been fully consumed by the rule.
	 *
	 * @param array    &$state   Mutable engine state (see forward()/reverse() for contract).
	 * @param array     $config  Read-only engine config (maps, virama, …).
	 * @param string    $direction
	 * @param string[] &$log
	 */
	private function run_loop_snippet_hooks( array &$state, array $config, string $direction, array &$log ): void {
		$snippets = $this->get_php_snippets( $direction, 'loop' );
		foreach ( $snippets as $php_body ) {
			$decoded = json_decode( $php_body, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			$this->apply_loop_rules( $state, $decoded, $config, $log );
		}
	}

	// ── Public: transliterate ─────────────────────────────────────────────────

	/**
	 * Entry point. Returns [ 'output' => string, 'log' => string[] ].
	 *
	 * @param string $input
	 * @param string $direction 'forward'|'reverse'
	 * @return array{output:string,log:string[]}
	 */
	public function transliterate( string $input, string $direction ): array {
		$log    = array();
		$output = '';

		if ( 'forward' === $direction ) {
			list( $output, $log ) = $this->forward( $input );
		} elseif ( 'reverse' === $direction ) {
			list( $output, $log ) = $this->reverse( $input );
		} else {
			$log[] = "[ERROR] Unknown direction: {$direction}";
		}

		return array( 'output' => $output, 'log' => $log );
	}

	// ── Pre/post processing rule runner ───────────────────────────────────────

	/**
	 * Apply an array of find-replace processing rules to a plain string.
	 *
	 * Pre/post stage rule schema:
	 *   { "type": "replace", "from": "pattern", "to": "replacement", "regex": false }
	 *
	 * Loop-stage rules additionally support optional context keys (evaluated by
	 * apply_loop_rules() against live $state). This method handles only the
	 * string-level operation; context evaluation lives in apply_loop_rules().
	 *
	 * @param string   $text
	 * @param array    $rules
	 * @param string[] &$log
	 * @return string
	 */
	public function apply_processing_rules( string $text, array $rules, array &$log = array() ): string {
		if ( empty( $rules ) ) {
			return $text;
		}

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}
			$type  = $rule['type']  ?? 'replace';
			$from  = $rule['from']  ?? '';
			$to    = $rule['to']    ?? '';
			$regex = ! empty( $rule['regex'] );

			if ( '' === $from ) {
				continue;
			}

			if ( 'replace' === $type ) {
				if ( $regex ) {
					$result = @preg_replace( $from, $to, $text ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					if ( null !== $result ) {
						if ( $result !== $text ) {
							$log[] = "[PRE/POST RULE] regex replace '{$from}' → '{$to}'";
						}
						$text = $result;
					}
				} else {
					if ( str_contains( $text, $from ) ) {
						$log[] = "[PRE/POST RULE] replace '{$from}' → '{$to}'";
						$text  = str_replace( $from, $to, $text );
					}
				}
			}
		}

		return $text;
	}

	/**
	 * Apply loop-stage rules against the live engine state at the current position.
	 *
	 * Loop-stage rules use the same base schema as pre/post rules, extended with
	 * optional context conditions that are evaluated against $state before
	 * applying the replacement. All context keys are optional; omitting them
	 * produces unconditional matching (equivalent to a pre/post rule).
	 *
	 * Extended loop-stage rule schema:
	 * {
	 *   "type":                     "replace",
	 *   "from":                     "<literal or regex>",
	 *   "to":                       "<replacement>",
	 *   "regex":                    false,
	 *
	 *   // Optional context conditions (all must pass when present):
	 *   "context_output_ends_with": "<string>",   // $state['output'] ends with this value
	 *   "context_next_token_in":    "<section>",  // next input token exists in the named map section
	 *   "context_prev_was_consonant": true|false  // $state['prev_was_consonant'] must match
	 * }
	 *
	 * When a rule's context conditions are satisfied, $state['output'] is
	 * modified by replacing the 'from' string/pattern in a context-aware manner:
	 *
	 *  - If 'from' matches the tail of $state['output'], the match is removed
	 *    from the tail of output and 'to' is appended instead — enabling
	 *    retroactive corrections of the most recently emitted token.
	 *  - Otherwise the rule applies as a plain str_replace / preg_replace on
	 *    $state['output'] (whole-output transformation).
	 *
	 * A matched loop rule sets $state['handled'] = true so the calling loop
	 * knows not to advance past the current position via the core lookup.
	 *
	 * @param array    &$state   Mutable engine state.
	 * @param array     $rules   Decoded JSON rule array.
	 * @param array     $config  Engine config (maps, virama, …).
	 * @param string[] &$log
	 */
	private function apply_loop_rules( array &$state, array $rules, array $config, array &$log ): void {
		if ( empty( $rules ) ) {
			return;
		}

		$map       = $config['map']       ?? array();
		$direction = $config['direction'] ?? 'forward';

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}

			$type  = $rule['type']  ?? 'replace';
			$from  = $rule['from']  ?? '';
			$to    = $rule['to']    ?? '';
			$regex = ! empty( $rule['regex'] );

			if ( '' === $from || 'replace' !== $type ) {
				continue;
			}

			// ── Evaluate optional context conditions ──────────────────────────

			// context_output_ends_with: $state['output'] must end with this string.
			if ( isset( $rule['context_output_ends_with'] ) ) {
				if ( ! str_ends_with( $state['output'], (string) $rule['context_output_ends_with'] ) ) {
					continue;
				}
			}

			// context_next_token_in: the next input character(s) must be a key
			// found in the named map section (e.g. 'matras', 'consonants').
			if ( isset( $rule['context_next_token_in'] ) ) {
				$section     = (string) $rule['context_next_token_in'];
				$remaining   = mb_substr( $state['input'], $state['pos'] );
				$section_keys = $this->section_keys( $map, $section );
				$token_found  = false;
				foreach ( $section_keys as $key ) {
					if ( str_starts_with( $remaining, $key ) ) {
						$token_found = true;
						break;
					}
				}
				if ( ! $token_found ) {
					continue;
				}
			}

			// context_prev_was_consonant: $state['prev_was_consonant'] must match.
			if ( isset( $rule['context_prev_was_consonant'] ) ) {
				$expected = (bool) $rule['context_prev_was_consonant'];
				if ( (bool) $state['prev_was_consonant'] !== $expected ) {
					continue;
				}
			}

			// ── All context conditions passed — apply the rule ────────────────

			$output_before = $state['output'];

			if ( $regex ) {
				// Regex replacement on accumulated output.
				$result = @preg_replace( $from, $to, $state['output'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				if ( null !== $result && $result !== $state['output'] ) {
					$state['output']  = $result;
					$state['handled'] = true;
					$log[] = "[LOOP RULE] regex '{$from}' → '{$to}' (pos {$state['pos']})";
				}
			} else {
				// Literal replacement: prefer tail-of-output substitution when
				// 'from' matches the end of accumulated output (retroactive fix).
				if ( str_ends_with( $state['output'], $from ) ) {
					$state['output']  = mb_substr( $state['output'], 0, mb_strlen( $state['output'] ) - mb_strlen( $from ) ) . $to;
					$state['handled'] = true;
					$log[] = "[LOOP RULE] tail-replace '{$from}' → '{$to}' (pos {$state['pos']})";
				} elseif ( str_contains( $state['output'], $from ) ) {
					$state['output']  = str_replace( $from, $to, $state['output'] );
					$state['handled'] = true;
					$log[] = "[LOOP RULE] replace '{$from}' → '{$to}' (pos {$state['pos']})";
				}
			}
		}
	}

	// ── Forward: Roman → Bengali-Assamese ─────────────────────────────────────

	/**
	 * @param string $input
	 * @return array{string,string[]}  [output, log]
	 */
	private function forward( string $input ): array {
		$log = array();

		// ── Pre-processing hooks ───────────────────────────────────────────────
		$input = $this->run_php_snippet_hooks( $input, 'forward', 'pre', $log );

		$lookup = $this->flatten_map(
			$this->forward_map,
			array( 'special', 'consonants', 'matras', 'independent_vowels', 'digits', 'punctuation' )
		);

		$consonants_set = $this->section_keys( $this->forward_map, 'consonants' );
		$len            = mb_strlen( $input );

		// Engine config passed to loop-stage snippet hooks.
		$config = array(
			'map'            => $this->forward_map,
			'direction'      => 'forward',
			'virama'         => $this->virama,
			'inherent_vowel' => $this->inherent_vowel,
		);

		// $state matches the JS engine's state contract.
		$state = array(
			'input'             => $input,
			'output'            => '',
			'pos'               => 0,
			'prev_was_consonant' => false,
			'prev'              => array(
				'token'        => '',
				'was_consonant' => false,
				'was_matra'    => false,
				'token_length' => 0,
			),
			'handled'           => false,
			'log'               => &$log,
		);

		while ( $state['pos'] < $len ) {

			// Reset per-position handled flag.
			$state['handled'] = false;

			// ── Loop-stage snippet hooks ───────────────────────────────────────
			// Hooks run first; they may set $state['handled'] = true to claim
			// the current position (skipping the core map lookup below).
			$this->run_loop_snippet_hooks( $state, $config, 'forward', $log );

			if ( $state['handled'] ) {
				// The hook already advanced $state['pos'] — nothing more to do.
				continue;
			}

			// ── Core map lookup ───────────────────────────────────────────────
			$matched = false;

			foreach ( $lookup as $roman => $bpm ) {
				$chunk_len = mb_strlen( $roman );
				if ( $state['pos'] + $chunk_len > $len ) {
					continue;
				}
				$chunk = mb_substr( $input, $state['pos'], $chunk_len );

				if ( $chunk === $roman ) {
					$is_consonant = in_array( $roman, $consonants_set, true );
					$is_matra     = $this->section_has_key( $this->forward_map, 'matras', $roman );

					if ( $state['prev_was_consonant'] && $is_consonant ) {
						$state['output'] .= $this->virama;
						$log[]            = "[VIRAMA] before '{$roman}'";
					}

					$state['output'] .= $bpm;
					$log[]            = "[MATCH] '{$roman}' → '{$bpm}' (pos {$state['pos']})";

					$state['prev'] = array(
						'token'        => $roman,
						'was_consonant' => $is_consonant,
						'was_matra'    => $is_matra,
						'token_length' => $chunk_len,
					);

					$state['pos'] += $chunk_len;
					$state['prev_was_consonant'] = $is_consonant && ! $is_matra;

					$matched = true;
					break;
				}
			}

			if ( ! $matched ) {
				$char             = mb_substr( $input, $state['pos'], 1 );
				$state['output'] .= $char;
				$log[]            = "[PASS] '{$char}' (pos {$state['pos']})";
				$state['pos']++;
				$state['prev_was_consonant'] = false;
				$state['prev'] = array(
					'token'        => $char,
					'was_consonant' => false,
					'was_matra'    => false,
					'token_length' => 1,
				);
			}
		}

		$output = $state['output'];

		// ── Post-processing hooks ──────────────────────────────────────────────
		$output = $this->run_php_snippet_hooks( $output, 'forward', 'post', $log );

		return array( $output, $log );
	}

	// ── Reverse: Bengali-Assamese → Roman ─────────────────────────────────────

	/**
	 * @param string $input
	 * @return array{string,string[]}  [output, log]
	 */
	private function reverse( string $input ): array {
		$log = array();

		// NFC normalise.
		if ( function_exists( 'normalizer_normalize' ) ) {
			$input = normalizer_normalize( $input, Normalizer::NFC );
		}

		// ── Pre-processing hooks ───────────────────────────────────────────────
		$input = $this->run_php_snippet_hooks( $input, 'reverse', 'pre', $log );

		$lookup        = $this->flatten_map(
			$this->reverse_map,
			array( 'special', 'consonants', 'matras', 'independent_vowels', 'digits', 'punctuation' )
		);
		$consonant_bpm = $this->section_keys( $this->reverse_map, 'consonants' );
		$virama        = $this->virama;
		$inherent      = $this->inherent_vowel;

		$chars = $this->mb_str_split( $input );
		$total = count( $chars );

		// Engine config passed to loop-stage snippet hooks.
		$config = array(
			'map'            => $this->reverse_map,
			'direction'      => 'reverse',
			'virama'         => $virama,
			'inherent_vowel' => $inherent,
		);

		// $state matches the JS engine's state contract (reverse direction).
		$state = array(
			'input'             => $input,
			'output'            => '',
			'pos'               => 0,
			'prev_was_consonant' => false,
			'prev'              => array(
				'token'        => '',
				'was_consonant' => false,
				'was_matra'    => false,
				'token_length' => 0,
			),
			'handled'           => false,
			'log'               => &$log,
		);

		while ( $state['pos'] < $total ) {

			// Reset per-position handled flag.
			$state['handled'] = false;

			// ── Loop-stage snippet hooks ───────────────────────────────────────
			$this->run_loop_snippet_hooks( $state, $config, 'reverse', $log );

			if ( $state['handled'] ) {
				continue;
			}

			// ── Core map lookup ───────────────────────────────────────────────
			$matched = false;

			foreach ( $lookup as $bpm => $roman ) {
				$bpm_len = mb_strlen( $bpm );
				$slice   = implode( '', array_slice( $chars, $state['pos'], $bpm_len ) );

				if ( $slice === $bpm ) {
					$is_consonant     = in_array( $bpm, $consonant_bpm, true );
					$state['output'] .= $roman;

					if ( $is_consonant ) {
						$next_char      = $chars[ $state['pos'] + $bpm_len ] ?? '';
						$is_next_matra  = $this->section_has_key( $this->reverse_map, 'matras', $next_char );
						$is_next_virama = ( $next_char === $virama );
						if ( ! $is_next_matra && ! $is_next_virama ) {
							$state['output'] .= $inherent;
							$log[]            = "[INHERENT] after '{$bpm}'";
						}
					}

					$log[] = "[MATCH] '{$bpm}' → '{$roman}' (i={$state['pos']})";

					$state['prev'] = array(
						'token'        => $bpm,
						'was_consonant' => $is_consonant,
						'was_matra'    => false,
						'token_length' => $bpm_len,
					);

					$state['pos']               += $bpm_len;
					$state['prev_was_consonant']  = $is_consonant;

					$matched = true;
					break;
				}
			}

			if ( ! $matched ) {
				$state['output'] .= $chars[ $state['pos'] ];
				$log[]            = "[PASS] '{$chars[$state['pos']]}' (i={$state['pos']})";
				$state['prev'] = array(
					'token'        => $chars[ $state['pos'] ],
					'was_consonant' => false,
					'was_matra'    => false,
					'token_length' => 1,
				);
				$state['pos']++;
				$state['prev_was_consonant'] = false;
			}
		}

		$output = $state['output'];

		// ── Post-processing hooks ──────────────────────────────────────────────
		$output = $this->run_php_snippet_hooks( $output, 'reverse', 'post', $log );

		return array( $output, $log );
	}

	// ── Map helpers ───────────────────────────────────────────────────────────

	/**
	 * Flatten map sections into a sorted lookup array (longest-match-first).
	 *
	 * @param array    $map
	 * @param string[] $sections
	 * @return array<string,string>
	 */
	private function flatten_map( array $map, array $sections ): array {
		$items = array();
		$pos   = 0;

		foreach ( $sections as $section ) {
			$raw = $map[ $section ] ?? array();
			if ( ! is_array( $raw ) || empty( $raw ) ) {
				continue;
			}

			if ( $this->is_pairs_array( $raw ) ) {
				foreach ( $raw as $pair ) {
					if ( is_array( $pair ) && isset( $pair[0] ) && '_meta' !== $pair[0] ) {
						$items[] = array( (string) $pair[0], (string) $pair[1], $pos++ );
					}
				}
			} else {
				foreach ( $raw as $k => $v ) {
					if ( '_meta' !== $k ) {
						$items[] = array( (string) $k, (string) $v, $pos++ );
					}
				}
			}
		}

		usort(
			$items,
			function ( $a, $b ) {
				$len_diff = mb_strlen( $b[0] ) - mb_strlen( $a[0] );
				return 0 !== $len_diff ? $len_diff : ( $a[2] - $b[2] );
			}
		);

		$flat = array();
		foreach ( $items as list( $k, $v ) ) {
			if ( ! array_key_exists( $k, $flat ) ) {
				$flat[ $k ] = $v;
			}
		}

		return $flat;
	}

	/**
	 * Return all keys from a map section as a plain array.
	 *
	 * @param array  $map
	 * @param string $section
	 * @return string[]
	 */
	private function section_keys( array $map, string $section ): array {
		$raw  = $map[ $section ] ?? array();
		$keys = array();
		if ( ! is_array( $raw ) ) {
			return $keys;
		}

		if ( $this->is_pairs_array( $raw ) ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0] ) ) {
					$keys[] = (string) $pair[0];
				}
			}
		} else {
			$keys = array_keys( $raw );
		}

		return $keys;
	}

	/**
	 * Check if a key exists in a map section.
	 *
	 * @param array  $map
	 * @param string $section
	 * @param string $key
	 * @return bool
	 */
	private function section_has_key( array $map, string $section, string $key ): bool {
		$raw = $map[ $section ] ?? array();
		if ( ! is_array( $raw ) ) {
			return false;
		}

		if ( $this->is_pairs_array( $raw ) ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0] ) && (string) $pair[0] === $key ) {
					return true;
				}
			}
			return false;
		}

		return array_key_exists( $key, $raw );
	}

	/**
	 * Detect whether an array is a v2 pairs array (list of [from,to] pairs).
	 *
	 * @param array $arr
	 * @return bool
	 */
	private function is_pairs_array( array $arr ): bool {
		if ( ! array_is_list( $arr ) ) {
			return false;
		}
		foreach ( $arr as $item ) {
			if ( null === $item ) {
				continue;
			}
			return is_array( $item ) && array_is_list( $item ) && count( $item ) >= 2;
		}
		return false;
	}

	/**
	 * Split a multibyte string into an array of Unicode characters.
	 *
	 * @param string $str
	 * @return string[]
	 */
	private function mb_str_split( string $str ): array {
		return preg_split( '//u', $str, -1, PREG_SPLIT_NO_EMPTY ) ?: array();
	}
}
