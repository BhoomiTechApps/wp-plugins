<?php
/**
 * WordPress admin integration — menu, page, and asset enqueuing.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the admin menu page and enqueues assets.
 */
class CPLAI_Admin {

	public function __construct() {
		add_action( 'admin_menu',             array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts',  array( $this, 'enqueue_assets' ) );
	}

	// ── Menu ──────────────────────────────────────────────────────────────────

	public function register_menu(): void {
		add_menu_page(
			__( 'BPM Transliteration Lab', 'compiling-ai' ),
			__( 'BPM Lab', 'compiling-ai' ),
			'manage_options',
			'cplai-lab',
			array( $this, 'render_page' ),
			'dashicons-translation',
			30
		);
	}

	// ── Page ──────────────────────────────────────────────────────────────────

	public function render_page(): void {
		require_once CPLAI_DIR . 'admin/page-lab.php';
	}

	// ── Assets ────────────────────────────────────────────────────────────────

	public function enqueue_assets( string $hook ): void {
		if ( 'toplevel_page_cplai-lab' !== $hook ) {
			return;
		}

		// Stylesheet.
		wp_enqueue_style(
			'cplai-admin',
			CPLAI_URL . 'assets/css/admin.css',
			array(),
			CPLAI_VERSION
		);

		// Fixed JS engine — no dependencies, loaded in footer.
		wp_enqueue_script(
			'cplai-engine',
			CPLAI_URL . 'assets/js/engine.js',
			array(),
			CPLAI_VERSION,
			true
		);

		// Admin UI — depends on jQuery and the engine.
		wp_enqueue_script(
			'cplai-admin',
			CPLAI_URL . 'assets/js/admin.js',
			array( 'jquery', 'cplai-engine' ),
			CPLAI_VERSION,
			true
		);

		// Runtime config passed to JS.
		wp_localize_script(
			'cplai-admin',
			'CPLAI',
			array(
				'rest_url' => rest_url( 'cplai/v1/' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'debug'    => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '1' : '0',
				'version'  => CPLAI_VERSION,
			)
		);
	}
}