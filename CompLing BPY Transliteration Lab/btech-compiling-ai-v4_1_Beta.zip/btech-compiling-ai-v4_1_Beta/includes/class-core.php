<?php
/**
 * Plugin core bootstrap — wires all sub-systems together.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central init class. Instantiates admin and registers REST routes.
 */
class CPLAI_Core {

	/**
	 * Boot the plugin. Called on the `plugins_loaded` action.
	 */
	public static function init(): void {
		new CPLAI_Admin();
		add_action( 'rest_api_init', array( 'CPLAI_Rest', 'register_routes' ) );
	}
}
