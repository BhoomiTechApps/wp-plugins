<?php
/**
 * Database installer and upgrader.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Handles table creation, seeding, and migrations.
 */
class CPLAI_Installer {

	// ── Table names ───────────────────────────────────────────────────────────

	public static function table_maps(): string {
		global $wpdb;
		return $wpdb->prefix . 'cplai_maps';
	}

	public static function table_sessions(): string {
		global $wpdb;
		return $wpdb->prefix . 'cplai_sessions';
	}

	public static function table_snippets(): string {
		global $wpdb;
		return $wpdb->prefix . 'cplai_snippets';
	}

	// ── Activate / upgrade ────────────────────────────────────────────────────

	public static function activate(): void {
		global $wpdb;
		$charset = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		// Maps table.
		dbDelta(
			"CREATE TABLE " . self::table_maps() . " (
				id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				map_type    ENUM('forward','reverse') NOT NULL,
				label       VARCHAR(120) NOT NULL,
				source      ENUM('default','user') NOT NULL DEFAULT 'user',
				is_active   TINYINT(1)  NOT NULL DEFAULT 0,
				json_data   LONGTEXT    NOT NULL,
				created_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at  DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY map_type  (map_type),
				KEY is_active (is_active)
			) $charset;"
		);

		// Sessions table (AI snippet generation history).
		dbDelta(
			"CREATE TABLE " . self::table_sessions() . " (
				id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				session_key VARCHAR(60)         NOT NULL UNIQUE,
				direction   ENUM('forward','reverse','both') NOT NULL DEFAULT 'both',
				prompt_text LONGTEXT,
				gen_code    LONGTEXT,
				status      ENUM('generated','saved','error') NOT NULL DEFAULT 'generated',
				created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id)
			) $charset;"
		);

		// Snippets table.
		dbDelta(
			"CREATE TABLE " . self::table_snippets() . " (
				id                BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
				snippet_key       VARCHAR(80)  NOT NULL UNIQUE,
				label             VARCHAR(160) NOT NULL,
				direction         ENUM('forward','reverse','both') NOT NULL DEFAULT 'both',
				hook_stage        ENUM('pre','loop','post')        NOT NULL DEFAULT 'loop',
				logic_description LONGTEXT,
				js_body           LONGTEXT,
				php_body          LONGTEXT,
				sort_order        INT          NOT NULL DEFAULT 0,
				is_active         TINYINT(1)   NOT NULL DEFAULT 0,
				source            ENUM('default','user','ai_generated') NOT NULL DEFAULT 'user',
				created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
				PRIMARY KEY (id),
				KEY direction  (direction),
				KEY hook_stage (hook_stage),
				KEY is_active  (is_active),
				KEY sort_order (sort_order)
			) $charset;"
		);

		self::seed_defaults();
		self::drop_legacy_tables();

		update_option( 'cplai_db_version', CPLAI_VERSION );
	}

	/**
	 * Drop tables from pre-4.0 that are no longer used.
	 * Safe to call repeatedly — checks existence first.
	 */
	private static function drop_legacy_tables(): void {
		global $wpdb;
		// cplai_injected_code was used in v2/v3 to store AI-generated engine blobs.
		// In v4 the engine is fixed; this table is obsolete.
		$legacy = $wpdb->prefix . 'cplai_injected_code';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( "DROP TABLE IF EXISTS `{$legacy}`" ); // nosemgrep: direct-db-query
	}

	// ── Deactivate ────────────────────────────────────────────────────────────

	public static function deactivate(): void {
		// Intentionally left empty — data is preserved on deactivation.
	}

	// ── Seed ──────────────────────────────────────────────────────────────────

	private static function seed_defaults(): void {
		self::seed_default_maps();
		self::seed_default_snippets();
	}

	private static function seed_default_maps(): void {
		global $wpdb;
		$table = self::table_maps();
		$files = array(
			'forward' => 'forwardMap.json',
			'reverse' => 'reverseMap.json',
		);

		foreach ( $files as $type => $filename ) {
			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM `{$table}` WHERE map_type = %s AND source = 'default' LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$type
				)
			);
			if ( $exists ) {
				continue;
			}

			$path = CPLAI_DATA_DIR . $filename;
			if ( ! file_exists( $path ) ) {
				continue;
			}

			$wpdb->insert(
				$table,
				array(
					'map_type'  => $type,
					'label'     => 'Default BPM ' . ucfirst( $type ),
					'source'    => 'default',
					'is_active' => 1,
					'json_data' => file_get_contents( $path ), // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				)
			);
		}
	}

	/**
	 * Seed or update default snippets from data/snippets/defaults.json.
	 * On first insert, is_active is read from the defaults.json entry so that
	 * curated defaults can ship pre-enabled. User toggles are never overwritten
	 * on subsequent syncs.
	 */
	public static function seed_default_snippets(): void {
		global $wpdb;
		$table = self::table_snippets();

		$snippets_file = CPLAI_SNIPPETS_DIR . 'defaults.json';
		if ( ! file_exists( $snippets_file ) ) {
			return;
		}

		$snippets = json_decode( file_get_contents( $snippets_file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( ! is_array( $snippets ) ) {
			return;
		}

		foreach ( $snippets as $s ) {
			if ( empty( $s['snippet_key'] ) ) {
				continue;
			}

			$data = array(
				'label'             => $s['label']             ?? $s['snippet_key'],
				'direction'         => $s['direction']         ?? 'both',
				'hook_stage'        => $s['hook_stage']        ?? 'loop',
				'logic_description' => $s['logic_description'] ?? '',
				'js_body'           => $s['js_body']           ?? '',
				'php_body'          => $s['php_body']          ?? '',
				'sort_order'        => (int) ( $s['sort_order'] ?? 0 ),
				'source'            => 'default',
			);

			$existing_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM `{$table}` WHERE snippet_key = %s LIMIT 1", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
					$s['snippet_key']
				)
			);

			if ( $existing_id ) {
				// Update code/metadata — never touch is_active.
				$wpdb->update( $table, $data, array( 'snippet_key' => $s['snippet_key'] ) );
			} else {
				// New snippet: honour the is_active value from defaults.json.
				// 1 = enabled by default, 0 = off (user must opt in).
				$wpdb->insert(
					$table,
					array_merge(
						$data,
						array(
							'snippet_key' => $s['snippet_key'],
							'is_active'   => isset( $s['is_active'] ) ? (int) $s['is_active'] : 0,
						)
					)
				);
			}
		}
	}
}