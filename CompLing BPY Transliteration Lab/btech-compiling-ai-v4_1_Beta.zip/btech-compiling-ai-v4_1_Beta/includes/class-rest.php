<?php
/**
 * REST API routes for CompLing AI v4.
 *
 * Architecture change from v3:
 *  - ai/generate and ai/inject endpoints are REMOVED. The engine is now fixed.
 *  - AI generates both js_body (named JS function) and php_body (JSON rule array)
 *    via /snippets/generate for all three hook stages: pre, loop, and post.
 *  - /snippets/active  — returns active snippet js_body strings for the JS engine.
 *  - /test/run         — always uses the PHP engine server-side; JS engine runs client-side.
 *  - Loop-stage php_body payloads are fully supported by the PHP engine using a
 *    context-aware rule schema (see build_snippet_php_prompt for full schema docs).
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles all REST API routes.
 */
class CPLAI_Rest {

	// ── Route registration ────────────────────────────────────────────────────

	public static function register_routes(): void {
		$ns = 'cplai/v1';

		// ── Maps ──────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/maps', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_maps' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/upload', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'upload_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/(?P<id>\d+)/activate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'activate_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/(?P<id>\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( __CLASS__, 'delete_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/save-edit', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_edit' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/restore-default', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'restore_default' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Snippets ──────────────────────────────────────────────────────────
		register_rest_route( $ns, '/snippets', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_snippets' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/active', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_active_snippets' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
			'args'                => array(
				'direction' => array(
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => function ( $v ) {
						return in_array( $v, array( 'forward', 'reverse' ), true );
					},
				),
			),
		) );
		register_rest_route( $ns, '/snippets/generate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_generate' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/sync-defaults', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_sync_defaults' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/save', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_save' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)/toggle', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_toggle' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)/reorder', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_reorder' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'snippets_get_one' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'snippets_update' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'snippets_delete' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
		) );

		// ── Test ──────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/test/run', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'test_run' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Status ────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/status', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_status' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Lexicon ───────────────────────────────────────────────────────────
		register_rest_route( $ns, '/lexicon', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_lexicon' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Settings ──────────────────────────────────────────────────────────
		register_rest_route( $ns, '/settings', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_settings' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'save_settings' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
		) );
	}

	// ── Permission check ──────────────────────────────────────────────────────

	public static function check_admin( WP_REST_Request $req ): bool {
		return current_user_can( 'manage_options' );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// MAPS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_maps( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT id, map_type, label, source, is_active, created_at FROM `{$table}` ORDER BY map_type, source, created_at DESC" );
		return rest_ensure_response( array( 'success' => true, 'maps' => $rows, 'debug' => self::db_debug() ) );
	}

	public static function upload_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		$label    = sanitize_text_field( (string) $req->get_param( 'label' ) );
		$json_raw = $req->get_param( 'json_data' );

		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}
		$decoded = json_decode( $json_raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return self::error( 'invalid_json', 'JSON parse error: ' . json_last_error_msg(), 400 );
		}

		$table  = CPLAI_Installer::table_maps();
		$result = $wpdb->insert( $table, array(
			'map_type'  => $map_type,
			'label'     => $label ?: 'Custom ' . $map_type . ' ' . gmdate( 'Y-m-d H:i' ),
			'source'    => 'user',
			'is_active' => 0,
			'json_data' => wp_json_encode( $decoded ),
		) );

		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true, 'id' => $wpdb->insert_id ) );
	}

	public static function activate_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Map not found', 404 );
		}
		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $row->map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'activated_id' => $id, 'map_type' => $row->map_type ) );
	}

	public static function delete_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Map not found', 404 );
		}
		if ( 'default' === $row->source ) {
			return self::error( 'protected', 'Default maps cannot be deleted', 403 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', 'Delete failed: ' . $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	public static function save_edit( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		$json_raw = $req->get_param( 'json_data' );

		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}
		$decoded = json_decode( $json_raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return self::error( 'invalid_json', 'JSON parse error: ' . json_last_error_msg(), 400 );
		}

		$table    = CPLAI_Installer::table_maps();
		$label    = 'Edited ' . $map_type . ' – ' . gmdate( 'Y-m-d H:i' );
		$inserted = $wpdb->insert( $table, array(
			'map_type'  => $map_type,
			'label'     => $label,
			'source'    => 'user',
			'is_active' => 0,
			'json_data' => wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE ),
		) );
		if ( false === $inserted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		$new_id = $wpdb->insert_id;
		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $new_id ) );

		return rest_ensure_response( array( 'success' => true, 'id' => $new_id, 'label' => $label, 'activated_id' => $new_id ) );
	}

	public static function restore_default( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}

		$table      = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$default_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE map_type = %s AND source = 'default' LIMIT 1",
				$map_type
			)
		);

		if ( ! $default_id ) {
			$files = array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' );
			$path  = CPLAI_DATA_DIR . $files[ $map_type ];
			if ( ! file_exists( $path ) ) {
				return self::error( 'missing_file', 'Bundled default map file not found', 500 );
			}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$wpdb->insert( $table, array(
				'map_type'  => $map_type,
				'label'     => 'Default BPM ' . ucfirst( $map_type ),
				'source'    => 'default',
				'is_active' => 0,
				'json_data' => file_get_contents( $path ),
			) );
			$default_id = $wpdb->insert_id;
		}

		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $default_id ) );
		return rest_ensure_response( array( 'success' => true, 'map_type' => $map_type, 'activated_id' => (int) $default_id ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// SNIPPETS
	// ══════════════════════════════════════════════════════════════════════════

	public static function snippets_sync_defaults( WP_REST_Request $req ): WP_REST_Response {
		CPLAI_Installer::seed_default_snippets();
		return rest_ensure_response( array( 'success' => true, 'message' => 'Default snippets synced.' ) );
	}

	public static function get_snippets( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			"SELECT id, snippet_key, label, direction, hook_stage, logic_description,
			        js_body, php_body,
			        sort_order, is_active, source, created_at, updated_at
			 FROM `{$table}`
			 ORDER BY hook_stage, sort_order, id"
		);
		return rest_ensure_response( array( 'success' => true, 'snippets' => $rows ) );
	}

	/**
	 * Return active snippet js_body strings for a given direction.
	 * Used by the Lab JS engine to load hook functions at runtime.
	 *
	 * GET /cplai/v1/snippets/active?direction=forward
	 *
	 * Response:
	 *   {
	 *     success: true,
	 *     pre:  [ { snippet_key, label, js_body }, … ],
	 *     loop: [ … ],
	 *     post: [ … ]
	 *   }
	 */
	public static function get_active_snippets( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$direction = sanitize_text_field( (string) $req->get_param( 'direction' ) );
		$table     = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT snippet_key, label, hook_stage, js_body
				 FROM `{$table}`
				 WHERE is_active = 1
				   AND ( direction = %s OR direction = 'both' )
				   AND js_body IS NOT NULL
				   AND js_body != ''
				 ORDER BY hook_stage, sort_order ASC, id ASC",
				$direction
			)
		);

		$grouped = array( 'pre' => array(), 'loop' => array(), 'post' => array() );
		foreach ( (array) $rows as $row ) {
			$stage = $row->hook_stage;
			if ( isset( $grouped[ $stage ] ) ) {
				$grouped[ $stage ][] = array(
					'snippet_key' => $row->snippet_key,
					'label'       => $row->label,
					'js_body'     => $row->js_body,
				);
			}
		}

		return rest_ensure_response( array(
			'success'   => true,
			'direction' => $direction,
			'pre'       => $grouped['pre'],
			'loop'      => $grouped['loop'],
			'post'      => $grouped['post'],
		) );
	}

	public static function snippets_get_one( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		return rest_ensure_response( array( 'success' => true, 'snippet' => $row ) );
	}

	/**
	 * AI-generate a snippet: js_body (named JS function) + php_body (JSON rule array).
	 * POST /snippets/generate
	 */
	public static function snippets_generate( WP_REST_Request $req ): WP_REST_Response {
		$snippet_key       = sanitize_text_field( (string) ( $req->get_param( 'snippet_key' ) ?? '' ) );
		$label             = sanitize_text_field( (string) ( $req->get_param( 'label' ) ?? '' ) );
		$direction         = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'both' );
		$hook_stage        = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? 'loop' ) );
		$logic_description = sanitize_textarea_field( (string) ( $req->get_param( 'logic_description' ) ?? '' ) );
		$map_source        = self::validate_map_source( (string) ( $req->get_param( 'map_source' ) ?? '' ) );

		if ( is_wp_error( $direction ) )  return self::error( 'invalid_direction',  $direction->get_error_message(), 400 );
		if ( is_wp_error( $map_source ) ) return self::error( 'invalid_map_source', $map_source->get_error_message(), 400 );
		if ( empty( $snippet_key ) )       return self::error( 'empty_key',          'snippet_key is required', 400 );
		if ( empty( $logic_description ) ) return self::error( 'empty_description',  'logic_description is required', 400 );
		if ( ! in_array( $hook_stage, array( 'pre', 'loop', 'post' ), true ) ) {
			return self::error( 'invalid_hook_stage', 'hook_stage must be pre, loop, or post', 400 );
		}

		$maps     = self::get_active_maps_data( $map_source );
		$user_msg = self::build_snippet_user_message( $snippet_key, $label, $logic_description, $direction, $hook_stage );

		// ── JS body ───────────────────────────────────────────────────────────
		$js_system = self::build_snippet_system_prompt( $direction, $hook_stage, $maps );
		$js_resp   = self::call_ai( $js_system, $user_msg );
		if ( is_wp_error( $js_resp ) ) {
			return self::error( 'ai_error', $js_resp->get_error_message(), 500 );
		}

		// ── PHP body ──────────────────────────────────────────────────────────
		$php_body  = '';
		$php_system = self::build_snippet_php_prompt( $direction, $hook_stage, $maps );
		$php_resp   = self::call_ai( $php_system, $user_msg );
		if ( ! is_wp_error( $php_resp ) ) {
			$extracted = self::extract_php_rules( $php_resp['code'] );
			if ( ! is_wp_error( $extracted ) ) {
				$php_body = $extracted;
			}
		}

		return rest_ensure_response( array(
			'success'     => true,
			'snippet_key' => $snippet_key,
			'js_body'     => $js_resp['code'],
			'php_body'    => $php_body,
			'explanation' => $js_resp['explanation'],
		) );
	}

	/**
	 * Save or update a snippet.
	 * POST /snippets/save
	 */
	public static function snippets_save( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();

		$id          = (int) ( $req->get_param( 'id' ) ?? 0 );
		$snippet_key = sanitize_text_field( (string) ( $req->get_param( 'snippet_key' ) ?? '' ) );
		$label       = sanitize_text_field( (string) ( $req->get_param( 'label' ) ?? '' ) );
		$direction   = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );
		$hook_stage  = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? 'loop' ) );
		$logic_desc  = sanitize_textarea_field( (string) ( $req->get_param( 'logic_description' ) ?? '' ) );
		$js_body     = (string) ( $req->get_param( 'js_body' )  ?? '' ); // raw code — not sanitized.
		$php_body    = (string) ( $req->get_param( 'php_body' ) ?? '' );
		$sort_order  = (int) ( $req->get_param( 'sort_order' ) ?? 0 );
		$source      = sanitize_text_field( (string) ( $req->get_param( 'source' ) ?? 'user' ) );

		if ( empty( $snippet_key ) ) {
			return self::error( 'empty_key', 'snippet_key is required', 400 );
		}
		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'Invalid direction', 400 );
		}
		if ( ! in_array( $hook_stage, array( 'pre', 'loop', 'post' ), true ) ) {
			return self::error( 'invalid_hook_stage', 'hook_stage must be pre, loop, or post', 400 );
		}
		if ( mb_strlen( $js_body ) > 200000 ) {
			return self::error( 'code_too_large', 'js_body exceeds maximum allowed size', 400 );
		}

		$data = array(
			'snippet_key'       => $snippet_key,
			'label'             => $label ?: $snippet_key,
			'direction'         => $direction,
			'hook_stage'        => $hook_stage,
			'logic_description' => $logic_desc,
			'js_body'           => $js_body,
			'php_body'          => $php_body,
			'sort_order'        => $sort_order,
			'source'            => in_array( $source, array( 'default', 'user', 'ai_generated' ), true ) ? $source : 'user',
		);

		if ( $id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
			if ( ! $existing ) {
				return self::error( 'not_found', 'Snippet not found', 404 );
			}
			if ( 'default' === $existing->source ) {
				$data['source'] = 'default'; // preserve source for defaults.
			}
			$wpdb->update( $table, $data, array( 'id' => $id ) );
			return rest_ensure_response( array( 'success' => true, 'id' => $id, 'updated' => true ) );
		}

		$result = $wpdb->insert( $table, $data );
		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		$new_id = $wpdb->insert_id;
		// Auto-activate new user/AI snippets.
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $new_id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $new_id, 'inserted' => true ) );
	}

	/** POST /snippets/{id} — inline field update */
	public static function snippets_update( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}

		$allowed = array( 'label', 'logic_description', 'js_body', 'php_body', 'sort_order', 'direction', 'hook_stage' );
		$update  = array();
		foreach ( $allowed as $f ) {
			$val = $req->get_param( $f );
			if ( null !== $val ) {
				$update[ $f ] = in_array( $f, array( 'js_body', 'php_body' ), true )
					? (string) $val
					: sanitize_text_field( (string) $val );
			}
		}
		if ( empty( $update ) ) {
			return self::error( 'no_data', 'No fields to update', 400 );
		}

		$wpdb->update( $table, $update, array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id ) );
	}

	/** POST /snippets/{id}/toggle */
	public static function snippets_toggle( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, is_active FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}

		$new_state = $row->is_active ? 0 : 1;
		$wpdb->update( $table, array( 'is_active' => $new_state ), array( 'id' => $id ) );

		return rest_ensure_response( array(
			'success'   => true,
			'id'        => $id,
			'is_active' => $new_state,
		) );
	}

	/** POST /snippets/{id}/reorder  Body: { sort_order: int } */
	public static function snippets_reorder( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id         = (int) $req->get_param( 'id' );
		$sort_order = (int) $req->get_param( 'sort_order' );
		$table      = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		$wpdb->update( $table, array( 'sort_order' => $sort_order ), array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id, 'sort_order' => $sort_order ) );
	}

	/** DELETE /snippets/{id} */
	public static function snippets_delete( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		if ( 'default' === $row->source ) {
			return self::error( 'protected', 'Default snippets cannot be deleted', 403 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// TEST
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Server-side PHP engine test.
	 * The JS fixed engine runs entirely client-side — this endpoint is for
	 * PHP-engine validation only.
	 *
	 * POST /test/run
	 * Body: { input_text, direction }
	 */
	public static function test_run( WP_REST_Request $req ): WP_REST_Response {
		$input_text = sanitize_textarea_field( (string) $req->get_param( 'input_text' ) );
		$direction  = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'forward' );

		if ( is_wp_error( $direction ) ) {
			return self::error( 'invalid_direction', $direction->get_error_message(), 400 );
		}
		if ( empty( $input_text ) ) {
			return self::error( 'empty_input', 'input_text is required', 400 );
		}

		$engine = new CPLAI_Engine();
		$result = $engine->transliterate( $input_text, $direction );

		return rest_ensure_response( array(
			'success'   => true,
			'mode'      => 'php_engine',
			'output'    => $result['output'],
			'log'       => $result['log'],
			'direction' => $direction,
			'debug'     => self::db_debug(),
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// STATUS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_status( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$maps_table     = CPLAI_Installer::table_maps();
		$snippets_table = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_maps     = $wpdb->get_results( "SELECT id, map_type, label, source FROM `{$maps_table}` WHERE is_active = 1" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_snippets = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$snippets_table}` WHERE is_active = 1" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_snippets  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$snippets_table}`" );

		return rest_ensure_response( array(
			'active_maps'    => $active_maps,
			'snippets'       => array( 'active' => $active_snippets, 'total' => $total_snippets ),
			'engine'         => 'fixed-v4',
			'php_version'    => PHP_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'wp_debug'       => WP_DEBUG,
			'plugin_version' => CPLAI_VERSION,
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// SETTINGS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_settings( WP_REST_Request $req ): WP_REST_Response {
		$anthropic_raw = (string) get_option( 'cplai_anthropic_key', '' );
		$gemini_raw    = (string) get_option( 'cplai_gemini_key',    '' );
		$openai_raw    = (string) get_option( 'cplai_openai_key',    '' );
		$grok_raw      = (string) get_option( 'cplai_grok_key',      '' );

		$mask = static function ( string $k ): string {
			return $k ? ( substr( $k, 0, 8 ) . str_repeat( '•', max( 0, strlen( $k ) - 8 ) ) ) : '';
		};

		return rest_ensure_response( array(
			'success'           => true,
			'api_key_hint'      => $mask( $anthropic_raw ),
			'gemini_key_hint'   => $mask( $gemini_raw ),
			'openai_key_hint'   => $mask( $openai_raw ),
			'grok_key_hint'     => $mask( $grok_raw ),
			'has_anthropic_key' => ! empty( $anthropic_raw ),
			'has_gemini_key'    => ! empty( $gemini_raw ),
			'has_openai_key'    => ! empty( $openai_raw ),
			'has_grok_key'      => ! empty( $grok_raw ),
			'model'             => (string) get_option( 'cplai_model',       'claude-sonnet-4-6' ),
			'ai_provider'       => (string) get_option( 'cplai_ai_provider', 'anthropic' ),
		) );
	}

	public static function save_settings( WP_REST_Request $req ): WP_REST_Response {
		$params   = $req->get_json_params();
		$provider = sanitize_text_field( (string) ( $params['ai_provider'] ?? 'anthropic' ) );
		$model    = sanitize_text_field( (string) ( $params['model']       ?? 'claude-sonnet-4-6' ) );

		$allowed_providers = array( 'anthropic', 'gemini', 'openai', 'grok' );
		if ( ! in_array( $provider, $allowed_providers, true ) ) {
			return self::error( 'invalid_provider', 'Invalid provider.', 400 );
		}

		$allowed_models = array(
			'claude-opus-4-6', 'claude-sonnet-4-6',
			'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash',
			'gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo',
			'grok-3', 'grok-3-fast', 'grok-3-mini', 'grok-3-mini-fast',
		);
		if ( ! in_array( $model, $allowed_models, true ) ) {
			return self::error( 'invalid_model', 'Invalid model.', 400 );
		}

		$key_map = array(
			'api_key'    => 'cplai_anthropic_key',
			'gemini_key' => 'cplai_gemini_key',
			'openai_key' => 'cplai_openai_key',
			'grok_key'   => 'cplai_grok_key',
		);
		foreach ( $key_map as $param => $option ) {
			$val = sanitize_text_field( (string) ( $params[ $param ] ?? '' ) );
			if ( ! empty( $val ) ) {
				update_option( $option, $val );
			}
		}

		update_option( 'cplai_model',       $model );
		update_option( 'cplai_ai_provider', $provider );

		return rest_ensure_response( array( 'success' => true, 'saved' => true ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// LEXICON
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_lexicon( WP_REST_Request $req ): WP_REST_Response {
		$sections = array( 'independent_vowels', 'consonants', 'matras', 'special', 'digits', 'punctuation' );

		$file_defaults = array();
		foreach ( array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' ) as $type => $filename ) {
			$path = CPLAI_DATA_DIR . $filename;
			if ( file_exists( $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$decoded = json_decode( file_get_contents( $path ), true );
				if ( is_array( $decoded ) ) {
					$file_defaults[ $type ] = $decoded;
				}
			}
		}

		$db_maps = self::get_active_maps_data( 'default' );
		$maps    = array();
		foreach ( array( 'forward', 'reverse' ) as $type ) {
			$db           = $db_maps[ $type ] ?? array();
			$has_sections = false;
			foreach ( $sections as $s ) {
				if ( ! empty( $db[ $s ] ) ) {
					$has_sections = true;
					break;
				}
			}
			$maps[ $type ] = $has_sections ? $db : ( $file_defaults[ $type ] ?? array() );
		}

		$forward = array();
		$reverse = array();

		foreach ( $sections as $section ) {
			$fwd = self::normalise_section_to_pairs( $maps['forward'][ $section ] ?? array() );
			$rev = self::normalise_section_to_pairs( $maps['reverse'][ $section ] ?? array() );
			if ( ! empty( $fwd ) ) $forward[ $section ] = $fwd;
			if ( ! empty( $rev ) ) $reverse[ $section ] = $rev;
		}

		if ( empty( $forward ) ) $forward = array_fill_keys( $sections, array() );
		if ( empty( $reverse ) ) $reverse = array_fill_keys( $sections, array() );

		return rest_ensure_response( array( 'forward' => $forward, 'reverse' => $reverse ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// HELPERS
	// ══════════════════════════════════════════════════════════════════════════

	private static function get_active_maps_data( string $source ): array {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = ( 'db' === $source )
			? $wpdb->get_results( "SELECT map_type, json_data, source FROM `{$table}` WHERE is_active = 1 ORDER BY source DESC" )
			: $wpdb->get_results( "SELECT map_type, json_data, source FROM `{$table}` WHERE is_active = 1" );

		$maps = array();
		foreach ( (array) $rows as $row ) {
			$maps[ $row->map_type ] = json_decode( $row->json_data, true );
		}

		foreach ( array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' ) as $type => $file ) {
			if ( empty( $maps[ $type ] ) ) {
				$path = CPLAI_DATA_DIR . $file;
				if ( file_exists( $path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$maps[ $type ] = json_decode( file_get_contents( $path ), true );
				}
			}
		}

		return $maps;
	}

	// ── Snippet AI system prompt ──────────────────────────────────────────────

	private static function build_snippet_system_prompt( string $direction, string $hook_stage, array $maps ): string {
		$map_json       = wp_json_encode( $maps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		$virama         = '্'; // U+09CD.
		$inherent_vowel = 'o';

		return <<<SYSPROMPT
You are an expert computational linguist and JavaScript developer specialising in Bishnupriya Manipuri (BPM) transliteration.

## Task
Generate a SINGLE named JavaScript snippet hook function — NOT a full transliteration engine.
The snippet implements one specific parsing logic unit (e.g. reph ligature, anusvara revert, schwa deletion).

## Engine Architecture (v4 — Fixed Engine)
The engine is fixed PHP/JS. AI only generates snippet hook functions that plug into pre/loop/post slots.
The engine passes a `state` object and a `config` object to every hook.

## Snippet Hook Interface Contract

  function snippetName(state, config) {
    // state.input    {string}  — full original input string
    // state.output   {string}  — accumulated output so far
    // state.pos      {number}  — current position in input (loop stage)
    // state.prev     {object}  — { token, was_consonant, was_matra }
    // state.log      {Array}   — push strings to append log entries
    // state.handled  {boolean} — SET TRUE in loop stage to claim the token
    //                            and block the default match for this position.
    //                            First hook that sets handled=true wins; chain stops.
    //
    // config.maps           — { forward: {…}, reverse: {…} } active maps
    // config.virama         — '{$virama}' (U+09CD Bengali virama)
    // config.inherent_vowel — '{$inherent_vowel}' (inherent vowel Roman token)
    // config.direction      — 'forward' | 'reverse'
    // config.consonants_set — Set<string> of consonant keys for active direction
    // config.matras_set     — Set<string> of matra keys for active direction
    //
    // Must return the modified state object.
    return state;
  }

## Hook Stage: {$hook_stage}
- pre:  Runs before the main loop. Modify state.input (e.g. string substitutions). state.pos is 0.
- loop: Runs inside the loop at each position. Set state.handled = true to claim the token.
         Sort order is priority — lower sort_order = higher priority.
- post: Runs after the main loop. Modify state.output (e.g. trim, case changes).

## Direction: {$direction}

## Rules
1. Return ONLY the JavaScript function definition — no markdown fences, no preamble, no extra functions.
2. Use the provided active maps for any lookup needed.
3. The function must be self-contained (no imports, no external dependencies).
4. Use a descriptive camelCase function name matching the snippet_key.
5. Always return state.

## Active maps (source of truth):
{$map_json}
SYSPROMPT;
	}

	private static function build_snippet_user_message(
		string $key, string $label, string $description, string $direction, string $hook_stage
	): string {
		return "Generate a snippet hook function with these parameters:\n\n"
			. "snippet_key: {$key}\n"
			. "label: {$label}\n"
			. "direction: {$direction}\n"
			. "hook_stage: {$hook_stage}\n\n"
			. "Logic to implement:\n{$description}";
	}

	/**
	 * Build the system prompt for PHP rule-array generation.
	 *
	 * The PHP engine cannot execute functions. It only accepts a JSON-encoded
	 * array of find-replace rule objects processed by apply_processing_rules().
	 *
	 * @param string $direction  'forward'|'reverse'|'both'
	 * @param string $hook_stage 'pre'|'loop'|'post'
	 * @param array  $maps       Active forward + reverse maps (source of truth for Unicode values).
	 * @return string
	 */
	private static function build_snippet_php_prompt( string $direction, string $hook_stage, array $maps ): string {
		$map_json = wp_json_encode( $maps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

		return <<<PHPPROMPT
You are generating the PHP-side equivalent of a transliteration snippet hook for a Bengali-Assamese transliteration engine.

## What the PHP engine accepts

The PHP engine does NOT execute JavaScript or PHP functions.
It reads php_body as a JSON-encoded array of find-replace rule objects and applies them sequentially via str_replace or preg_replace.

Each rule follows this base structure:
{ "type": "replace", "from": "<search>", "to": "<replacement>", "regex": false }

- "type"  — must be "replace" (the only supported type).
- "from"  — the literal string to find, or a regex pattern if "regex" is true.
- "to"    — the replacement string. May contain literal UTF-8 Bengali/Assamese characters.
- "regex" — false for plain str_replace (default); true for preg_replace.

## Rules for ordering

Order matters — rules are applied top-to-bottom in a single pass.
Always place longer / more specific patterns before shorter ones that share a prefix.
Example: "ngOI" must come before "ngO", which must come before "ng".

## Hook stage: {$hook_stage}

- pre:  Rules run on the raw input string before the main transliteration loop.

- loop: Rules run inside the main transliteration loop at every input position.
        Loop-stage rules support optional context conditions evaluated against
        live engine state. All context keys are optional; omit any you do not need.

        Extended loop-stage rule schema:
        {
          "type":                       "replace",
          "from":                       "<literal or regex>",
          "to":                         "<replacement>",
          "regex":                      false,
          "context_output_ends_with":   "<string>",
          "context_next_token_in":      "<map section name>",
          "context_prev_was_consonant": true
        }

        Context keys:
        - "context_output_ends_with"   — rule fires only when the accumulated output
                                         ends with this string. Use it to retroactively
                                         correct the most recently emitted token.
                                         Example: "context_output_ends_with": "\u0982"
                                         ensures the rule only fires when anusvara (ং)
                                         was the last character written.

        - "context_next_token_in"      — rule fires only when the next input token
                                         is found in the named map section.
                                         Valid section names: "matras", "consonants",
                                         "independent_vowels", "special", "digits",
                                         "punctuation".
                                         Example: "context_next_token_in": "matras"
                                         fires only if a vowel matra follows.

        - "context_prev_was_consonant" — rule fires only when the previous token
                                         was (true) or was not (false) a consonant.

        When all stated conditions are satisfied, "from" is matched against the
        tail of the current output (for retroactive corrections) or the full output
        (for broader replacements), and replaced with "to".

        Example — anusvara revert before matra (ং → ঙ):
        {
          "type":                     "replace",
          "context_output_ends_with": "\u0982",
          "context_next_token_in":    "matras",
          "from":                     "\u0982",
          "to":                       "\u0999"
        }

- post: Rules run on the transliterated output string after the main loop.

## Direction: {$direction}

## Output format

Return ONLY the raw JSON array — no markdown fences, no explanation, no preamble, no trailing text.
The array must be valid JSON parseable by json_decode() in PHP.
Unicode Bengali/Assamese characters must be included as literal UTF-8, not as escape sequences.

## Active maps (use these to resolve correct Unicode values for matras, consonants, and vowels)

{$map_json}
PHPPROMPT;
	}

	// ── Provider-aware AI dispatcher ──────────────────────────────────────────

	/**
	 * @return array{code:string,explanation:string}|WP_Error
	 */
	private static function call_ai( string $system, string $user_msg ): array|WP_Error {
		$provider = (string) get_option( 'cplai_ai_provider', 'anthropic' );

		switch ( $provider ) {
			case 'gemini':
				$key = (string) get_option( 'cplai_gemini_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Google Gemini API key not configured. Go to Settings.' );
				return self::call_gemini( $key, $system, $user_msg );

			case 'openai':
				$key = (string) get_option( 'cplai_openai_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'OpenAI API key not configured. Go to Settings.' );
				return self::call_openai( $key, $system, $user_msg );

			case 'grok':
				$key = (string) get_option( 'cplai_grok_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Grok API key not configured. Go to Settings.' );
				return self::call_grok( $key, $system, $user_msg );

			default:
				$key = (string) get_option( 'cplai_anthropic_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Anthropic API key not configured. Go to Settings.' );
				return self::call_anthropic( $key, $system, $user_msg );
		}
	}

	private static function call_gemini( string $key, string $system, string $user_msg ): array|WP_Error {
		$model    = (string) get_option( 'cplai_model', 'gemini-2.5-flash' );
		$endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $key );
		$body     = array(
			'system_instruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
			'contents'           => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $user_msg ) ) ) ),
			'generationConfig'   => array( 'maxOutputTokens' => 4096, 'temperature' => 0.2 ),
		);
		$response = wp_remote_post( $endpoint, array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'gemini_error', $data['error']['message'] ?? "Gemini HTTP {$http_code}" );
		$full_text = '';
		foreach ( $data['candidates'][0]['content']['parts'] ?? array() as $part ) {
			if ( isset( $part['text'] ) ) $full_text .= $part['text'];
		}
		return self::extract_code_and_explanation( $full_text );
	}

	private static function call_openai( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'gpt-4o' );
		$body  = array(
			'model'       => $model,
			'max_tokens'  => 4096,
			'temperature' => 0.2,
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user',   'content' => $user_msg ),
			),
		);
		$response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'openai_error', $data['error']['message'] ?? "OpenAI HTTP {$http_code}" );
		return self::extract_code_and_explanation( $data['choices'][0]['message']['content'] ?? '' );
	}

	private static function call_grok( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'grok-3-fast' );
		$body  = array(
			'model'       => $model,
			'max_tokens'  => 4096,
			'temperature' => 0.2,
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user',   'content' => $user_msg ),
			),
		);
		$response = wp_remote_post( 'https://api.x.ai/v1/chat/completions', array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'grok_error', $data['error']['message'] ?? "Grok HTTP {$http_code}" );
		return self::extract_code_and_explanation( $data['choices'][0]['message']['content'] ?? '' );
	}

	private static function call_anthropic( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'claude-sonnet-4-6' );
		$body  = array(
			'model'      => $model,
			'max_tokens' => 4096,
			'system'     => $system,
			'messages'   => array( array( 'role' => 'user', 'content' => $user_msg ) ),
		);
		$response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
			'timeout' => 90,
			'headers' => array(
				'Content-Type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => '2023-06-01',
			),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code ) return new WP_Error( 'anthropic_error', $data['error']['message'] ?? "HTTP {$code}" );
		$full_text = '';
		foreach ( $data['content'] ?? array() as $block ) {
			if ( ( $block['type'] ?? '' ) === 'text' ) $full_text .= $block['text'];
		}
		return self::extract_code_and_explanation( $full_text );
	}

	private static function extract_code_and_explanation( string $full_text ): array {
		if ( preg_match( '/```(?:javascript|js)?\s*([\s\S]*?)```/i', $full_text, $m ) ) {
			$code_part   = trim( $m[1] );
			$explanation = trim( preg_replace( '/```[\s\S]*?```/i', '', $full_text ) );
		} else {
			$code_part   = trim( $full_text );
			$explanation = '';
		}
		return array( 'code' => $code_part, 'explanation' => $explanation );
	}

	/**
	 * Extract and validate a PHP rule array from the AI response.
	 *
	 * Strips markdown fences if the AI added them despite instructions,
	 * decodes the JSON, validates each rule has 'from' and 'to', then
	 * re-encodes to ensure consistent UTF-8 output.
	 *
	 * @param string $full_text Raw AI response text.
	 * @return string|WP_Error  JSON string on success, WP_Error on failure.
	 */
	private static function extract_php_rules( string $full_text ): string|WP_Error {
		// Strip markdown fences (```json ... ``` or ``` ... ```).
		$clean = preg_replace( '/^```(?:json)?\s*/i', '', trim( $full_text ) );
		$clean = preg_replace( '/\s*```\s*$/i', '', $clean );
		$clean = trim( $clean );

		$decoded = json_decode( $clean, true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'invalid_php_body', 'AI returned invalid JSON for php_body.' );
		}

		foreach ( $decoded as $rule ) {
			if ( ! is_array( $rule ) || ! isset( $rule['from'], $rule['to'] ) || '' === $rule['from'] ) {
				return new WP_Error( 'invalid_rule', 'One or more rules are missing required from/to fields.' );
			}
		}

		return wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE );
	}

	// ── Normalise map section to pairs ────────────────────────────────────────

	private static function normalise_section_to_pairs( array $raw ): array {
		$pairs = array();
		if ( empty( $raw ) ) return $pairs;

		$is_v2 = array_is_list( $raw )
			&& isset( $raw[0] )
			&& is_array( $raw[0] )
			&& array_is_list( $raw[0] )
			&& count( $raw[0] ) >= 2;

		if ( $is_v2 ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0], $pair[1] ) ) {
					$pairs[] = array( 'from' => (string) $pair[0], 'to' => (string) $pair[1] );
				}
			}
		} else {
			foreach ( $raw as $k => $v ) {
				if ( '_meta' === $k ) continue;
				$pairs[] = array( 'from' => (string) $k, 'to' => (string) $v );
			}
		}
		return $pairs;
	}

	// ── Validators ────────────────────────────────────────────────────────────

	private static function validate_direction( string $value, string $default = 'both' ): string|WP_Error {
		$allowed = array( 'forward', 'reverse', 'both' );
		$value   = sanitize_text_field( $value ?: $default );
		if ( ! in_array( $value, $allowed, true ) ) {
			return new WP_Error( 'invalid_direction', 'direction must be one of: ' . implode( ', ', $allowed ) );
		}
		return $value;
	}

	private static function validate_map_source( string $value ): string|WP_Error {
		$allowed = array( 'default', 'db' );
		$value   = sanitize_text_field( $value ?: 'default' );
		if ( ! in_array( $value, $allowed, true ) ) {
			return new WP_Error( 'invalid_map_source', "map_source must be 'default' or 'db'" );
		}
		return $value;
	}

	// ── DB debug helper ───────────────────────────────────────────────────────

	private static function db_debug(): array {
		if ( ! WP_DEBUG ) return array();
		global $wpdb;
		return array(
			'last_query'  => $wpdb->last_query,
			'last_error'  => $wpdb->last_error,
			'num_queries' => $wpdb->num_queries,
		);
	}

	// ── Error response helper ─────────────────────────────────────────────────

	private static function error( string $code, string $msg, int $status ): WP_REST_Response {
		$data = array( 'success' => false, 'code' => $code, 'message' => $msg );
		if ( WP_DEBUG ) {
			$data['debug'] = array( 'backtrace' => array_slice( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS ), 0, 5 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
		}
		return new WP_REST_Response( $data, $status );
	}
}