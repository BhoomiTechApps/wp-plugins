<?php
/**
 * PHP-side rule-based transliteration engine.
 *
 * v4.3 changes:
 *  - Hardcoded the 4 forward-loop core snippets directly into forward() so that
 *    PHP and JS engines produce identical output without relying on DB/snippet hooks
 *    for fundamental engine operations:
 *      1. fwd_loop_atstart_independent_vowel — word-start independent vowel
 *      2. loop_explicit_zwnj                 — apostrophe → ZWNJ
 *      3. fwd_loop_consonant_plus_matra      — consonant + matra pair
 *      4. fwd_loop_consonant_cluster_halanta — consonant cluster + halanta/ZWJ
 *  - Removed the native prev_was_consonant virama insertion from the core map
 *    lookup block; virama between consonant clusters is now owned exclusively
 *    by fwd_loop_consonant_cluster_halanta (step 4 above).
 *  - loop_virama_conjunct was dead code (referenced non-existent
 *    state.currentIsConsonant in JS) and is not ported.
 *  - Non-linking consonants list hardcoded: ['ng','M','NG','Ng',':','H','^','~'].
 *  - All string operations use mb_substr / mb_strlen (never substr / strlen).
 *
 * v4.2 changes:
 *  - Pre/post snippet hooks wired via DB (is_active snippets with php_body).
 *  - Loop-stage snippet hooks now fully supported.
 *  - Bare local loop variables replaced with a proper $state array matching
 *    the JS engine's state contract.
 *  - $state['handled'] flag allows loop-stage snippet hooks to mark a position
 *    as fully consumed, bypassing the core map lookup for that position.
 *  - apply_processing_rules() extended with context-aware loop rules.
 *  - virama and inherent_vowel are hardcoded constants.
 *
 * Map section format support:
 *   v2 (preferred): ordered array of [from, to] pairs → [["k","ক"],["kh","খ"],…]
 *   v1 (legacy):    plain associative object           → {"k":"ক","kh":"খ",…}
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * PHP transliteration engine with pre/loop/post hook support.
 */
class CPLAI_Engine {

	// ── Map storage ───────────────────────────────────────────────────────────

	/** @var array<string,mixed> */
	private array $forward_map = array();

	/** @var array<string,mixed> */
	private array $reverse_map = array();

	/**
	 * Snippets injected from outside (e.g. user replicate table).
	 * When non-empty, get_php_snippets() uses this instead of querying the DB.
	 *
	 * Each element is an object with at minimum: php_body, hook_stage, direction.
	 *
	 * @var array<int,object>
	 */
	private array $injected_snippets = array();

	// ── Engine constants ──────────────────────────────────────────────────────

	/** Bengali virama U+09CD. */
	private string $virama = '্';

	/** Inherent vowel Roman token for reverse direction. */
	private string $inherent_vowel = 'o';

	/** Zero Width Joiner U+200D. */
	private string $zwj = "\u{200D}";

	/** Zero Width Non-Joiner U+200C. */
	private string $zwnj = "\u{200C}";

	/**
	 * Non-linking consonants: emit bare without halanta before the next consonant.
	 *
	 * @var string[]
	 */
	private array $non_linking_consonants = array( 'ng', 'M', 'NG', 'Ng', ':', 'H', '^', '~' );

	// ── Constructor ───────────────────────────────────────────────────────────

	public function __construct() {
		$this->load_active_maps();
	}

	// ── Map loader ────────────────────────────────────────────────────────────

	private function load_active_maps(): void {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT map_type, json_data FROM `{$table}` WHERE is_active = 1" );

		foreach ( $rows as $row ) {
			$data = json_decode( $row->json_data, true );
			switch ( $row->map_type ) {
				case 'forward':
					$this->forward_map = $data;
					break;
				case 'reverse':
					$this->reverse_map = $data;
					break;
			}
		}

		// File-based fallbacks if DB rows are missing.
		$fallbacks = array(
			'forward_map' => 'forwardMap.json',
			'reverse_map' => 'reverseMap.json',
		);
		foreach ( $fallbacks as $prop => $file ) {
			if ( empty( $this->$prop ) ) {
				$path = CPLAI_DATA_DIR . $file;
				if ( file_exists( $path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$this->$prop = json_decode( file_get_contents( $path ), true ) ?? array();
				}
			}
		}
	}

	// ── Snippet hook loader ───────────────────────────────────────────────────

	/**
	 * Fetch active PHP snippets for a given direction and hook stage.
	 * Returns an array of php_body strings (JSON rule arrays).
	 *
	 * When $injected_snippets is non-empty (set by transliterate() from an
	 * external source such as the per-user replicate table), those rows are
	 * filtered and returned directly — no DB query is made.
	 * Otherwise falls back to querying the main cplai_snippets table.
	 *
	 * Supports all three hook stages: 'pre', 'loop', and 'post'.
	 *
	 * @param string $direction  'forward'|'reverse'
	 * @param string $hook_stage 'pre'|'loop'|'post'
	 * @return array<int,string>
	 */
	private function get_php_snippets( string $direction, string $hook_stage ): array {
		// ── Injected path — use pre-fetched rows from caller (e.g. user replicate table) ──
		if ( ! empty( $this->injected_snippets ) ) {
			$bodies = array();
			foreach ( $this->injected_snippets as $row ) {
				$row_stage = is_array( $row ) ? ( $row['hook_stage'] ?? '' ) : ( $row->hook_stage ?? '' );
				$row_dir   = is_array( $row ) ? ( $row['direction']  ?? '' ) : ( $row->direction  ?? '' );
				$row_body  = is_array( $row ) ? ( $row['php_body']   ?? '' ) : ( $row->php_body   ?? '' );

				if ( $row_stage !== $hook_stage ) {
					continue;
				}
				if ( $row_dir !== $direction && $row_dir !== 'both' ) {
					continue;
				}
				if ( '' !== $row_body ) {
					$bodies[] = $row_body;
				}
			}
			return $bodies;
		}

		// ── DB path — query main cplai_snippets table ─────────────────────────
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT php_body FROM `{$table}`
				 WHERE is_active = 1
				   AND hook_stage = %s
				   AND ( direction = %s OR direction = 'both' )
				   AND php_body IS NOT NULL
				   AND php_body != ''
				 ORDER BY sort_order ASC, id ASC",
				$hook_stage,
				$direction
			)
		);

		return array_column( (array) $rows, 'php_body' );
	}

	/**
	 * Run pre/post snippet hooks: apply JSON rule arrays against a plain string.
	 *
	 * @param string   $text
	 * @param string   $direction
	 * @param string   $hook_stage 'pre'|'post'
	 * @param string[] &$log
	 * @return string
	 */
	private function run_php_snippet_hooks( string $text, string $direction, string $hook_stage, array &$log ): string {
		$snippets = $this->get_php_snippets( $direction, $hook_stage );
		foreach ( $snippets as $php_body ) {
			$decoded = json_decode( $php_body, true );
			if ( is_array( $decoded ) ) {
				$text = $this->apply_processing_rules( $text, $decoded, $log );
			}
			// Non-JSON php_body values are reserved for future use.
		}
		return $text;
	}

	/**
	 * Run loop-stage snippet hooks at a single input position.
	 *
	 * Each active loop-stage php_body is a JSON-encoded array of context-aware
	 * rules. Rules are evaluated against the live $state (output so far, current
	 * position, remaining input) and may set $state['handled'] = true to signal
	 * that the current position has been fully consumed by the rule.
	 *
	 * @param array    &$state   Mutable engine state (see forward()/reverse() for contract).
	 * @param array     $config  Read-only engine config (maps, virama, …).
	 * @param string    $direction
	 * @param string[] &$log
	 */
	private function run_loop_snippet_hooks( array &$state, array $config, string $direction, array &$log ): void {
		$snippets = $this->get_php_snippets( $direction, 'loop' );
		foreach ( $snippets as $php_body ) {
			$decoded = json_decode( $php_body, true );
			if ( ! is_array( $decoded ) ) {
				continue;
			}
			$this->apply_loop_rules( $state, $decoded, $config, $log );
		}
	}

	// ── Public: transliterate ─────────────────────────────────────────────────

	/**
	 * Entry point. Returns [ 'output' => string, 'log' => string[] ].
	 *
	 * @param string $input
	 * @param string $direction  'forward'|'reverse'
	 * @param array  $snippets   Optional. Pre-fetched snippet rows (objects with php_body,
	 *                           hook_stage, direction). When provided, the engine uses these
	 *                           instead of querying the main cplai_snippets table — allowing
	 *                           callers to supply snippets from any source (e.g. the per-user
	 *                           replicate table) without modifying engine internals.
	 * @return array{output:string,log:string[]}
	 */
	public function transliterate( string $input, string $direction, array $snippets = array() ): array {
		$this->injected_snippets = $snippets;

		$log    = array();
		$output = '';

		if ( 'forward' === $direction ) {
			list( $output, $log ) = $this->forward( $input );
		} elseif ( 'reverse' === $direction ) {
			list( $output, $log ) = $this->reverse( $input );
		} else {
			$log[] = "[ERROR] Unknown direction: {$direction}";
		}

		return array( 'output' => $output, 'log' => $log );
	}

	// ── Pre/post processing rule runner ───────────────────────────────────────

	/**
	 * Apply an array of find-replace processing rules to a plain string.
	 *
	 * Pre/post stage rule schema:
	 *   { "type": "replace", "from": "pattern", "to": "replacement", "regex": false }
	 *
	 * Loop-stage rules additionally support optional context keys (evaluated by
	 * apply_loop_rules() against live $state). This method handles only the
	 * string-level operation; context evaluation lives in apply_loop_rules().
	 *
	 * @param string   $text
	 * @param array    $rules
	 * @param string[] &$log
	 * @return string
	 */
	public function apply_processing_rules( string $text, array $rules, array &$log = array() ): string {
		if ( empty( $rules ) ) {
			return $text;
		}

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}
			$type  = $rule['type']  ?? 'replace';
			$from  = $rule['from']  ?? '';
			$to    = $rule['to']    ?? '';
			$regex = ! empty( $rule['regex'] );

			if ( '' === $from ) {
				continue;
			}

			if ( 'replace' === $type ) {
				if ( $regex ) {
					$result = @preg_replace( $from, $to, $text ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
					if ( null !== $result ) {
						if ( $result !== $text ) {
							$log[] = "[PRE/POST RULE] regex replace '{$from}' → '{$to}'";
						}
						$text = $result;
					}
				} else {
					if ( str_contains( $text, $from ) ) {
						$log[] = "[PRE/POST RULE] replace '{$from}' → '{$to}'";
						$text  = str_replace( $from, $to, $text );
					}
				}
			}
		}

		return $text;
	}

	/**
	 * Apply loop-stage rules against the live engine state at the current position.
	 *
	 * Loop-stage rules use the same base schema as pre/post rules, extended with
	 * optional context conditions that are evaluated against $state before
	 * applying the replacement. All context keys are optional; omitting them
	 * produces unconditional matching (equivalent to a pre/post rule).
	 *
	 * Extended loop-stage rule schema:
	 * {
	 *   "type":                     "replace",
	 *   "from":                     "<literal or regex>",
	 *   "to":                       "<replacement>",
	 *   "regex":                    false,
	 *
	 *   // Optional context conditions (all must pass when present):
	 *   "context_output_ends_with": "<string>",   // $state['output'] ends with this value
	 *   "context_next_token_in":    "<section>",  // next input token exists in the named map section
	 *   "context_prev_was_consonant": true|false  // $state['prev_was_consonant'] must match
	 * }
	 *
	 * When a rule's context conditions are satisfied, $state['output'] is
	 * modified by replacing the 'from' string/pattern in a context-aware manner:
	 *
	 *  - If 'from' matches the tail of $state['output'], the match is removed
	 *    from the tail of output and 'to' is appended instead — enabling
	 *    retroactive corrections of the most recently emitted token.
	 *  - Otherwise the rule applies as a plain str_replace / preg_replace on
	 *    $state['output'] (whole-output transformation).
	 *
	 * A matched loop rule sets $state['handled'] = true so the calling loop
	 * knows not to advance past the current position via the core lookup.
	 *
	 * @param array    &$state   Mutable engine state.
	 * @param array     $rules   Decoded JSON rule array.
	 * @param array     $config  Engine config (maps, virama, …).
	 * @param string[] &$log
	 */
	private function apply_loop_rules( array &$state, array $rules, array $config, array &$log ): void {
		if ( empty( $rules ) ) {
			return;
		}

		$map       = $config['map']       ?? array();
		$direction = $config['direction'] ?? 'forward';

		foreach ( $rules as $rule ) {
			if ( ! is_array( $rule ) ) {
				continue;
			}

			$type  = $rule['type']  ?? 'replace';
			$from  = $rule['from']  ?? '';
			$to    = $rule['to']    ?? '';
			$regex = ! empty( $rule['regex'] );

			if ( '' === $from || 'replace' !== $type ) {
				continue;
			}

			// ── Evaluate optional context conditions ──────────────────────────

			// context_output_ends_with: $state['output'] must end with this string.
			if ( isset( $rule['context_output_ends_with'] ) ) {
				if ( ! str_ends_with( $state['output'], (string) $rule['context_output_ends_with'] ) ) {
					continue;
				}
			}

			// context_next_token_in: the next input character(s) must be a key
			// found in the named map section (e.g. 'matras', 'consonants').
			if ( isset( $rule['context_next_token_in'] ) ) {
				$section      = (string) $rule['context_next_token_in'];
				$remaining    = mb_substr( $state['input'], $state['pos'] );
				$section_keys = $this->section_keys( $map, $section );
				$token_found  = false;
				foreach ( $section_keys as $key ) {
					if ( str_starts_with( $remaining, $key ) ) {
						$token_found = true;
						break;
					}
				}
				if ( ! $token_found ) {
					continue;
				}
			}

			// context_prev_was_consonant: $state['prev_was_consonant'] must match.
			if ( isset( $rule['context_prev_was_consonant'] ) ) {
				$expected = (bool) $rule['context_prev_was_consonant'];
				if ( (bool) $state['prev_was_consonant'] !== $expected ) {
					continue;
				}
			}

			// ── All context conditions passed — apply the rule ────────────────

			if ( $regex ) {
				// Regex replacement on accumulated output.
				$result = @preg_replace( $from, $to, $state['output'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
				if ( null !== $result && $result !== $state['output'] ) {
					$state['output']  = $result;
					$state['handled'] = true;
					$log[] = "[LOOP RULE] regex '{$from}' → '{$to}' (pos {$state['pos']})";
				}
			} else {
				// Literal replacement: prefer tail-of-output substitution when
				// 'from' matches the end of accumulated output (retroactive fix).
				if ( str_ends_with( $state['output'], $from ) ) {
					$state['output']  = mb_substr( $state['output'], 0, mb_strlen( $state['output'] ) - mb_strlen( $from ) ) . $to;
					$state['handled'] = true;
					$log[] = "[LOOP RULE] tail-replace '{$from}' → '{$to}' (pos {$state['pos']})";
				} elseif ( str_contains( $state['output'], $from ) ) {
					$state['output']  = str_replace( $from, $to, $state['output'] );
					$state['handled'] = true;
					$log[] = "[LOOP RULE] replace '{$from}' → '{$to}' (pos {$state['pos']})";
				}
			}
		}
	}

	// ── Forward: Roman → Bengali-Assamese ─────────────────────────────────────

	/**
	 * @param string $input
	 * @return array{string,string[]}  [output, log]
	 */
	private function forward( string $input ): array {
		$log = array();

		// ── Pre-processing hooks ───────────────────────────────────────────────
		$input = $this->run_php_snippet_hooks( $input, 'forward', 'pre', $log );

		$lookup = $this->flatten_map(
			$this->forward_map,
			array( 'special', 'consonants', 'matras', 'independent_vowels', 'digits', 'punctuation' )
		);

		$len = mb_strlen( $input );

		// Build sorted consonant, matra, and independent-vowel lookups.
		// Used by the hardcoded core logic below.
		$consonant_map = array();
		$matra_map     = array();
		$iv_map        = array();

		$raw_cons = $this->forward_map['consonants'] ?? array();
		if ( $this->is_pairs_array( $raw_cons ) ) {
			foreach ( $raw_cons as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0], $pair[1] ) ) {
					$consonant_map[ (string) $pair[0] ] = (string) $pair[1];
				}
			}
		} else {
			foreach ( $raw_cons as $k => $v ) {
				$consonant_map[ (string) $k ] = (string) $v;
			}
		}

		$raw_matras = $this->forward_map['matras'] ?? array();
		if ( $this->is_pairs_array( $raw_matras ) ) {
			foreach ( $raw_matras as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0], $pair[1] ) ) {
					$matra_map[ (string) $pair[0] ] = (string) $pair[1];
				}
			}
		} else {
			foreach ( $raw_matras as $k => $v ) {
				$matra_map[ (string) $k ] = (string) $v;
			}
		}

		$raw_iv = $this->forward_map['independent_vowels'] ?? array();
		if ( $this->is_pairs_array( $raw_iv ) ) {
			foreach ( $raw_iv as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0], $pair[1] ) ) {
					$iv_map[ (string) $pair[0] ] = (string) $pair[1];
				}
			}
		} else {
			foreach ( $raw_iv as $k => $v ) {
				$iv_map[ (string) $k ] = (string) $v;
			}
		}

		// Sort all three longest-first.
		uksort( $consonant_map, fn( $a, $b ) => mb_strlen( $b ) - mb_strlen( $a ) );
		uksort( $matra_map,     fn( $a, $b ) => mb_strlen( $b ) - mb_strlen( $a ) );
		uksort( $iv_map,        fn( $a, $b ) => mb_strlen( $b ) - mb_strlen( $a ) );

		$sorted_cons   = array_keys( $consonant_map );
		$sorted_matras = array_keys( $matra_map );
		$sorted_iv     = array_keys( $iv_map );

		// Engine config passed to loop-stage snippet hooks.
		$config = array(
			'map'            => $this->forward_map,
			'direction'      => 'forward',
			'virama'         => $this->virama,
			'inherent_vowel' => $this->inherent_vowel,
		);

		// $state matches the JS engine's state contract.
		$state = array(
			'input'              => $input,
			'output'             => '',
			'pos'                => 0,
			'prev_was_consonant' => false,
			'prev'               => array(
				'token'         => '',
				'was_consonant' => false,
				'was_matra'     => false,
				'token_length'  => 0,
			),
			'handled'            => false,
			'log'                => &$log,
		);

		while ( $state['pos'] < $len ) {

			// Reset per-position handled flag.
			$state['handled'] = false;
			$pos              = $state['pos'];

			// ── 1. fwd_loop_atstart_independent_vowel ──────────────────────────
			// Emit independent vowel form when at word start (pos 0 or after
			// non-alpha) AND the consumed slice does not already end with a vowel
			// key (which would make it a matra handled by step 3 below).
			if ( ! $state['handled'] ) {
				$at_start = ( 0 === $pos ) || ! ctype_alpha( mb_substr( $input, $pos - 1, 1 ) );
				if ( $at_start ) {
					$consumed        = mb_substr( $input, 0, $pos );
					$prev_ends_vowel = false;
					foreach ( $sorted_iv as $vk ) {
						if ( str_ends_with( $consumed, $vk ) ) {
							$prev_ends_vowel = true;
							break;
						}
					}
					if ( ! $prev_ends_vowel ) {
						$iv_match = null;
						foreach ( $sorted_iv as $vk ) {
							if ( mb_substr( $input, $pos, mb_strlen( $vk ) ) === $vk ) {
								$iv_match = $vk;
								break;
							}
						}
						if ( null !== $iv_match ) {
							$state['output']             .= $iv_map[ $iv_match ];
							$state['pos']                += mb_strlen( $iv_match );
							$state['prev']['was_consonant'] = false;
							$state['prev_was_consonant']  = false;
							$state['handled']             = true;
							$log[]                        = "[FWD IND VOWEL] {$iv_match} → {$iv_map[$iv_match]}";
						}
					}
				}
			}

			// ── 2. loop_explicit_zwnj ──────────────────────────────────────────
			// Apostrophe in input → emit ZWNJ to break conjunct formation.
			if ( ! $state['handled'] ) {
				if ( mb_substr( $input, $state['pos'], 1 ) === "'" ) {
					$state['output']  .= $this->zwnj;
					$state['pos']     += 1;
					$state['handled']  = true;
					$log[]             = '[ZWNJ] explicit ZWNJ emitted at pos ' . $state['pos'];
				}
			}

			// ── 3. fwd_loop_consonant_plus_matra ──────────────────────────────
			// Match a consonant, then scan for an immediately following matra.
			// Sub-cases:
			//   (a) matra 'o' = inherent vowel suppressor.
			//   (b) apostrophe matra → consonant + ZWNJ.
			//   (c) y/Y matra: y-fala chaining with optional second matra.
			//   (d) all other matras: consonant + matra glyph.
			// Sets prev_was_consonant = true.
			if ( ! $state['handled'] ) {
				$c_match = null;
				foreach ( $sorted_cons as $ck ) {
					$ck_len = mb_strlen( $ck );
					if ( mb_substr( $input, $state['pos'], $ck_len ) === $ck ) {
						$c_match = $ck;
						break;
					}
				}
				if ( null !== $c_match ) {
					$next_pos    = $state['pos'] + mb_strlen( $c_match );
					$matra_match = null;
					foreach ( $sorted_matras as $mk ) {
						$mk_len = mb_strlen( $mk );
						if ( mb_substr( $input, $next_pos, $mk_len ) === $mk ) {
							$matra_match = $mk;
							break;
						}
					}
					if ( null !== $matra_match ) {
						$bpm         = $consonant_map[ $c_match ];
						$after_matra = $next_pos + mb_strlen( $matra_match );

						if ( 'o' === $matra_match ) {
							$char_after    = mb_substr( $input, $after_matra, 1 );
							$at_word_end   = ( '' === $char_after ) || ! ctype_alpha( $char_after );
							$state['output'] .= $at_word_end ? $bpm . $this->zwnj : $bpm;
							$state['pos']     = $after_matra;
						} elseif ( "'" === $matra_match ) {
							$state['output'] .= $bpm . $this->zwnj;
							$state['pos']     = $after_matra;
						} elseif ( 'y' === $matra_match || 'Y' === $matra_match ) {
							$y_value           = $matra_map[ $matra_match ] ?? '';
							$second_matra      = null;
							foreach ( $sorted_matras as $mk2 ) {
								$mk2_len = mb_strlen( $mk2 );
								if ( mb_substr( $input, $after_matra, $mk2_len ) === $mk2 ) {
									$second_matra = $mk2;
									break;
								}
							}
							if ( null !== $second_matra ) {
								if ( 'o' === $second_matra ) {
									$char_after2   = mb_substr( $input, $after_matra + mb_strlen( $second_matra ), 1 );
									$at_end2       = ( '' === $char_after2 ) || ! ctype_alpha( $char_after2 );
									$state['output'] .= $bpm . $y_value . ( $at_end2 ? $this->zwnj : '' );
								} else {
									$state['output'] .= $bpm . $y_value . ( $matra_map[ $second_matra ] ?? '' );
								}
								$state['pos'] = $after_matra + mb_strlen( $second_matra );
							} else {
								$state['output'] .= $bpm . $y_value;
								$state['pos']     = $after_matra;
							}
						} else {
							$state['output'] .= $bpm . ( $matra_map[ $matra_match ] ?? '' );
							$state['pos']     = $after_matra;
						}

						$state['prev_was_consonant']     = true;
						$state['prev']['was_consonant']  = true;
						$state['handled']                = true;
						$log[] = "[FWD CONS+MATRA] {$c_match} + {$matra_match}";
					}
				}
			}

			// ── 4. fwd_loop_consonant_cluster_halanta ─────────────────────────
			// Consonant followed by another consonant (no matra between them).
			// 'r' + consonant → reph: r + HALANTA + ZWJ.
			// 'r' + 'r'       → double-r: r + HALANTA (no ZWJ).
			// non-linking      → emit bare (no halanta).
			// Sets prev_was_consonant = true.
			if ( ! $state['handled'] ) {
				$c_match = null;
				foreach ( $sorted_cons as $ck ) {
					$ck_len = mb_strlen( $ck );
					if ( mb_substr( $input, $state['pos'], $ck_len ) === $ck ) {
						$c_match = $ck;
						break;
					}
				}
				if ( null !== $c_match ) {
					$next_pos    = $state['pos'] + mb_strlen( $c_match );
					// Only fires when there is NO matra immediately after the consonant.
					$matra_match = null;
					foreach ( $sorted_matras as $mk ) {
						$mk_len = mb_strlen( $mk );
						if ( mb_substr( $input, $next_pos, $mk_len ) === $mk ) {
							$matra_match = $mk;
							break;
						}
					}
					if ( null === $matra_match ) {
						$bpm           = $consonant_map[ $c_match ];
						$is_non_linking = in_array( $c_match, $this->non_linking_consonants, true );

						// Find next consonant.
						$next_cons = null;
						foreach ( $sorted_cons as $ck2 ) {
							$ck2_len = mb_strlen( $ck2 );
							if ( mb_substr( $input, $next_pos, $ck2_len ) === $ck2 ) {
								$next_cons = $ck2;
								break;
							}
						}

						if ( null !== $next_cons && ! $is_non_linking ) {
							if ( 'r' === $c_match && mb_substr( $input, $next_pos, 1 ) === 'r' ) {
								// rr → r + HALANTA (no ZWJ).
								$state['output'] .= $bpm . $this->virama;
							} elseif ( 'r' === $c_match ) {
								// reph: r + HALANTA + ZWJ.
								$state['output'] .= $bpm . $this->virama . $this->zwj;
							} else {
								$state['output'] .= $bpm . $this->virama;
							}
							$log[] = "[FWD CLUSTER] {$c_match}+HALANTA";
						} else {
							$state['output'] .= $bpm; // non-linking or end of cluster.
							$log[] = "[FWD CLUSTER] {$c_match} bare";
						}

						$state['pos']                    = $next_pos;
						$state['prev_was_consonant']     = true;
						$state['prev']['was_consonant']  = true;
						$state['handled']                = true;
					}
				}
			}

			if ( $state['handled'] ) {
				$state['handled'] = false;
				continue;
			}

			// ── 5. Loop-stage snippet hooks ────────────────────────────────────
			// External snippet hooks run after the hardcoded core logic above.
			// They may still set $state['handled'] = true to claim the position.
			$this->run_loop_snippet_hooks( $state, $config, 'forward', $log );

			if ( $state['handled'] ) {
				$state['handled'] = false;
				continue;
			}

			// ── 6. Core map lookup ─────────────────────────────────────────────
			// Default longest-match. Virama insertion between consecutive
			// consonants was removed from here; it is now owned exclusively
			// by fwd_loop_consonant_cluster_halanta (step 4 above).
			$matched = false;

			foreach ( $lookup as $roman => $bpm ) {
				$chunk_len = mb_strlen( $roman );
				if ( $state['pos'] + $chunk_len > $len ) {
					continue;
				}
				$chunk = mb_substr( $input, $state['pos'], $chunk_len );

				if ( $chunk === $roman ) {
					$is_consonant = $this->section_has_key( $this->forward_map, 'consonants', $roman );
					$is_matra     = $this->section_has_key( $this->forward_map, 'matras', $roman );

					$state['output'] .= $bpm;
					$log[]            = "[MATCH] '{$roman}' → '{$bpm}' (pos {$state['pos']})";

					$state['prev'] = array(
						'token'         => $roman,
						'was_consonant' => $is_consonant,
						'was_matra'     => $is_matra,
						'token_length'  => $chunk_len,
					);

					$state['pos'] += $chunk_len;
					$state['prev_was_consonant'] = $is_consonant && ! $is_matra;

					$matched = true;
					break;
				}
			}

			if ( ! $matched ) {
				$char             = mb_substr( $input, $state['pos'], 1 );
				$state['output'] .= $char;
				$log[]            = "[PASS] '{$char}' (pos {$state['pos']})";
				$state['pos']++;
				$state['prev_was_consonant'] = false;
				$state['prev'] = array(
					'token'         => $char,
					'was_consonant' => false,
					'was_matra'     => false,
					'token_length'  => 1,
				);
			}
		}

		$output = $state['output'];

		// ── Post-processing hooks ──────────────────────────────────────────────
		$output = $this->run_php_snippet_hooks( $output, 'forward', 'post', $log );

		return array( $output, $log );
	}

	// ── Reverse: Bengali-Assamese → Roman ─────────────────────────────────────

	/**
	 * @param string $input
	 * @return array{string,string[]}  [output, log]
	 */
	private function reverse( string $input ): array {
		$log = array();

		// NFC normalise.
		if ( function_exists( 'normalizer_normalize' ) ) {
			$input = normalizer_normalize( $input, Normalizer::NFC );
		}

		// ── Pre-processing hooks ───────────────────────────────────────────────
		$input = $this->run_php_snippet_hooks( $input, 'reverse', 'pre', $log );

		$lookup        = $this->flatten_map(
			$this->reverse_map,
			array( 'special', 'consonants', 'matras', 'independent_vowels', 'digits', 'punctuation' )
		);
		$consonant_bpm = $this->section_keys( $this->reverse_map, 'consonants' );
		$virama        = $this->virama;
		$inherent      = $this->inherent_vowel;

		$chars = $this->mb_str_split( $input );
		$total = count( $chars );

		// Engine config passed to loop-stage snippet hooks.
		$config = array(
			'map'            => $this->reverse_map,
			'direction'      => 'reverse',
			'virama'         => $virama,
			'inherent_vowel' => $inherent,
		);

		// $state matches the JS engine's state contract (reverse direction).
		$state = array(
			'input'              => $input,
			'output'             => '',
			'pos'                => 0,
			'prev_was_consonant' => false,
			'prev'               => array(
				'token'         => '',
				'was_consonant' => false,
				'was_matra'     => false,
				'token_length'  => 0,
			),
			'handled'            => false,
			'log'                => &$log,
		);

		while ( $state['pos'] < $total ) {

			// Reset per-position handled flag.
			$state['handled'] = false;

			// ── Loop-stage snippet hooks ───────────────────────────────────────
			$this->run_loop_snippet_hooks( $state, $config, 'reverse', $log );

			if ( $state['handled'] ) {
				$state['handled'] = false;
				continue;
			}

			// ── Core map lookup ───────────────────────────────────────────────
			$matched = false;

			foreach ( $lookup as $bpm => $roman ) {
				$bpm_len = mb_strlen( $bpm );
				$slice   = implode( '', array_slice( $chars, $state['pos'], $bpm_len ) );

				if ( $slice === $bpm ) {
					$is_consonant     = in_array( $bpm, $consonant_bpm, true );
					$state['output'] .= $roman;

					if ( $is_consonant ) {
						$next_char      = $chars[ $state['pos'] + $bpm_len ] ?? '';
						$is_next_matra  = $this->section_has_key( $this->reverse_map, 'matras', $next_char );
						$is_next_virama = ( $next_char === $virama );
						if ( ! $is_next_matra && ! $is_next_virama ) {
							$state['output'] .= $inherent;
							$log[]            = "[INHERENT] after '{$bpm}'";
						}
					}

					$log[] = "[MATCH] '{$bpm}' → '{$roman}' (i={$state['pos']})";

					$state['prev'] = array(
						'token'         => $bpm,
						'was_consonant' => $is_consonant,
						'was_matra'     => false,
						'token_length'  => $bpm_len,
					);

					$state['pos']               += $bpm_len;
					$state['prev_was_consonant']  = $is_consonant;

					$matched = true;
					break;
				}
			}

			if ( ! $matched ) {
				$state['output'] .= $chars[ $state['pos'] ];
				$log[]            = "[PASS] '{$chars[$state['pos']]}' (i={$state['pos']})";
				$state['prev'] = array(
					'token'         => $chars[ $state['pos'] ],
					'was_consonant' => false,
					'was_matra'     => false,
					'token_length'  => 1,
				);
				$state['pos']++;
				$state['prev_was_consonant'] = false;
			}
		}

		$output = $state['output'];

		// ── Post-processing hooks ──────────────────────────────────────────────
		$output = $this->run_php_snippet_hooks( $output, 'reverse', 'post', $log );

		return array( $output, $log );
	}

	// ── Map helpers ───────────────────────────────────────────────────────────

	/**
	 * Flatten map sections into a sorted lookup array (longest-match-first).
	 *
	 * @param array    $map
	 * @param string[] $sections
	 * @return array<string,string>
	 */
	private function flatten_map( array $map, array $sections ): array {
		$items = array();
		$pos   = 0;

		foreach ( $sections as $section ) {
			$raw = $map[ $section ] ?? array();
			if ( ! is_array( $raw ) || empty( $raw ) ) {
				continue;
			}

			if ( $this->is_pairs_array( $raw ) ) {
				foreach ( $raw as $pair ) {
					if ( is_array( $pair ) && isset( $pair[0] ) && '_meta' !== $pair[0] ) {
						$items[] = array( (string) $pair[0], (string) $pair[1], $pos++ );
					}
				}
			} else {
				foreach ( $raw as $k => $v ) {
					if ( '_meta' !== $k ) {
						$items[] = array( (string) $k, (string) $v, $pos++ );
					}
				}
			}
		}

		usort(
			$items,
			function ( $a, $b ) {
				$len_diff = mb_strlen( $b[0] ) - mb_strlen( $a[0] );
				return 0 !== $len_diff ? $len_diff : ( $a[2] - $b[2] );
			}
		);

		$flat = array();
		foreach ( $items as list( $k, $v ) ) {
			if ( ! array_key_exists( $k, $flat ) ) {
				$flat[ $k ] = $v;
			}
		}

		return $flat;
	}

	/**
	 * Return all keys from a map section as a plain array.
	 *
	 * @param array  $map
	 * @param string $section
	 * @return string[]
	 */
	private function section_keys( array $map, string $section ): array {
		$raw  = $map[ $section ] ?? array();
		$keys = array();
		if ( ! is_array( $raw ) ) {
			return $keys;
		}

		if ( $this->is_pairs_array( $raw ) ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0] ) ) {
					$keys[] = (string) $pair[0];
				}
			}
		} else {
			$keys = array_keys( $raw );
		}

		return $keys;
	}

	/**
	 * Check if a key exists in a map section.
	 *
	 * @param array  $map
	 * @param string $section
	 * @param string $key
	 * @return bool
	 */
	private function section_has_key( array $map, string $section, string $key ): bool {
		$raw = $map[ $section ] ?? array();
		if ( ! is_array( $raw ) ) {
			return false;
		}

		if ( $this->is_pairs_array( $raw ) ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0] ) && (string) $pair[0] === $key ) {
					return true;
				}
			}
			return false;
		}

		return array_key_exists( $key, $raw );
	}

	/**
	 * Detect whether an array is a v2 pairs array (list of [from,to] pairs).
	 *
	 * @param array $arr
	 * @return bool
	 */
	private function is_pairs_array( array $arr ): bool {
		if ( ! array_is_list( $arr ) ) {
			return false;
		}
		foreach ( $arr as $item ) {
			if ( null === $item ) {
				continue;
			}
			return is_array( $item ) && array_is_list( $item ) && count( $item ) >= 2;
		}
		return false;
	}

	/**
	 * Split a multibyte string into an array of Unicode characters.
	 *
	 * @param string $str
	 * @return string[]
	 */
	private function mb_str_split( string $str ): array {
		return preg_split( '//u', $str, -1, PREG_SPLIT_NO_EMPTY ) ?: array();
	}
}
