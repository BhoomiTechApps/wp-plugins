<?php
/**
 * Frontend shortcode for public-facing transliteration + per-user panel.
 *
 * Shortcode:
 *   [bpm_transliterator]  — Transliterator widget + Snippets & Lexicon tabs
 *                           for logged-in cplai_transliterator / manage_options users.
 *                           Non-authorised visitors see the widget only;
 *                           non-logged-in visitors see a login prompt for the panel.
 *
 * Removed:
 *   [bpm_researcher_panel] shortcode and all researcher assets.
 *   add_admin_bar_link method.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the [bpm_transliterator] shortcode.
 */
class CPLAI_Frontend {

	/** Tracks whether transliterator assets have been enqueued. */
	private static bool $assets_enqueued = false;

	/** Tracks whether frontend-panel assets have been enqueued. */
	private static bool $panel_assets_enqueued = false;

	/** Instance counter for unique widget IDs. */
	private static int $instance = 0;

	public function __construct() {
		add_shortcode( 'bpm_transliterator', array( $this, 'render_shortcode' ) );
	}

	// ── Access helper ─────────────────────────────────────────────────────────

	/**
	 * Returns true if the current user may access the transliterator panel.
	 */
	private static function user_can_panel(): bool {
		return is_user_logged_in() &&
		       ( current_user_can( 'cplai_transliterator' ) || current_user_can( 'manage_options' ) );
	}

	// ── [bpm_transliterator] shortcode ────────────────────────────────────────

	/**
	 * Renders the transliterator widget HTML, plus the Snippets + Lexicon panel
	 * for authorised users.
	 *
	 * @param array|string $atts Shortcode attributes.
	 * @return string HTML output.
	 */
	public function render_shortcode( $atts ): string {
		$atts = shortcode_atts(
			array(
				'direction'   => 'both',
				'engine'      => 'php',
				'placeholder' => __( 'Type Roman text here…', 'compiling-ai' ),
			),
			$atts,
			'bpm_transliterator'
		);

		// Sanitise.
		$direction   = in_array( $atts['direction'], array( 'forward', 'reverse', 'both' ), true )
			? $atts['direction'] : 'forward';
		$placeholder = esc_attr( sanitize_text_field( $atts['placeholder'] ) );

		// Enqueue assets once.
		$this->maybe_enqueue_assets( $direction );

		// Unique widget ID.
		self::$instance++;
		$widget_id = 'bpm-transliterator-' . self::$instance;

		// Labels.
		$dir_label_forward = esc_html__( 'Roman → BPM', 'compiling-ai' );
		$dir_label_reverse = esc_html__( 'BPM → Roman', 'compiling-ai' );
		$input_label       = esc_html__( 'Input', 'compiling-ai' );
		$output_label      = esc_html__( 'Output', 'compiling-ai' );
		$copy_label        = esc_html__( 'Copy', 'compiling-ai' );
		$clear_label       = esc_html__( 'Clear', 'compiling-ai' );
		$toggle_label      = ( 'both' === $direction )
			? esc_html__( 'Switch Direction', 'compiling-ai' )
			: ( 'forward' === $direction ? $dir_label_forward : $dir_label_reverse );

		ob_start();
		?>
		<div id="<?php echo esc_attr( $widget_id ); ?>"
			class="bpm-transliterator-widget"
			data-direction="<?php echo esc_attr( 'both' === $direction ? 'forward' : $direction ); ?>"
			data-mode="<?php echo esc_attr( $direction ); ?>"
			data-engine="<?php echo esc_attr( $atts['engine'] ); ?>">

			<div class="bpm-tr-header">
				<span class="bpm-tr-brand">
					<span class="dashicons dashicons-translation"></span>
					<?php esc_html_e( 'BPM Transliterator', 'compiling-ai' ); ?>
				</span>

				<?php if ( 'both' === $direction ) : ?>
				<button type="button" class="bpm-tr-toggle-dir" title="<?php echo $toggle_label; ?>">
					<span class="bpm-tr-dir-label"><?php echo $dir_label_forward; ?></span>
					<span class="dashicons dashicons-randomize"></span>
				</button>
				<?php else : ?>
				<span class="bpm-tr-dir-badge"><?php echo $toggle_label; ?></span>
				<?php endif; ?>

				<button type="button" class="bpm-tr-toggle-engine" title="<?php esc_attr_e( 'Switch engine', 'compiling-ai' ); ?>">
					<span class="dashicons dashicons-superhero-alt"></span>
					<span class="bpm-tr-engine-label"><?php echo esc_html( strtoupper( $atts['engine'] ) ); ?></span>
				</button>
			</div>

			<div class="bpm-tr-body">
				<div class="bpm-tr-panel bpm-tr-input-panel">
					<label class="bpm-tr-panel-label" for="<?php echo esc_attr( $widget_id ); ?>-input">
						<?php echo $input_label; ?>
					</label>
					<textarea
						id="<?php echo esc_attr( $widget_id ); ?>-input"
						class="bpm-tr-input"
						placeholder="<?php echo $placeholder; ?>"
						rows="5"
						spellcheck="false"
					></textarea>
				</div>

				<div class="bpm-tr-divider" aria-hidden="true">
					<span class="bpm-tr-arrow dashicons dashicons-arrow-right-alt"></span>
				</div>

				<div class="bpm-tr-panel bpm-tr-output-panel">
					<label class="bpm-tr-panel-label" for="<?php echo esc_attr( $widget_id ); ?>-output">
						<?php echo $output_label; ?>
					</label>
					<div
						id="<?php echo esc_attr( $widget_id ); ?>-output"
						class="bpm-tr-output"
						aria-live="polite"
					></div>
					<div class="bpm-tr-spinner" aria-hidden="true"></div>
				</div>
			</div>

			<div class="bpm-tr-footer">
				<button type="button" class="bpm-tr-btn bpm-tr-btn-copy" disabled>
					<span class="dashicons dashicons-clipboard"></span> <?php echo $copy_label; ?>
				</button>
				<button type="button" class="bpm-tr-btn bpm-tr-btn-clear">
					<span class="dashicons dashicons-trash"></span> <?php echo $clear_label; ?>
				</button>
				<span class="bpm-tr-status" aria-live="polite"></span>
			</div>

		</div>
		<?php

		// ── Panel section (below the widget) ──────────────────────────────────
		echo $this->render_panel();

		return ob_get_clean();
	}

	// ── Panel HTML ────────────────────────────────────────────────────────────

	/**
	 * Renders the Snippets + Lexicon panel, or appropriate notices.
	 */
	private function render_panel(): string {
		// Not logged in — show login prompt.
		if ( ! is_user_logged_in() ) {
			return '<div class="bpm-fp-login-notice">' .
				'<p>' . esc_html__( 'Please log in to access the transliterator panel.', 'compiling-ai' ) . '</p>' .
				'<a href="' . esc_url( wp_login_url( get_permalink() ) ) . '" class="bpm-fp-login-link">' .
				esc_html__( 'Log in', 'compiling-ai' ) . '</a>' .
				'</div>';
		}

		// Logged in but no permission — silent (don't expose capability names).
		if ( ! self::user_can_panel() ) {
			return '';
		}

		$this->maybe_enqueue_panel_assets();

		$is_admin = current_user_can( 'manage_options' );

		ob_start();
		?>
		<div class="bpm-frontend-panel" id="bpm-frontend-panel">

			<!-- Tab nav -->
			<nav class="bpm-fp-tabs" role="tablist">
				<button class="bpm-fp-tab active" data-tab="transliterator" role="tab"
					aria-controls="bpm-fp-tab-transliterator" aria-selected="true">
					<?php esc_html_e( '⇄ Transliterator', 'compiling-ai' ); ?>
				</button>
				<button class="bpm-fp-tab" data-tab="snippets" role="tab"
					aria-controls="bpm-fp-tab-snippets" aria-selected="false">
					<?php esc_html_e( '🧩 Snippets', 'compiling-ai' ); ?>
				</button>
				<button class="bpm-fp-tab" data-tab="lexicon" role="tab"
					aria-controls="bpm-fp-tab-lexicon" aria-selected="false">
					<?php esc_html_e( '📖 Lexicon', 'compiling-ai' ); ?>
				</button>
			</nav>

			<!-- Message bar -->
			<div class="bpm-fp-msg" id="bpm-fp-msg" style="display:none;" role="alert"></div>

			<!-- ── Transliterator tab ── -->
			<div class="bpm-fp-panel active" id="bpm-fp-tab-transliterator" role="tabpanel">
				<div class="bpm-fp-toolbar bpm-fp-toolbar--transliterator">
					<label for="bpm-fp-active-direction"><?php esc_html_e( 'Active direction:', 'compiling-ai' ); ?></label>
					<select id="bpm-fp-active-direction">
						<option value="forward"><?php esc_html_e( 'Forward — Roman → BPM', 'compiling-ai' ); ?></option>
						<option value="reverse"><?php esc_html_e( 'Reverse — BPM → Roman', 'compiling-ai' ); ?></option>
					</select>
					<button type="button" class="bpm-fp-btn bpm-fp-btn-secondary" id="bpm-fp-btn-swap-dir">
						<?php esc_html_e( '⇄ Swap', 'compiling-ai' ); ?>
					</button>
				</div>
				<p class="bpm-fp-tr-hint">
					<?php esc_html_e( 'Changing the direction above updates the transliterator widget on this page in real time.', 'compiling-ai' ); ?>
				</p>
			</div>

			<!-- ── Snippets tab ── -->
			<div class="bpm-fp-panel" id="bpm-fp-tab-snippets" role="tabpanel">
				<div class="bpm-fp-toolbar">
					<select id="bpm-fp-snip-dir">
						<option value=""><?php esc_html_e( 'All directions', 'compiling-ai' ); ?></option>
						<option value="forward"><?php esc_html_e( 'Forward', 'compiling-ai' ); ?></option>
						<option value="reverse"><?php esc_html_e( 'Reverse', 'compiling-ai' ); ?></option>
						<option value="both"><?php esc_html_e( 'Both', 'compiling-ai' ); ?></option>
					</select>
					<select id="bpm-fp-snip-stage">
						<option value=""><?php esc_html_e( 'All stages', 'compiling-ai' ); ?></option>
						<option value="pre"><?php esc_html_e( 'Pre', 'compiling-ai' ); ?></option>
						<option value="loop"><?php esc_html_e( 'Loop', 'compiling-ai' ); ?></option>
						<option value="post"><?php esc_html_e( 'Post', 'compiling-ai' ); ?></option>
					</select>
					<button class="bpm-fp-btn" id="bpm-fp-btn-load-snippets">
						<?php esc_html_e( 'Load', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-secondary" id="bpm-fp-btn-seed-snippets">
						<?php esc_html_e( 'Load Defaults', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-add" id="bpm-fp-btn-add-snippet">
						<?php esc_html_e( '+ Add Snippet', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-danger" id="bpm-fp-btn-clear-snippets">
						<?php esc_html_e( '🗑 Clear All', 'compiling-ai' ); ?>
					</button>
				</div>

				<div class="bpm-fp-table-wrap">
					<table class="bpm-fp-table" id="bpm-fp-snip-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Key', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Label', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Direction', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Stage', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Source', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Active', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'compiling-ai' ); ?></th>
							</tr>
						</thead>
						<tbody id="bpm-fp-snip-tbody">
							<tr><td colspan="7" class="bpm-fp-placeholder">
								<?php esc_html_e( 'Click Load to fetch your snippets.', 'compiling-ai' ); ?>
							</td></tr>
						</tbody>
					</table>
				</div>
			</div>

			<!-- ── Lexicon tab ── -->
			<div class="bpm-fp-panel" id="bpm-fp-tab-lexicon" role="tabpanel">
				<div class="bpm-fp-toolbar">
					<select id="bpm-fp-lex-dir">
						<option value="forward"><?php esc_html_e( 'Forward map', 'compiling-ai' ); ?></option>
						<option value="reverse"><?php esc_html_e( 'Reverse map', 'compiling-ai' ); ?></option>
					</select>
					<input type="text" id="bpm-fp-lex-search"
						placeholder="<?php esc_attr_e( 'Filter entries…', 'compiling-ai' ); ?>" />
					<button class="bpm-fp-btn" id="bpm-fp-btn-load-lexicon">
						<?php esc_html_e( 'Load', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-secondary" id="bpm-fp-btn-seed-lexicon">
						<?php esc_html_e( 'Load Defaults', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-add" id="bpm-fp-btn-add-lex">
						<?php esc_html_e( '+ Add Entry', 'compiling-ai' ); ?>
					</button>
					<button class="bpm-fp-btn bpm-fp-btn-danger" id="bpm-fp-btn-clear-lexicon">
						<?php esc_html_e( '🗑 Clear All', 'compiling-ai' ); ?>
					</button>
				</div>

				<div class="bpm-fp-table-wrap">
					<table class="bpm-fp-table" id="bpm-fp-lex-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'From', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'To', 'compiling-ai' ); ?></th>
								<th><?php esc_html_e( 'Actions', 'compiling-ai' ); ?></th>
							</tr>
						</thead>
						<tbody id="bpm-fp-lex-tbody">
							<tr><td colspan="3" class="bpm-fp-placeholder">
								<?php esc_html_e( 'Select a direction and click Load.', 'compiling-ai' ); ?>
							</td></tr>
						</tbody>
					</table>
				</div>
			</div>

			<?php if ( $is_admin ) : ?>
			<!-- Admin link -->
			<div class="bpm-fp-admin-link">
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=cplai-lab' ) ); ?>">
					<?php esc_html_e( 'Edit in Lab →', 'compiling-ai' ); ?>
				</a>
			</div>
			<?php endif; ?>

		</div><!-- .bpm-frontend-panel -->

		<!-- Snippet edit modal -->
		<div class="bpm-fp-modal" id="bpm-fp-snip-modal" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="bpm-fp-modal-title">
			<div class="bpm-fp-modal-inner">
				<div class="bpm-fp-modal-header">
					<h3 id="bpm-fp-modal-title"><?php esc_html_e( 'Snippet', 'compiling-ai' ); ?></h3>
					<button class="bpm-fp-modal-close" id="bpm-fp-modal-close" aria-label="<?php esc_attr_e( 'Close', 'compiling-ai' ); ?>">&times;</button>
				</div>
				<div class="bpm-fp-modal-body">
					<input type="hidden" id="bpm-fp-modal-snip-id" value="" />
					<div class="bpm-fp-field">
						<label for="bpm-fp-modal-snip-key"><?php esc_html_e( 'Key', 'compiling-ai' ); ?></label>
						<input type="text" id="bpm-fp-modal-snip-key" placeholder="my_snippet_key" />
					</div>
					<div class="bpm-fp-field">
						<label for="bpm-fp-modal-snip-label"><?php esc_html_e( 'Label', 'compiling-ai' ); ?></label>
						<input type="text" id="bpm-fp-modal-snip-label" />
					</div>
					<div class="bpm-fp-field-row">
						<div class="bpm-fp-field">
							<label for="bpm-fp-modal-snip-dir"><?php esc_html_e( 'Direction', 'compiling-ai' ); ?></label>
							<select id="bpm-fp-modal-snip-dir">
								<option value="both"><?php esc_html_e( 'Both', 'compiling-ai' ); ?></option>
								<option value="forward"><?php esc_html_e( 'Forward', 'compiling-ai' ); ?></option>
								<option value="reverse"><?php esc_html_e( 'Reverse', 'compiling-ai' ); ?></option>
							</select>
						</div>
						<div class="bpm-fp-field">
							<label for="bpm-fp-modal-snip-stage"><?php esc_html_e( 'Stage', 'compiling-ai' ); ?></label>
							<select id="bpm-fp-modal-snip-stage">
								<option value="pre"><?php esc_html_e( 'Pre', 'compiling-ai' ); ?></option>
								<option value="loop"><?php esc_html_e( 'Loop', 'compiling-ai' ); ?></option>
								<option value="post"><?php esc_html_e( 'Post', 'compiling-ai' ); ?></option>
							</select>
						</div>
					</div>
					<div class="bpm-fp-field">
						<label for="bpm-fp-modal-snip-desc"><?php esc_html_e( 'Description', 'compiling-ai' ); ?></label>
						<textarea id="bpm-fp-modal-snip-desc" rows="2"></textarea>
					</div>
					<div class="bpm-fp-field">
						<label for="bpm-fp-modal-snip-js"><?php esc_html_e( 'JS Body', 'compiling-ai' ); ?></label>
						<textarea id="bpm-fp-modal-snip-js" rows="5" class="bpm-fp-code"></textarea>
					</div>
					<div class="bpm-fp-field">
						<label for="bpm-fp-modal-snip-php"><?php esc_html_e( 'PHP Body', 'compiling-ai' ); ?></label>
						<textarea id="bpm-fp-modal-snip-php" rows="5" class="bpm-fp-code"></textarea>
					</div>
				</div>
				<div class="bpm-fp-modal-footer">
					<button class="bpm-fp-btn" id="bpm-fp-modal-save"><?php esc_html_e( 'Save', 'compiling-ai' ); ?></button>
					<button class="bpm-fp-btn bpm-fp-btn-ghost" id="bpm-fp-modal-cancel"><?php esc_html_e( 'Cancel', 'compiling-ai' ); ?></button>
				</div>
			</div>
		</div>

		<!-- Lexicon entry edit modal -->
		<div class="bpm-fp-modal" id="bpm-fp-lex-modal" style="display:none;" role="dialog" aria-modal="true" aria-labelledby="bpm-fp-lex-modal-title">
			<div class="bpm-fp-modal-inner bpm-fp-modal-inner--sm">
				<div class="bpm-fp-modal-header">
					<h3 id="bpm-fp-lex-modal-title"><?php esc_html_e( 'Lexicon Entry', 'compiling-ai' ); ?></h3>
					<button class="bpm-fp-modal-close" id="bpm-fp-lex-modal-close" aria-label="<?php esc_attr_e( 'Close', 'compiling-ai' ); ?>">&times;</button>
				</div>
				<div class="bpm-fp-modal-body">
					<input type="hidden" id="bpm-fp-lex-modal-id" value="" />
					<div class="bpm-fp-field">
						<label for="bpm-fp-lex-modal-from"><?php esc_html_e( 'From', 'compiling-ai' ); ?></label>
						<input type="text" id="bpm-fp-lex-modal-from" />
					</div>
					<div class="bpm-fp-field">
						<label for="bpm-fp-lex-modal-to"><?php esc_html_e( 'To', 'compiling-ai' ); ?></label>
						<input type="text" id="bpm-fp-lex-modal-to" />
					</div>
				</div>
				<div class="bpm-fp-modal-footer">
					<button class="bpm-fp-btn" id="bpm-fp-lex-modal-save"><?php esc_html_e( 'Save', 'compiling-ai' ); ?></button>
					<button class="bpm-fp-btn bpm-fp-btn-ghost" id="bpm-fp-lex-modal-cancel"><?php esc_html_e( 'Cancel', 'compiling-ai' ); ?></button>
				</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	// ── Asset enqueuing ───────────────────────────────────────────────────────

	/**
	 * Enqueues transliterator frontend CSS and JS once per page load.
	 */
	private function maybe_enqueue_assets( string $direction ): void {
		if ( self::$assets_enqueued ) {
			return;
		}
		self::$assets_enqueued = true;

		wp_enqueue_style( 'dashicons' );

		wp_enqueue_style(
			'cplai-frontend',
			CPLAI_URL . 'assets/css/frontend.css',
			array( 'dashicons' ),
			CPLAI_VERSION
		);

		wp_enqueue_script(
			'cplai-engine',
			CPLAI_URL . 'assets/js/engine.js',
			array(),
			CPLAI_VERSION,
			true
		);

		wp_enqueue_script(
			'cplai-frontend',
			CPLAI_URL . 'assets/js/frontend.js',
			array( 'cplai-engine' ),
			CPLAI_VERSION,
			true
		);

		wp_localize_script(
			'cplai-frontend',
			'CPLAI_Frontend',
			array(
				'rest_url'      => rest_url( 'cplai/v1/public/transliterate' ),
				'rest_url_base' => rest_url( 'cplai/v1/' ),
				'nonce'         => wp_create_nonce( 'wp_rest' ),
				'direction'     => $direction,
				'debug'         => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '1' : '0',
			)
		);
	}

	/**
	 * Enqueues frontend-panel CSS and JS once per page load.
	 */
	private function maybe_enqueue_panel_assets(): void {
		if ( self::$panel_assets_enqueued ) {
			return;
		}
		self::$panel_assets_enqueued = true;

		wp_enqueue_style(
			'cplai-frontend-panel',
			CPLAI_URL . 'assets/css/frontend-panel.css',
			array(),
			CPLAI_VERSION
		);

		wp_enqueue_script(
			'cplai-frontend-panel',
			CPLAI_URL . 'assets/js/frontend-panel.js',
			array(),
			CPLAI_VERSION,
			true
		);

		wp_localize_script(
			'cplai-frontend-panel',
			'CPLAI_FrontendPanel',
			array(
				'rest_url' => rest_url( 'cplai/v1/' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'debug'    => ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '1' : '0',
			)
		);
	}
}
