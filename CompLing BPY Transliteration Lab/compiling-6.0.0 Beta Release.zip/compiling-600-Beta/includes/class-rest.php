<?php
/**
 * REST API routes for CompLing AI v5.
 *
 * New in v5 (architectural remodel):
 *  - /researcher/* routes REMOVED (researcher role removed).
 *  - New /user/* routes for per-user replicate CRUD:
 *      GET/POST/PUT/DELETE  /user/snippets
 *      GET/POST/PUT/DELETE  /user/lexicon
 *      POST                 /user/snippets/seed
 *      POST                 /user/lexicon/seed
 *      POST                 /user/transliterate  (uses only user's replicate snippets)
 *  - check_transliterator() permission: is_user_logged_in() + (cplai_transliterator OR manage_options)
 *
 * All other routes (maps, snippets, test, status, settings, lexicon, public) are unchanged.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles all REST API routes.
 */
class CPLAI_Rest {

	// ── Route registration ────────────────────────────────────────────────────

	public static function register_routes(): void {
		$ns = 'cplai/v1';

		// ── Maps ──────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/maps', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_maps' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/upload', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'upload_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/(?P<id>\d+)/activate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'activate_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/(?P<id>\d+)', array(
			'methods'             => 'DELETE',
			'callback'            => array( __CLASS__, 'delete_map' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/save-edit', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'save_edit' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/maps/restore-default', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'restore_default' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Snippets ──────────────────────────────────────────────────────────
		register_rest_route( $ns, '/snippets', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_snippets' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/active', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_active_snippets' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
			'args'                => array(
				'direction' => array(
					'required'          => true,
					'sanitize_callback' => 'sanitize_text_field',
					'validate_callback' => function ( $v ) {
						return in_array( $v, array( 'forward', 'reverse' ), true );
					},
				),
			),
		) );
		register_rest_route( $ns, '/snippets/generate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_generate' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/sync-defaults', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_sync_defaults' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/save', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_save' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)/toggle', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_toggle' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)/reorder', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'snippets_reorder' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );
		register_rest_route( $ns, '/snippets/(?P<id>\d+)', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'snippets_get_one' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'snippets_update' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'snippets_delete' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
		) );

		// ── Test ──────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/test/run', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'test_run' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Status ────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/status', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_status' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Lexicon ───────────────────────────────────────────────────────────
		register_rest_route( $ns, '/lexicon', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'get_lexicon' ),
			'permission_callback' => array( __CLASS__, 'check_admin' ),
		) );

		// ── Settings ──────────────────────────────────────────────────────────
		register_rest_route( $ns, '/settings', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'get_settings' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'save_settings' ),
				'permission_callback' => array( __CLASS__, 'check_admin' ),
			),
		) );

		// ── Public transliteration (no auth required) ─────────────────────────
		register_rest_route( $ns, '/public/transliterate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'public_transliterate' ),
			'permission_callback' => '__return_true',
		) );

		// ══════════════════════════════════════════════════════════════════════
		// USER / REPLICATE ROUTES  (requires cplai_transliterator OR manage_options)
		// ══════════════════════════════════════════════════════════════════════

		// ── User transliteration (uses only user's replicate snippets) ─────────
		register_rest_route( $ns, '/user/transliterate', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'user_transliterate' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );

		// ── User snippets CRUD ─────────────────────────────────────────────────
		register_rest_route( $ns, '/user/snippets/seed', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'user_snippets_seed' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );
		register_rest_route( $ns, '/user/snippets', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'user_snippets_list' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'user_snippets_create' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
		) );
		register_rest_route( $ns, '/user/snippets/(?P<id>\d+)/toggle', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'user_snippets_toggle' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );
		register_rest_route( $ns, '/user/snippets/(?P<id>\d+)', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'user_snippets_get_one' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'user_snippets_update' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'user_snippets_delete' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
		) );

		// ── User bulk-clear ────────────────────────────────────────────────────
		register_rest_route( $ns, '/user/snippets/clear', array(
			'methods'             => 'DELETE',
			'callback'            => array( __CLASS__, 'user_snippets_clear' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );
		register_rest_route( $ns, '/user/lexicon/clear', array(
			'methods'             => 'DELETE',
			'callback'            => array( __CLASS__, 'user_lexicon_clear' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );

		// ── User JS-engine helpers ─────────────────────────────────────────────
		// GET /user/snippets/active — active snippets for the JS engine, scoped to current user.
		register_rest_route( $ns, '/user/snippets/active', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'user_get_active_snippets' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );
		// GET /user/lexicon/maps — forward+reverse maps for the JS engine, scoped to current user.
		register_rest_route( $ns, '/user/lexicon/maps', array(
			'methods'             => 'GET',
			'callback'            => array( __CLASS__, 'user_get_lexicon_maps' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );

		// ── User lexicon CRUD ──────────────────────────────────────────────────
		register_rest_route( $ns, '/user/lexicon/seed', array(
			'methods'             => 'POST',
			'callback'            => array( __CLASS__, 'user_lexicon_seed' ),
			'permission_callback' => array( __CLASS__, 'check_transliterator' ),
		) );
		register_rest_route( $ns, '/user/lexicon', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'user_lexicon_list' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'user_lexicon_create' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
		) );
		register_rest_route( $ns, '/user/lexicon/(?P<id>\d+)', array(
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'user_lexicon_get_one' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'PUT',
				'callback'            => array( __CLASS__, 'user_lexicon_update' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'user_lexicon_delete' ),
				'permission_callback' => array( __CLASS__, 'check_transliterator' ),
			),
		) );
	}

	// ── Permission checks ──────────────────────────────────────────────────────

	public static function check_admin( WP_REST_Request $req ): bool {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Transliterator permission: logged-in cplai_transliterator OR admin.
	 */
	public static function check_transliterator( WP_REST_Request $req ): bool {
		return is_user_logged_in() &&
		       ( current_user_can( 'cplai_transliterator' ) || current_user_can( 'manage_options' ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// USER TRANSLITERATION
	// Uses only the current user's replicate snippets — NO fallback to main DB.
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * POST /user/transliterate
	 * Body: { input_text, direction }
	 * Uses only cplai_user_snippets WHERE user_id = current_user_id AND is_active = 1.
	 * NO fallback — returns a 422 error when the user has no active snippets.
	 */
	public static function user_transliterate( WP_REST_Request $req ): WP_REST_Response {
		$input_text = sanitize_textarea_field( (string) ( $req->get_param( 'input_text' ) ?? '' ) );
		$direction  = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'forward' );

		if ( is_wp_error( $direction ) ) {
			return self::error( 'invalid_direction', $direction->get_error_message(), 400 );
		}
		if ( empty( $input_text ) ) {
			return self::error( 'empty_input', 'input_text is required', 400 );
		}

		$user_id  = get_current_user_id();
		$snippets = self::get_user_active_snippets_for_engine( $user_id, $direction );

		// No fallback — block transliteration when the user has no active snippets.
		if ( empty( $snippets ) ) {
			return self::error(
				'no_snippets',
				'No snippets found, Load from Default',
				422
			);
		}

		$engine = new CPLAI_Engine();
		$result = $engine->transliterate( $input_text, $direction, $snippets );

		return rest_ensure_response( array(
			'success'   => true,
			'output'    => $result['output'],
			'direction' => $direction,
		) );
	}

	/**
	 * Fetch active user snippets formatted for CPLAI_Engine consumption.
	 * Returns an array of snippet rows (objects) scoped to user_id.
	 */
	private static function get_user_active_snippets_for_engine( int $user_id, string $direction ): array {
		global $wpdb;
		$table = CPLAI_Installer::table_user_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		return (array) $wpdb->get_results(
			$wpdb->prepare(
				"SELECT snippet_key, label, hook_stage, js_body, php_body, sort_order
				 FROM `{$table}`
				 WHERE user_id  = %d
				   AND is_active = 1
				   AND ( direction = %s OR direction = 'both' )
				 ORDER BY hook_stage, sort_order ASC, id ASC",
				$user_id,
				$direction
			)
		);
	}

	// ══════════════════════════════════════════════════════════════════════════
	// USER BULK-CLEAR
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * DELETE /user/snippets/clear
	 * Deletes ALL snippet rows belonging to the current user.
	 */
	public static function user_snippets_clear( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$table   = CPLAI_Installer::table_user_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$deleted = $wpdb->delete( $table, array( 'user_id' => $user_id ), array( '%d' ) );

		if ( false === $deleted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}

		return rest_ensure_response( array( 'success' => true, 'deleted' => (int) $deleted ) );
	}

	/**
	 * DELETE /user/lexicon/clear
	 * Deletes ALL lexicon rows (both forward and reverse) belonging to the current user.
	 * Query param: direction = 'forward'|'reverse'|'both' (default 'both')
	 */
	public static function user_lexicon_clear( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward, reverse, or both', 400 );
		}

		$deleted = 0;
		$dirs    = ( 'both' === $direction ) ? array( 'forward', 'reverse' ) : array( $direction );

		foreach ( $dirs as $dir ) {
			$table = ( 'forward' === $dir )
				? CPLAI_Installer::table_user_fwd_lexicon()
				: CPLAI_Installer::table_user_rev_lexicon();

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$result = $wpdb->delete( $table, array( 'user_id' => $user_id ), array( '%d' ) );

			if ( false === $result ) {
				return self::error( 'db_error', $wpdb->last_error, 500 );
			}

			$deleted += (int) $result;
		}

		return rest_ensure_response( array( 'success' => true, 'deleted' => $deleted ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// USER JS-ENGINE HELPERS
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * GET /user/snippets/active
	 * Returns active snippets for the JS engine scoped to the current user.
	 * Mirrors the shape of get_active_snippets() but queries cplai_user_snippets.
	 * NO fallback — includes a `has_snippets` boolean so the JS engine can block
	 * transliteration and prompt the user when their snippet workspace is empty.
	 */
	public static function user_get_active_snippets( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) $req->get_param( 'direction' ) );
		$table     = CPLAI_Installer::table_user_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT snippet_key, label, hook_stage, js_body
				 FROM `{$table}`
				 WHERE user_id  = %d
				   AND is_active = 1
				   AND ( direction = %s OR direction = 'both' )
				   AND js_body IS NOT NULL
				   AND js_body != ''
				 ORDER BY hook_stage, sort_order ASC, id ASC",
				$user_id,
				$direction
			)
		);

		$grouped = array( 'pre' => array(), 'loop' => array(), 'post' => array() );
		foreach ( (array) $rows as $row ) {
			$stage = $row->hook_stage;
			if ( isset( $grouped[ $stage ] ) ) {
				$grouped[ $stage ][] = array(
					'snippet_key' => $row->snippet_key,
					'label'       => $row->label,
					'js_body'     => $row->js_body,
				);
			}
		}

		$has_snippets = ! empty( $rows );

		return rest_ensure_response( array(
			'success'      => true,
			'has_snippets' => $has_snippets,
			'direction'    => $direction,
			'pre'          => $grouped['pre'],
			'loop'         => $grouped['loop'],
			'post'         => $grouped['post'],
		) );
	}

	/**
	 * GET /user/lexicon/maps
	 * Returns forward + reverse maps for the JS engine scoped to the current user.
	 * NO fallback to global maps.
	 *
	 * The user lexicon tables store flat key→value pairs with no section column.
	 * The JS engine (buildForwardLookups) requires pairs to be grouped under the
	 * canonical section names — consonants, matras, independent_vowels, special,
	 * digits, punctuation — so it can build the correct lookahead structures.
	 *
	 * Strategy: load the source maps (DB → JSON), build a key→section index for
	 * each direction, then re-section the user's pairs on the way out.
	 * Keys not found in the source index fall into 'special' as a safe catch-all.
	 */
	public static function user_get_lexicon_maps( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id  = get_current_user_id();

		$fwd_table = CPLAI_Installer::table_user_fwd_lexicon();
		$rev_table = CPLAI_Installer::table_user_rev_lexicon();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$fwd_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT roman_key AS `from`, bpm_value AS `to` FROM `{$fwd_table}` WHERE user_id = %d ORDER BY id ASC",
				$user_id
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rev_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT bpm_key AS `from`, roman_value AS `to` FROM `{$rev_table}` WHERE user_id = %d ORDER BY id ASC",
				$user_id
			)
		);

		// No fallback — return empty + flags if user has nothing seeded.
		$sections = array( 'independent_vowels', 'consonants', 'matras', 'special', 'digits', 'punctuation' );

		$has_forward = ! empty( $fwd_rows );
		$has_reverse = ! empty( $rev_rows );

		// Build key→section index from the bundled JSON maps so re-sectioning is
		// always based on the full 107-entry set, not a potentially-partial DB map.
		$source_maps  = self::get_bundled_maps_data();

		$build_key_index = function( array $dir_map ) use ( $sections ): array {
			$index = array();
			foreach ( $sections as $section ) {
				$pairs = self::normalise_section_to_pairs( $dir_map[ $section ] ?? array() );
				foreach ( $pairs as $pair ) {
					if ( isset( $pair['from'] ) && '' !== $pair['from'] ) {
						$index[ $pair['from'] ] = $section;
					}
				}
			}
			return $index;
		};

		$fwd_index = $build_key_index( $source_maps['forward'] ?? array() );
		$rev_index = $build_key_index( $source_maps['reverse'] ?? array() );

		// Re-section user rows using the index; unknown keys fall into 'special'.
		$resection = function( array $rows, array $index ) use ( $sections ): array {
			$grouped = array_fill_keys( $sections, array() );
			foreach ( $rows as $row ) {
				$section = $index[ $row->from ] ?? 'special';
				$grouped[ $section ][] = array( $row->from, $row->to );
			}
			// Drop empty sections so the response stays lean.
			return array_filter( $grouped, function( $pairs ) { return ! empty( $pairs ); } );
		};

		$forward = $resection( (array) $fwd_rows, $fwd_index );
		$reverse = $resection( (array) $rev_rows, $rev_index );

		return rest_ensure_response( array(
			'has_forward' => $has_forward,
			'has_reverse' => $has_reverse,
			'forward'     => $forward,
			'reverse'     => $reverse,
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// USER SNIPPETS
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * GET /user/snippets
	 * Query params: direction, hook_stage (optional filters)
	 */
	public static function user_snippets_list( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$table   = CPLAI_Installer::table_user_snippets();

		$where  = $wpdb->prepare( 'WHERE user_id = %d', $user_id );
		$dir    = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? '' ) );
		$stage  = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? '' ) );
		if ( $dir && in_array( $dir, array( 'forward', 'reverse', 'both' ), true ) ) {
			$where .= $wpdb->prepare( ' AND direction = %s', $dir );
		}
		if ( $stage && in_array( $stage, array( 'pre', 'loop', 'post' ), true ) ) {
			$where .= $wpdb->prepare( ' AND hook_stage = %s', $stage );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			"SELECT id, snippet_key, label, direction, hook_stage, logic_description,
			        js_body, php_body, sort_order, is_active, source, created_at, updated_at
			 FROM `{$table}` {$where}
			 ORDER BY hook_stage, sort_order, id"
		);
		return rest_ensure_response( array( 'success' => true, 'snippets' => $rows ) );
	}

	/**
	 * POST /user/snippets — create new snippet in user's replicate.
	 */
	public static function user_snippets_create( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id     = get_current_user_id();
		$table       = CPLAI_Installer::table_user_snippets();
		$snippet_key = sanitize_text_field( (string) ( $req->get_param( 'snippet_key' ) ?? '' ) );
		$label       = sanitize_text_field( (string) ( $req->get_param( 'label' ) ?? '' ) );
		$direction   = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );
		$hook_stage  = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? 'loop' ) );
		$logic_desc  = sanitize_textarea_field( (string) ( $req->get_param( 'logic_description' ) ?? '' ) );
		$js_body     = (string) ( $req->get_param( 'js_body' )  ?? '' );
		$php_body    = (string) ( $req->get_param( 'php_body' ) ?? '' );
		$sort_order  = (int) ( $req->get_param( 'sort_order' ) ?? 0 );

		if ( empty( $snippet_key ) ) {
			return self::error( 'empty_key', 'snippet_key is required', 400 );
		}
		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'Invalid direction', 400 );
		}
		if ( ! in_array( $hook_stage, array( 'pre', 'loop', 'post' ), true ) ) {
			return self::error( 'invalid_hook_stage', 'hook_stage must be pre, loop, or post', 400 );
		}

		$result = $wpdb->insert( $table, array(
			'user_id'           => $user_id,
			'snippet_key'       => $snippet_key,
			'label'             => $label ?: $snippet_key,
			'direction'         => $direction,
			'hook_stage'        => $hook_stage,
			'logic_description' => $logic_desc,
			'js_body'           => $js_body,
			'php_body'          => $php_body,
			'sort_order'        => $sort_order,
			'is_active'         => 1,
			'source'            => 'user',
		) );
		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true, 'id' => $wpdb->insert_id ) );
	}

	/**
	 * GET /user/snippets/{id}
	 */
	public static function user_snippets_get_one( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$id      = (int) $req->get_param( 'id' );
		$table   = CPLAI_Installer::table_user_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		return rest_ensure_response( array( 'success' => true, 'snippet' => $row ) );
	}

	/**
	 * PUT /user/snippets/{id}
	 */
	public static function user_snippets_update( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$id      = (int) $req->get_param( 'id' );
		$table   = CPLAI_Installer::table_user_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}

		$allowed = array( 'label', 'logic_description', 'js_body', 'php_body', 'sort_order', 'direction', 'hook_stage' );
		$update  = array();
		foreach ( $allowed as $f ) {
			$val = $req->get_param( $f );
			if ( null !== $val ) {
				$update[ $f ] = in_array( $f, array( 'js_body', 'php_body' ), true )
					? (string) $val
					: sanitize_text_field( (string) $val );
			}
		}
		if ( empty( $update ) ) {
			return self::error( 'no_data', 'No fields to update', 400 );
		}
		$wpdb->update( $table, $update, array( 'id' => $id, 'user_id' => $user_id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id ) );
	}

	/**
	 * DELETE /user/snippets/{id}
	 */
	public static function user_snippets_delete( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$id      = (int) $req->get_param( 'id' );
		$table   = CPLAI_Installer::table_user_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id, 'user_id' => $user_id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	/**
	 * POST /user/snippets/{id}/toggle
	 */
	public static function user_snippets_toggle( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id = get_current_user_id();
		$id      = (int) $req->get_param( 'id' );
		$table   = CPLAI_Installer::table_user_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, is_active FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		$new_state = $row->is_active ? 0 : 1;
		$wpdb->update( $table, array( 'is_active' => $new_state ), array( 'id' => $id, 'user_id' => $user_id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id, 'is_active' => $new_state ) );
	}

	/**
	 * POST /user/snippets/seed
	 * Seeds snippets from the bundled defaults.json file into the user's replicate.
	 *
	 * IMPORTANT: always reads from data/snippets/defaults.json directly — never
	 * from the cplai_snippets DB table — so users always receive the full,
	 * up-to-date default set regardless of the main DB table's state.
	 *
	 * Body: { direction: 'forward'|'reverse'|'both', overwrite: true|false }
	 *
	 * Direction semantics:
	 *   - 'forward' → copies forward + both-direction snippets
	 *   - 'reverse' → copies reverse + both-direction snippets
	 *   - 'both'    → copies all snippets
	 * Generic (direction='both') snippets are ALWAYS included regardless of requested direction.
	 */
	public static function user_snippets_seed( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );
		$overwrite = (bool) ( $req->get_param( 'overwrite' ) ?? false );

		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'Invalid direction', 400 );
		}

		// Load source of truth from the bundled JSON file — never the main DB table.
		$snippets_file = CPLAI_SNIPPETS_DIR . 'defaults.json';
		if ( ! file_exists( $snippets_file ) ) {
			return self::error( 'missing_file', 'Bundled snippets defaults file not found', 500 );
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		$all_snippets = json_decode( file_get_contents( $snippets_file ), true );
		if ( ! is_array( $all_snippets ) ) {
			return self::error( 'invalid_json', 'Bundled snippets defaults file is not valid JSON', 500 );
		}

		// Filter by direction.
		$source_snippets = array();
		foreach ( $all_snippets as $s ) {
			if ( empty( $s['snippet_key'] ) ) {
				continue;
			}
			$snip_dir = $s['direction'] ?? 'both';
			if ( 'both' === $direction ) {
				// Seed everything.
				$source_snippets[] = $s;
			} elseif ( $snip_dir === $direction || 'both' === $snip_dir ) {
				$source_snippets[] = $s;
			}
		}

		if ( empty( $source_snippets ) ) {
			return rest_ensure_response( array( 'success' => true, 'seeded' => 0, 'skipped' => 0 ) );
		}

		$dest_table = CPLAI_Installer::table_user_snippets();
		$seeded     = 0;
		$skipped    = 0;

		foreach ( $source_snippets as $s ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$existing = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM `{$dest_table}` WHERE user_id = %d AND snippet_key = %s",
					$user_id,
					$s['snippet_key']
				)
			);

			if ( $existing && ! $overwrite ) {
				$skipped++;
				continue;
			}

			$row_data = array(
				'user_id'           => $user_id,
				'snippet_key'       => $s['snippet_key'],
				'label'             => $s['label']             ?? $s['snippet_key'],
				'direction'         => $s['direction']         ?? 'both',
				'hook_stage'        => $s['hook_stage']        ?? 'loop',
				'logic_description' => $s['logic_description'] ?? '',
				'js_body'           => $s['js_body']           ?? '',
				'php_body'          => $s['php_body']          ?? '',
				'sort_order'        => (int) ( $s['sort_order'] ?? 0 ),
				'is_active'         => isset( $s['is_active'] ) ? (int) $s['is_active'] : 0,
				'source'            => 'default',
			);

			if ( $existing && $overwrite ) {
				// Preserve is_active only when not overwriting (user may have toggled it).
				unset( $row_data['user_id'] ); // update WHERE already scopes to user.
				$wpdb->update(
					$dest_table,
					$row_data,
					array( 'id' => (int) $existing, 'user_id' => $user_id )
				);
			} else {
				$wpdb->insert( $dest_table, $row_data );
			}
			$seeded++;
		}

		return rest_ensure_response( array(
			'success' => true,
			'seeded'  => $seeded,
			'skipped' => $skipped,
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// USER LEXICON
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * GET /user/lexicon
	 * Query param: direction = 'forward'|'reverse' (required)
	 */
	public static function user_lexicon_list( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'forward' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward or reverse', 400 );
		}

		$table = ( 'forward' === $direction )
			? CPLAI_Installer::table_user_fwd_lexicon()
			: CPLAI_Installer::table_user_rev_lexicon();

		$key_col = ( 'forward' === $direction ) ? 'roman_key' : 'bpm_key';
		$val_col = ( 'forward' === $direction ) ? 'bpm_value' : 'roman_value';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, {$key_col} AS lex_from, {$val_col} AS lex_to, created_at, updated_at
				 FROM `{$table}`
				 WHERE user_id = %d
				 ORDER BY id",
				$user_id
			)
		);
		return rest_ensure_response( array( 'success' => true, 'entries' => $rows, 'direction' => $direction ) );
	}

	/**
	 * POST /user/lexicon — create new entry.
	 * Body: { direction, lex_from, lex_to }
	 */
	public static function user_lexicon_create( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'forward' ) );
		$lex_from  = sanitize_text_field( (string) ( $req->get_param( 'lex_from' ) ?? '' ) );
		$lex_to    = sanitize_text_field( (string) ( $req->get_param( 'lex_to' ) ?? '' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward or reverse', 400 );
		}
		if ( empty( $lex_from ) ) {
			return self::error( 'empty_from', 'lex_from is required', 400 );
		}

		$table   = ( 'forward' === $direction )
			? CPLAI_Installer::table_user_fwd_lexicon()
			: CPLAI_Installer::table_user_rev_lexicon();
		$key_col = ( 'forward' === $direction ) ? 'roman_key' : 'bpm_key';
		$val_col = ( 'forward' === $direction ) ? 'bpm_value' : 'roman_value';

		$result = $wpdb->insert( $table, array(
			'user_id'  => $user_id,
			$key_col   => $lex_from,
			$val_col   => $lex_to,
		) );
		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true, 'id' => $wpdb->insert_id ) );
	}

	/**
	 * GET /user/lexicon/{id}
	 * Query param: direction (required to resolve the right table)
	 */
	public static function user_lexicon_get_one( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$id        = (int) $req->get_param( 'id' );
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'forward' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward or reverse', 400 );
		}
		$table = ( 'forward' === $direction )
			? CPLAI_Installer::table_user_fwd_lexicon()
			: CPLAI_Installer::table_user_rev_lexicon();

		$key_col = ( 'forward' === $direction ) ? 'roman_key' : 'bpm_key';
		$val_col = ( 'forward' === $direction ) ? 'bpm_value' : 'roman_value';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, {$key_col} AS lex_from, {$val_col} AS lex_to, created_at, updated_at
			 FROM `{$table}` WHERE id = %d AND user_id = %d",
			$id, $user_id
		) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Entry not found', 404 );
		}
		return rest_ensure_response( array( 'success' => true, 'entry' => $row ) );
	}

	/**
	 * PUT /user/lexicon/{id}
	 * Body: { direction, lex_from, lex_to }
	 */
	public static function user_lexicon_update( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$id        = (int) $req->get_param( 'id' );
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'forward' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward or reverse', 400 );
		}
		$table   = ( 'forward' === $direction )
			? CPLAI_Installer::table_user_fwd_lexicon()
			: CPLAI_Installer::table_user_rev_lexicon();
		$key_col = ( 'forward' === $direction ) ? 'roman_key' : 'bpm_key';
		$val_col = ( 'forward' === $direction ) ? 'bpm_value' : 'roman_value';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Entry not found', 404 );
		}

		$update   = array();
		$lex_from = $req->get_param( 'lex_from' );
		$lex_to   = $req->get_param( 'lex_to' );
		if ( null !== $lex_from ) {
			$update[ $key_col ] = sanitize_text_field( (string) $lex_from );
		}
		if ( null !== $lex_to ) {
			$update[ $val_col ] = sanitize_text_field( (string) $lex_to );
		}
		if ( empty( $update ) ) {
			return self::error( 'no_data', 'No fields to update', 400 );
		}
		$wpdb->update( $table, $update, array( 'id' => $id, 'user_id' => $user_id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id ) );
	}

	/**
	 * DELETE /user/lexicon/{id}
	 */
	public static function user_lexicon_delete( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$id        = (int) $req->get_param( 'id' );
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'forward' ) );

		if ( ! in_array( $direction, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward or reverse', 400 );
		}
		$table = ( 'forward' === $direction )
			? CPLAI_Installer::table_user_fwd_lexicon()
			: CPLAI_Installer::table_user_rev_lexicon();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d AND user_id = %d", $id, $user_id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Entry not found', 404 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id, 'user_id' => $user_id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	/**
	 * POST /user/lexicon/seed
	 * Seeds lexicon from the bundled JSON files (the canonical source of truth)
	 * into the user's fwd/rev replicate tables.
	 *
	 * IMPORTANT: always reads from the bundled JSON files directly — never from
	 * the cplai_maps DB table — so the full 107-entry set is always seeded
	 * regardless of whether the DB map is partial, stale, or missing entries.
	 *
	 * Body: { direction: 'forward'|'reverse'|'both', overwrite: true|false }
	 */
	public static function user_lexicon_seed( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$user_id   = get_current_user_id();
		$direction = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );
		$overwrite = (bool) ( $req->get_param( 'overwrite' ) ?? false );

		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'direction must be forward, reverse, or both', 400 );
		}

		$seeded  = 0;
		$skipped = 0;
		$dirs    = ( 'both' === $direction ) ? array( 'forward', 'reverse' ) : array( $direction );

		// Always load from the bundled JSON files — never from the DB map.
		// This guarantees the full entry set regardless of DB map state.
		$maps = self::get_bundled_maps_data();

		$sections = array( 'independent_vowels', 'consonants', 'matras', 'special', 'digits', 'punctuation' );

		foreach ( $dirs as $dir ) {
			$table   = ( 'forward' === $dir )
				? CPLAI_Installer::table_user_fwd_lexicon()
				: CPLAI_Installer::table_user_rev_lexicon();
			$key_col = ( 'forward' === $dir ) ? 'roman_key' : 'bpm_key';
			$val_col = ( 'forward' === $dir ) ? 'bpm_value' : 'roman_value';
			$map_data = $maps[ $dir ] ?? array();

			foreach ( $sections as $section ) {
				$pairs = self::normalise_section_to_pairs( $map_data[ $section ] ?? array() );
				foreach ( $pairs as $pair ) {
					$lex_from = $pair['from'];
					$lex_to   = $pair['to'];
					if ( '' === $lex_from ) continue;

					// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
					$existing = $wpdb->get_var(
						$wpdb->prepare(
							"SELECT id FROM `{$table}` WHERE user_id = %d AND {$key_col} = %s",
							$user_id,
							$lex_from
						)
					);

					if ( $existing && ! $overwrite ) {
						$skipped++;
						continue;
					}

					if ( $existing && $overwrite ) {
						$wpdb->update(
							$table,
							array( $val_col => $lex_to ),
							array( 'id' => (int) $existing, 'user_id' => $user_id )
						);
					} else {
						$wpdb->insert( $table, array(
							'user_id' => $user_id,
							$key_col  => $lex_from,
							$val_col  => $lex_to,
						) );
					}
					$seeded++;
				}
			}
		}

		return rest_ensure_response( array(
			'success' => true,
			'seeded'  => $seeded,
			'skipped' => $skipped,
		) );
	}

	// ── Public transliteration ────────────────────────────────────────────────

	/**
	 * Public endpoint — no auth. Accepts {input_text, direction}, returns {output}.
	 * Only exposes transliteration output; no maps, snippets, or settings are leaked.
	 */
	public static function public_transliterate( WP_REST_Request $req ): WP_REST_Response {
		$input_text = sanitize_textarea_field( (string) ( $req->get_param( 'input_text' ) ?? '' ) );
		$direction  = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'forward' );

		if ( is_wp_error( $direction ) ) {
			return self::error( 'invalid_direction', $direction->get_error_message(), 400 );
		}
		if ( empty( $input_text ) ) {
			return self::error( 'empty_input', 'input_text is required', 400 );
		}

		$engine = new CPLAI_Engine();
		$result = $engine->transliterate( $input_text, $direction );

		return rest_ensure_response( array(
			'success'   => true,
			'output'    => $result['output'],
			'direction' => $direction,
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// MAPS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_maps( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results( "SELECT id, map_type, label, source, is_active, created_at FROM `{$table}` ORDER BY map_type, source, created_at DESC" );
		return rest_ensure_response( array( 'success' => true, 'maps' => $rows, 'debug' => self::db_debug() ) );
	}

	public static function upload_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		$label    = sanitize_text_field( (string) $req->get_param( 'label' ) );
		$json_raw = $req->get_param( 'json_data' );

		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}
		$decoded = json_decode( $json_raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return self::error( 'invalid_json', 'JSON parse error: ' . json_last_error_msg(), 400 );
		}

		$table  = CPLAI_Installer::table_maps();
		$result = $wpdb->insert( $table, array(
			'map_type'  => $map_type,
			'label'     => $label ?: 'Custom ' . $map_type . ' ' . gmdate( 'Y-m-d H:i' ),
			'source'    => 'user',
			'is_active' => 0,
			'json_data' => wp_json_encode( $decoded ),
		) );

		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true, 'id' => $wpdb->insert_id ) );
	}

	public static function activate_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Map not found', 404 );
		}
		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $row->map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'activated_id' => $id, 'map_type' => $row->map_type ) );
	}

	public static function delete_map( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Map not found', 404 );
		}
		if ( 'default' === $row->source ) {
			return self::error( 'protected', 'Default maps cannot be deleted', 403 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', 'Delete failed: ' . $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	public static function save_edit( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		$json_raw = $req->get_param( 'json_data' );

		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}
		$decoded = json_decode( $json_raw, true );
		if ( JSON_ERROR_NONE !== json_last_error() ) {
			return self::error( 'invalid_json', 'JSON parse error: ' . json_last_error_msg(), 400 );
		}

		$table    = CPLAI_Installer::table_maps();
		$label    = 'Edited ' . $map_type . ' – ' . gmdate( 'Y-m-d H:i' );
		$inserted = $wpdb->insert( $table, array(
			'map_type'  => $map_type,
			'label'     => $label,
			'source'    => 'user',
			'is_active' => 0,
			'json_data' => wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE ),
		) );
		if ( false === $inserted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		$new_id = $wpdb->insert_id;
		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $new_id ) );

		return rest_ensure_response( array( 'success' => true, 'id' => $new_id, 'label' => $label, 'activated_id' => $new_id ) );
	}

	public static function restore_default( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$map_type = sanitize_text_field( (string) $req->get_param( 'map_type' ) );
		if ( ! in_array( $map_type, array( 'forward', 'reverse' ), true ) ) {
			return self::error( 'invalid_map_type', 'map_type must be forward or reverse', 400 );
		}

		$table      = CPLAI_Installer::table_maps();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$default_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE map_type = %s AND source = 'default' LIMIT 1",
				$map_type
			)
		);

		if ( ! $default_id ) {
			$files = array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' );
			$path  = CPLAI_DATA_DIR . $files[ $map_type ];
			if ( ! file_exists( $path ) ) {
				return self::error( 'missing_file', 'Bundled default map file not found', 500 );
			}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$wpdb->insert( $table, array(
				'map_type'  => $map_type,
				'label'     => 'Default BPM ' . ucfirst( $map_type ),
				'source'    => 'default',
				'is_active' => 0,
				'json_data' => file_get_contents( $path ),
			) );
			$default_id = $wpdb->insert_id;
		}

		$wpdb->update( $table, array( 'is_active' => 0 ), array( 'map_type' => $map_type ) );
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $default_id ) );
		return rest_ensure_response( array( 'success' => true, 'map_type' => $map_type, 'activated_id' => (int) $default_id ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// SNIPPETS  (admin/main DB)
	// ══════════════════════════════════════════════════════════════════════════

	public static function snippets_sync_defaults( WP_REST_Request $req ): WP_REST_Response {
		CPLAI_Installer::seed_default_snippets();
		return rest_ensure_response( array( 'success' => true, 'message' => 'Default snippets synced.' ) );
	}

	public static function get_snippets( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			"SELECT id, snippet_key, label, direction, hook_stage, logic_description,
			        js_body, php_body,
			        sort_order, is_active, source, created_at, updated_at
			 FROM `{$table}`
			 ORDER BY hook_stage, sort_order, id"
		);
		return rest_ensure_response( array( 'success' => true, 'snippets' => $rows ) );
	}

	public static function get_active_snippets( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$direction = sanitize_text_field( (string) $req->get_param( 'direction' ) );
		$table     = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT snippet_key, label, hook_stage, js_body
				 FROM `{$table}`
				 WHERE is_active = 1
				   AND ( direction = %s OR direction = 'both' )
				   AND js_body IS NOT NULL
				   AND js_body != ''
				 ORDER BY hook_stage, sort_order ASC, id ASC",
				$direction
			)
		);

		$grouped = array( 'pre' => array(), 'loop' => array(), 'post' => array() );
		foreach ( (array) $rows as $row ) {
			$stage = $row->hook_stage;
			if ( isset( $grouped[ $stage ] ) ) {
				$grouped[ $stage ][] = array(
					'snippet_key' => $row->snippet_key,
					'label'       => $row->label,
					'js_body'     => $row->js_body,
				);
			}
		}

		return rest_ensure_response( array(
			'success'   => true,
			'direction' => $direction,
			'pre'       => $grouped['pre'],
			'loop'      => $grouped['loop'],
			'post'      => $grouped['post'],
		) );
	}

	public static function snippets_get_one( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		return rest_ensure_response( array( 'success' => true, 'snippet' => $row ) );
	}

	public static function snippets_generate( WP_REST_Request $req ): WP_REST_Response {
		$snippet_key       = sanitize_text_field( (string) ( $req->get_param( 'snippet_key' ) ?? '' ) );
		$label             = sanitize_text_field( (string) ( $req->get_param( 'label' ) ?? '' ) );
		$direction         = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'both' );
		$hook_stage        = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? 'loop' ) );
		$logic_description = sanitize_textarea_field( (string) ( $req->get_param( 'logic_description' ) ?? '' ) );
		$map_source        = self::validate_map_source( (string) ( $req->get_param( 'map_source' ) ?? '' ) );

		if ( is_wp_error( $direction ) )  return self::error( 'invalid_direction',  $direction->get_error_message(), 400 );
		if ( is_wp_error( $map_source ) ) return self::error( 'invalid_map_source', $map_source->get_error_message(), 400 );
		if ( empty( $snippet_key ) )       return self::error( 'empty_key',          'snippet_key is required', 400 );
		if ( empty( $logic_description ) ) return self::error( 'empty_description',  'logic_description is required', 400 );
		if ( ! in_array( $hook_stage, array( 'pre', 'loop', 'post' ), true ) ) {
			return self::error( 'invalid_hook_stage', 'hook_stage must be pre, loop, or post', 400 );
		}

		$maps     = self::get_active_maps_data( $map_source );
		$user_msg = self::build_snippet_user_message( $snippet_key, $label, $logic_description, $direction, $hook_stage );

		$js_system = self::build_snippet_system_prompt( $direction, $hook_stage, $maps );
		$js_resp   = self::call_ai( $js_system, $user_msg );
		if ( is_wp_error( $js_resp ) ) {
			return self::error( 'ai_error', $js_resp->get_error_message(), 500 );
		}

		$php_body   = '';
		$php_system = self::build_snippet_php_prompt( $direction, $hook_stage, $maps );
		$php_resp   = self::call_ai( $php_system, $user_msg );
		if ( ! is_wp_error( $php_resp ) ) {
			$extracted = self::extract_php_rules( $php_resp['code'] );
			if ( ! is_wp_error( $extracted ) ) {
				$php_body = $extracted;
			}
		}

		return rest_ensure_response( array(
			'success'     => true,
			'snippet_key' => $snippet_key,
			'js_body'     => $js_resp['code'],
			'php_body'    => $php_body,
			'explanation' => $js_resp['explanation'],
		) );
	}

	public static function snippets_save( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$table = CPLAI_Installer::table_snippets();

		$id          = (int) ( $req->get_param( 'id' ) ?? 0 );
		$snippet_key = sanitize_text_field( (string) ( $req->get_param( 'snippet_key' ) ?? '' ) );
		$label       = sanitize_text_field( (string) ( $req->get_param( 'label' ) ?? '' ) );
		$direction   = sanitize_text_field( (string) ( $req->get_param( 'direction' ) ?? 'both' ) );
		$hook_stage  = sanitize_text_field( (string) ( $req->get_param( 'hook_stage' ) ?? 'loop' ) );
		$logic_desc  = sanitize_textarea_field( (string) ( $req->get_param( 'logic_description' ) ?? '' ) );
		$js_body     = (string) ( $req->get_param( 'js_body' )  ?? '' );
		$php_body    = (string) ( $req->get_param( 'php_body' ) ?? '' );
		$sort_order  = (int) ( $req->get_param( 'sort_order' ) ?? 0 );
		$source      = sanitize_text_field( (string) ( $req->get_param( 'source' ) ?? 'user' ) );

		if ( empty( $snippet_key ) ) {
			return self::error( 'empty_key', 'snippet_key is required', 400 );
		}
		if ( ! in_array( $direction, array( 'forward', 'reverse', 'both' ), true ) ) {
			return self::error( 'invalid_direction', 'Invalid direction', 400 );
		}
		if ( ! in_array( $hook_stage, array( 'pre', 'loop', 'post' ), true ) ) {
			return self::error( 'invalid_hook_stage', 'hook_stage must be pre, loop, or post', 400 );
		}
		if ( mb_strlen( $js_body ) > 200000 ) {
			return self::error( 'code_too_large', 'js_body exceeds maximum allowed size', 400 );
		}

		$data = array(
			'snippet_key'       => $snippet_key,
			'label'             => $label ?: $snippet_key,
			'direction'         => $direction,
			'hook_stage'        => $hook_stage,
			'logic_description' => $logic_desc,
			'js_body'           => $js_body,
			'php_body'          => $php_body,
			'sort_order'        => $sort_order,
			'source'            => in_array( $source, array( 'default', 'user', 'ai_generated' ), true ) ? $source : 'user',
		);

		if ( $id > 0 ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
			if ( ! $existing ) {
				return self::error( 'not_found', 'Snippet not found', 404 );
			}
			if ( 'default' === $existing->source ) {
				$data['source'] = 'default';
			}
			$wpdb->update( $table, $data, array( 'id' => $id ) );
			return rest_ensure_response( array( 'success' => true, 'id' => $id, 'updated' => true ) );
		}

		$result = $wpdb->insert( $table, $data );
		if ( false === $result ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		$new_id = $wpdb->insert_id;
		$wpdb->update( $table, array( 'is_active' => 1 ), array( 'id' => $new_id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $new_id, 'inserted' => true ) );
	}

	public static function snippets_update( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}

		$allowed = array( 'label', 'logic_description', 'js_body', 'php_body', 'sort_order', 'direction', 'hook_stage' );
		$update  = array();
		foreach ( $allowed as $f ) {
			$val = $req->get_param( $f );
			if ( null !== $val ) {
				$update[ $f ] = in_array( $f, array( 'js_body', 'php_body' ), true )
					? (string) $val
					: sanitize_text_field( (string) $val );
			}
		}
		if ( empty( $update ) ) {
			return self::error( 'no_data', 'No fields to update', 400 );
		}
		$wpdb->update( $table, $update, array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id ) );
	}

	public static function snippets_toggle( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, is_active FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		$new_state = $row->is_active ? 0 : 1;
		$wpdb->update( $table, array( 'is_active' => $new_state ), array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id, 'is_active' => $new_state ) );
	}

	public static function snippets_reorder( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id         = (int) $req->get_param( 'id' );
		$sort_order = (int) $req->get_param( 'sort_order' );
		$table      = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		$wpdb->update( $table, array( 'sort_order' => $sort_order ), array( 'id' => $id ) );
		return rest_ensure_response( array( 'success' => true, 'id' => $id, 'sort_order' => $sort_order ) );
	}

	public static function snippets_delete( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$id    = (int) $req->get_param( 'id' );
		$table = CPLAI_Installer::table_snippets();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `{$table}` WHERE id = %d", $id ) );
		if ( ! $row ) {
			return self::error( 'not_found', 'Snippet not found', 404 );
		}
		if ( 'default' === $row->source ) {
			return self::error( 'protected', 'Default snippets cannot be deleted', 403 );
		}
		$deleted = $wpdb->delete( $table, array( 'id' => $id ) );
		if ( false === $deleted ) {
			return self::error( 'db_error', $wpdb->last_error, 500 );
		}
		return rest_ensure_response( array( 'success' => true ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// TEST
	// ══════════════════════════════════════════════════════════════════════════

	public static function test_run( WP_REST_Request $req ): WP_REST_Response {
		$input_text = sanitize_textarea_field( (string) $req->get_param( 'input_text' ) );
		$direction  = self::validate_direction( (string) ( $req->get_param( 'direction' ) ?? '' ), 'forward' );

		if ( is_wp_error( $direction ) ) {
			return self::error( 'invalid_direction', $direction->get_error_message(), 400 );
		}
		if ( empty( $input_text ) ) {
			return self::error( 'empty_input', 'input_text is required', 400 );
		}

		$engine = new CPLAI_Engine();
		$result = $engine->transliterate( $input_text, $direction );

		return rest_ensure_response( array(
			'success'   => true,
			'mode'      => 'php_engine',
			'output'    => $result['output'],
			'log'       => $result['log'],
			'direction' => $direction,
			'debug'     => self::db_debug(),
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// STATUS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_status( WP_REST_Request $req ): WP_REST_Response {
		global $wpdb;
		$maps_table     = CPLAI_Installer::table_maps();
		$snippets_table = CPLAI_Installer::table_snippets();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_maps     = $wpdb->get_results( "SELECT id, map_type, label, source FROM `{$maps_table}` WHERE is_active = 1" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$active_snippets = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$snippets_table}` WHERE is_active = 1" );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$total_snippets  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$snippets_table}`" );

		return rest_ensure_response( array(
			'active_maps'    => $active_maps,
			'snippets'       => array( 'active' => $active_snippets, 'total' => $total_snippets ),
			'engine'         => 'fixed-v4',
			'php_version'    => PHP_VERSION,
			'wp_version'     => get_bloginfo( 'version' ),
			'wp_debug'       => WP_DEBUG,
			'plugin_version' => CPLAI_VERSION,
		) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// SETTINGS
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_settings( WP_REST_Request $req ): WP_REST_Response {
		$anthropic_raw = (string) get_option( 'cplai_anthropic_key', '' );
		$gemini_raw    = (string) get_option( 'cplai_gemini_key',    '' );
		$openai_raw    = (string) get_option( 'cplai_openai_key',    '' );
		$grok_raw      = (string) get_option( 'cplai_grok_key',      '' );

		$mask = static function ( string $k ): string {
			return $k ? ( substr( $k, 0, 8 ) . str_repeat( '•', max( 0, strlen( $k ) - 8 ) ) ) : '';
		};

		return rest_ensure_response( array(
			'success'           => true,
			'api_key_hint'      => $mask( $anthropic_raw ),
			'gemini_key_hint'   => $mask( $gemini_raw ),
			'openai_key_hint'   => $mask( $openai_raw ),
			'grok_key_hint'     => $mask( $grok_raw ),
			'has_anthropic_key' => ! empty( $anthropic_raw ),
			'has_gemini_key'    => ! empty( $gemini_raw ),
			'has_openai_key'    => ! empty( $openai_raw ),
			'has_grok_key'      => ! empty( $grok_raw ),
			'model'             => (string) get_option( 'cplai_model',       'claude-sonnet-4-6' ),
			'ai_provider'       => (string) get_option( 'cplai_ai_provider', 'anthropic' ),
		) );
	}

	public static function save_settings( WP_REST_Request $req ): WP_REST_Response {
		$params   = $req->get_json_params();
		$provider = sanitize_text_field( (string) ( $params['ai_provider'] ?? 'anthropic' ) );
		$model    = sanitize_text_field( (string) ( $params['model']       ?? 'claude-sonnet-4-6' ) );

		$allowed_providers = array( 'anthropic', 'gemini', 'openai', 'grok' );
		if ( ! in_array( $provider, $allowed_providers, true ) ) {
			return self::error( 'invalid_provider', 'Invalid provider.', 400 );
		}

		$allowed_models = array(
			'claude-opus-4-6', 'claude-sonnet-4-6',
			'gemini-2.5-pro', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-pro', 'gemini-1.5-flash',
			'gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo',
			'grok-3', 'grok-3-fast', 'grok-3-mini', 'grok-3-mini-fast',
		);
		if ( ! in_array( $model, $allowed_models, true ) ) {
			return self::error( 'invalid_model', 'Invalid model.', 400 );
		}

		$key_map = array(
			'api_key'    => 'cplai_anthropic_key',
			'gemini_key' => 'cplai_gemini_key',
			'openai_key' => 'cplai_openai_key',
			'grok_key'   => 'cplai_grok_key',
		);
		foreach ( $key_map as $param => $option ) {
			$val = sanitize_text_field( (string) ( $params[ $param ] ?? '' ) );
			if ( ! empty( $val ) ) {
				update_option( $option, $val );
			}
		}

		update_option( 'cplai_model',       $model );
		update_option( 'cplai_ai_provider', $provider );

		return rest_ensure_response( array( 'success' => true, 'saved' => true ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// LEXICON  (admin — main maps)
	// ══════════════════════════════════════════════════════════════════════════

	public static function get_lexicon( WP_REST_Request $req ): WP_REST_Response {
		$sections = array( 'independent_vowels', 'consonants', 'matras', 'special', 'digits', 'punctuation' );

		$file_defaults = array();
		foreach ( array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' ) as $type => $filename ) {
			$path = CPLAI_DATA_DIR . $filename;
			if ( file_exists( $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$decoded = json_decode( file_get_contents( $path ), true );
				if ( is_array( $decoded ) ) {
					$file_defaults[ $type ] = $decoded;
				}
			}
		}

		$db_maps = self::get_active_maps_data( 'default' );
		$maps    = array();
		foreach ( array( 'forward', 'reverse' ) as $type ) {
			$db           = $db_maps[ $type ] ?? array();
			$has_sections = false;
			foreach ( $sections as $s ) {
				if ( ! empty( $db[ $s ] ) ) {
					$has_sections = true;
					break;
				}
			}
			$maps[ $type ] = $has_sections ? $db : ( $file_defaults[ $type ] ?? array() );
		}

		$forward = array();
		$reverse = array();

		foreach ( $sections as $section ) {
			$fwd = self::normalise_section_to_pairs( $maps['forward'][ $section ] ?? array() );
			$rev = self::normalise_section_to_pairs( $maps['reverse'][ $section ] ?? array() );
			if ( ! empty( $fwd ) ) $forward[ $section ] = $fwd;
			if ( ! empty( $rev ) ) $reverse[ $section ] = $rev;
		}

		if ( empty( $forward ) ) $forward = array_fill_keys( $sections, array() );
		if ( empty( $reverse ) ) $reverse = array_fill_keys( $sections, array() );

		return rest_ensure_response( array( 'forward' => $forward, 'reverse' => $reverse ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// HELPERS
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Load forward and reverse maps directly from the bundled JSON files.
	 * This is the canonical source of truth for seeding operations and must
	 * never be replaced by the DB map, which may be partial or stale.
	 */
	private static function get_bundled_maps_data(): array {
		$maps  = array();
		$files = array(
			'forward' => 'forwardMap.json',
			'reverse' => 'reverseMap.json',
		);
		foreach ( $files as $type => $filename ) {
			$path = CPLAI_DATA_DIR . $filename;
			if ( file_exists( $path ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				$decoded = json_decode( file_get_contents( $path ), true );
				if ( is_array( $decoded ) ) {
					$maps[ $type ] = $decoded;
				}
			}
		}
		return $maps;
	}

	private static function get_active_maps_data( string $source ): array {
		global $wpdb;
		$table = CPLAI_Installer::table_maps();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = ( 'db' === $source )
			? $wpdb->get_results( "SELECT map_type, json_data, source FROM `{$table}` WHERE is_active = 1 ORDER BY source DESC" )
			: $wpdb->get_results( "SELECT map_type, json_data, source FROM `{$table}` WHERE is_active = 1" );

		$maps = array();
		foreach ( (array) $rows as $row ) {
			$maps[ $row->map_type ] = json_decode( $row->json_data, true );
		}

		foreach ( array( 'forward' => 'forwardMap.json', 'reverse' => 'reverseMap.json' ) as $type => $file ) {
			if ( empty( $maps[ $type ] ) ) {
				$path = CPLAI_DATA_DIR . $file;
				if ( file_exists( $path ) ) {
					// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$maps[ $type ] = json_decode( file_get_contents( $path ), true );
				}
			}
		}

		return $maps;
	}

	private static function build_snippet_system_prompt( string $direction, string $hook_stage, array $maps ): string {
		$map_json       = wp_json_encode( $maps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		$virama         = '্'; // U+09CD.
		$inherent_vowel = 'o';

		return <<<SYSPROMPT
You are an expert computational linguist and JavaScript developer specialising in Bishnupriya Manipuri (BPM) transliteration.

## Task
Generate a SINGLE named JavaScript snippet hook function — NOT a full transliteration engine.
The snippet implements one specific parsing logic unit (e.g. reph ligature, anusvara revert, schwa deletion).

## Engine Architecture (v4 — Fixed Engine)
The engine is fixed PHP/JS. AI only generates snippet hook functions that plug into pre/loop/post slots.
The engine passes a `state` object and a `config` object to every hook.

## Snippet Hook Interface Contract

  function snippetName(state, config) {
    // state.input    {string}  — full original input string
    // state.output   {string}  — accumulated output so far
    // state.pos      {number}  — current position in input (loop stage)
    // state.prev     {object}  — { token, was_consonant, was_matra }
    // state.log      {Array}   — push strings to append log entries
    // state.handled  {boolean} — SET TRUE in loop stage to claim the token
    //                            and block the default match for this position.
    //                            First hook that sets handled=true wins; chain stops.
    //
    // config.maps           — { forward: {…}, reverse: {…} } active maps
    // config.virama         — '{$virama}' (U+09CD Bengali virama)
    // config.inherent_vowel — '{$inherent_vowel}' (inherent vowel Roman token)
    // config.direction      — 'forward' | 'reverse'
    // config.consonants_set — Set<string> of consonant keys for active direction
    // config.matras_set     — Set<string> of matra keys for active direction
    //
    // Must return the modified state object.
    return state;
  }

## Hook Stage: {$hook_stage}
- pre:  Runs before the main loop. Modify state.input (e.g. string substitutions). state.pos is 0.
- loop: Runs inside the loop at each position. Set state.handled = true to claim the token.
         Sort order is priority — lower sort_order = higher priority.
- post: Runs after the main loop. Modify state.output (e.g. trim, case changes).

## Direction: {$direction}

## Rules
1. Return ONLY the JavaScript function definition — no markdown fences, no preamble, no extra functions.
2. Use the provided active maps for any lookup needed.
3. The function must be self-contained (no imports, no external dependencies).
4. Use a descriptive camelCase function name matching the snippet_key.
5. Always return state.

## Active maps (source of truth):
{$map_json}
SYSPROMPT;
	}

	private static function build_snippet_user_message(
		string $key, string $label, string $description, string $direction, string $hook_stage
	): string {
		return "Generate a snippet hook function with these parameters:\n\n"
			. "snippet_key: {$key}\n"
			. "label: {$label}\n"
			. "direction: {$direction}\n"
			. "hook_stage: {$hook_stage}\n\n"
			. "Logic to implement:\n{$description}";
	}

	private static function build_snippet_php_prompt( string $direction, string $hook_stage, array $maps ): string {
		$map_json = wp_json_encode( $maps, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

		return <<<PHPPROMPT
You are generating the PHP-side equivalent of a transliteration snippet hook for a Bengali-Assamese transliteration engine.

## What the PHP engine accepts

The PHP engine does NOT execute JavaScript or PHP functions.
It reads php_body as a JSON-encoded array of find-replace rule objects and applies them sequentially via str_replace or preg_replace.

Each rule follows this base structure:
{ "type": "replace", "from": "<search>", "to": "<replacement>", "regex": false }

- "type"  — must be "replace" (the only supported type).
- "from"  — the literal string to find, or a regex pattern if "regex" is true.
- "to"    — the replacement string. May contain literal UTF-8 Bengali/Assamese characters.
- "regex" — false for plain str_replace (default); true for preg_replace.

## Rules for ordering

Order matters — rules are applied top-to-bottom in a single pass.
Always place longer / more specific patterns before shorter ones that share a prefix.

## Hook stage: {$hook_stage}

## Direction: {$direction}

## Output format

Return ONLY the raw JSON array — no markdown fences, no explanation, no preamble, no trailing text.
The array must be valid JSON parseable by json_decode() in PHP.

## Active maps (use these to resolve correct Unicode values)

{$map_json}
PHPPROMPT;
	}

	private static function call_ai( string $system, string $user_msg ): array|WP_Error {
		$provider = (string) get_option( 'cplai_ai_provider', 'anthropic' );

		switch ( $provider ) {
			case 'gemini':
				$key = (string) get_option( 'cplai_gemini_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Google Gemini API key not configured. Go to Settings.' );
				return self::call_gemini( $key, $system, $user_msg );

			case 'openai':
				$key = (string) get_option( 'cplai_openai_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'OpenAI API key not configured. Go to Settings.' );
				return self::call_openai( $key, $system, $user_msg );

			case 'grok':
				$key = (string) get_option( 'cplai_grok_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Grok API key not configured. Go to Settings.' );
				return self::call_grok( $key, $system, $user_msg );

			default:
				$key = (string) get_option( 'cplai_anthropic_key', '' );
				if ( empty( $key ) ) return new WP_Error( 'no_api_key', 'Anthropic API key not configured. Go to Settings.' );
				return self::call_anthropic( $key, $system, $user_msg );
		}
	}

	private static function call_gemini( string $key, string $system, string $user_msg ): array|WP_Error {
		$model    = (string) get_option( 'cplai_model', 'gemini-2.5-flash' );
		$endpoint = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $key );
		$body     = array(
			'system_instruction' => array( 'parts' => array( array( 'text' => $system ) ) ),
			'contents'           => array( array( 'role' => 'user', 'parts' => array( array( 'text' => $user_msg ) ) ) ),
			'generationConfig'   => array( 'maxOutputTokens' => 4096, 'temperature' => 0.2 ),
		);
		$response = wp_remote_post( $endpoint, array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'gemini_error', $data['error']['message'] ?? "Gemini HTTP {$http_code}" );
		$full_text = '';
		foreach ( $data['candidates'][0]['content']['parts'] ?? array() as $part ) {
			if ( isset( $part['text'] ) ) $full_text .= $part['text'];
		}
		return self::extract_code_and_explanation( $full_text );
	}

	private static function call_openai( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'gpt-4o' );
		$body  = array(
			'model'       => $model,
			'max_tokens'  => 4096,
			'temperature' => 0.2,
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user',   'content' => $user_msg ),
			),
		);
		$response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'openai_error', $data['error']['message'] ?? "OpenAI HTTP {$http_code}" );
		return self::extract_code_and_explanation( $data['choices'][0]['message']['content'] ?? '' );
	}

	private static function call_grok( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'grok-3-fast' );
		$body  = array(
			'model'       => $model,
			'max_tokens'  => 4096,
			'temperature' => 0.2,
			'messages'    => array(
				array( 'role' => 'system', 'content' => $system ),
				array( 'role' => 'user',   'content' => $user_msg ),
			),
		);
		$response = wp_remote_post( 'https://api.x.ai/v1/chat/completions', array(
			'timeout' => 90,
			'headers' => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$http_code = wp_remote_retrieve_response_code( $response );
		$data      = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $http_code ) return new WP_Error( 'grok_error', $data['error']['message'] ?? "Grok HTTP {$http_code}" );
		return self::extract_code_and_explanation( $data['choices'][0]['message']['content'] ?? '' );
	}

	private static function call_anthropic( string $key, string $system, string $user_msg ): array|WP_Error {
		$model = (string) get_option( 'cplai_model', 'claude-sonnet-4-6' );
		$body  = array(
			'model'      => $model,
			'max_tokens' => 4096,
			'system'     => $system,
			'messages'   => array( array( 'role' => 'user', 'content' => $user_msg ) ),
		);
		$response = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
			'timeout' => 90,
			'headers' => array(
				'Content-Type'      => 'application/json',
				'x-api-key'         => $key,
				'anthropic-version' => '2023-06-01',
			),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $response ) ) return $response;
		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( 200 !== $code ) return new WP_Error( 'anthropic_error', $data['error']['message'] ?? "HTTP {$code}" );
		$full_text = '';
		foreach ( $data['content'] ?? array() as $block ) {
			if ( ( $block['type'] ?? '' ) === 'text' ) $full_text .= $block['text'];
		}
		return self::extract_code_and_explanation( $full_text );
	}

	private static function extract_code_and_explanation( string $full_text ): array {
		if ( preg_match( '/```(?:javascript|js)?\s*([\s\S]*?)```/i', $full_text, $m ) ) {
			$code_part   = trim( $m[1] );
			$explanation = trim( preg_replace( '/```[\s\S]*?```/i', '', $full_text ) );
		} else {
			$code_part   = trim( $full_text );
			$explanation = '';
		}
		return array( 'code' => $code_part, 'explanation' => $explanation );
	}

	private static function extract_php_rules( string $full_text ): string|WP_Error {
		$clean = preg_replace( '/^```(?:json)?\s*/i', '', trim( $full_text ) );
		$clean = preg_replace( '/\s*```\s*$/i', '', $clean );
		$clean = trim( $clean );

		$decoded = json_decode( $clean, true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'invalid_php_body', 'AI returned invalid JSON for php_body.' );
		}

		foreach ( $decoded as $rule ) {
			if ( ! is_array( $rule ) || ! isset( $rule['from'], $rule['to'] ) || '' === $rule['from'] ) {
				return new WP_Error( 'invalid_rule', 'One or more rules are missing required from/to fields.' );
			}
		}

		return wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE );
	}

	private static function normalise_section_to_pairs( array $raw ): array {
		$pairs = array();
		if ( empty( $raw ) ) return $pairs;

		$is_v2 = array_is_list( $raw )
			&& isset( $raw[0] )
			&& is_array( $raw[0] )
			&& array_is_list( $raw[0] )
			&& count( $raw[0] ) >= 2;

		if ( $is_v2 ) {
			foreach ( $raw as $pair ) {
				if ( is_array( $pair ) && isset( $pair[0], $pair[1] ) ) {
					$pairs[] = array( 'from' => (string) $pair[0], 'to' => (string) $pair[1] );
				}
			}
		} else {
			foreach ( $raw as $k => $v ) {
				if ( '_meta' === $k ) continue;
				$pairs[] = array( 'from' => (string) $k, 'to' => (string) $v );
			}
		}
		return $pairs;
	}

	private static function validate_direction( string $value, string $default = 'both' ): string|WP_Error {
		$allowed = array( 'forward', 'reverse', 'both' );
		$value   = sanitize_text_field( $value ?: $default );
		if ( ! in_array( $value, $allowed, true ) ) {
			return new WP_Error( 'invalid_direction', 'direction must be one of: ' . implode( ', ', $allowed ) );
		}
		return $value;
	}

	private static function validate_map_source( string $value ): string|WP_Error {
		$allowed = array( 'default', 'db' );
		$value   = sanitize_text_field( $value ?: 'default' );
		if ( ! in_array( $value, $allowed, true ) ) {
			return new WP_Error( 'invalid_map_source', "map_source must be 'default' or 'db'" );
		}
		return $value;
	}

	private static function db_debug(): array {
		if ( ! WP_DEBUG ) return array();
		global $wpdb;
		return array(
			'last_query'  => $wpdb->last_query,
			'last_error'  => $wpdb->last_error,
			'num_queries' => $wpdb->num_queries,
		);
	}

	private static function error( string $code, string $msg, int $status ): WP_REST_Response {
		$data = array( 'success' => false, 'code' => $code, 'message' => $msg );
		if ( WP_DEBUG ) {
			$data['debug'] = array( 'backtrace' => array_slice( debug_backtrace( DEBUG_BACKTRACE_IGNORE_ARGS ), 0, 5 ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_debug_backtrace
		}
		return new WP_REST_Response( $data, $status );
	}
}
