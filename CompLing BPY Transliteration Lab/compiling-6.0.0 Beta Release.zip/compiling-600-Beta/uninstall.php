<?php
/**
 * Uninstall handler — runs automatically when the plugin is deleted from WP admin.
 *
 * Removes all custom DB tables and plugin options created by Compiling AI.
 * Cleans up:
 *  - Main plugin tables   : cplai_maps, cplai_sessions, cplai_snippets
 *  - Per-user replicate   : cplai_user_snippets, cplai_user_fwd_lexicon,
 *                           cplai_user_rev_lexicon
 *  - Legacy v2/v3 table   : cplai_injected_code
 *  - Roles                : cplai_transliterator, cplai_researcher (legacy)
 *  - All plugin options
 *
 * @package CompilingAI
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// ── Drop all plugin tables ────────────────────────────────────────────────────

$tables = array(
	// Main tables.
	$wpdb->prefix . 'cplai_maps',
	$wpdb->prefix . 'cplai_sessions',
	$wpdb->prefix . 'cplai_snippets',
	// Per-user replicate tables (added in v5.2).
	$wpdb->prefix . 'cplai_user_snippets',
	$wpdb->prefix . 'cplai_user_fwd_lexicon',
	$wpdb->prefix . 'cplai_user_rev_lexicon',
	// Legacy v2/v3 — safe to include even if it no longer exists.
	$wpdb->prefix . 'cplai_injected_code',
);

foreach ( $tables as $table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" );
}

// ── Remove roles ──────────────────────────────────────────────────────────────

// Remove cplai_transliterator role (added in v5.2).
if ( get_role( 'cplai_transliterator' ) ) {
	remove_role( 'cplai_transliterator' );
}

// Remove legacy cplai_researcher role if it still exists on this install.
if ( get_role( 'cplai_researcher' ) ) {
	remove_role( 'cplai_researcher' );
}

// Remove any leftover caps from administrators.
$admin_role = get_role( 'administrator' );
if ( $admin_role ) {
	$admin_role->remove_cap( 'cplai_researcher' );
	$admin_role->remove_cap( 'cplai_transliterator' );
}

// ── Remove all plugin options ─────────────────────────────────────────────────

$options = array(
	'cplai_db_version',
	'cplai_anthropic_key',
	'cplai_gemini_key',
	'cplai_openai_key',
	'cplai_grok_key',
	'cplai_model',
	'cplai_ai_provider',
);

foreach ( $options as $opt ) {
	delete_option( $opt );
}

// ── Multisite: clean per-site data ────────────────────────────────────────────

if ( is_multisite() ) {
	$sites = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
	foreach ( $sites as $site_id ) {
		switch_to_blog( $site_id );
		foreach ( $options as $opt ) {
			delete_option( $opt );
		}
		restore_current_blog();
	}
}
