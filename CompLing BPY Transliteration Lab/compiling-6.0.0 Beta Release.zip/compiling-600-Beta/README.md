# CompLing AI — BPM Transliteration Lab

> A WordPress plugin for AI-assisted computational linguistics research on **Bishnupriya Manipuri (BPM)** — a Bengali-Assamese script language of Northeast India and Bangladesh.

---

## Overview

**CompLing AI** provides a full transliteration research workbench inside the WordPress admin panel. It combines a **fixed, deterministic transliteration engine** (PHP server-side + JS browser-side) with an AI code generation pipeline (Anthropic Claude, Google Gemini, OpenAI GPT, xAI Grok).

**v4.0 Architecture — Fixed Engine + Snippet Hooks:**

- The transliteration engine is **fixed, hand-written PHP and JavaScript** — never AI-generated.
- The engine exposes **three hook slots** — `pre`, `loop`, and `post` — where named snippet functions can be wired in.
- **AI's only job** is generating the `js_body` of individual snippets — small, testable, replaceable units.
- Snippets are **optional overlays** — the engine runs correctly with zero snippets enabled.
- The old AI inject / `cplai_injected_code` model is removed entirely.

---

## Requirements

| Requirement | Minimum |
|---|---|
| WordPress | 6.4+ |
| PHP | 8.1+ |
| MySQL / MariaDB | 5.7+ / 10.3+ |
| AI Provider API Key | Required for AI snippet generation |
| Browser | Any modern browser (ES2020+) |

---

## Installation

1. Download `compiling-ai-v4.0.0-beta.zip`
2. In WordPress admin: **Plugins → Add New → Upload Plugin**
3. Select the zip → **Install Now → Activate**
4. Go to **WP Admin → BPM Lab → Settings**
5. Choose your AI provider and enter the corresponding API key → Save
6. Default maps and snippets are seeded automatically on activation.

---

## Plugin Structure

```
compiling-ai/
├── compiling-ai.php             Main entry point, constants, autoloader
├── uninstall.php                Clean uninstall (removes all DB tables + options)
├── README.md                    This file
├── admin/
│   └── page-lab.php             Admin UI — 6-tab lab interface
├── assets/
│   ├── css/admin.css            Lab stylesheet
│   └── js/
│       ├── engine.js            Fixed JS transliteration engine (never AI-generated)
│       └── admin.js             Admin UI logic (REST calls, snippet editor, test console)
├── data/
│   ├── forwardMap.json          Roman → BPM default map
│   ├── reverseMap.json          BPM → Roman default map
│   └── snippets/
│       └── defaults.json        Default snippet definitions (seeded on activation)
└── includes/
    ├── class-installer.php      DB schema creation, map + snippet seeding, legacy table cleanup
    ├── class-core.php           Boot orchestrator
    ├── class-admin.php          Admin menu + asset enqueue
    ├── class-rest.php           REST API endpoints
    └── class-engine.php         Fixed PHP transliteration engine with pre/post snippet hooks
```

---

## Database Tables

Three tables are created on activation (prefixed with your WP table prefix, e.g. `wp_`):

| Table | Purpose |
|---|---|
| `wp_cplai_maps` | Default and user-uploaded JSON transliteration maps |
| `wp_cplai_sessions` | AI snippet generation history |
| `wp_cplai_snippets` | Named parsing-logic hook functions |

The legacy `wp_cplai_injected_code` table (v2/v3) is dropped automatically on first activation of v4.

All tables are **dropped cleanly** on plugin deletion.

---

## WordPress Options Stored

| Option Key | Value |
|---|---|
| `cplai_db_version` | Plugin version string (used for DB upgrade checks) |
| `cplai_anthropic_key` | Anthropic API key (admin-only) |
| `cplai_gemini_key` | Google Gemini API key (admin-only) |
| `cplai_openai_key` | OpenAI API key (admin-only) |
| `cplai_grok_key` | xAI Grok API key (admin-only) |
| `cplai_model` | Chosen AI model identifier |
| `cplai_ai_provider` | Active AI provider (`anthropic`, `gemini`, `openai`, `grok`) |

All options are **deleted on uninstall**.

---

## Engine Architecture (v4)

```
Fixed PHP engine (class-engine.php)
  └── pre hook slot  → runs active php_body snippets (find-replace rules, pre stage)
  └── loop hook slot → handled natively by the PHP engine (Option C — JS-only loop snippets)
  └── post hook slot → runs active php_body snippets (find-replace rules, post stage)

Fixed JS engine (assets/js/engine.js)
  └── pre hook slot  → runs active snippet js_body functions (pre stage)
  └── loop hook slot → runs active snippet js_body functions (loop stage)
                        state.handled = true blocks the default match for that position
  └── post hook slot → runs active snippet js_body functions (post stage)

AI generates snippet js_body only
  → Snippet saved to DB → user toggles active → engine picks it up at runtime
  → No compile step. No injected engine blobs.
```

**Where each engine runs:**

| Context | Engine |
|---|---|
| Lab / browser test | JS engine in-browser |
| REST `/test/run` call | PHP engine server-side |
| WordPress shortcode output | PHP engine server-side |

---

## JSON Map Format

### forwardMap.json (Roman → BPM)

```json
{
  "_meta": { "description": "...", "version": "1.0" },
  "independent_vowels": [["a", "আ"], ["i", "ই"], ...],
  "consonants":         [["k", "ক"], ["kh", "খ"], ...],
  "matras":             [["a", "া"], ["i", "ি"], ...],
  "special":            [["M", "ং"], ["H", "ঃ"], ...],
  "digits":             [["0", "০"], ...],
  "punctuation":        [[".", "।"], ["..", "॥"]]
}
```

Map sections support two formats:
- **v2 (preferred):** ordered array of `[from, to]` pairs — `[["k","ক"], ["kh","খ"], …]`
- **v1 (legacy):** plain associative object — `{"k":"ক", "kh":"খ", …}`

Both engines handle both formats transparently. v2 is preferred because ordering is preserved.

### reverseMap.json (BPM → Roman)

Same structure, source and target swapped.

---

## Snippet Registry

### What snippets are

Each snippet is a named JavaScript hook function that targets one parsing logic unit. Snippets are stored in the database, toggled on/off independently, and executed in `sort_order` sequence at their declared stage (`pre`, `loop`, or `post`).

### Snippet fields

| Field | Purpose |
|---|---|
| `snippet_key` | Unique machine name, e.g. `loop_reph_ligature` — also used as the JS function name |
| `label` | Human-readable name shown in the UI |
| `direction` | `forward`, `reverse`, or `both` |
| `hook_stage` | `pre`, `loop`, or `post` |
| `sort_order` | Integer — lower runs first within the same stage |
| `logic_description` | Plain-language description; sent to AI for generation |
| `js_body` | The JavaScript hook function (used by the JS engine) |
| `php_body` | Optional JSON-encoded find-replace rules (used by the PHP engine, pre/post only) |
| `is_active` | `0` / `1` — enable/disable toggle |
| `source` | `default`, `user`, or `ai_generated` |

### Snippet hook contract

```javascript
function mySnippet(state, config) {
  // state.input    {string}  — full original input string
  // state.output   {string}  — accumulated output so far
  // state.pos      {number}  — current position in input (loop stage)
  // state.prev     {object}  — { token, was_consonant, was_matra }
  // state.log      {Array}   — push strings to append log entries
  // state.handled  {boolean} — set TRUE in loop stage to claim the token
  //                            and block the default match for this position.
  //                            First hook to set handled=true wins; chain stops.
  //
  // config.maps           — { forward: {…}, reverse: {…} } active maps
  // config.virama         — '্' (U+09CD Bengali virama)
  // config.inherent_vowel — 'o' (inherent vowel Roman token)
  // config.direction      — 'forward' | 'reverse'
  // config.consonants_set — Set<string> of consonant keys for active direction
  // config.matras_set     — Set<string> of matra keys for active direction

  // Must return the modified state object.
  return state;
}
```

### Default snippets

Default snippets are seeded from `data/snippets/defaults.json` on activation. They are inserted **inactive** — users opt in deliberately. Upgrading never overwrites a user's `is_active` setting.

---

## REST API Endpoints

All endpoints are under `/wp-json/cplai/v1/` and require `manage_options` capability.

### Maps

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/maps` | List all installed maps |
| `POST` | `/maps/upload` | Upload a new JSON map |
| `POST` | `/maps/{id}/activate` | Set a map as active for its type |
| `DELETE` | `/maps/{id}` | Delete a user map (default maps protected) |
| `POST` | `/maps/save-edit` | Save an edited map from the Lexicon editor |
| `POST` | `/maps/restore-default` | Restore the bundled default for a map type |

### Snippets

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/snippets` | List all snippets |
| `GET` | `/snippets/active?direction=X` | Active snippet `js_body` strings for the JS engine |
| `GET` | `/snippets/{id}` | Get a single snippet |
| `POST` | `/snippets/generate` | AI-generate a snippet `js_body` |
| `POST` | `/snippets/sync-defaults` | Insert new default snippets from `defaults.json` |
| `POST` | `/snippets/save` | Insert a new snippet |
| `POST` | `/snippets/{id}/toggle` | Enable or disable a snippet |
| `POST` | `/snippets/{id}/reorder` | Update `sort_order` |
| `POST` | `/snippets/{id}` | Update snippet fields |
| `DELETE` | `/snippets/{id}` | Delete a user / AI-generated snippet |

### Other

| Method | Endpoint | Purpose |
|---|---|---|
| `POST` | `/test/run` | Run transliteration via the PHP engine (server-side) |
| `GET` | `/status` | Plugin status, active maps, snippet counts |
| `GET` | `/lexicon` | Active forward + reverse map data for the Lexicon editor |
| `GET/POST` | `/settings` | Get or update plugin settings |

---

## Admin UI Tabs

| Tab | Purpose |
|---|---|
| 🤖 AI Studio | Describe transliteration logic → AI generates a compatible snippet hook function → save to Snippet Registry |
| 🧩 Snippets | Browse, enable/disable, reorder, edit, and AI-generate individual snippet hook functions |
| ⚗️ Test Console | Run transliteration with the fixed JS engine (browser, with active snippets) or the fixed PHP engine (server-side) |
| 🗺️ Map Manager | Upload, activate, and delete forward/reverse JSON maps |
| 📖 Lexicon | Browse and inline-edit the active map; save edits back to DB |
| 🔧 Settings | Configure AI provider, API keys, and model selection |

---

## The AI Workflow (v4)

```
1. AI Studio tab — fill in snippet key, label, direction, hook stage, logic description
         ↓
2. [Generate Snippet] → AI receives active maps + engine contract → returns a named hook function
         ↓
3. Inspect generated js_body
         ↓
4. [Save as Snippet] or [Open in Snippet Editor] → saved to DB, inactive by default
         ↓
5. Snippets tab → toggle snippet ON
         ↓
6. Test Console → JS engine loads active snippets → run test → inspect log
```

---

## BPM Script Notes

- **Script family:** Bengali-Assamese abugida (Unicode U+0980–U+09FF)
- **Inherent vowel:** `o` (অ) — differs from Sanskrit/Hindi (`a`)
- **Assamese-specific:** ৰ (`rr`), ৱ (`w`) — used in BPM
- **Virama:** ্ (U+09CD) — suppresses the inherent vowel in consonant clusters
- **ZWJ / ZWNJ:** used to force or break reph ligatures and conjuncts
- **ISO 639-3:** BPY

---

## Debug Mode

Enable WordPress debug mode in `wp-config.php`:

```php
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
```

With debug enabled, the plugin:
- Shows DB errors in the admin message bar
- Logs REST errors to the browser console
- Includes `debug` objects in API responses (last query, last error, query count)
- Logs snippet execution errors with function name and message

---

## Uninstallation

**WP Admin → Plugins → Deactivate → Delete**

The `uninstall.php` script runs automatically and removes:
- All three custom DB tables (`maps`, `sessions`, `snippets`) plus the legacy `injected_code` table if present
- All plugin options from `wp_options`
- Per-site data on multisite installations

No residue is left on the server.

---

## Changelog

### 4.1.0-beta
- **Fixed engine architecture** — PHP (`class-engine.php`) and JS (`assets/js/engine.js`) engines are now fixed, hand-written code; never AI-generated
- **Snippet hook slots** — pre, loop, and post hook slots wired into both engines
- **AI Studio** now generates snippet `js_body` only — full engine generation removed
- **JS engine** (`assets/js/engine.js`) — new fixed file with hook slots, loaded as an enqueued asset
- **`/snippets/active`** REST endpoint — serves active `js_body` strings to the browser JS engine
- **Test Console** — engine selector now offers JS engine (browser + active snippets) vs PHP engine (server-side)
- **`wp_cplai_injected_code`** table dropped on activation (legacy v2/v3)
- **`data/parseLogic.json`** removed — `virama` and `inherent_vowel` are hardcoded engine constants
- Version bumped to `4.0.0-beta`; minimum PHP raised to 8.1, minimum WP raised to 6.4

### 2.0.0 / 3.x
- Snippet Registry introduced (`wp_cplai_snippets` table)
- Multi-provider AI support (Gemini, OpenAI, Grok)
- Lexicon inline editor
- Map format v2 (ordered pairs)

### 1.0.0
- Initial release — forward/reverse transliteration framework, AI inject workflow, default maps

---

## License

GPL-2.0-or-later — [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html)

---

## Credits

Developed by **BhoomiTech Heritage and Development Foundation**  
Plugin site: [https://bhoomitechfoundation.org/apps/bmime/](https://bhoomitechfoundation.org/apps/bmime/)

Built for Bishnupriya Manipuri (বিষ্ণুপ্রিয়া মণিপুরী) computational linguistics research.  
Script reference: Bengali-Assamese Unicode block, ISO 15919, and BPM community orthographic conventions.
