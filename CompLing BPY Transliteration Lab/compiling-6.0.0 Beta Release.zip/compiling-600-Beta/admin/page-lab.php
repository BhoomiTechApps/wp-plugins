<?php
/**
 * Admin page template — BPM Transliteration Lab.
 *
 * v4.0 changes:
 *  - AI Studio tab generates snippet hook functions only (no full engine generation).
 *  - Test Console runs the fixed JS engine (CPLAI_ENGINE) client-side; PHP engine via REST.
 *  - Snippets tab has full CRUD + AI generation for each snippet's js_body.
 *  - Inject / cplai_injected UI elements removed entirely.
 *
 * @package CompilingAI
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="cplai-wrap" class="wrap">

  <h1 class="cplai-title">
    <span class="cplai-logo">বিষ্ণুপ্রিয়া</span>
    BPM Transliteration Lab
    <span class="cplai-version">v<?php echo esc_html( CPLAI_VERSION ); ?></span>
  </h1>

  <!-- Debug / server message bar -->
  <div id="cplai-msg-bar" class="cplai-msg-bar" style="display:none;"></div>

  <!-- ── Tab navigation ──────────────────────────────────────────────────── -->
  <nav class="cplai-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Lab sections', 'compiling-ai' ); ?>">
    <button class="cplai-tab active" data-tab="ai-studio"    role="tab" aria-controls="tab-ai-studio"    aria-selected="true" ><?php esc_html_e( '🤖 AI Studio',    'compiling-ai' ); ?></button>
    <button class="cplai-tab"        data-tab="snippets"     role="tab" aria-controls="tab-snippets"     aria-selected="false"><?php esc_html_e( '🧩 Snippets',     'compiling-ai' ); ?></button>
    <button class="cplai-tab"        data-tab="test-console" role="tab" aria-controls="tab-test-console" aria-selected="false"><?php esc_html_e( '⚗️ Test Console', 'compiling-ai' ); ?></button>
    <button class="cplai-tab"        data-tab="maps"         role="tab" aria-controls="tab-maps"         aria-selected="false"><?php esc_html_e( '🗺️ Map Manager',  'compiling-ai' ); ?></button>
    <button class="cplai-tab"        data-tab="lexicon"      role="tab" aria-controls="tab-lexicon"      aria-selected="false"><?php esc_html_e( '📖 Lexicon',      'compiling-ai' ); ?></button>
    <button class="cplai-tab"        data-tab="settings"     role="tab" aria-controls="tab-settings"     aria-selected="false"><?php esc_html_e( '🔧 Settings',     'compiling-ai' ); ?></button>
  </nav>


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 1 — AI STUDIO
       Generates a single snippet hook function (js_body only).
       No engine injection. Output can be saved directly to the snippet DB.
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-ai-studio" class="cplai-panel active" role="tabpanel" aria-labelledby="tab-ai-studio">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'AI Code Studio', 'compiling-ai' ); ?></h2>
      <p>
        <?php esc_html_e( 'Describe a single transliteration rule in plain language. The AI generates a compatible JavaScript snippet hook function. Inspect the code, then save it to the Snippet Registry — or send it directly to the Snippet editor via the button below.', 'compiling-ai' ); ?>
      </p>
      <p class="cplai-notice cplai-notice-info">
        <strong><?php esc_html_e( 'v4 Architecture:', 'compiling-ai' ); ?></strong>
        <?php esc_html_e( 'The transliteration engine is now fixed code. AI only generates hook functions (snippets) that plug into the engine\'s pre / loop / post slots.', 'compiling-ai' ); ?>
      </p>
    </div>

    <div class="cplai-row">

      <!-- Left: controls -->
      <div class="cplai-col cplai-col-controls">

        <div class="cplai-field">
          <label for="ai-snippet-key"><?php esc_html_e( 'Snippet Key', 'compiling-ai' ); ?> <span class="cplai-required">*</span></label>
          <input type="text" id="ai-snippet-key" placeholder="e.g. loop_reph_ligature" />
          <span class="cplai-hint"><?php esc_html_e( 'Unique machine name (lowercase + underscores). Used as the JS function name.', 'compiling-ai' ); ?></span>
        </div>

        <div class="cplai-field">
          <label for="ai-snippet-label"><?php esc_html_e( 'Label', 'compiling-ai' ); ?></label>
          <input type="text" id="ai-snippet-label" placeholder="e.g. Loop: Reph Ligature" />
        </div>

        <div class="cplai-row cplai-row-tight">
          <div class="cplai-field">
            <label for="ai-direction"><?php esc_html_e( 'Direction', 'compiling-ai' ); ?></label>
            <select id="ai-direction">
              <option value="both"><?php esc_html_e( 'Both', 'compiling-ai' ); ?></option>
              <option value="forward"><?php esc_html_e( 'Forward (Roman → BPM)', 'compiling-ai' ); ?></option>
              <option value="reverse"><?php esc_html_e( 'Reverse (BPM → Roman)', 'compiling-ai' ); ?></option>
            </select>
          </div>
          <div class="cplai-field">
            <label for="ai-hook-stage"><?php esc_html_e( 'Hook Stage', 'compiling-ai' ); ?></label>
            <select id="ai-hook-stage">
              <option value="pre"><?php esc_html_e( 'Pre (before main loop)', 'compiling-ai' ); ?></option>
              <option value="loop" selected><?php esc_html_e( 'Loop (during main loop)', 'compiling-ai' ); ?></option>
              <option value="post"><?php esc_html_e( 'Post (after main loop)', 'compiling-ai' ); ?></option>
            </select>
          </div>
        </div>

        <div class="cplai-field">
          <label for="ai-map-source"><?php esc_html_e( 'Active Map Source', 'compiling-ai' ); ?></label>
          <select id="ai-map-source">
            <option value="default"><?php esc_html_e( 'Default (bundled JSON files)', 'compiling-ai' ); ?></option>
            <option value="db"><?php esc_html_e( 'Database (user-uploaded)', 'compiling-ai' ); ?></option>
          </select>
          <span class="cplai-hint"><?php esc_html_e( 'The selected active maps are embedded in the AI generation context.', 'compiling-ai' ); ?></span>
        </div>

        <div class="cplai-field">
          <label for="ai-prompt"><?php esc_html_e( 'Logic Description', 'compiling-ai' ); ?> <span class="cplai-required">*</span></label>
          <textarea id="ai-prompt" rows="8"
            placeholder="<?php esc_attr_e( "Describe what this snippet should do, e.g.:\n\n• When the input sequence 'ng' appears before 'k', 'g', 'kh', or 'gh', map it to ঙ (velar nasal) instead of the default ন.\n\n• During forward transliteration, before the main loop, replace all occurrences of 'rr' with the special reph token '্র' so the loop handles it as a unit.\n\n• After reverse transliteration, trim any trailing inherent vowel that appears before a word boundary.", 'compiling-ai' ); ?>"></textarea>
        </div>

        <div class="cplai-btn-row">
          <button id="btn-generate" class="cplai-btn cplai-btn-primary">
            <?php esc_html_e( '✨ Generate Snippet', 'compiling-ai' ); ?>
          </button>
          <span id="ai-spinner" class="cplai-spinner" style="display:none;"><?php esc_html_e( 'Generating…', 'compiling-ai' ); ?></span>
        </div>

      </div><!-- .cplai-col-controls -->

      <!-- Right: generated code output -->
      <div class="cplai-col cplai-col-output">

        <div class="cplai-code-header">
          <span><?php esc_html_e( 'Generated JavaScript Hook', 'compiling-ai' ); ?></span>
          <div class="cplai-code-actions" style="display:none;" id="code-actions">
            <button id="btn-copy-code"     class="cplai-btn cplai-btn-sm"><?php esc_html_e( '📋 Copy', 'compiling-ai' ); ?></button>
            <button id="btn-send-to-snip"  class="cplai-btn cplai-btn-success"><?php esc_html_e( '→ Open in Snippet Editor', 'compiling-ai' ); ?></button>
            <button id="btn-save-as-snip"  class="cplai-btn cplai-btn-primary"><?php esc_html_e( '💾 Save as Snippet', 'compiling-ai' ); ?></button>
          </div>
        </div>

        <div id="ai-explanation" class="cplai-explanation" style="display:none;"></div>

        <pre id="code-output" class="cplai-code-block"><code id="code-inner"><?php esc_html_e( '// Generated snippet code will appear here…', 'compiling-ai' ); ?></code></pre>

        <div id="ai-save-status" class="cplai-inject-status" style="display:none;"></div>

      </div><!-- .cplai-col-output -->

    </div><!-- .cplai-row -->
  </section><!-- #tab-ai-studio -->


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 2 — SNIPPETS
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-snippets" class="cplai-panel" role="tabpanel" aria-labelledby="tab-snippets;">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'Snippet Registry', 'compiling-ai' ); ?></h2>
      <p><?php esc_html_e( 'Named, independently enable/disable-able hook functions. Each snippet targets one parsing logic unit (reph, anusvara, y-fala, etc.) and runs at a specific engine stage: pre, loop, or post.', 'compiling-ai' ); ?></p>
    </div>

    <!-- Toolbar -->
    <div class="cplai-snippet-toolbar">
      <span id="snip-count" class="cplai-snippet-count"></span>
      <input type="text" id="snip-search" class="cplai-snip-search" placeholder="<?php esc_attr_e( 'Search snippets…', 'compiling-ai' ); ?>" />
      <div class="cplai-snippet-actions">
        <button id="btn-snip-sync-defaults" class="cplai-btn cplai-btn-sm" title="<?php esc_attr_e( 'Insert any new default snippets from defaults.json that are not yet in the database', 'compiling-ai' ); ?>">
          <?php esc_html_e( '⬇ Sync Defaults', 'compiling-ai' ); ?>
        </button>
        <button id="btn-snip-export" class="cplai-btn cplai-btn-sm" title="<?php esc_attr_e( 'Export all snippets as defaults.json', 'compiling-ai' ); ?>"><?php esc_html_e( '⬆ Export JSON', 'compiling-ai' ); ?></button>
        <button id="btn-snip-refresh" class="cplai-btn cplai-btn-sm"><?php esc_html_e( '↻ Refresh', 'compiling-ai' ); ?></button>
        <button id="btn-snip-new"     class="cplai-btn cplai-btn-primary"><?php esc_html_e( '＋ New Snippet', 'compiling-ai' ); ?></button>
      </div>
    </div>

    <!-- Snippet list -->
    <div id="snip-loading" class="cplai-loading" style="display:none;"><?php esc_html_e( 'Loading snippets…', 'compiling-ai' ); ?></div>
    <div id="snip-list"></div>

    <!-- Snippet editor panel (hidden until New / Edit) -->
    <div id="snip-editor" class="cplai-snip-editor" style="display:none;">

      <div class="cplai-snip-editor-header">
        <h3 id="snip-editor-title"><?php esc_html_e( 'New Snippet', 'compiling-ai' ); ?></h3>
        <button id="btn-snip-editor-close" class="cplai-btn cplai-btn-sm"><?php esc_html_e( '✕ Close', 'compiling-ai' ); ?></button>
      </div>

      <input type="hidden" id="snip-id" value="" />

      <div class="cplai-row">
        <div class="cplai-col">

          <div class="cplai-field">
            <label for="snip-key"><?php esc_html_e( 'Snippet Key', 'compiling-ai' ); ?> <span class="cplai-required">*</span></label>
            <input type="text" id="snip-key" placeholder="e.g. loop_reph_ligature" />
            <span class="cplai-hint"><?php esc_html_e( 'Unique machine name. Use lowercase + underscores. Cannot be changed after saving.', 'compiling-ai' ); ?></span>
          </div>

          <div class="cplai-field">
            <label for="snip-label"><?php esc_html_e( 'Label', 'compiling-ai' ); ?></label>
            <input type="text" id="snip-label" placeholder="e.g. Loop: Reph Ligature" />
          </div>

          <div class="cplai-row cplai-row-tight">
            <div class="cplai-field">
              <label for="snip-direction"><?php esc_html_e( 'Direction', 'compiling-ai' ); ?></label>
              <select id="snip-direction">
                <option value="forward"><?php esc_html_e( 'Forward', 'compiling-ai' ); ?></option>
                <option value="reverse"><?php esc_html_e( 'Reverse', 'compiling-ai' ); ?></option>
                <option value="both"><?php esc_html_e( 'Both', 'compiling-ai' ); ?></option>
              </select>
            </div>
            <div class="cplai-field">
              <label for="snip-stage"><?php esc_html_e( 'Hook Stage', 'compiling-ai' ); ?></label>
              <select id="snip-stage">
                <option value="pre"><?php esc_html_e( 'Pre (before main loop)', 'compiling-ai' ); ?></option>
                <option value="loop"><?php esc_html_e( 'Loop (during main loop)', 'compiling-ai' ); ?></option>
                <option value="post"><?php esc_html_e( 'Post (after main loop)', 'compiling-ai' ); ?></option>
              </select>
            </div>
            <div class="cplai-field">
              <label for="snip-order"><?php esc_html_e( 'Sort Order', 'compiling-ai' ); ?></label>
              <input type="number" id="snip-order" value="100" min="0" step="10" style="width:90px;" />
              <span class="cplai-hint"><?php esc_html_e( 'Lower = higher priority.', 'compiling-ai' ); ?></span>
            </div>
          </div>

          <div class="cplai-field">
            <label for="snip-description"><?php esc_html_e( 'Logic Description', 'compiling-ai' ); ?></label>
            <textarea id="snip-description" rows="4"
              placeholder="<?php esc_attr_e( 'Describe what this snippet does in plain language — this is sent to AI to generate the function body.', 'compiling-ai' ); ?>"></textarea>
          </div>

          <div class="cplai-btn-row">
            <button id="btn-snip-ai-gen" class="cplai-btn cplai-btn-primary">
              <?php esc_html_e( '✨ Generate with AI', 'compiling-ai' ); ?>
            </button>
            <span id="snip-ai-spinner" class="cplai-spinner" style="display:none;"><?php esc_html_e( 'Generating…', 'compiling-ai' ); ?></span>
          </div>

        </div><!-- .cplai-col -->

        <div class="cplai-col">
          <div class="cplai-field">
            <label for="snip-js-body"><?php esc_html_e( 'JavaScript Function Body', 'compiling-ai' ); ?></label>
            <textarea id="snip-js-body" rows="18" class="cplai-code-textarea"
              placeholder="<?php esc_attr_e( "function mySnippet(state, config) {\n  // state.input  — full original input string\n  // state.output — accumulated output\n  // state.pos    — current position in input (loop stage)\n  // state.prev   — { token, was_consonant, was_matra }\n  // state.log    — string[] debug log\n  // state.handled — set true in loop stage to claim the token\n  // config.virama, config.inherent_vowel\n  // config.maps.forward, config.maps.reverse\n  // config.consonants_set, config.matras_set\n  return state;\n}", 'compiling-ai' ); ?>"></textarea>
          </div>
          <div class="cplai-field">
            <label for="snip-php-body"><?php esc_html_e( 'PHP Rule Array (JSON)', 'compiling-ai' ); ?></label>
            <textarea id="snip-php-body" rows="8" class="cplai-code-textarea"
              placeholder="<?php esc_attr_e( '[ { "type": "replace", "from": "source", "to": "target", "regex": false } ]', 'compiling-ai' ); ?>"></textarea>
            <p class="description"><?php esc_html_e( 'JSON array of find-replace rules for the server-side PHP engine. Auto-filled by AI generation. Leave empty if this snippet is JS-only.', 'compiling-ai' ); ?></p>
          </div>
          <div class="cplai-btn-row">
            <button id="btn-snip-save" class="cplai-btn cplai-btn-success"><?php esc_html_e( '💾 Save Snippet', 'compiling-ai' ); ?></button>
          </div>
        </div><!-- .cplai-col -->
      </div><!-- .cplai-row -->

    </div><!-- #snip-editor -->

  </section><!-- #tab-snippets -->


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 3 — TEST CONSOLE
       v4: JS engine (fixed) runs client-side with active snippets.
           PHP engine runs server-side via REST (rule-based, pre/post hooks only).
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-test-console" class="cplai-panel" role="tabpanel" aria-labelledby="tab-test-console;">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'Test Console', 'compiling-ai' ); ?></h2>
      <p><?php esc_html_e( 'Run transliteration through either engine. The JS engine loads active snippets from the database and runs entirely in the browser. The PHP engine processes server-side with pre/post rule hooks.', 'compiling-ai' ); ?></p>
    </div>

    <div class="cplai-row" style="align-items:flex-end; gap:1rem; flex-wrap:wrap; margin-bottom:16px;">
      <div class="cplai-field">
        <label for="test-direction"><?php esc_html_e( 'Direction', 'compiling-ai' ); ?></label>
        <select id="test-direction">
          <option value="forward"><?php esc_html_e( 'Forward (Roman → BPM)', 'compiling-ai' ); ?></option>
          <option value="reverse"><?php esc_html_e( 'Reverse (BPM → Roman)', 'compiling-ai' ); ?></option>
        </select>
      </div>
      <div class="cplai-field">
        <label for="test-engine"><?php esc_html_e( 'Engine', 'compiling-ai' ); ?></label>
        <select id="test-engine">
          <option value="js"><?php esc_html_e( 'JS Engine (fixed, browser-side, with active snippets)', 'compiling-ai' ); ?></option>
          <option value="php"><?php esc_html_e( 'PHP Engine (fixed, server-side, pre/post hooks only)', 'compiling-ai' ); ?></option>
        </select>
      </div>
      <div class="cplai-field cplai-field-inline" id="test-engine-note" style="align-self:flex-end;">
        <span class="cplai-badge cplai-badge-js"><?php esc_html_e( 'Fixed engine + active snippets', 'compiling-ai' ); ?></span>
      </div>
    </div>

    <div class="cplai-test-grid">

      <div class="cplai-test-pane">
        <label for="test-input"><?php esc_html_e( 'Input Text', 'compiling-ai' ); ?></label>
        <textarea id="test-input" rows="10"
          placeholder="<?php esc_attr_e( "Enter text here…\n\nRoman example: ima Thar punci palok\nBPM example: ইমা ঠাৰ পুন্চি পালক", 'compiling-ai' ); ?>"></textarea>
      </div>

      <div class="cplai-test-arrow">
        <button id="btn-run-test" class="cplai-btn cplai-btn-primary cplai-btn-run">
          <?php esc_html_e( '▶ Run', 'compiling-ai' ); ?>
        </button>
        <span id="test-direction-label" class="cplai-dir-label">→</span>
      </div>

      <div class="cplai-test-pane">
        <label><?php esc_html_e( 'Output', 'compiling-ai' ); ?></label>
        <textarea id="test-output" rows="10" readonly
          placeholder="<?php esc_attr_e( 'Output appears here…', 'compiling-ai' ); ?>"></textarea>
      </div>

    </div><!-- .cplai-test-grid -->

    <div id="test-log" class="cplai-log" style="display:none;">
      <div class="cplai-log-header">
        <?php esc_html_e( 'Engine Log', 'compiling-ai' ); ?>
        <button id="btn-clear-log" class="cplai-btn cplai-btn-sm"><?php esc_html_e( 'Clear', 'compiling-ai' ); ?></button>
      </div>
      <pre id="test-log-content"></pre>
    </div>

  </section><!-- #tab-test-console -->


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 4 — MAP MANAGER
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-maps" class="cplai-panel" role="tabpanel" aria-labelledby="tab-maps;">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'Map Manager', 'compiling-ai' ); ?></h2>
      <p><?php esc_html_e( 'Upload custom forwardMap.json or reverseMap.json. Activate the map you want the engine and AI to use. Default maps are protected.', 'compiling-ai' ); ?></p>
    </div>

    <!-- Upload form -->
    <div class="cplai-upload-box">
      <h3><?php esc_html_e( 'Upload New Map', 'compiling-ai' ); ?></h3>
      <div class="cplai-row cplai-row-tight">
        <div class="cplai-field">
          <label for="upload-type"><?php esc_html_e( 'Map Type', 'compiling-ai' ); ?></label>
          <select id="upload-type">
            <option value="forward"><?php esc_html_e( 'Forward Map', 'compiling-ai' ); ?></option>
            <option value="reverse"><?php esc_html_e( 'Reverse Map', 'compiling-ai' ); ?></option>
          </select>
        </div>
        <div class="cplai-field">
          <label for="upload-label"><?php esc_html_e( 'Label', 'compiling-ai' ); ?></label>
          <input type="text" id="upload-label" placeholder="<?php esc_attr_e( 'e.g. BPM Cachar dialect v2', 'compiling-ai' ); ?>" />
        </div>
      </div>
      <div class="cplai-field">
        <label for="upload-json"><?php esc_html_e( 'JSON Content', 'compiling-ai' ); ?></label>
        <textarea id="upload-json" rows="12" placeholder="<?php esc_attr_e( 'Paste JSON content here…', 'compiling-ai' ); ?>"></textarea>
      </div>
      <div class="cplai-btn-row">
        <button id="btn-upload-map" class="cplai-btn cplai-btn-primary"><?php esc_html_e( '📤 Upload Map', 'compiling-ai' ); ?></button>
        <button id="btn-load-file"  class="cplai-btn cplai-btn-sm"><?php esc_html_e( '📂 Load from file…', 'compiling-ai' ); ?></button>
        <input type="file" id="file-picker" accept=".json" style="display:none;" />
      </div>
    </div>

    <!-- Maps table -->
    <div class="cplai-maps-section">
      <div class="cplai-maps-header">
        <h3><?php esc_html_e( 'Installed Maps', 'compiling-ai' ); ?></h3>
        <button id="btn-refresh-maps" class="cplai-btn cplai-btn-sm"><?php esc_html_e( '↻ Refresh', 'compiling-ai' ); ?></button>
      </div>
      <div id="maps-table-wrap">
        <table class="cplai-table" id="maps-table">
          <thead>
            <tr>
              <th><?php esc_html_e( 'ID',      'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Type',    'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Label',   'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Source',  'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Active',  'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Added',   'compiling-ai' ); ?></th>
              <th><?php esc_html_e( 'Actions', 'compiling-ai' ); ?></th>
            </tr>
          </thead>
          <tbody id="maps-tbody">
            <tr><td colspan="7" class="cplai-loading"><?php esc_html_e( 'Loading maps…', 'compiling-ai' ); ?></td></tr>
          </tbody>
        </table>
      </div>
    </div>

  </section><!-- #tab-maps -->


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 5 — LEXICON VIEWER / EDITOR
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-lexicon" class="cplai-panel" role="tabpanel" aria-labelledby="tab-lexicon;">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'Lexicon', 'compiling-ai' ); ?></h2>
      <p><?php esc_html_e( 'Browse and edit the active Forward (Roman → BPM) and Reverse (BPM → Roman) mapping tables, grouped by category.', 'compiling-ai' ); ?></p>
    </div>

    <div class="cplai-lexicon-toolbar">
      <div class="cplai-lexicon-toggles">
        <button class="cplai-btn cplai-btn-sm cplai-lex-dir-btn active" data-dir="forward"><?php esc_html_e( 'Forward (Roman → BPM)', 'compiling-ai' ); ?></button>
        <button class="cplai-btn cplai-btn-sm cplai-lex-dir-btn"        data-dir="reverse"><?php esc_html_e( 'Reverse (BPM → Roman)', 'compiling-ai' ); ?></button>
      </div>
      <input type="text" id="lex-search" class="cplai-lex-search" placeholder="<?php esc_attr_e( 'Filter entries…', 'compiling-ai' ); ?>" />
      <div class="cplai-lexicon-edit-actions">
        <button id="btn-lex-expand-all"  class="cplai-btn cplai-btn-sm"><?php esc_html_e( '⊞ Expand All',     'compiling-ai' ); ?></button>
        <button id="btn-lex-collapse-all" class="cplai-btn cplai-btn-sm"><?php esc_html_e( '⊟ Collapse All',   'compiling-ai' ); ?></button>
        <button id="btn-lex-export"      class="cplai-btn cplai-btn-sm"><?php esc_html_e( '⬇ Export JSON',    'compiling-ai' ); ?></button>
        <button id="btn-lex-edit"        class="cplai-btn cplai-btn-sm cplai-btn-primary"><?php esc_html_e( '✏️ Edit Map',       'compiling-ai' ); ?></button>
        <button id="btn-lex-save"        class="cplai-btn cplai-btn-sm cplai-btn-success" style="display:none;"><?php esc_html_e( '💾 Save Changes',  'compiling-ai' ); ?></button>
        <button id="btn-lex-discard"     class="cplai-btn cplai-btn-sm cplai-btn-danger"  style="display:none;"><?php esc_html_e( '✕ Discard',        'compiling-ai' ); ?></button>
        <button id="btn-lex-restore"     class="cplai-btn cplai-btn-sm"                   style="display:none;"><?php esc_html_e( '↩ Restore Default', 'compiling-ai' ); ?></button>
      </div>
    </div>

    <div id="lex-loading" class="cplai-loading" style="display:none;"><?php esc_html_e( 'Loading lexicon…', 'compiling-ai' ); ?></div>
    <div id="lex-content"></div>

  </section><!-- #tab-lexicon -->


  <!-- ════════════════════════════════════════════════════════════════════════
       TAB 6 — SETTINGS
  ════════════════════════════════════════════════════════════════════════ -->
  <section id="tab-settings" class="cplai-panel" role="tabpanel" aria-labelledby="tab-settings;">

    <div class="cplai-panel-header">
      <h2><?php esc_html_e( 'Settings', 'compiling-ai' ); ?></h2>
    </div>

    <table class="cplai-settings-table">
      <tr>
        <th><label for="s-ai-provider"><?php esc_html_e( 'AI Provider', 'compiling-ai' ); ?></label></th>
        <td>
          <select id="s-ai-provider">
            <option value="anthropic"><?php esc_html_e( 'Anthropic (Claude)',  'compiling-ai' ); ?></option>
            <option value="gemini"><?php esc_html_e( 'Google Gemini',         'compiling-ai' ); ?></option>
            <option value="openai"><?php esc_html_e( 'OpenAI (ChatGPT)',      'compiling-ai' ); ?></option>
            <option value="grok"><?php esc_html_e( 'xAI Grok',               'compiling-ai' ); ?></option>
          </select>
          <p class="cplai-hint"><?php esc_html_e( 'Choose which AI provider to use for snippet code generation. Enter the corresponding API key below.', 'compiling-ai' ); ?></p>
        </td>
      </tr>

      <!-- Anthropic key -->
      <tr id="s-row-anthropic-key">
        <th><label for="s-api-key"><?php esc_html_e( 'Anthropic API Key', 'compiling-ai' ); ?></label></th>
        <td>
          <div class="cplai-key-row">
            <input type="password" id="s-api-key" class="cplai-wide-input" placeholder="sk-ant-…" autocomplete="off" />
            <span id="s-api-key-tick" class="cplai-key-tick" style="display:none;" title="<?php esc_attr_e( 'API key is saved', 'compiling-ai' ); ?>">✔</span>
          </div>
          <p class="cplai-hint">
            <?php esc_html_e( 'Used when Anthropic is selected. Get your key from', 'compiling-ai' ); ?>
            <a href="https://console.anthropic.com/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Anthropic Console', 'compiling-ai' ); ?></a>.
            <?php esc_html_e( 'Never exposed to the front-end.', 'compiling-ai' ); ?>
          </p>
        </td>
      </tr>

      <!-- Gemini key -->
      <tr id="s-row-gemini-key">
        <th><label for="s-gemini-key"><?php esc_html_e( 'Google Gemini API Key', 'compiling-ai' ); ?></label></th>
        <td>
          <div class="cplai-key-row">
            <input type="password" id="s-gemini-key" class="cplai-wide-input" placeholder="AIza…" autocomplete="off" />
            <span id="s-gemini-key-tick" class="cplai-key-tick" style="display:none;" title="<?php esc_attr_e( 'API key is saved', 'compiling-ai' ); ?>">✔</span>
          </div>
          <p class="cplai-hint">
            <?php esc_html_e( 'Used when Google Gemini is selected. Get your key from', 'compiling-ai' ); ?>
            <a href="https://aistudio.google.com/app/apikey" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Google AI Studio', 'compiling-ai' ); ?></a>.
            <?php esc_html_e( 'Never exposed to the front-end.', 'compiling-ai' ); ?>
          </p>
        </td>
      </tr>

      <!-- OpenAI key -->
      <tr id="s-row-openai-key">
        <th><label for="s-openai-key"><?php esc_html_e( 'OpenAI API Key', 'compiling-ai' ); ?></label></th>
        <td>
          <div class="cplai-key-row">
            <input type="password" id="s-openai-key" class="cplai-wide-input" placeholder="sk-…" autocomplete="off" />
            <span id="s-openai-key-tick" class="cplai-key-tick" style="display:none;" title="<?php esc_attr_e( 'API key is saved', 'compiling-ai' ); ?>">✔</span>
          </div>
          <p class="cplai-hint">
            <?php esc_html_e( 'Used when OpenAI is selected. Get your key from', 'compiling-ai' ); ?>
            <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'OpenAI Platform', 'compiling-ai' ); ?></a>.
            <?php esc_html_e( 'Never exposed to the front-end.', 'compiling-ai' ); ?>
          </p>
        </td>
      </tr>

      <!-- Grok key -->
      <tr id="s-row-grok-key">
        <th><label for="s-grok-key"><?php esc_html_e( 'xAI Grok API Key', 'compiling-ai' ); ?></label></th>
        <td>
          <div class="cplai-key-row">
            <input type="password" id="s-grok-key" class="cplai-wide-input" placeholder="xai-…" autocomplete="off" />
            <span id="s-grok-key-tick" class="cplai-key-tick" style="display:none;" title="<?php esc_attr_e( 'API key is saved', 'compiling-ai' ); ?>">✔</span>
          </div>
          <p class="cplai-hint">
            <?php esc_html_e( 'Used when Grok is selected. Get your key from', 'compiling-ai' ); ?>
            <a href="https://console.x.ai/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'xAI Console', 'compiling-ai' ); ?></a>.
            <?php esc_html_e( 'Never exposed to the front-end.', 'compiling-ai' ); ?>
          </p>
        </td>
      </tr>

      <!-- Model selector -->
      <tr>
        <th><label for="s-model"><?php esc_html_e( 'AI Model', 'compiling-ai' ); ?></label></th>
        <td>
          <select id="s-model">
            <optgroup label="<?php esc_attr_e( 'Anthropic — Claude', 'compiling-ai' ); ?>" class="s-model-anthropic">
              <option value="claude-opus-4-6"><?php esc_html_e( 'claude-opus-4-6 (most capable)', 'compiling-ai' ); ?></option>
              <option value="claude-sonnet-4-6"><?php esc_html_e( 'claude-sonnet-4-6 (recommended)', 'compiling-ai' ); ?></option>
            </optgroup>
            <optgroup label="<?php esc_attr_e( 'Google — Gemini', 'compiling-ai' ); ?>" class="s-model-gemini">
              <option value="gemini-2.5-pro"><?php esc_html_e( 'gemini-2.5-pro (most capable)', 'compiling-ai' ); ?></option>
              <option value="gemini-2.5-flash"><?php esc_html_e( 'gemini-2.5-flash (recommended)', 'compiling-ai' ); ?></option>
              <option value="gemini-2.0-flash"><?php esc_html_e( 'gemini-2.0-flash (fast)', 'compiling-ai' ); ?></option>
            </optgroup>
            <optgroup label="<?php esc_attr_e( 'OpenAI — ChatGPT', 'compiling-ai' ); ?>" class="s-model-openai">
              <option value="gpt-4o"><?php esc_html_e( 'gpt-4o (recommended)', 'compiling-ai' ); ?></option>
              <option value="gpt-4o-mini"><?php esc_html_e( 'gpt-4o-mini (faster, cheaper)', 'compiling-ai' ); ?></option>
            </optgroup>
            <optgroup label="<?php esc_attr_e( 'xAI — Grok', 'compiling-ai' ); ?>" class="s-model-grok">
              <option value="grok-3"><?php esc_html_e( 'grok-3 (most capable)', 'compiling-ai' ); ?></option>
              <option value="grok-3-fast"><?php esc_html_e( 'grok-3-fast (recommended)', 'compiling-ai' ); ?></option>
              <option value="grok-3-mini-fast"><?php esc_html_e( 'grok-3-mini-fast (fastest)', 'compiling-ai' ); ?></option>
            </optgroup>
          </select>
          <p class="cplai-hint" id="s-model-hint"></p>
        </td>
      </tr>

      <!-- Status -->
      <tr>
        <th><?php esc_html_e( 'Status', 'compiling-ai' ); ?></th>
        <td>
          <div id="status-box" class="cplai-status-box">
            <button id="btn-load-status" class="cplai-btn cplai-btn-sm"><?php esc_html_e( 'Load Status', 'compiling-ai' ); ?></button>
            <pre id="status-content" style="display:none;"></pre>
          </div>
        </td>
      </tr>
    </table>

    <div class="cplai-btn-row">
      <button id="btn-save-settings" class="cplai-btn cplai-btn-primary"><?php esc_html_e( '💾 Save Settings', 'compiling-ai' ); ?></button>
    </div>
    <div id="settings-msg" style="display:none;"></div>

  </section><!-- #tab-settings -->

</div><!-- #cplai-wrap -->
