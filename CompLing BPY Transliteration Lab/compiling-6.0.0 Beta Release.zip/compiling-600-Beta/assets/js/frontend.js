/**
 * BPM Transliterator — Frontend Widget JS
 *
 * Handles all `.bpm-transliterator-widget` instances on the page.
 * Debounces input (300ms), then either:
 *   - engine="js"  → runs CPLAI_ENGINE.bpmTransliterate() in-browser
 *   - engine="php" → POSTs to the REST endpoint (default)
 * Supports direction="both" toggle.
 *
 * Global config: window.CPLAI_Frontend = { rest_url, rest_url_base, direction, debug }
 *
 * JS-engine data sources (user-specific, never global):
 *   - Maps    : GET user/lexicon/maps
 *   - Snippets: GET user/snippets/active
 *
 * @package CompilingAI
 */
/* global CPLAI_Frontend, CPLAI_ENGINE */
( function () {
	'use strict';

	const REST_URL      = ( window.CPLAI_Frontend && CPLAI_Frontend.rest_url )
		? CPLAI_Frontend.rest_url
		: '';
	const REST_URL_BASE = ( window.CPLAI_Frontend && CPLAI_Frontend.rest_url_base )
		? CPLAI_Frontend.rest_url_base
		: '';
	const NONCE = ( window.CPLAI_Frontend && CPLAI_Frontend.nonce )
		? CPLAI_Frontend.nonce
		: '';
	const DEBUG = window.CPLAI_Frontend && CPLAI_Frontend.debug === '1';

	// ── JS-engine helpers (maps + snippet hooks) ──────────────────────────────

	let mapsCache        = null;
	const snippetCache   = {};

	async function fetchJSON( url ) {
		const resp = await fetch( url, { headers: { 'X-WP-Nonce': NONCE } } );
		if ( ! resp.ok ) { throw new Error( 'HTTP ' + resp.status ); }
		return resp.json();
	}

	async function getActiveMaps() {
		if ( mapsCache ) { return mapsCache; }
		const data = await fetchJSON( REST_URL_BASE + 'user/lexicon/maps' );
		if ( ! data ) { return null; }

		// PHP now returns pairs pre-sectioned under canonical keys
		// (consonants, matras, independent_vowels, special, digits, punctuation).
		// Each section is an array of [from, to] tuples — the v2 pairs format
		// that isPairsArray() in the engine recognises directly.
		function repack( dirMap ) {
			const out = {};
			for ( const [ section, pairs ] of Object.entries( dirMap ) ) {
				if ( Array.isArray( pairs ) ) {
					out[ section ] = pairs.map( function ( p ) {
						// PHP sends [from, to] tuples; pass them straight through.
						return Array.isArray( p ) ? p : [ p.from, p.to ];
					} );
				}
			}
			return out;
		}

		// Preserve the has_forward / has_reverse flags alongside the repacked map data.
		mapsCache = {
			has_forward: !! data.has_forward,
			has_reverse: !! data.has_reverse,
			forward:     repack( data.forward || {} ),
			reverse:     repack( data.reverse || {} ),
		};
		return mapsCache;
	}

	async function getActiveSnippetHooks( direction ) {
		if ( snippetCache[ direction ] ) { return snippetCache[ direction ]; }
		const data = await fetchJSON(
			REST_URL_BASE + 'user/snippets/active?direction=' + encodeURIComponent( direction )
		);
		if ( ! data ) { return { has_snippets: false, pre: [], loop: [], post: [] }; }
		const hooks = { has_snippets: !! data.has_snippets, pre: [], loop: [], post: [] };
		for ( const stage of [ 'pre', 'loop', 'post' ] ) {
			for ( const snip of ( data[ stage ] || [] ) ) {
				try {
					// eslint-disable-next-line no-new-func
					const fn = new Function(
						'"use strict";\n' + snip.js_body + '\nreturn ' +
						snip.snippet_key.replace( /_([a-z])/g, ( _, c ) => c.toUpperCase() ) + ';'
					)();
					if ( typeof fn === 'function' ) { hooks[ stage ].push( fn ); }
				} catch ( e ) {
					if ( DEBUG ) { console.warn( '[CPLAI Frontend] Snippet compile error:', snip.snippet_key, e ); } // eslint-disable-line no-console
				}
			}
		}
		snippetCache[ direction ] = hooks;
		return hooks;
	}

	// ── Per-widget init ───────────────────────────────────────────────────────

	function initWidget( widget ) {
		const ENGINE    = ( widget.dataset.engine === 'js' ) ? 'js' : 'php';
		const inputEl   = widget.querySelector( '.bpm-tr-input' );
		const outputEl  = widget.querySelector( '.bpm-tr-output' );
		const spinner   = widget.querySelector( '.bpm-tr-spinner' );
		const copyBtn   = widget.querySelector( '.bpm-tr-btn-copy' );
		const clearBtn  = widget.querySelector( '.bpm-tr-btn-clear' );
		const statusEl  = widget.querySelector( '.bpm-tr-status' );
		const toggleBtn = widget.querySelector( '.bpm-tr-toggle-dir' );
		const dirLabel  = widget.querySelector( '.bpm-tr-dir-label' );
		const arrowEl   = widget.querySelector( '.bpm-tr-arrow' );
		const engineBtn   = widget.querySelector( '.bpm-tr-toggle-engine' );
		const engineLabel = widget.querySelector( '.bpm-tr-engine-label' );

		if ( ! inputEl || ! outputEl ) return;

		let debounceTimer = null;
		let currentOutput = '';
		let currentEngine = ENGINE;

		// ── Engine toggle ──────────────────────────────────────────────────────
		function setEngine( eng ) {
			currentEngine = eng;
			widget.dataset.engine = eng;
			if ( engineLabel ) {
				engineLabel.textContent = eng.toUpperCase();
			}
			// Re-transliterate with new engine.
			if ( inputEl.value.trim() ) {
				transliterate( inputEl.value );
			}
		}

		if ( engineBtn ) {
			engineBtn.addEventListener( 'click', () => {
				setEngine( currentEngine === 'php' ? 'js' : 'php' );
			} );
		}

		// ── Direction ──────────────────────────────────────────────────────────
		function getDirection() {
			return widget.dataset.direction || 'forward';
		}

		function setDirection( dir ) {
			widget.dataset.direction = dir;
			if ( dirLabel ) {
				dirLabel.textContent = dir === 'forward'
					? 'Roman → BPM'
					: 'BPM → Roman';
			}
			if ( arrowEl ) {
				// Flip arrow visually for reverse direction.
				arrowEl.className = dir === 'forward'
					? 'bpm-tr-arrow dashicons dashicons-arrow-right-alt'
					: 'bpm-tr-arrow dashicons dashicons-arrow-left-alt';
			}
			// Re-transliterate existing input.
			if ( inputEl.value.trim() ) {
				transliterate( inputEl.value );
			}
		}

		if ( toggleBtn ) {
			toggleBtn.addEventListener( 'click', () => {
				setDirection( getDirection() === 'forward' ? 'reverse' : 'forward' );
			} );
		}

		// ── Transliterate ──────────────────────────────────────────────────────
		function transliterate( text ) {
			clearTimeout( debounceTimer );
			debounceTimer = setTimeout( () => doTransliterate( text ), 300 );
		}

		async function doTransliterate( text ) {
			if ( ! text.trim() ) {
				outputEl.textContent = '';
				currentOutput = '';
				copyBtn && ( copyBtn.disabled = true );
				return;
			}

			spinner && ( spinner.style.display = 'block' );
			setStatus( '' );

			try {
				let output;

				if ( currentEngine === 'js' ) {
					// ── JS engine path ─────────────────────────────────────────
					const direction = getDirection();
					const [ maps, hooks ] = await Promise.all( [
						getActiveMaps(),
						getActiveSnippetHooks( direction ),
					] );

					// Hard blocks — no fallback.
					if ( ! maps ) {
						setStatus( 'Could not load maps.', 'error' );
						return;
					}
					if ( direction === 'forward' && ! maps.has_forward ) {
						setStatus( 'No Forward Lexicon Map found. Load from Default', 'error' );
						return;
					}
					if ( direction === 'reverse' && ! maps.has_reverse ) {
						setStatus( 'No Reverse Lexicon Map found. Load from Default', 'error' );
						return;
					}
					if ( ! hooks || ! hooks.has_snippets ) {
						setStatus( 'No snippets found, Load from Default', 'error' );
						return;
					}

					const safeHooks = { pre: hooks.pre || [], loop: hooks.loop || [], post: hooks.post || [] };
					const result = CPLAI_ENGINE.bpmTransliterate(
						text,
						direction,
						maps,
						safeHooks.pre,
						safeHooks.loop,
						safeHooks.post
					);
					output = result.output || '';
					if ( DEBUG ) { console.log( '[CPLAI Frontend JS engine]', result ); } // eslint-disable-line no-console

				} else {
					// ── PHP engine path (default) ──────────────────────────────
					const resp = await fetch( REST_URL, {
						method:  'POST',
						headers: Object.assign(
							{ 'Content-Type': 'application/json' },
							NONCE ? { 'X-WP-Nonce': NONCE } : {}
						),
						body: JSON.stringify( {
							input_text: text,
							direction:  getDirection(),
						} ),
					} );

					const data = await resp.json();

					if ( data && data.output !== undefined ) {
						output = data.output;
						if ( DEBUG ) { console.log( '[CPLAI Frontend PHP engine]', data ); } // eslint-disable-line no-console
					} else {
						// Surface server-side block messages (e.g. no_snippets) directly.
						const msg = data?.message || 'Transliteration failed.';
						setStatus( msg, 'error' );
						if ( DEBUG ) { console.warn( '[CPLAI Frontend] Error:', data ); } // eslint-disable-line no-console
						return;
					}
				}

				outputEl.textContent = output;
				currentOutput = output;
				copyBtn && ( copyBtn.disabled = false );

			} catch ( err ) {
				setStatus( 'Connection error.', 'error' );
				if ( DEBUG ) { console.error( '[CPLAI Frontend] Error:', err ); } // eslint-disable-line no-console
			} finally {
				spinner && ( spinner.style.display = 'none' );
			}
		}

		// ── Input handler ──────────────────────────────────────────────────────
		inputEl.addEventListener( 'input', () => {
			transliterate( inputEl.value );
		} );

		// ── Copy ───────────────────────────────────────────────────────────────
		if ( copyBtn ) {
			copyBtn.addEventListener( 'click', async () => {
				if ( ! currentOutput ) return;
				try {
					await navigator.clipboard.writeText( currentOutput );
					setStatus( 'Copied!', 'success' );
					setTimeout( () => setStatus( '' ), 2000 );
				} catch {
					// Fallback for older browsers.
					const tmp = document.createElement( 'textarea' );
					tmp.value = currentOutput;
					document.body.appendChild( tmp );
					tmp.select();
					document.execCommand( 'copy' );
					document.body.removeChild( tmp );
					setStatus( 'Copied!', 'success' );
					setTimeout( () => setStatus( '' ), 2000 );
				}
			} );
		}

		// ── Clear ──────────────────────────────────────────────────────────────
		if ( clearBtn ) {
			clearBtn.addEventListener( 'click', () => {
				inputEl.value      = '';
				outputEl.textContent = '';
				currentOutput      = '';
				copyBtn && ( copyBtn.disabled = true );
				setStatus( '' );
				inputEl.focus();
			} );
		}

		// ── Status helper ──────────────────────────────────────────────────────
		function setStatus( msg, type = 'info' ) {
			if ( ! statusEl ) return;
			statusEl.textContent = msg;
			statusEl.className   = 'bpm-tr-status' + ( msg ? ' bpm-tr-status-' + type : '' );
		}
	}

	// ── Boot ──────────────────────────────────────────────────────────────────

	function boot() {
		document.querySelectorAll( '.bpm-transliterator-widget' ).forEach( initWidget );
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', boot );
	} else {
		boot();
	}

} )();
