/**
 * CompLing AI — BPM Lab Admin UI
 *
 * Version:   4.0.0-beta
 * Package:   CompilingAI
 * Author:    BhoomiTech Heritage and Development Foundation
 * License:   GPL-2.0-or-later
 *
 * Architecture v4:
 *  - Fixed JS engine (CPLAI_ENGINE) loaded via engine.js — no AI-generated blobs.
 *  - Active snippets loaded from REST /snippets/active?direction=X on test run.
 *  - AI Studio tab generates snippet js_body only (not full engines).
 *  - ai/generate and ai/inject endpoints removed.
 */

/* global CPLAI, CPLAI_ENGINE, jQuery */
( function ( $ ) {
	'use strict';

	const API = CPLAI.rest_url;
	const HDR = { 'Content-Type': 'application/json', 'X-WP-Nonce': CPLAI.nonce };
	const DBG = CPLAI.debug === '1';

	// ── Snippet cache ─────────────────────────────────────────────────────────
	// Keyed by direction: { forward: { pre: [], loop: [], post: [] }, reverse: {…} }
	const snippetCache = { forward: null, reverse: null };

	// ── Map cache ─────────────────────────────────────────────────────────────
	let mapsData = null;

	// ══════════════════════════════════════════════════════════════════════════
	// UTILITIES
	// ══════════════════════════════════════════════════════════════════════════

	function showMsg( msg, type ) {
		type = type || 'info';
		const bar = $( '#cplai-msg-bar' );
		bar.attr( 'class', 'cplai-msg-bar is-' + type ).text( msg ).show();
		if ( type !== 'error' ) {
			setTimeout( function () { bar.fadeOut(); }, 6000 );
		}
		if ( DBG ) {
			console.log( '[CPLAI]', type.toUpperCase(), msg ); // eslint-disable-line no-console
		}
	}

	function dbgDump( data ) {
		if ( ! DBG || ! data || ! data.debug ) { return; }
		const d = data.debug;
		if ( d.last_error ) { showMsg( '[DB ERROR] ' + d.last_error, 'error' ); }
		console.groupCollapsed( '[CPLAI] Debug dump' ); // eslint-disable-line no-console
		console.log( 'Last query:', d.last_query );     // eslint-disable-line no-console
		console.log( 'Num queries:', d.num_queries );   // eslint-disable-line no-console
		console.groupEnd();                              // eslint-disable-line no-console
	}

	async function apiPost( endpoint, payload ) {
		try {
			const resp = await fetch( API + endpoint, {
				method:  'POST',
				headers: HDR,
				body:    JSON.stringify( payload ),
			} );
			const data = await resp.json();
			if ( ! resp.ok || ! data.success ) {
				showMsg( '[API ERROR] ' + ( data.message || 'HTTP ' + resp.status ), 'error' );
				dbgDump( data );
				return null;
			}
			dbgDump( data );
			return data;
		} catch ( e ) {
			showMsg( '[NETWORK ERROR] ' + e.message, 'error' );
			if ( DBG ) { console.error( '[CPLAI] fetch error:', e ); } // eslint-disable-line no-console
			return null;
		}
	}

	async function apiGet( endpoint ) {
		try {
			const resp = await fetch( API + endpoint, { headers: { 'X-WP-Nonce': CPLAI.nonce } } );
			const data = await resp.json();
			if ( ! resp.ok ) {
				showMsg( '[API ERROR] ' + ( data.message || 'HTTP ' + resp.status ), 'error' );
				return null;
			}
			dbgDump( data );
			return data;
		} catch ( e ) {
			showMsg( '[NETWORK ERROR] ' + e.message, 'error' );
			return null;
		}
	}

	function esc( str ) {
		return String( str )
			.replace( /&/g, '&amp;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' )
			.replace( /"/g, '&quot;' );
	}

	function deepClone( obj ) {
		return JSON.parse( JSON.stringify( obj ) );
	}

	// ══════════════════════════════════════════════════════════════════════════
	// TAB NAVIGATION
	// ══════════════════════════════════════════════════════════════════════════

	$( document ).on( 'click', '.cplai-tab', function () {
		const target = $( this ).data( 'tab' );
		$( '.cplai-tab' ).removeClass( 'active' );
		$( this ).addClass( 'active' );
		$( '.cplai-panel' ).removeClass( 'active' );
		$( '#tab-' + target ).addClass( 'active' );

		if ( target === 'maps' )     { loadMaps(); }
		if ( target === 'settings' ) { loadSettings(); }
		if ( target === 'lexicon' )  { loadLexicon(); }
		if ( target === 'snippets' ) { loadSnippets(); }
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// ACTIVE MAPS LOADER (for JS engine)
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Fetch and cache active maps for use by CPLAI_ENGINE.
	 * Returns { forward: {…}, reverse: {…} } or null.
	 */
	async function getActiveMaps() {
		if ( mapsData ) { return mapsData; }
		const data = await apiGet( 'lexicon' );
		if ( ! data ) { return null; }
		// Convert pairs format { from, to } back to engine's section-array format.
		// CPLAI_ENGINE.flattenMap handles both v1 (object) and v2 (pairs) formats.
		// The lexicon endpoint returns { section: [ { from, to }, … ] } — repack
		// to v2 pairs arrays [ [ from, to ], … ] that the engine expects.
		mapsData = {
			forward: repackLexiconToV2( data.forward || {} ),
			reverse: repackLexiconToV2( data.reverse || {} ),
		};
		return mapsData;
	}

	function repackLexiconToV2( dirMap ) {
		const out = {};
		for ( const [ section, pairs ] of Object.entries( dirMap ) ) {
			if ( Array.isArray( pairs ) ) {
				out[ section ] = pairs.map( function ( p ) { return [ p.from, p.to ]; } );
			}
		}
		return out;
	}

	// ══════════════════════════════════════════════════════════════════════════
	// ACTIVE SNIPPET LOADER (for JS engine hooks)
	// ══════════════════════════════════════════════════════════════════════════

	/**
	 * Fetch active snippets for a direction and compile them into live functions.
	 * Returns { pre: [fn,…], loop: [fn,…], post: [fn,…] } or null.
	 */
	async function getActiveSnippetHooks( direction ) {
		if ( snippetCache[ direction ] ) { return snippetCache[ direction ]; }

		const data = await apiGet( 'snippets/active?direction=' + encodeURIComponent( direction ) );
		if ( ! data ) { return null; }

		const hooks = { pre: [], loop: [], post: [] };
		let compileErrors = 0;

		for ( const stage of [ 'pre', 'loop', 'post' ] ) {
			for ( const snip of ( data[ stage ] || [] ) ) {
				try {
					// Wrap js_body (a named function declaration) in an IIFE to
					// extract the function reference by name.
					// eslint-disable-next-line no-new-func
					const fn = new Function(
						'\"use strict\";\n' + snip.js_body + '\nreturn ' + snip.snippet_key.replace( /_([a-z])/g, ( _, c ) => c.toUpperCase() ) + ';'
					)();
					if ( typeof fn === 'function' ) {
						hooks[ stage ].push( fn );
					} else {
						showMsg( '[SNIPPET] "' + snip.snippet_key + '" did not return a function.', 'error' );
						compileErrors++;
					}
				} catch ( e ) {
					showMsg( '[SNIPPET COMPILE ERROR] ' + snip.snippet_key + ': ' + e.message, 'error' );
					compileErrors++;
				}
			}
		}

		if ( DBG ) {
			const total = hooks.pre.length + hooks.loop.length + hooks.post.length;
			console.log( // eslint-disable-line no-console
				'[CPLAI ENGINE] ' + direction + ' hooks loaded — pre:' + hooks.pre.length +
				' loop:' + hooks.loop.length + ' post:' + hooks.post.length +
				( compileErrors ? ' (' + compileErrors + ' errors)' : '' )
			);
		}

		snippetCache[ direction ] = hooks;
		return hooks;
	}

	/** Invalidate the snippet cache (call after toggle/save/reorder). */
	function invalidateSnippetCache( direction ) {
		if ( direction ) {
			snippetCache[ direction ] = null;
		} else {
			snippetCache.forward = null;
			snippetCache.reverse = null;
		}
	}

	// ══════════════════════════════════════════════════════════════════════════
	// TEST CONSOLE
	// ══════════════════════════════════════════════════════════════════════════

	$( '#test-direction' ).on( 'change', function () {
		$( '#test-direction-label' ).text( $( this ).val() === 'forward' ? '→' : '←' );
	} );

	$( '#btn-run-test' ).on( 'click', async function () {
		const inputText = $( '#test-input' ).val();
		const direction = $( '#test-direction' ).val();
		const engine    = $( '#test-engine' ).val(); // 'js' | 'php'

		if ( ! inputText.trim() ) { showMsg( 'Enter input text.', 'error' ); return; }

		$( this ).prop( 'disabled', true ).text( '▶ Running…' );

		if ( engine === 'js' ) {
			// ── Fixed JS engine path ───────────────────────────────────────────
			const [ maps, hooks ] = await Promise.all( [
				getActiveMaps(),
				getActiveSnippetHooks( direction ),
			] );

			$( this ).prop( 'disabled', false ).text( '▶ Run' );

			if ( ! maps ) { showMsg( 'Could not load maps. Check settings.', 'error' ); return; }

			const safeHooks = hooks || { pre: [], loop: [], post: [] };

			try {
				const result = CPLAI_ENGINE.bpmTransliterate(
					inputText,
					direction,
					maps,
					safeHooks.pre,
					safeHooks.loop,
					safeHooks.post
				);
				$( '#test-output' ).val( result.output || '' );
				if ( result.log && result.log.length ) { appendLog( result.log ); }

				const activeCount = safeHooks.pre.length + safeHooks.loop.length + safeHooks.post.length;
				appendLog( [
					'[ENGINE] JS fixed engine v4 | direction: ' + direction +
					' | active hooks: ' + activeCount +
					' (pre:' + safeHooks.pre.length +
					' loop:' + safeHooks.loop.length +
					' post:' + safeHooks.post.length + ')',
				] );
			} catch ( e ) {
				showMsg( '[JS ENGINE ERROR] ' + e.message, 'error' );
				appendLog( [ '[ENGINE ERROR] ' + e.message ] );
				if ( DBG ) { console.error( '[CPLAI] engine error:', e ); } // eslint-disable-line no-console
			}

		} else {
			// ── PHP engine path ────────────────────────────────────────────────
			const data = await apiPost( 'test/run', {
				input_text: inputText,
				direction:  direction,
			} );

			$( this ).prop( 'disabled', false ).text( '▶ Run' );
			if ( ! data ) { return; }

			$( '#test-output' ).val( data.output || '' );
			if ( data.log && data.log.length ) { appendLog( data.log ); }
			appendLog( [ '[ENGINE] PHP server-side engine | direction: ' + direction ] );
		}
	} );

	function appendLog( lines ) {
		const pre = $( '#test-log-content' );
		pre.text( pre.text() + lines.join( '\n' ) + '\n' );
		$( '#test-log' ).show();
		pre[ 0 ].scrollTop = pre[ 0 ].scrollHeight;
	}

	$( '#btn-clear-log' ).on( 'click', function () {
		$( '#test-log-content' ).text( '' );
		$( '#test-log' ).hide();
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// SNIPPET REGISTRY
	// ══════════════════════════════════════════════════════════════════════════

	let snippetData          = [];
	let lastGeneratedPhpBody = '';

	async function loadSnippets( force ) {
		if ( ! force && snippetData.length ) { renderSnippets(); return; }
		$( '#snip-loading' ).show();
		$( '#snip-list' ).empty();
		const data = await apiGet( 'snippets' );
		$( '#snip-loading' ).hide();
		if ( ! data ) { return; }
		snippetData = data.snippets || [];
		renderSnippets();
	}

	// Track collapsed state for snippet stage groups
	const snipCollapsedStages = { pre: true, loop: true, post: true };

	function renderSnippets() {
		const container = $( '#snip-list' );
		container.empty();

		const filter = ( $( '#snip-search' ).val() || '' ).trim().toLowerCase();

		const filtered = filter ? snippetData.filter( function ( s ) {
			return s.snippet_key.toLowerCase().indexOf( filter ) !== -1 ||
			       ( s.label || '' ).toLowerCase().indexOf( filter ) !== -1 ||
			       ( s.logic_description || '' ).toLowerCase().indexOf( filter ) !== -1 ||
			       ( s.hook_stage || '' ).toLowerCase().indexOf( filter ) !== -1 ||
			       ( s.direction || '' ).toLowerCase().indexOf( filter ) !== -1;
		} ) : snippetData;

		if ( ! snippetData.length ) {
			$( '#snip-count' ).text( '' );
			container.html( '<p class="cplai-loading">No snippets found. Create one with the ＋ New Snippet button.</p>' );
			return;
		}

		const visibleCount = filtered.length;
		$( '#snip-count' ).text(
			( filter ? visibleCount + ' of ' : '' ) +
			snippetData.length + ' snippet' + ( snippetData.length !== 1 ? 's' : '' )
		);

		if ( filter && ! visibleCount ) {
			container.html( '<p class="cplai-loading">No snippets match your search.</p>' );
			return;
		}

		const STAGE_LABELS = { pre: 'Pre', loop: 'Loop', post: 'Post' };
		const STAGE_DESCS  = { pre: 'Runs before the main loop', loop: 'Runs during the main loop', post: 'Runs after the main loop' };
		const DIR_LABELS   = { forward: '→ Fwd', reverse: '← Rev', both: '⇄ Both' };

		const STAGE_ORDER  = [ 'pre', 'loop', 'post' ];
		let html = '';

		STAGE_ORDER.forEach( function ( stage ) {
			const stageSnippets = filtered.filter( function ( s ) { return s.hook_stage === stage; } );
			const allStageSnippets = snippetData.filter( function ( s ) { return s.hook_stage === stage; } );
			if ( ! allStageSnippets.length ) { return; }

			// Auto-expand when filter is active
			const isCollapsed = filter ? false : snipCollapsedStages[ stage ];
			const stageLabel  = STAGE_LABELS[ stage ] || stage;
			const stageDesc   = STAGE_DESCS[ stage ] || '';

			html += '<div class="cplai-snip-group' + ( isCollapsed ? ' cplai-snip-group-collapsed' : '' ) + '" data-stage="' + esc( stage ) + '">' +
				'<div class="cplai-snip-group-header" data-stage="' + esc( stage ) + '">' +
				'<span class="cplai-snip-group-chevron">' + ( isCollapsed ? '▶' : '▼' ) + '</span>' +
				'<span class="cplai-snip-group-label"><span class="cplai-badge cplai-badge-stage-' + esc( stage ) + '">' + esc( stageLabel ) + '</span> ' + esc( stageDesc ) + '</span>' +
				'<span class="cplai-snip-group-count">' + ( filter ? stageSnippets.length + ' / ' : '' ) + allStageSnippets.length + '</span>' +
				'</div>' +
				'<div class="cplai-snip-group-body">';

			if ( ! stageSnippets.length ) {
				html += '<p class="cplai-loading" style="padding:10px 16px;">No snippets match in this group.</p>';
			} else {
				html += '<table class="cplai-table cplai-snip-table">' +
					'<thead><tr>' +
					'<th>Active</th><th class="cplai-col-order">Order</th><th>Key</th><th>Label</th>' +
					'<th>Dir</th><th>Source</th><th>Actions</th>' +
					'</tr></thead><tbody>';

				stageSnippets.forEach( function ( s ) {
					const toggleSwitch =
						'<label class="cplai-toggle" title="' + ( s.is_active == 1 ? 'Disable' : 'Enable' ) + '">' +
						'<input type="checkbox" class="btn-snip-toggle" data-id="' + s.id + '" data-direction="' + esc( s.direction ) + '" data-active="' + s.is_active + '" ' + ( s.is_active == 1 ? 'checked' : '' ) + '>' +
						'<span class="cplai-toggle-slider"></span>' +
						'</label>';

					const srcBadge = s.source === 'default'
						? '<span class="cplai-badge cplai-badge-default">Default</span>'
						: s.source === 'ai_generated'
							? '<span class="cplai-badge cplai-badge-user">AI</span>'
							: '<span class="cplai-badge cplai-badge-user">User</span>';

					html += '<tr>' +
						'<td>' + toggleSwitch + '</td>' +
						'<td class="cplai-col-order"><span class="cplai-order-badge">' + ( s.sort_order !== undefined ? s.sort_order : '—' ) + '</span></td>' +
						'<td><code class="cplai-snip-key">' + esc( s.snippet_key ) + '</code></td>' +
						'<td>' + esc( s.label ) + '</td>' +
						'<td>' + esc( DIR_LABELS[ s.direction ] || s.direction ) + '</td>' +
						'<td>' + srcBadge + '</td>' +
						'<td>' +
						'<a href="#" class="cplai-snip-edit-link btn-snip-edit" data-id="' + s.id + '">Edit</a>' +
						( s.source !== 'default'
							? ' &nbsp;<a href="#" class="cplai-snip-delete-link btn-snip-delete" data-id="' + s.id + '">Delete</a>'
							: '' ) +
						'</td>' +
						'</tr>';
				} );

				html += '</tbody></table>';
			}

			html += '</div></div>'; // .cplai-snip-group-body, .cplai-snip-group
		} );

		container.html( html );
	}

	// Toggle snippet stage group collapse
	$( document ).on( 'click', '.cplai-snip-group-header', function () {
		const stage = $( this ).data( 'stage' );
		const $grp  = $( this ).closest( '.cplai-snip-group' );
		const nowCollapsed = ! $grp.hasClass( 'cplai-snip-group-collapsed' );
		$grp.toggleClass( 'cplai-snip-group-collapsed', nowCollapsed );
		$( this ).find( '.cplai-snip-group-chevron' ).text( nowCollapsed ? '▶' : '▼' );
		snipCollapsedStages[ stage ] = nowCollapsed;
	} );

	// Live search
	$( document ).on( 'input', '#snip-search', function () {
		renderSnippets();
	} );

	// Sync defaults.
	$( '#btn-snip-sync-defaults' ).on( 'click', async function () {
		$( this ).prop( 'disabled', true ).text( 'Syncing…' );
		const data = await apiPost( 'snippets/sync-defaults', {} );
		$( this ).prop( 'disabled', false ).text( '⬇ Sync Defaults' );
		if ( data && data.success ) {
			showMsg( 'Default snippets synced.', 'success' );
			loadSnippets( true );
		}
	} );

	$( '#btn-snip-refresh' ).on( 'click', function () { loadSnippets( true ); } );

	// Export all snippets as defaults.json
	$( '#btn-snip-export' ).on( 'click', function () {
		if ( ! snippetData.length ) { showMsg( 'No snippets loaded. Click Refresh first.', 'error' ); return; }

		// Build a clean defaults.json — same shape the installer expects:
		// array of plain objects, no DB-only fields (id, created_at, updated_at).
		const EXPORT_FIELDS = [ 'snippet_key', 'label', 'direction', 'hook_stage', 'sort_order',
		                         'is_active', 'source', 'logic_description', 'js_body', 'php_body' ];

		const exportData = snippetData
			.slice()
			.sort( function ( a, b ) {
				// Sort by stage order (pre → loop → post), then sort_order within stage
				const stageRank = { pre: 0, loop: 1, post: 2 };
				const stageDiff = ( stageRank[ a.hook_stage ] || 0 ) - ( stageRank[ b.hook_stage ] || 0 );
				return stageDiff !== 0 ? stageDiff : ( a.sort_order || 0 ) - ( b.sort_order || 0 );
			} )
			.map( function ( s ) {
				const out = {};
				EXPORT_FIELDS.forEach( function ( f ) {
					if ( s[ f ] !== undefined && s[ f ] !== null ) { out[ f ] = s[ f ]; }
				} );
				return out;
			} );

		const json = JSON.stringify( exportData, null, 2 );
		const blob = new Blob( [ json ], { type: 'application/json' } );
		const url  = URL.createObjectURL( blob );
		const a    = document.createElement( 'a' );
		a.href     = url;
		a.download = 'defaults.json';
		document.body.appendChild( a );
		a.click();
		setTimeout( function () { URL.revokeObjectURL( url ); a.remove(); }, 1000 );
		showMsg( 'Exported defaults.json (' + exportData.length + ' snippets).', 'success' );
	} );

	// Toggle active — invalidate snippet hook cache for affected direction(s).
	$( document ).on( 'change', '.btn-snip-toggle', async function () {
		const id        = $( this ).data( 'id' );
		const direction = $( this ).data( 'direction' ); // forward | reverse | both
		const active    = $( this ).data( 'active' );
		const data      = await apiPost( 'snippets/' + id + '/toggle', {} );
		if ( data ) {
			// Invalidate the hook cache so the next test run reloads.
			if ( direction === 'both' ) {
				invalidateSnippetCache( null );
			} else {
				invalidateSnippetCache( direction );
			}
			loadSnippets( true );
		} else {
			$( this ).prop( 'checked', active == 1 );
		}
	} );

	// Delete.
	$( document ).on( 'click', '.btn-snip-delete', async function ( e ) {
		e.preventDefault();
		const id = $( this ).data( 'id' );
		if ( ! confirm( 'Delete this snippet? This cannot be undone.' ) ) { return; }
		const resp = await fetch( API + 'snippets/' + id, { method: 'DELETE', headers: HDR } );
		const data = await resp.json();
		if ( data.success ) {
			invalidateSnippetCache( null );
			showMsg( 'Snippet deleted.', 'success' );
			loadSnippets( true );
		} else {
			showMsg( '[DELETE ERROR] ' + data.message, 'error' );
		}
	} );

	// Edit.
	$( document ).on( 'click', '.btn-snip-edit', function ( e ) {
		e.preventDefault();
		const id = parseInt( $( this ).data( 'id' ), 10 );
		const s  = snippetData.find( function ( x ) { return x.id == id; } );
		if ( ! s ) { return; }

		$( '#snip-editor-title' ).text( 'Edit Snippet' );
		$( '#snip-id' ).val( s.id );
		$( '#snip-key' ).val( s.snippet_key ).prop( 'disabled', true );
		$( '#snip-label' ).val( s.label );
		$( '#snip-direction' ).val( s.direction );
		$( '#snip-stage' ).val( s.hook_stage );
		$( '#snip-order' ).val( s.sort_order );
		$( '#snip-description' ).val( s.logic_description || '' );
		$( '#snip-js-body' ).val( s.js_body || '' );
		$( '#snip-php-body' ).val( s.php_body || '' );

		$( '#snip-editor' ).show();
		$( 'html, body' ).animate( { scrollTop: $( '#snip-editor' ).offset().top - 30 }, 300 );
	} );

	// New snippet.
	$( '#btn-snip-new' ).on( 'click', function () {
		$( '#snip-editor-title' ).text( 'New Snippet' );
		$( '#snip-id' ).val( '' );
		$( '#snip-key' ).val( '' ).prop( 'disabled', false );
		$( '#snip-label' ).val( '' );
		$( '#snip-direction' ).val( 'forward' );
		$( '#snip-stage' ).val( 'loop' );
		$( '#snip-order' ).val( 100 );
		$( '#snip-description' ).val( '' );
		$( '#snip-js-body' ).val( '' );
		$( '#snip-php-body' ).val( '' );

		$( '#snip-editor' ).show();
		$( 'html, body' ).animate( { scrollTop: $( '#snip-editor' ).offset().top - 30 }, 300 );
	} );

	$( '#btn-snip-editor-close' ).on( 'click', function () {
		$( '#snip-editor' ).hide();
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// AI CODE STUDIO TAB
	// ══════════════════════════════════════════════════════════════════════════

	$( '#btn-generate' ).on( 'click', async function () {
		const snippet_key       = $( '#ai-snippet-key' ).val().trim();
		const label             = $( '#ai-snippet-label' ).val().trim();
		const direction         = $( '#ai-direction' ).val();
		const hook_stage        = $( '#ai-hook-stage' ).val();
		const map_source        = $( '#ai-map-source' ).val();
		const logic_description = $( '#ai-prompt' ).val().trim();

		if ( ! snippet_key )       { showMsg( 'Enter a snippet key first.', 'error' ); return; }
		if ( ! logic_description ) { showMsg( 'Enter a logic description for the AI.', 'error' ); return; }

		$( this ).prop( 'disabled', true );
		$( '#ai-spinner' ).show();
		$( '#code-actions' ).hide();
		$( '#ai-explanation' ).hide();
		$( '#ai-save-status' ).hide();
		$( '#code-inner' ).text( '// Generating…' );

		const data = await apiPost( 'snippets/generate', {
			snippet_key,
			label:             label || snippet_key,
			direction,
			hook_stage,
			logic_description,
			map_source,
		} );

		$( this ).prop( 'disabled', false );
		$( '#ai-spinner' ).hide();

		if ( ! data ) { return; }

		$( '#code-inner' ).text( data.js_body || '// (empty response)' );
		lastGeneratedPhpBody = data.php_body || '';
		$( '#code-actions' ).show();

		if ( data.explanation ) {
			$( '#ai-explanation' ).text( data.explanation ).show();
		}
	} );

	// Copy generated code to clipboard.
	$( '#btn-copy-code' ).on( 'click', function () {
		const code = $( '#code-inner' ).text();
		navigator.clipboard.writeText( code ).then( function () {
			showMsg( 'Code copied to clipboard.', 'success' );
		} ).catch( function () {
			showMsg( 'Copy failed — please select and copy manually.', 'error' );
		} );
	} );

	// Send generated code to Snippet Editor (switches tab + pre-fills form).
	$( '#btn-send-to-snip' ).on( 'click', function () {
		const js_body     = $( '#code-inner' ).text();
		const snippet_key = $( '#ai-snippet-key' ).val().trim();
		const label       = $( '#ai-snippet-label' ).val().trim();
		const direction   = $( '#ai-direction' ).val();
		const hook_stage  = $( '#ai-hook-stage' ).val();
		const description = $( '#ai-prompt' ).val().trim();

		// Switch to Snippets tab.
		$( '.cplai-tab[data-tab="snippets"]' ).trigger( 'click' );

		// Pre-fill the snippet editor.
		$( '#snip-editor-title' ).text( 'New Snippet (from AI Studio)' );
		$( '#snip-id' ).val( '' );
		$( '#snip-key' ).val( snippet_key ).prop( 'disabled', false );
		$( '#snip-label' ).val( label || snippet_key );
		$( '#snip-direction' ).val( direction );
		$( '#snip-stage' ).val( hook_stage );
		$( '#snip-order' ).val( 100 );
		$( '#snip-description' ).val( description );
		$( '#snip-js-body' ).val( js_body );
		$( '#snip-php-body' ).val( lastGeneratedPhpBody );

		$( '#snip-editor' ).show();
		$( 'html, body' ).animate( { scrollTop: $( '#snip-editor' ).offset().top - 30 }, 300 );
	} );

	// Save directly from AI Studio (bypasses Snippet Editor).
	$( '#btn-save-as-snip' ).on( 'click', async function () {
		const js_body     = $( '#code-inner' ).text();
		const snippet_key = $( '#ai-snippet-key' ).val().trim();
		const label       = $( '#ai-snippet-label' ).val().trim();
		const direction   = $( '#ai-direction' ).val();
		const hook_stage  = $( '#ai-hook-stage' ).val();
		const description = $( '#ai-prompt' ).val().trim();

		if ( ! snippet_key ) { showMsg( 'Snippet key is required.', 'error' ); return; }
		if ( ! js_body || js_body === '// Generating…' || js_body === '// Generated snippet code will appear here…' ) {
			showMsg( 'Generate a snippet first.', 'error' ); return;
		}

		$( this ).prop( 'disabled', true ).text( '💾 Saving…' );

		const data = await apiPost( 'snippets/save', {
			snippet_key,
			label:             label || snippet_key,
			direction,
			hook_stage,
			logic_description: description,
			js_body,
			php_body:          lastGeneratedPhpBody,
			sort_order:        100,
			source:            'ai_generated',
		} );

		$( this ).prop( 'disabled', false ).text( '💾 Save as Snippet' );
		if ( ! data ) { return; }

		const statusEl = $( '#ai-save-status' );
		statusEl.text( 'Snippet "' + snippet_key + '" saved and activated.' ).show();
		showMsg( 'Snippet "' + snippet_key + '" saved.', 'success' );
	} );

	// ── AI generate snippet js_body (Snippet Editor inline button) ────────────

	// AI generate snippet js_body.
	$( '#btn-snip-ai-gen' ).on( 'click', async function () {
		const snippet_key       = $( '#snip-key' ).val().trim();
		const label             = $( '#snip-label' ).val().trim();
		const direction         = $( '#snip-direction' ).val();
		const hook_stage        = $( '#snip-stage' ).val();
		const logic_description = $( '#snip-description' ).val().trim();

		if ( ! snippet_key )       { showMsg( 'Enter a snippet key first.', 'error' ); return; }
		if ( ! logic_description ) { showMsg( 'Enter a logic description for the AI.', 'error' ); return; }

		$( this ).prop( 'disabled', true );
		$( '#snip-ai-spinner' ).show();

		const data = await apiPost( 'snippets/generate', {
			snippet_key,
			label:             label || snippet_key,
			direction,
			hook_stage,
			logic_description,
			map_source:        'db',
		} );

		$( this ).prop( 'disabled', false );
		$( '#snip-ai-spinner' ).hide();

		if ( ! data ) { return; }

		$( '#snip-js-body' ).val( data.js_body || '' );
		$( '#snip-php-body' ).val( data.php_body || '' );
		if ( data.explanation ) {
			showMsg( 'Generated. ' + data.explanation.substring( 0, 120 ), 'success' );
		} else {
			showMsg( 'Snippet code generated. Review and save.', 'success' );
		}
	} );

	// Save snippet.
	$( '#btn-snip-save' ).on( 'click', async function () {
		const id               = $( '#snip-id' ).val();
		const snippet_key      = $( '#snip-key' ).val().trim();
		const label            = $( '#snip-label' ).val().trim();
		const direction        = $( '#snip-direction' ).val();
		const hook_stage       = $( '#snip-stage' ).val();
		const sort_order       = parseInt( $( '#snip-order' ).val(), 10 ) || 0;
		const logic_description = $( '#snip-description' ).val().trim();
		const js_body          = $( '#snip-js-body' ).val().trim();
		const php_body         = $( '#snip-php-body' ).val().trim();

		if ( ! snippet_key ) { showMsg( 'Snippet key is required.', 'error' ); return; }
		if ( ! js_body )     { showMsg( 'JS function body is required.', 'error' ); return; }

		$( this ).prop( 'disabled', true ).text( '💾 Saving…' );

		const payload = { snippet_key, label, direction, hook_stage, sort_order, logic_description, js_body, php_body };
		if ( id ) { payload.id = parseInt( id, 10 ); }

		const data = await apiPost( 'snippets/save', payload );

		$( this ).prop( 'disabled', false ).text( '💾 Save Snippet' );
		if ( ! data ) { return; }

		// Invalidate cache for this direction so the next test run picks up the new code.
		if ( direction === 'both' ) {
			invalidateSnippetCache( null );
		} else {
			invalidateSnippetCache( direction );
		}

		showMsg( 'Snippet "' + snippet_key + '" saved.', 'success' );
		$( '#snip-editor' ).hide();
		loadSnippets( true );
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// MAP MANAGER
	// ══════════════════════════════════════════════════════════════════════════

	async function loadMaps() {
		const data = await apiGet( 'maps' );
		if ( ! data ) { return; }

		const tbody = $( '#maps-tbody' );
		tbody.empty();

		if ( ! data.maps || ! data.maps.length ) {
			tbody.html( '<tr><td colspan="7" class="cplai-loading">No maps found.</td></tr>' );
			return;
		}

		data.maps.forEach( function ( m ) {
			const activeHtml = m.is_active == 1
				? '<span class="cplai-badge cplai-badge-active">Active</span>'
				: '';
			const srcBadge = m.source === 'default'
				? '<span class="cplai-badge cplai-badge-default">Default</span>'
				: '<span class="cplai-badge cplai-badge-user">User</span>';

			const actions = [];
			if ( m.is_active != 1 ) {
				actions.push( '<button class="cplai-btn cplai-btn-sm btn-activate" data-id="' + m.id + '">Activate</button>' );
			}
			if ( m.source !== 'default' ) {
				actions.push( '<button class="cplai-btn cplai-btn-sm cplai-btn-danger btn-delete-map" data-id="' + m.id + '">Delete</button>' );
			}

			tbody.append(
				'<tr>' +
				'<td>' + m.id + '</td>' +
				'<td>' + esc( m.map_type ) + '</td>' +
				'<td>' + esc( m.label ) + '</td>' +
				'<td>' + srcBadge + '</td>' +
				'<td>' + activeHtml + '</td>' +
				'<td>' + esc( m.created_at || '—' ) + '</td>' +
				'<td>' + actions.join( ' ' ) + '</td>' +
				'</tr>'
			);
		} );
	}

	$( document ).on( 'click', '.btn-activate', async function () {
		const id   = $( this ).data( 'id' );
		const data = await apiPost( 'maps/' + id + '/activate', {} );
		if ( data ) {
			// Map changed — clear map and snippet caches.
			mapsData = null;
			invalidateSnippetCache( null );
			showMsg( 'Map #' + id + ' activated.', 'success' );
			loadMaps();
		}
	} );

	$( document ).on( 'click', '.btn-delete-map', async function () {
		const id = $( this ).data( 'id' );
		if ( ! confirm( 'Delete this map? This cannot be undone.' ) ) { return; }
		const resp = await fetch( API + 'maps/' + id, { method: 'DELETE', headers: HDR } );
		const data = await resp.json();
		if ( data.success ) {
			mapsData = null;
			showMsg( 'Map deleted.', 'success' );
			loadMaps();
		} else {
			showMsg( '[DELETE ERROR] ' + data.message, 'error' );
		}
	} );

	$( '#btn-refresh-maps' ).on( 'click', loadMaps );

	$( '#btn-load-file' ).on( 'click', function () { $( '#file-picker' ).click(); } );
	$( '#file-picker' ).on( 'change', function () {
		const file = this.files[ 0 ];
		if ( ! file ) { return; }
		const reader = new FileReader();
		reader.onload = function ( e ) {
			$( '#upload-json' ).val( e.target.result );
			if ( ! $( '#upload-label' ).val() ) {
				$( '#upload-label' ).val( file.name.replace( '.json', '' ) );
			}
		};
		reader.readAsText( file );
	} );

	$( '#btn-upload-map' ).on( 'click', async function () {
		const map_type  = $( '#upload-type' ).val();
		const label     = $( '#upload-label' ).val().trim();
		const json_data = $( '#upload-json' ).val().trim();

		if ( ! json_data ) { showMsg( 'Paste JSON content first.', 'error' ); return; }

		try { JSON.parse( json_data ); } catch ( e ) {
			showMsg( '[JSON ERROR] ' + e.message, 'error' ); return;
		}

		const data = await apiPost( 'maps/upload', { map_type, label, json_data } );
		if ( data ) {
			showMsg( 'Map uploaded (ID: ' + data.id + '). Activate it to use it.', 'success' );
			$( '#upload-json' ).val( '' );
			$( '#upload-label' ).val( '' );
			loadMaps();
		}
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// SETTINGS
	// ══════════════════════════════════════════════════════════════════════════

	function applyProviderUI( provider ) {
		$( '#s-row-anthropic-key, #s-row-gemini-key, #s-row-openai-key, #s-row-grok-key' ).hide();
		$( '.s-model-anthropic, .s-model-gemini, .s-model-openai, .s-model-grok' ).hide().prop( 'disabled', true );

		const currentModel = $( '#s-model' ).val() || '';

		switch ( provider ) {
			case 'gemini':
				$( '#s-row-gemini-key' ).show();
				$( '.s-model-gemini' ).show().prop( 'disabled', false );
				if ( currentModel.indexOf( 'gemini-' ) !== 0 ) { $( '#s-model' ).val( 'gemini-2.5-flash' ); }
				break;
			case 'openai':
				$( '#s-row-openai-key' ).show();
				$( '.s-model-openai' ).show().prop( 'disabled', false );
				if ( currentModel.indexOf( 'gpt-' ) !== 0 ) { $( '#s-model' ).val( 'gpt-4o' ); }
				break;
			case 'grok':
				$( '#s-row-grok-key' ).show();
				$( '.s-model-grok' ).show().prop( 'disabled', false );
				if ( currentModel.indexOf( 'grok-' ) !== 0 ) { $( '#s-model' ).val( 'grok-3-fast' ); }
				break;
			default:
				$( '#s-row-anthropic-key' ).show();
				$( '.s-model-anthropic' ).show().prop( 'disabled', false );
				if ( currentModel.indexOf( 'claude-' ) !== 0 ) { $( '#s-model' ).val( 'claude-sonnet-4-6' ); }
				break;
		}
	}

	$( '#s-ai-provider' ).on( 'change', function () { applyProviderUI( $( this ).val() ); } );

	async function loadSettings() {
		const res = await apiGet( 'settings' );
		if ( ! res ) { return; }
		const d = res.data || res;
		$( '#s-api-key' ).val( d.api_key_hint    || '' );
		$( '#s-gemini-key' ).val( d.gemini_key_hint || '' );
		$( '#s-openai-key' ).val( d.openai_key_hint || '' );
		$( '#s-grok-key' ).val( d.grok_key_hint   || '' );
		$( '#s-ai-provider' ).val( d.ai_provider  || 'anthropic' );
		applyProviderUI( d.ai_provider || 'anthropic' );
		$( '#s-model' ).val( d.model || 'claude-sonnet-4-6' );
		$( '#s-api-key-tick' ).toggle( !! d.has_anthropic_key );
		$( '#s-gemini-key-tick' ).toggle( !! d.has_gemini_key );
		$( '#s-openai-key-tick' ).toggle( !! d.has_openai_key );
		$( '#s-grok-key-tick' ).toggle( !! d.has_grok_key );
	}

	$( '#btn-save-settings' ).on( 'click', async function () {
		const data = await apiPost( 'settings', {
			api_key:     $( '#s-api-key' ).val().trim(),
			gemini_key:  $( '#s-gemini-key' ).val().trim(),
			openai_key:  $( '#s-openai-key' ).val().trim(),
			grok_key:    $( '#s-grok-key' ).val().trim(),
			model:       $( '#s-model' ).val(),
			ai_provider: $( '#s-ai-provider' ).val(),
		} );
		if ( data ) { showMsg( 'Settings saved.', 'success' ); }
	} );

	$( '#btn-load-status' ).on( 'click', async function () {
		const data = await apiGet( 'status' );
		if ( ! data ) { return; }
		$( '#status-content' ).text( JSON.stringify( data, null, 2 ) ).show();
	} );

	// ══════════════════════════════════════════════════════════════════════════
	// LEXICON
	// ══════════════════════════════════════════════════════════════════════════

	let lexiconData   = null;
	let editData      = null;
	let lexiconDir    = 'forward';
	let lexiconLoaded = false;
	let editMode      = false;
	let lexiconDirty  = false;

	const SECTION_LABELS = {
		independent_vowels: 'Independent Vowels',
		consonants:         'Consonants',
		matras:             'Vowel Matras',
		special:            'Special / Anusvara / Visarga',
		digits:             'Digits',
		punctuation:        'Punctuation',
	};

	async function loadLexicon() {
		if ( lexiconLoaded ) { renderLexicon(); return; }
		$( '#lex-loading' ).show();
		$( '#lex-content' ).empty();
		const data = await apiGet( 'lexicon' );
		$( '#lex-loading' ).hide();

		if ( ! data ) { return; }
		if ( ! data.forward && ! data.reverse ) {
			$( '#lex-content' ).html( '<p class="cplai-loading">Lexicon data unavailable.</p>' );
			return;
		}

		lexiconData   = data;
		lexiconLoaded = true;
		editData      = deepClone( lexiconData );
		$( '#lex-search' ).val( '' );
		renderLexicon();
	}

	async function reloadLexicon() {
		lexiconLoaded = false;
		editMode      = false;
		lexiconDirty  = false;
		editData      = null;
		lexiconData   = null;
		mapsData      = null; // Bust JS engine map cache too.
		syncEditModeUI();
		await loadLexicon();
	}

	// Track collapsed state for lexicon sections. Persists while on the tab.
	const lexCollapsedSections = {};

	function renderLexicon() {
		if ( ! lexiconData ) { return; }

		const mapSource = editMode ? editData : lexiconData;
		const map       = mapSource[ lexiconDir ] || {};
		const filter    = ( $( '#lex-search' ).val() || '' ).trim().toLowerCase();
		const content   = $( '#lex-content' );
		content.empty();

		if ( ! Object.keys( map ).length ) {
			content.html( '<p class="cplai-loading">No lexicon data for this direction.</p>' );
			return;
		}

		let totalVisible = 0;

		Object.entries( map ).forEach( function ( entry ) {
			const section = entry[ 0 ];
			const pairs   = entry[ 1 ];
			if ( ! Array.isArray( pairs ) || ! pairs.length ) { return; }

			const visible = pairs.filter( function ( p ) {
				if ( ! filter ) { return true; }
				return String( p.from ).toLowerCase().indexOf( filter ) !== -1 ||
				       String( p.to ).toLowerCase().indexOf( filter ) !== -1;
			} );
			if ( ! visible.length ) { return; }
			totalVisible += visible.length;

			const label     = SECTION_LABELS[ section ] || section;
			const isForward = lexiconDir === 'forward';

			// Collapsed by default; auto-expand when a filter is active
			const isCollapsed = filter ? false : ( lexCollapsedSections[ section ] !== false );

			let html = '<div class="cplai-lex-section' + ( isCollapsed ? ' cplai-lex-collapsed' : '' ) + '" data-section="' + esc( section ) + '">' +
				'<h3 class="cplai-lex-section-title cplai-lex-toggle-header" data-section="' + esc( section ) + '">' +
				'<span class="cplai-lex-chevron">' + ( isCollapsed ? '▶' : '▼' ) + '</span>' +
				esc( label ) +
				'<span class="cplai-lex-count">' + pairs.length + '</span>' +
				( editMode ? '<button class="cplai-btn cplai-btn-sm cplai-btn-success lex-add-row" data-section="' + esc( section ) + '">+ Add row</button>' : '' ) +
				'</h3>' +
				'<div class="cplai-lex-section-body">' +
				'<table class="cplai-table cplai-lex-table"><thead><tr>' +
				( editMode ? '<th class="lex-col-order"></th>' : '' ) +
				'<th class="lex-col-key">' + ( isForward ? 'Roman (Input)' : 'BPM Script (Input)' ) + '</th>' +
				'<th class="lex-col-arrow"></th>' +
				'<th class="lex-col-val">' + ( isForward ? 'BPM Script (Output)' : 'Roman (Output)' ) + '</th>' +
				( editMode ? '<th class="lex-col-del"></th>' : '' ) +
				'</tr></thead><tbody>';

			const renderPairs  = filter ? visible : pairs;
			const filterActive = !! filter;

			renderPairs.forEach( function ( p, idx ) {
				const from    = p.from;
				const to      = p.to;
				const realIdx = filter ? pairs.findIndex( function ( q ) { return q.from === from && q.to === to; } ) : idx;

				const fromClass = isForward ? 'cplai-lex-roman' : 'cplai-lex-bpm';
				const toClass   = isForward ? 'cplai-lex-bpm'   : 'cplai-lex-roman';

				const fromCell = editMode
					? '<td class="lex-col-key ' + fromClass + '"><input class="lex-cell-input lex-from" data-section="' + esc( section ) + '" data-idx="' + realIdx + '" value="' + esc( from ) + '" /></td>'
					: '<td class="lex-col-key ' + fromClass + '">' + esc( from ) + '</td>';
				const toCell = editMode
					? '<td class="lex-col-val ' + toClass + '"><input class="lex-cell-input lex-to" data-section="' + esc( section ) + '" data-idx="' + realIdx + '" value="' + esc( to ) + '" /></td>'
					: '<td class="lex-col-val ' + toClass + '">' + esc( String( to ) ) + '</td>';

				const orderBtns = editMode && ! filterActive
					? '<td class="lex-col-order">' +
					  '<button class="lex-move-btn lex-move-up" data-section="' + esc( section ) + '" data-idx="' + realIdx + '" ' + ( realIdx === 0 ? 'disabled' : '' ) + '>▲</button>' +
					  '<button class="lex-move-btn lex-move-down" data-section="' + esc( section ) + '" data-idx="' + realIdx + '" ' + ( realIdx === pairs.length - 1 ? 'disabled' : '' ) + '>▼</button>' +
					  '</td>'
					: editMode ? '<td class="lex-col-order">—</td>' : '';

				const delBtn = editMode
					? '<td class="lex-col-del"><button class="lex-del-btn" data-section="' + esc( section ) + '" data-idx="' + realIdx + '">✕</button></td>'
					: '';

				html += '<tr data-section="' + esc( section ) + '" data-idx="' + realIdx + '">' +
					orderBtns + fromCell + '<td class="cplai-lex-arrow">→</td>' + toCell + delBtn +
					'</tr>';
			} );

			html += '</tbody></table></div></div>';
			content.append( html );
		} );

		if ( ! totalVisible ) {
			content.html( '<p class="cplai-loading">No entries match your filter.</p>' );
		}
	}

	// Toggle lexicon section collapse on header click
	$( document ).on( 'click', '.cplai-lex-toggle-header', function ( e ) {
		// Don\'t collapse if clicking the "Add row" button inside the header
		if ( $( e.target ).hasClass( 'lex-add-row' ) || $( e.target ).closest( '.lex-add-row' ).length ) { return; }
		const section = $( this ).data( 'section' );
		const $sec    = $( this ).closest( '.cplai-lex-section' );
		const nowCollapsed = ! $sec.hasClass( 'cplai-lex-collapsed' );
		$sec.toggleClass( 'cplai-lex-collapsed', nowCollapsed );
		$( this ).find( '.cplai-lex-chevron' ).text( nowCollapsed ? '▶' : '▼' );
		lexCollapsedSections[ section ] = nowCollapsed;
	} );

	// Expand All / Collapse All buttons
	$( document ).on( 'click', '#btn-lex-expand-all', function () {
		$( '.cplai-lex-section' ).each( function () {
			const section = $( this ).data( 'section' );
			$( this ).removeClass( 'cplai-lex-collapsed' );
			$( this ).find( '.cplai-lex-chevron' ).first().text( '▼' );
			lexCollapsedSections[ section ] = false;
		} );
	} );

	$( document ).on( 'click', '#btn-lex-collapse-all', function () {
		$( '.cplai-lex-section' ).each( function () {
			const section = $( this ).data( 'section' );
			$( this ).addClass( 'cplai-lex-collapsed' );
			$( this ).find( '.cplai-lex-chevron' ).first().text( '▶' );
			lexCollapsedSections[ section ] = true;
		} );
	} );

	// Export active map as JSON
	$( document ).on( 'click', '#btn-lex-export', function () {
		if ( ! lexiconData ) { showMsg( 'Lexicon not loaded yet.', 'error' ); return; }
		const mapSource = editMode ? editData : lexiconData;
		const map       = mapSource[ lexiconDir ] || {};
		const json      = JSON.stringify( buildStorageJson( map, lexiconDir ), null, 2 );
		const blob      = new Blob( [ json ], { type: 'application/json' } );
		const url       = URL.createObjectURL( blob );
		const a         = document.createElement( 'a' );
		a.href          = url;
		a.download      = lexiconDir + 'Map.json';
		document.body.appendChild( a );
		a.click();
		setTimeout( function () { URL.revokeObjectURL( url ); a.remove(); }, 1000 );
		showMsg( 'Exported ' + lexiconDir + 'Map.json', 'success' );
	} );

	function syncEditModeUI() {
		const $dirBtns = $( '.cplai-lex-dir-btn' );
		if ( editMode ) {
			$( '#btn-lex-edit' ).hide();
			$( '#btn-lex-save, #btn-lex-discard, #btn-lex-restore' ).show();
			$dirBtns.prop( 'disabled', true );
		} else {
			$( '#btn-lex-edit' ).show();
			$( '#btn-lex-save, #btn-lex-discard, #btn-lex-restore' ).hide();
			$dirBtns.prop( 'disabled', false );
		}
	}

	$( document ).on( 'click', '#btn-lex-edit', function () {
		editData     = deepClone( lexiconData );
		editMode     = true;
		lexiconDirty = false;
		syncEditModeUI();
		renderLexicon();
	} );

	$( document ).on( 'click', '#btn-lex-discard', function () {
		if ( lexiconDirty && ! confirm( 'Discard all unsaved changes?' ) ) { return; }
		editData     = deepClone( lexiconData );
		editMode     = false;
		lexiconDirty = false;
		syncEditModeUI();
		renderLexicon();
	} );

	$( document ).on( 'input', '.lex-cell-input', function () {
		const section = $( this ).data( 'section' );
		const idx     = parseInt( $( this ).data( 'idx' ), 10 );
		const isFrom  = $( this ).hasClass( 'lex-from' );
		const val     = $( this ).val();
		const pairs   = editData[ lexiconDir ][ section ];
		if ( ! pairs || ! pairs[ idx ] ) { return; }
		if ( isFrom ) { pairs[ idx ] = { from: val, to: pairs[ idx ].to }; }
		else          { pairs[ idx ] = { from: pairs[ idx ].from, to: val }; }
		lexiconDirty = true;
	} );

	$( document ).on( 'click', '.lex-move-up', function () {
		const section = $( this ).data( 'section' );
		const idx     = parseInt( $( this ).data( 'idx' ), 10 );
		if ( idx === 0 ) { return; }
		const pairs = editData[ lexiconDir ][ section ];
		const tmp = pairs[ idx - 1 ]; pairs[ idx - 1 ] = pairs[ idx ]; pairs[ idx ] = tmp;
		lexiconDirty = true;
		renderLexicon();
	} );

	$( document ).on( 'click', '.lex-move-down', function () {
		const section = $( this ).data( 'section' );
		const idx     = parseInt( $( this ).data( 'idx' ), 10 );
		const pairs   = editData[ lexiconDir ][ section ];
		if ( idx >= pairs.length - 1 ) { return; }
		const tmp = pairs[ idx + 1 ]; pairs[ idx + 1 ] = pairs[ idx ]; pairs[ idx ] = tmp;
		lexiconDirty = true;
		renderLexicon();
	} );

	$( document ).on( 'click', '.lex-add-row', function () {
		const section = $( this ).data( 'section' );
		if ( ! editData[ lexiconDir ][ section ] ) { editData[ lexiconDir ][ section ] = []; }
		editData[ lexiconDir ][ section ].push( { from: '', to: '' } );
		lexiconDirty = true;
		renderLexicon();
		$( '#lex-content' ).find( '[data-section="' + section + '"] tbody tr:last-child .lex-from' ).focus();
	} );

	$( document ).on( 'click', '.lex-del-btn', function () {
		const section = $( this ).data( 'section' );
		const idx     = parseInt( $( this ).data( 'idx' ), 10 );
		const pairs   = editData[ lexiconDir ][ section ];
		if ( ! pairs ) { return; }
		const entry = pairs[ idx ];
		const label = entry ? '"' + entry.from + '" → "' + entry.to + '"' : 'row ' + ( idx + 1 );
		if ( ! confirm( 'Delete ' + label + '?' ) ) { return; }
		pairs.splice( idx, 1 );
		lexiconDirty = true;
		renderLexicon();
	} );

	$( document ).on( 'click', '#btn-lex-save', async function () {
		if ( ! lexiconDirty ) { showMsg( 'No changes to save.', 'info' ); return; }

		const pairs    = editData[ lexiconDir ];
		let hasEmpty   = false;
		Object.entries( pairs ).forEach( function ( entry ) {
			const sec  = entry[ 0 ];
			const rows = entry[ 1 ];
			rows.forEach( function ( p, i ) {
				if ( ! String( p.from ).trim() ) {
					hasEmpty = true;
					showMsg( 'Empty "from" in section "' + sec + '" row ' + ( i + 1 ) + '.', 'error' );
				}
			} );
		} );
		if ( hasEmpty ) { return; }

		$( this ).prop( 'disabled', true ).text( '💾 Saving…' );

		const jsonForStorage = buildStorageJson( editData[ lexiconDir ], lexiconDir );
		const data = await apiPost( 'maps/save-edit', {
			map_type:  lexiconDir,
			json_data: JSON.stringify( jsonForStorage ),
		} );

		$( this ).prop( 'disabled', false ).text( '💾 Save Changes' );
		if ( ! data ) { return; }

		showMsg( 'Saved as "' + data.label + '" (ID ' + data.id + ') and activated.', 'success' );
		await reloadLexicon();
	} );

	$( document ).on( 'click', '#btn-lex-restore', async function () {
		const dirLabel = lexiconDir === 'forward' ? 'Forward (Roman → BPM)' : 'Reverse (BPM → Roman)';
		if ( ! confirm( 'Restore the bundled default for the ' + dirLabel + ' map?' ) ) { return; }
		$( this ).prop( 'disabled', true ).text( '↩ Restoring…' );
		const data = await apiPost( 'maps/restore-default', { map_type: lexiconDir } );
		$( this ).prop( 'disabled', false ).text( '↩ Restore Default' );
		if ( ! data ) { return; }
		showMsg( 'Default ' + lexiconDir + ' map restored and activated.', 'success' );
		await reloadLexicon();
	} );

	$( document ).on( 'click', '.cplai-lex-dir-btn', function () {
		if ( editMode ) { return; }
		$( '.cplai-lex-dir-btn' ).removeClass( 'active' );
		$( this ).addClass( 'active' );
		lexiconDir = $( this ).data( 'dir' );
		renderLexicon();
	} );

	$( '#lex-search' ).on( 'input', renderLexicon );

	function buildStorageJson( directionData, dir ) {
		const original    = lexiconData[ dir ] || {};
		const out         = {};
		const sectionOrder = [ 'independent_vowels', 'consonants', 'matras', 'special', 'digits', 'punctuation' ];
		if ( original._meta ) { out._meta = original._meta; }
		sectionOrder.forEach( function ( section ) {
			const pairs = directionData[ section ];
			if ( ! pairs || ! pairs.length ) { return; }
			out[ section ] = pairs
				.filter( function ( p ) { return String( p.from ).trim() !== ''; } )
				.map( function ( p ) { return [ String( p.from ), String( p.to ) ]; } );
		} );
		return out;
	}

	// ── Init ──────────────────────────────────────────────────────────────────

	$( function () {
		if ( $( '#tab-maps' ).hasClass( 'active' ) ) { loadMaps(); }
	} );

} )( jQuery );