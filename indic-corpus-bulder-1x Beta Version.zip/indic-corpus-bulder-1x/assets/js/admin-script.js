jQuery(document).ready(function($) {
    'use strict';

    // ── State registers ───────────────────────────────────────────────────────
    let unresolvedConflicts  = [];
    let preApprovedSafeWords = [];
    let userResolutionMap    = {};

    // ── Helper: inline notice ─────────────────────────────────────────────────
    function showNotice(type, msg) {
        const $n = $('<div class="icb-notice icb-notice-' + type + '">' + msg + '</div>');
        $('#icb-notice-area').html($n);
        setTimeout(() => $n.fadeOut(400, function() { $(this).remove(); }), 5000);
    }

    // ── Helper: similarity badge class ───────────────────────────────────────
    function badgeClass(pct) {
        if (pct >= 90) return 'badge-high';
        if (pct >= 80) return 'badge-medium';
        return 'badge-low';
    }

    // ── 1. Live Transliteration ───────────────────────────────────────────────
    $('#icb-input-container').on('input propertychange', function() {
        const romanizedText = $(this).val();

        if ($('#icb-transliterate-toggle').is(':checked') && window.ICB_Transliterator) {
            $('#icb-preview-container').val(window.ICB_Transliterator.convert(romanizedText));
        } else {
            $('#icb-preview-container').val(romanizedText);
        }
    });

    // Reset preview when toggle is switched off with content still in input
    $('#icb-transliterate-toggle').on('change', function() {
        const rawText = $('#icb-input-container').val();
        if ($(this).is(':checked') && window.ICB_Transliterator) {
            $('#icb-preview-container').val(window.ICB_Transliterator.convert(rawText));
        } else {
            $('#icb-preview-container').val(rawText);
        }
    });

    // ── 2. Submit to PHP processor ────────────────────────────────────────────
    $('#icb-process-btn').on('click', function() {
        const textToProcess = $('#icb-preview-container').val().trim();

        if (!textToProcess) {
            showNotice('error', 'Please paste or type some text first.');
            return;
        }

        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Processing…');
        $('#icb-notice-area').empty();

        $.post(ajaxurl, {
            action:   'icb_process_text',
            text:     textToProcess,
            security: icb_vars.nonce
        })
        .done(function(response) {
            if (response.success) {
                if (response.data.status === 'completed') {
                    showNotice('success', '✔ Saved <strong>' + response.data.inserted + '</strong> new word(s) to the corpus.');
                    clearWorkspace();
                } else if (response.data.status === 'requires_review') {
                    renderConflictModal(response.data.conflicts, response.data.safe_words);
                }
            } else {
                showNotice('error', 'Server error: ' + (response.data.message || 'Unknown processing error.'));
            }
        })
        .fail(function() {
            showNotice('error', 'Network error – please try again.');
        })
        .always(function() {
            $btn.prop('disabled', false).text('Analyse & Save');
        });
    });

    // ── 3. Conflict modal renderer ────────────────────────────────────────────
    function renderConflictModal(conflicts, safeWords) {
        unresolvedConflicts  = conflicts;
        preApprovedSafeWords = safeWords;
        userResolutionMap    = {};

        const $tableBody = $('#icb-conflict-rows');
        $tableBody.empty();

        conflicts.forEach(function(item, index) {
            const cls = badgeClass(item.percentage);
            const row = `
                <tr data-index="${index}">
                    <td class="new-word-cell"><strong>${item.new_word}</strong></td>
                    <td class="old-word-cell">${item.old_word}</td>
                    <td><span class="badge-similarity ${cls}">${item.percentage}%</span></td>
                    <td>
                        <div class="action-btn-group">
                            <label class="btn-label" data-index="${index}" data-value="keep_old">
                                <input type="radio" name="action-${index}" value="keep_old">
                                Keep Old
                            </label>
                            <label class="btn-label" data-index="${index}" data-value="replace_with_new">
                                <input type="radio" name="action-${index}" value="replace_with_new">
                                Replace with New
                            </label>
                            <label class="btn-label" data-index="${index}" data-value="keep_both">
                                <input type="radio" name="action-${index}" value="keep_both">
                                Keep Both
                            </label>
                        </div>
                    </td>
                </tr>`;
            $tableBody.append(row);
        });

        // Update footer info count
        $('#icb-modal-conflict-count').text(
            conflicts.length + ' conflict(s) · ' + safeWords.length + ' word(s) queued'
        );

        $('#icb-submit-resolution-btn').prop('disabled', true).text('Commit Approved Selections');
        $('#icb-conflict-modal').show();
    }

    // ── 4. Radio label selection (visual + state) ─────────────────────────────
    $(document).on('click', '.btn-label', function() {
        const index = $(this).data('index');
        const value = $(this).data('value');

        // Visual: deselect siblings, select this one
        $(this).closest('.action-btn-group').find('.btn-label').removeClass('is-selected');
        $(this).addClass('is-selected');

        // Actually check the hidden radio
        $(this).find('input[type="radio"]').prop('checked', true);

        // Update state map
        userResolutionMap[index] = {
            new_word: unresolvedConflicts[index].new_word,
            old_word: unresolvedConflicts[index].old_word,
            decision: value
        };

        // Enable commit button only when every row has a decision
        if (Object.keys(userResolutionMap).length === unresolvedConflicts.length) {
            $('#icb-submit-resolution-btn').prop('disabled', false);
        }
    });

    // ── 5. Cancel / discard ───────────────────────────────────────────────────
    $(document).on('click', '#icb-cancel-modal-btn', function() {
        if (confirm('Discard this batch? No changes will be saved.')) {
            $('#icb-conflict-modal').hide();
        }
    });

    // Close on backdrop click
    $(document).on('click', '#icb-conflict-modal', function(e) {
        if ($(e.target).is('#icb-conflict-modal')) {
            if (confirm('Discard this batch? No changes will be saved.')) {
                $('#icb-conflict-modal').hide();
            }
        }
    });

    // ── 6. Commit resolutions ─────────────────────────────────────────────────
    $(document).on('click', '#icb-submit-resolution-btn', function() {
        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Saving…');

        $.post(ajaxurl, {
            action:      'icb_save_resolved_corpus',
            resolutions: userResolutionMap,
            safe_words:  preApprovedSafeWords,
            security:    icb_vars.nonce
        })
        .done(function(response) {
            if (response.success) {
                $('#icb-conflict-modal').hide();
                clearWorkspace();
                showNotice(
                    'success',
                    '✔ Corpus updated — added <strong>' + response.data.inserted +
                    '</strong> word(s), updated <strong>' + response.data.updated + '</strong> entry/entries.'
                );
            } else {
                showNotice('error', 'Save failed: ' + response.data.message);
                $btn.prop('disabled', false).text('Commit Approved Selections');
            }
        })
        .fail(function() {
            showNotice('error', 'Network error – please try again.');
            $btn.prop('disabled', false).text('Commit Approved Selections');
        });
    });

    // ── Utility ───────────────────────────────────────────────────────────────
    function clearWorkspace() {
        $('#icb-input-container, #icb-preview-container').val('');
    }
});
