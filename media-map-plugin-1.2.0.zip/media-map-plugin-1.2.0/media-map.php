<?php
/**
 * Plugin Name: Media Map
 * Plugin URI:  https://bhoomitechfoundation.org/media-map
 * Description: Interactive Leaflet map with user-submitted multimedia content, admin approval workflow, and full frontend/backend management.
 * Version:           1.2.0
 * Author:      BhoomiTech Heritage and Development Foundation
 * Text Domain: media-map
 * License:     GPL-2.0+
 */

defined( 'ABSPATH' ) || exit;

define( 'MEDIAMAP_VERSION',    '1.1.1' );
define( 'MEDIAMAP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MEDIAMAP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'MEDIAMAP_PLUGIN_FILE', __FILE__ );

/* -----------------------------------------------------------------------
   Autoload includes
----------------------------------------------------------------------- */
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-install.php';
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-post-type.php';
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-settings.php';
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-ajax.php';
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-shortcode.php';
require_once MEDIAMAP_PLUGIN_DIR . 'includes/class-mediamap-notifications.php';
require_once MEDIAMAP_PLUGIN_DIR . 'admin/class-mediamap-admin.php';
require_once MEDIAMAP_PLUGIN_DIR . 'frontend/class-mediamap-frontend.php';

/* -----------------------------------------------------------------------
   Activation / Deactivation
----------------------------------------------------------------------- */
register_activation_hook( __FILE__,  [ 'MediaMap_Install', 'activate'   ] );
register_deactivation_hook( __FILE__, [ 'MediaMap_Install', 'deactivate' ] );

/* -----------------------------------------------------------------------
   Bootstrap
----------------------------------------------------------------------- */
add_action( 'plugins_loaded', function () {
    MediaMap_Post_Type::init();
    MediaMap_Settings::init();
    MediaMap_Ajax::init();
    MediaMap_Shortcode::init();
    MediaMap_Notifications::init();
    MediaMap_Admin::init();
    MediaMap_Frontend::init();
} );
