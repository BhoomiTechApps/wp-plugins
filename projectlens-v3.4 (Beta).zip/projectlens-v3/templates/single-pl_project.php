<?php
/**
 * ProjectLens — Full-page template for pl_project
 * Bypasses the active theme entirely.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$post_id  = get_the_ID();
$settings = get_post_meta( $post_id, '_pl_project_settings', true ) ?: [];
$styling  = get_post_meta( $post_id, '_pl_styling',          true ) ?: [];
$segments = get_post_meta( $post_id, '_pl_segments',         true ) ?: [];
$global   = get_option( 'pl_global', [] );

// Resolve styling with fallbacks to global defaults
$accent      = $styling['accent_color']    ?: ( $global['default_accent']        ?? '#2563eb' );
$heading_col = $styling['heading_color']   ?: '#111827';
$body_col    = $styling['body_color']      ?: '#374151';
$bg_col      = $styling['bg_color']        ?: '#f3f4f6';
$panel_bg    = $styling['panel_bg']        ?: '#ffffff';
$border_col  = $styling['border_color']    ?: '#e5e7eb';
$radius      = $styling['border_radius']   ?: ( $global['default_border_radius'] ?? 8 );
$font_size   = $styling['font_size_base']  ?: ( $global['default_font_size']     ?? 15 );
$h_size      = $styling['font_size_heading'] ?: 20;
$btn_style   = $styling['btn_style']       ?: 'filled';
$word_limit  = (int)( $settings['word_limit'] ?: ( $global['default_word_limit'] ?? 60 ) );
$map_tiles   = $global['map_tiles'] ?? 'osm';
$map_zoom    = $global['map_zoom']  ?? 13;

$font_family_map = [
    'inter'   => "'Inter', sans-serif",
    'roboto'  => "'Roboto', sans-serif",
    'georgia' => "Georgia, serif",
    'system'  => "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
];
$font_key    = $styling['font_family'] ?? 'system';
$font_family = $font_family_map[ $font_key ] ?? $font_family_map['system'];

$tile_urls = [
    'osm'        => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    'carto_light'=> 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
    'carto_dark' => 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
];
$tile_url = $tile_urls[ $map_tiles ] ?? $tile_urls['osm'];

$show_header   = (bool)( $settings['show_header'] ?? 1 );
$project_title = get_the_title( $post_id );
$project_status= $settings['project_status'] ?? 'concept';
$funder        = $settings['funder_name']    ?? '';
$location      = $settings['location']       ?? '';
$start_date    = $settings['start_date']     ?? '';
$end_date      = $settings['end_date']       ?? '';
$short_desc    = $settings['short_description'] ?? '';
$thumb_url     = get_the_post_thumbnail_url( $post_id, 'large' );

// Enrich segments with resolved URLs before JSON-encoding for JS
$segments_enriched = $segments;
foreach ( $segments_enriched as &$seg ) {
    $type = $seg['type'] ?? '';
    if ( $type === 'media' ) {
        foreach ( $seg['slides'] as &$slide ) {
            $mid = $slide['media_id'] ?? 0;
            if ( $mid ) {
                $slide['media_url'] = wp_get_attachment_url( $mid ) ?: '';
            }
        }
        unset( $slide );
    } elseif ( $type === 'team' ) {
        foreach ( $seg['members'] as &$member ) {
            $aid = $member['avatar_id'] ?? 0;
            if ( $aid ) {
                $member['avatar_url'] = wp_get_attachment_image_url( $aid, [80,80] ) ?: '';
            }
        }
        unset( $member );
    } elseif ( $type === 'documents' ) {
        foreach ( $seg['files'] as &$file ) {
            $fid = $file['file_id'] ?? 0;
            if ( $fid ) {
                $file['file_url']  = wp_get_attachment_url( $fid ) ?: '';
                $file['file_name'] = basename( get_attached_file( $fid ) );
                $file['ext']       = strtolower( pathinfo( get_attached_file( $fid ), PATHINFO_EXTENSION ) );
            }
            $file['allow_download'] = isset( $file['allow_download'] ) ? (int) $file['allow_download'] : 1;
            $file['allow_viewer']   = isset( $file['allow_viewer'] )   ? (int) $file['allow_viewer']   : 1;
        }
        unset( $file );
    }
}
unset( $seg );


wp_head();
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo esc_html( $project_title ); ?> — <?php bloginfo('name'); ?></title>
<style>
/* ── CSS Custom Properties from per-project settings ── */
:root {
    --pl-accent:      <?php echo esc_attr($accent); ?>;
    --pl-heading:     <?php echo esc_attr($heading_col); ?>;
    --pl-body:        <?php echo esc_attr($body_col); ?>;
    --pl-bg:          <?php echo esc_attr($bg_col); ?>;
    --pl-panel-bg:    <?php echo esc_attr($panel_bg); ?>;
    --pl-border:      <?php echo esc_attr($border_col); ?>;
    --pl-radius:      <?php echo intval($radius); ?>px;
    --pl-font-size:   <?php echo intval($font_size); ?>px;
    --pl-h-size:      <?php echo intval($h_size); ?>px;
    --pl-font-family: <?php echo $font_family; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- value is a whitelisted CSS string from $font_family_map, never user input ?>;
}
</style>
</head>
<body class="pl-project-page pl-btn-style--<?php echo esc_attr($btn_style); ?>">

<!-- Back to archive link -->
<div class="pl-topbar">
    <a href="<?php echo esc_url( get_post_type_archive_link('pl_project') ); ?>" class="pl-back-link">
        ← <?php esc_html_e( 'All Projects', 'projectlens' ); ?>
    </a>
    <span class="pl-site-name"><?php bloginfo('name'); ?></span>
</div>

<!-- Project Header -->
<?php if ( $show_header ) : ?>
<header class="pl-project-header" <?php if ($thumb_url) echo 'style="background-image:url(' . esc_url($thumb_url) . ')"'; ?>>
    <div class="pl-project-header__inner">
        <div class="pl-project-header__meta">
            <span class="pl-status-badge pl-status--<?php echo esc_attr($project_status); ?>">
                <?php echo esc_html( ucfirst($project_status) ); ?>
            </span>
            <?php if ($location) : ?><span class="pl-header-location">📍 <?php echo esc_html($location); ?></span><?php endif; ?>
            <?php if ($funder) : ?><span class="pl-header-funder"><?php esc_html_e('Funded by', 'projectlens'); ?>: <?php echo esc_html($funder); ?></span><?php endif; ?>
            <?php if ($start_date || $end_date) : ?>
            <span class="pl-header-dates">
                <?php echo esc_html( $start_date ); ?>
                <?php if ($start_date && $end_date) echo ' – '; ?>
                <?php echo esc_html( $end_date ); ?>
            </span>
            <?php endif; ?>
        </div>
        <h1 class="pl-project-header__title"><?php echo esc_html($project_title); ?></h1>
        <?php if ($short_desc) : ?>
        <p class="pl-project-header__desc"><?php echo esc_html($short_desc); ?></p>
        <?php endif; ?>
    </div>
</header>
<?php endif; ?>

<!-- Main split layout -->
<main class="pl-main" id="pl-main">

    <!-- LEFT: Summary panel (70%) -->
    <div class="pl-panel pl-panel--summary" id="pl-summary-panel">
        <?php if ( empty($segments) ) : ?>
        <p class="pl-empty"><?php esc_html_e( 'This project has no segments yet.', 'projectlens' ); ?></p>
        <?php else : ?>
            <?php foreach ( $segments as $segment ) :
                PL_Segment::render_summary_segment( $segment, $word_limit );
            endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- RIGHT: Detail panel (30%) -->
    <aside class="pl-panel pl-panel--detail" id="pl-detail-panel">
        <!-- Mobile back button -->
        <button type="button" id="pl-mobile-back" class="pl-mobile-back" style="display:none;">
            ← <?php esc_html_e( 'Back to Summary', 'projectlens' ); ?>
        </button>

        <!-- Default detail content (project overview) -->
        <div id="pl-detail-content" class="pl-detail-content">
            <div class="pl-detail pl-detail--welcome">
                <h2 class="pl-detail__title"><?php esc_html_e( 'Project Overview', 'projectlens' ); ?></h2>
                <?php if ($short_desc) : ?>
                <p><?php echo esc_html($short_desc); ?></p>
                <?php endif; ?>
                <dl class="pl-meta-table">
                    <?php if ($settings['project_code']   ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Code','projectlens'); ?></dt><dd><?php echo esc_html($settings['project_code']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['funder_name']    ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Funder','projectlens'); ?></dt><dd><?php echo esc_html($settings['funder_name']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['grant_number']   ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Grant No.','projectlens'); ?></dt><dd><?php echo esc_html($settings['grant_number']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['budget_total']   ?? '') : ?>
                        <div class="pl-meta-table__row"><dt><?php esc_html_e('Budget','projectlens'); ?></dt><dd><?php echo esc_html( ($settings['budget_currency']??'USD') . ' ' . number_format((float)$settings['budget_total']) ); ?></dd></div>
                    <?php endif; ?>
                    <?php if ($settings['start_date']     ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Start','projectlens'); ?></dt><dd><?php echo esc_html($settings['start_date']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['end_date']       ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('End','projectlens'); ?></dt><dd><?php echo esc_html($settings['end_date']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['implementing_agency'] ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Implementing','projectlens'); ?></dt><dd><?php echo esc_html($settings['implementing_agency']); ?></dd></div><?php endif; ?>
                    <?php if ($settings['location']       ?? '') : ?><div class="pl-meta-table__row"><dt><?php esc_html_e('Location','projectlens'); ?></dt><dd><?php echo esc_html($settings['location']); ?></dd></div><?php endif; ?>
                </dl>
                <p class="pl-detail-hint"><?php esc_html_e('Click any segment or thumbnail to view full details here.','projectlens'); ?></p>
            </div>
        </div>
    </aside>

</main>

<!-- Embedded segment data for JS -->
<script id="pl-segments-data" type="application/json"><?php echo wp_json_encode( $segments_enriched ); ?></script>
<script id="pl-config-data"   type="application/json"><?php echo wp_json_encode( [ 'tileUrl' => $tile_url, 'mapZoom' => $map_zoom, 'btnStyle' => $btn_style ] ); ?></script>

<?php wp_footer(); ?>
</body>
</html>
