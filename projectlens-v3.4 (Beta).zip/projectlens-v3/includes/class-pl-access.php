<?php
/**
 * ProjectLens — Role-Based Access Control
 *
 * Registers three plugin-level capabilities, enforces them on every
 * project create / edit / delete path, and provides the admin UI at
 * ProjectLens → Manage Access.
 *
 * Capabilities introduced:
 *   pl_create_projects  – publish / draft new pl_project posts
 *   pl_edit_projects    – edit existing pl_project posts
 *   pl_delete_projects  – trash / delete pl_project posts
 *   pl_manage_access    – assign the caps above to other users
 *
 * How it integrates with WordPress roles:
 *   On plugin activation (PL_Access::activate()) the caps are stamped
 *   onto the three built-in roles (administrator, editor, author) with
 *   sensible defaults.  Site owners can override them per-user from the
 *   Manage Access screen.
 *
 * Drop this file in /includes/ and add to projectlens.php:
 *   require_once PL_PLUGIN_DIR . 'includes/class-pl-access.php';
 * Then in pl_init():
 *   PL_Access::init();
 * And on register_activation_hook call:
 *   PL_Access::activate();
 * And on register_deactivation_hook call (optional cleanup):
 *   PL_Access::deactivate();
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Access {

	// -------------------------------------------------------------------------
	// Constants
	// -------------------------------------------------------------------------

	/** All four plugin caps in one place. */
	const CAPS = [
		'pl_create_projects',
		'pl_edit_projects',
		'pl_delete_projects',
		'pl_manage_access',
	];

	/**
	 * Default capability grants per built-in WordPress role.
	 * Key = WP role slug, value = array of PL caps that role receives.
	 */
	const ROLE_DEFAULTS = [
		'administrator' => [ 'pl_create_projects', 'pl_edit_projects', 'pl_delete_projects', 'pl_manage_access' ],
		'editor'        => [ 'pl_create_projects', 'pl_edit_projects' ],
		'author'        => [ 'pl_create_projects' ],
		'contributor'   => [],
		'subscriber'    => [],
	];

	/** Admin-page slug. */
	const PAGE_SLUG = 'pl-manage-access';

	// -------------------------------------------------------------------------
	// Bootstrap
	// -------------------------------------------------------------------------

	public static function init() {
		// Enforce caps on every CPT save / delete
		add_action( 'save_post_pl_project',        [ __CLASS__, 'gate_save'   ], 1, 2 );
		add_action( 'before_delete_post',           [ __CLASS__, 'gate_delete' ], 1, 1 );
		add_action( 'wp_trash_post',                [ __CLASS__, 'gate_trash'  ], 1, 1 );

		// Cap map: makes WP honour pl_* caps when checking edit_post etc.
		add_filter( 'map_meta_cap', [ __CLASS__, 'map_meta_cap' ], 10, 4 );

		// Admin UI
		add_action( 'admin_menu',                  [ __CLASS__, 'register_page'  ] );
		add_action( 'admin_post_pl_save_access',   [ __CLASS__, 'handle_save'    ] );
		add_action( 'admin_post_pl_remove_user',   [ __CLASS__, 'handle_remove'  ] );
		add_action( 'admin_enqueue_scripts',        [ __CLASS__, 'enqueue_assets' ] );

		// Restrict CPT list / edit screens to users with at least pl_edit_projects
		add_action( 'current_screen', [ __CLASS__, 'restrict_cpt_screen' ] );
	}

	// -------------------------------------------------------------------------
	// Activation / Deactivation
	// -------------------------------------------------------------------------

	/**
	 * Stamp default caps onto built-in WordPress roles.
	 * Called from register_activation_hook in projectlens.php.
	 */
	public static function activate() {
		foreach ( self::ROLE_DEFAULTS as $role_slug => $granted_caps ) {
			$role = get_role( $role_slug );
			if ( ! $role ) continue;
			foreach ( self::CAPS as $cap ) {
				if ( in_array( $cap, $granted_caps, true ) ) {
					$role->add_cap( $cap, true );
				} else {
					$role->add_cap( $cap, false );
				}
			}
		}
	}

	/**
	 * Remove all pl_* caps from every role on deactivation.
	 * Data is preserved; only capability grants are cleaned up.
	 */
	public static function deactivate() {
		global $wp_roles;
		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}
		foreach ( array_keys( $wp_roles->roles ) as $role_slug ) {
			$role = get_role( $role_slug );
			if ( ! $role ) continue;
			foreach ( self::CAPS as $cap ) {
				$role->remove_cap( $cap );
			}
		}
	}

	// -------------------------------------------------------------------------
	// Capability mapping
	// -------------------------------------------------------------------------

	/**
	 * Translate WordPress primitive caps (edit_post, delete_post, etc.) for
	 * pl_project posts into our custom caps so that current_user_can() and the
	 * post-edit screen work correctly.
	 *
	 * @param string[] $required_caps Primitive caps WP is about to check.
	 * @param string   $cap           The meta cap being checked.
	 * @param int      $user_id       User being checked.
	 * @param mixed[]  $args          Extra args (post ID for post caps).
	 * @return string[] Modified primitive caps.
	 */
	public static function map_meta_cap( $required_caps, $cap, $user_id, $args ) {
		// Only intercept caps that relate to pl_project posts.
		$post_id = $args[0] ?? 0;
		if ( $post_id && get_post_type( $post_id ) !== 'pl_project' ) {
			return $required_caps;
		}

		switch ( $cap ) {
			case 'read_post':
			case 'read_pl_project':
				return [ 'read' ];

			case 'edit_post':
			case 'edit_pl_project':
				return [ 'pl_edit_projects' ];

			case 'delete_post':
			case 'delete_pl_project':
				return [ 'pl_delete_projects' ];

			case 'publish_post':
			case 'create_pl_project':
				return [ 'pl_create_projects' ];
		}

		return $required_caps;
	}

	// -------------------------------------------------------------------------
	// Save / Delete gates
	// -------------------------------------------------------------------------

	/**
	 * Block save_post for pl_project when the user lacks the required cap.
	 * Runs at priority 1 — before PL_Meta_Boxes::save_meta().
	 *
	 * @param int     $post_id
	 * @param WP_Post $post
	 */
	public static function gate_save( $post_id, $post ) {
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
		if ( wp_is_post_revision( $post_id ) ) return;

		$is_new = $post->post_date === $post->post_modified; // heuristic for brand-new posts

		if ( $is_new && ! current_user_can( 'pl_create_projects' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to create ProjectLens projects.', 'projectlens' ),
				esc_html__( 'Access Denied', 'projectlens' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}

		if ( ! $is_new && ! current_user_can( 'pl_edit_projects' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to edit ProjectLens projects.', 'projectlens' ),
				esc_html__( 'Access Denied', 'projectlens' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}
	}

	/**
	 * Block permanent deletion of pl_project posts.
	 *
	 * @param int $post_id
	 */
	public static function gate_delete( $post_id ) {
		if ( get_post_type( $post_id ) !== 'pl_project' ) return;
		if ( ! current_user_can( 'pl_delete_projects' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to delete ProjectLens projects.', 'projectlens' ),
				esc_html__( 'Access Denied', 'projectlens' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}
	}

	/**
	 * Block moving pl_project posts to trash.
	 *
	 * @param int $post_id
	 */
	public static function gate_trash( $post_id ) {
		if ( get_post_type( $post_id ) !== 'pl_project' ) return;
		if ( ! current_user_can( 'pl_delete_projects' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to delete ProjectLens projects.', 'projectlens' ),
				esc_html__( 'Access Denied', 'projectlens' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}
	}

	// -------------------------------------------------------------------------
	// CPT screen restriction
	// -------------------------------------------------------------------------

	/**
	 * Redirect away from the pl_project list / edit screens when the user lacks
	 * even view-level access (no pl_edit_projects cap).
	 */
	public static function restrict_cpt_screen( $screen ) {
		if ( ! isset( $screen->post_type ) || $screen->post_type !== 'pl_project' ) return;
		if ( ! current_user_can( 'pl_edit_projects' ) && ! current_user_can( 'pl_create_projects' ) ) {
			wp_die(
				esc_html__( 'You do not have access to ProjectLens projects.', 'projectlens' ),
				esc_html__( 'Access Denied', 'projectlens' ),
				[ 'response' => 403, 'back_link' => true ]
			);
		}
	}

	// -------------------------------------------------------------------------
	// Admin menu
	// -------------------------------------------------------------------------

	public static function register_page() {
		add_submenu_page(
			'edit.php?post_type=pl_project',
			__( 'Manage Access', 'projectlens' ),
			__( 'Manage Access', 'projectlens' ),
			'pl_manage_access',           // only users with this cap see the page
			self::PAGE_SLUG,
			[ __CLASS__, 'render_page' ]
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( strpos( $hook, self::PAGE_SLUG ) === false ) return;
		// Reuse the plugin's existing admin stylesheet.
		wp_enqueue_style(
			'projectlens-admin',
			PL_PLUGIN_URL . 'admin/css/admin.css',
			[],
			PL_VERSION
		);
	}

	// -------------------------------------------------------------------------
	// Admin page renderer
	// -------------------------------------------------------------------------

	/**
	 * Full Manage Access screen:
	 *   Tab 1 – Users & their current PL caps
	 *   Tab 2 – Role-level defaults (bulk grant/revoke per WP role)
	 */
	public static function render_page() {
		if ( ! current_user_can( 'pl_manage_access' ) ) {
			wp_die( esc_html__( 'Access denied.', 'projectlens' ) );
		}

		$notice = sanitize_key( wp_unslash( $_GET['pl_notice'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$notice_map = [
			'saved'   => [ 'success', __( 'Access settings saved.', 'projectlens' ) ],
			'removed' => [ 'success', __( 'User access removed.', 'projectlens' ) ],
			'error'   => [ 'error',   __( 'Something went wrong. Please try again.', 'projectlens' ) ],
		];

		$active_tab = sanitize_key( wp_unslash( $_GET['tab'] ?? 'users' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'ProjectLens — Manage Access', 'projectlens' ); ?></h1>

			<?php if ( $notice && isset( $notice_map[ $notice ] ) ) :
				[ $type, $message ] = $notice_map[ $notice ]; ?>
				<div class="notice notice-<?php echo esc_attr( $type ); ?> is-dismissible"><p><?php echo esc_html( $message ); ?></p></div>
			<?php endif; ?>

			<nav class="nav-tab-wrapper" style="margin-bottom:20px">
				<a href="<?php echo esc_url( self::page_url( [ 'tab' => 'users' ] ) ); ?>"
				   class="nav-tab <?php echo $active_tab === 'users' ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Users', 'projectlens' ); ?>
				</a>
				<a href="<?php echo esc_url( self::page_url( [ 'tab' => 'roles' ] ) ); ?>"
				   class="nav-tab <?php echo $active_tab === 'roles' ? 'nav-tab-active' : ''; ?>">
					<?php esc_html_e( 'Role defaults', 'projectlens' ); ?>
				</a>
			</nav>

			<?php if ( $active_tab === 'users' ) : ?>
				<?php self::render_users_tab(); ?>
			<?php else : ?>
				<?php self::render_roles_tab(); ?>
			<?php endif; ?>

		</div>
		<?php
	}

	// -------------------------------------------------------------------------
	// Tab: Users
	// -------------------------------------------------------------------------

	private static function render_users_tab() {
		// Fetch all users who have at least one PL cap OR belong to a role
		// that has PL caps — easier to just list all users with edit_posts
		// and show their PL status.
		$users = get_users( [ 'capability' => 'edit_posts', 'orderby' => 'display_name' ] );

		$cap_labels = [
			'pl_create_projects' => __( 'Create', 'projectlens' ),
			'pl_edit_projects'   => __( 'Edit',   'projectlens' ),
			'pl_delete_projects' => __( 'Delete', 'projectlens' ),
			'pl_manage_access'   => __( 'Manage access', 'projectlens' ),
		];
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="pl_save_access">
			<?php wp_nonce_field( 'pl_save_access', 'pl_access_nonce' ); ?>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width:22%"><?php esc_html_e( 'User', 'projectlens' ); ?></th>
						<th style="width:18%"><?php esc_html_e( 'WP Role', 'projectlens' ); ?></th>
						<?php foreach ( $cap_labels as $cap => $label ) : ?>
							<th style="width:12%;text-align:center"><?php echo esc_html( $label ); ?></th>
						<?php endforeach; ?>
						<th style="width:8%;text-align:center"><?php esc_html_e( 'Actions', 'projectlens' ); ?></th>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $users as $user ) :
					$roles_display = implode( ', ', array_map( 'ucfirst', $user->roles ) );
					?>
					<tr>
						<td>
							<strong><?php echo esc_html( $user->display_name ); ?></strong><br>
							<small style="color:#888"><?php echo esc_html( $user->user_email ); ?></small>
						</td>
						<td><?php echo esc_html( $roles_display ); ?></td>

						<?php foreach ( $cap_labels as $cap => $label ) :
							$has = user_can( $user->ID, $cap );
							$input_name = "caps[{$user->ID}][{$cap}]";
							?>
							<td style="text-align:center">
								<input type="checkbox"
								       name="<?php echo esc_attr( $input_name ); ?>"
								       value="1"
								       <?php checked( $has ); ?>
								       aria-label="<?php echo esc_attr( "{$label}: {$user->display_name}" ); ?>" />
							</td>
						<?php endforeach; ?>

						<td style="text-align:center">
							<?php if ( $user->ID !== get_current_user_id() ) : ?>
								<a href="<?php echo esc_url(
									wp_nonce_url(
										admin_url( 'admin-post.php?action=pl_remove_user&user_id=' . $user->ID ),
										'pl_remove_user_' . $user->ID
									)
								); ?>"
								onclick="return confirm('<?php echo esc_js( __( 'Remove all ProjectLens caps from this user?', 'projectlens' ) ); ?>')"
								class="button button-small">
									<?php esc_html_e( 'Revoke all', 'projectlens' ); ?>
								</a>
							<?php else : ?>
								<em style="color:#999;font-size:11px"><?php esc_html_e( '(you)', 'projectlens' ); ?></em>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<p style="margin-top:16px">
				<?php submit_button( __( 'Save access settings', 'projectlens' ), 'primary', 'submit', false ); ?>
			</p>
		</form>
		<?php
	}

	// -------------------------------------------------------------------------
	// Tab: Role defaults
	// -------------------------------------------------------------------------

	private static function render_roles_tab() {
		global $wp_roles;
		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		$cap_labels = [
			'pl_create_projects' => __( 'Create projects', 'projectlens' ),
			'pl_edit_projects'   => __( 'Edit projects',   'projectlens' ),
			'pl_delete_projects' => __( 'Delete projects', 'projectlens' ),
			'pl_manage_access'   => __( 'Manage access',   'projectlens' ),
		];
		?>
		<p class="description" style="margin-bottom:16px">
			<?php esc_html_e( 'These settings grant or revoke ProjectLens capabilities for every user who holds that WordPress role. Individual overrides on the Users tab take precedence.', 'projectlens' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="pl_save_access">
			<input type="hidden" name="pl_save_target" value="roles">
			<?php wp_nonce_field( 'pl_save_access', 'pl_access_nonce' ); ?>

			<table class="wp-list-table widefat fixed striped">
				<thead>
					<tr>
						<th style="width:22%"><?php esc_html_e( 'WordPress role', 'projectlens' ); ?></th>
						<?php foreach ( $cap_labels as $cap => $label ) : ?>
							<th style="text-align:center"><?php echo esc_html( $label ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
				<?php foreach ( $wp_roles->roles as $role_slug => $role_data ) :
					$role_obj = get_role( $role_slug );
					if ( ! $role_obj ) continue;
					?>
					<tr>
						<td><strong><?php echo esc_html( $role_data['name'] ); ?></strong></td>
						<?php foreach ( $cap_labels as $cap => $label ) :
							$has = ! empty( $role_data['capabilities'][ $cap ] );
							?>
							<td style="text-align:center">
								<input type="checkbox"
								       name="role_caps[<?php echo esc_attr( $role_slug ); ?>][<?php echo esc_attr( $cap ); ?>]"
								       value="1"
								       <?php checked( $has ); ?>
								       aria-label="<?php echo esc_attr( "{$label}: {$role_data['name']}" ); ?>" />
							</td>
						<?php endforeach; ?>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<p style="margin-top:16px">
				<?php submit_button( __( 'Save role defaults', 'projectlens' ), 'primary', 'submit', false ); ?>
			</p>
		</form>
		<?php
	}

	// -------------------------------------------------------------------------
	// Form handlers
	// -------------------------------------------------------------------------

	/**
	 * Handles both the Users tab save and the Role defaults tab save.
	 * Routed via admin-post.php action=pl_save_access.
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'pl_manage_access' ) ) {
			wp_die( esc_html__( 'Access denied.', 'projectlens' ), 403 );
		}

		check_admin_referer( 'pl_save_access', 'pl_access_nonce' );

		$target = sanitize_key( wp_unslash( $_POST['pl_save_target'] ?? 'users' ) );

		if ( $target === 'roles' ) {
			self::save_role_caps();
		} else {
			self::save_user_caps();
		}

		wp_safe_redirect( add_query_arg(
			[ 'tab' => $target, 'pl_notice' => 'saved' ],
			self::page_url()
		) );
		exit;
	}

	/** Persist per-user cap overrides. */
	private static function save_user_caps() {
		$posted_caps = wp_unslash( $_POST['caps'] ?? [] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below

		// Collect all user IDs that are in the posted form.
		$all_users = get_users( [ 'capability' => 'edit_posts', 'fields' => 'ID' ] );

		foreach ( $all_users as $user_id ) {
			$user_id = (int) $user_id;

			// Protect current user's pl_manage_access cap from self-lockout.
			$protect_manage = ( $user_id === get_current_user_id() );

			foreach ( self::CAPS as $cap ) {
				if ( $protect_manage && $cap === 'pl_manage_access' ) continue;

				$grant = ! empty( $posted_caps[ $user_id ][ $cap ] );
				if ( $grant ) {
					grant_user_cap( $user_id, $cap );       // helper below
				} else {
					revoke_user_cap( $user_id, $cap );      // helper below
				}
			}
		}
	}

	/** Persist role-level cap changes. */
	private static function save_role_caps() {
		global $wp_roles;
		if ( ! isset( $wp_roles ) ) {
			$wp_roles = new WP_Roles(); // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		}

		$posted_role_caps = wp_unslash( $_POST['role_caps'] ?? [] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below

		foreach ( array_keys( $wp_roles->roles ) as $role_slug ) {
			$role = get_role( sanitize_key( $role_slug ) );
			if ( ! $role ) continue;

			foreach ( self::CAPS as $cap ) {
				$grant = ! empty( $posted_role_caps[ $role_slug ][ $cap ] );
				if ( $grant ) {
					$role->add_cap( $cap, true );
				} else {
					$role->add_cap( $cap, false );
				}
			}
		}
	}

	/**
	 * Revoke all PL caps from a single user (the "Revoke all" row action).
	 */
	public static function handle_remove() {
		if ( ! current_user_can( 'pl_manage_access' ) ) {
			wp_die( esc_html__( 'Access denied.', 'projectlens' ), 403 );
		}

		$user_id = absint( wp_unslash( $_GET['user_id'] ?? 0 ) );
		check_admin_referer( 'pl_remove_user_' . $user_id );

		if ( $user_id && $user_id !== get_current_user_id() ) {
			foreach ( self::CAPS as $cap ) {
				revoke_user_cap( $user_id, $cap );
			}
		}

		wp_safe_redirect( add_query_arg( 'pl_notice', 'removed', self::page_url() ) );
		exit;
	}

	// -------------------------------------------------------------------------
	// Helpers
	// -------------------------------------------------------------------------

	/**
	 * Build a URL to the Manage Access admin page, optionally merging extra args.
	 *
	 * @param array $extra_args Additional query args to merge.
	 * @return string
	 */
	public static function page_url( $extra_args = [] ) {
		return add_query_arg(
			array_merge( [ 'post_type' => 'pl_project', 'page' => self::PAGE_SLUG ], $extra_args ),
			admin_url( 'edit.php' )
		);
	}

	/**
	 * Checks whether the current user can perform a specific PL action.
	 * Convenience wrapper used throughout the plugin.
	 *
	 * @param string $action  One of: create | edit | delete | manage_access
	 * @return bool
	 */
	public static function current_user_can( $action ) {
		$cap_map = [
			'create'        => 'pl_create_projects',
			'edit'          => 'pl_edit_projects',
			'delete'        => 'pl_delete_projects',
			'manage_access' => 'pl_manage_access',
		];
		$cap = $cap_map[ $action ] ?? '';
		return $cap ? current_user_can( $cap ) : false;
	}
}

// -------------------------------------------------------------------------
// Module-level helpers (avoid polluting WP_User with methods)
// -------------------------------------------------------------------------

/**
 * Grant a specific capability to a user by user ID.
 *
 * @param int    $user_id
 * @param string $cap
 */
function grant_user_cap( $user_id, $cap ) {
	$user = new WP_User( (int) $user_id );
	if ( $user->exists() ) {
		$user->add_cap( sanitize_key( $cap ), true );
	}
}

/**
 * Revoke a specific capability from a user by user ID.
 *
 * @param int    $user_id
 * @param string $cap
 */
function revoke_user_cap( $user_id, $cap ) {
	$user = new WP_User( (int) $user_id );
	if ( $user->exists() ) {
		$user->add_cap( sanitize_key( $cap ), false );
	}
}
