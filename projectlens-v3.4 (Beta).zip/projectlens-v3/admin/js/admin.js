/**
 * ProjectLens — Admin JS
 * Handles: segment drag-drop reorder, add/delete segments, collapse/expand,
 *          add/delete sub-items (slides, meta fields, members, milestones, files),
 *          WP media picker for images/files, video URL toggle, WP color pickers,
 *          index renaming on sort/add/delete to keep PHP array keys contiguous.
 */
(function ($) {
    'use strict';

    // ── Segment type → sub-item HTML templates ─────────────────────────────
    // Mirrors the PHP render_admin_* methods so new rows look identical.

    const templates = {

        slide: function (segIdx, slideIdx) {
            const n = `pl_segments[${segIdx}][slides][${slideIdx}]`;
            return `
<div class="pl-slide-row pl-sub-row">
    <span class="pl-drag-handle dashicons dashicons-menu"></span>
    <div class="pl-sub-fields">
        <div class="pl-media-row">
            <input type="hidden" name="${n}[media_id]" value="" class="pl-media-id" />
            <img src="" class="pl-media-preview" style="max-width:80px;display:none;" />
            <button type="button" class="pl-btn-select-media button button-small">Select Image/Video</button>
            <button type="button" class="pl-btn-remove-media button-link" style="display:none;">Remove</button>
        </div>
        <p>
            <label>Media Type</label>
            <select name="${n}[media_type]">
                <option value="image" selected>Image</option>
                <option value="video">Video</option>
                <option value="video_url">External Video URL</option>
            </select>
        </p>
        <p class="pl-video-url-row" style="display:none;">
            <label>Video URL (YouTube / Vimeo)</label>
            <input type="url" name="${n}[video_url]" value="" class="widefat" />
        </p>
        <p>
            <label>Caption</label>
            <input type="text" name="${n}[caption]" value="" class="widefat" />
        </p>
        <p>
            <label>Description</label>
            <textarea name="${n}[description]" rows="2" class="widefat"></textarea>
        </p>
        <div class="pl-geo-fields">
            <label>Geo-location</label>
            <div class="pl-geo-row">
                <input type="text" name="${n}[geo_lat]" value="" placeholder="Latitude"  style="width:45%;" />
                <input type="text" name="${n}[geo_lng]" value="" placeholder="Longitude" style="width:45%;" />
            </div>
            <input type="text" name="${n}[geo_label]" value="" placeholder="Location label (e.g. Site Alpha, Dhemaji District)" class="widefat" />
        </div>
    </div>
    <button type="button" class="pl-btn-delete-sub button-link">
        <span class="dashicons dashicons-trash"></span>
    </button>
</div>`;
        },

        metaField: function (segIdx, fieldIdx) {
            const n = `pl_segments[${segIdx}][fields][${fieldIdx}]`;
            return `
<div class="pl-meta-field-row pl-sub-row">
    <span class="pl-drag-handle dashicons dashicons-menu"></span>
    <input type="text" name="${n}[label]" value="" placeholder="Field Label" style="width:30%;" />
    <input type="text" name="${n}[value]" value="" placeholder="Field Value"  style="width:55%;" />
    <button type="button" class="pl-btn-delete-sub button-link">
        <span class="dashicons dashicons-trash"></span>
    </button>
</div>`;
        },

        member: function (segIdx, memberIdx) {
            const n = `pl_segments[${segIdx}][members][${memberIdx}]`;
            return `
<div class="pl-member-row pl-sub-row">
    <span class="pl-drag-handle dashicons dashicons-menu"></span>
    <div class="pl-sub-fields">
        <div class="pl-media-row">
            <input type="hidden" name="${n}[avatar_id]" value="" class="pl-media-id" />
            <img src="" class="pl-media-preview" style="max-width:60px;border-radius:50%;display:none;" />
            <button type="button" class="pl-btn-select-media button button-small">Select Photo</button>
            <button type="button" class="pl-btn-remove-media button-link" style="display:none;">Remove Photo</button>
        </div>
        <p><input type="text"  name="${n}[name]"  value="" placeholder="Full Name"     class="widefat" /></p>
        <p><input type="text"  name="${n}[role]"  value="" placeholder="Role / Title"  class="widefat" /></p>
        <p><input type="email" name="${n}[email]" value="" placeholder="Email"          class="widefat" /></p>
        <p><textarea           name="${n}[bio]"   rows="2" class="widefat" placeholder="Short bio…"></textarea></p>
    </div>
    <button type="button" class="pl-btn-delete-sub button-link">
        <span class="dashicons dashicons-trash"></span>
    </button>
</div>`;
        },

        milestone: function (segIdx, msIdx) {
            const n = `pl_segments[${segIdx}][milestones][${msIdx}]`;
            return `
<div class="pl-milestone-row pl-sub-row">
    <span class="pl-drag-handle dashicons dashicons-menu"></span>
    <div class="pl-sub-fields">
        <p><input type="text" name="${n}[title]" value="" placeholder="Milestone Title" class="widefat" /></p>
        <div style="display:flex;gap:10px;">
            <input type="date" name="${n}[date]" value="" />
            <select name="${n}[status]">
                <option value="planned"   selected>Planned</option>
                <option value="active">Active</option>
                <option value="completed">Completed</option>
                <option value="delayed">Delayed</option>
            </select>
        </div>
        <p><textarea name="${n}[description]" rows="2" class="widefat" placeholder="Description…"></textarea></p>
    </div>
    <button type="button" class="pl-btn-delete-sub button-link">
        <span class="dashicons dashicons-trash"></span>
    </button>
</div>`;
        },

        file: function (segIdx, fileIdx) {
            const n = `pl_segments[${segIdx}][files][${fileIdx}]`;
            return `
<div class="pl-file-row pl-sub-row">
    <span class="pl-drag-handle dashicons dashicons-menu"></span>
    <div class="pl-sub-fields">
        <div class="pl-media-row">
            <input type="hidden" name="${n}[file_id]" value="" class="pl-media-id" />
            <span class="pl-file-name"></span>
            <button type="button" class="pl-btn-select-file button button-small" data-library="application">Select File</button>
            <button type="button" class="pl-btn-remove-file button-link" style="display:none;">Remove File</button>
        </div>
        <p><input type="text" name="${n}[label]" value="" placeholder="Display Name (optional)" class="widefat" /></p>
        <p><textarea name="${n}[description]" rows="2" class="widefat" placeholder="Short description…"></textarea></p>
        <p style="display:flex;gap:20px;margin-top:4px;">
            <label>
                <input type="hidden" name="${n}[allow_download]" value="0" />
                <input type="checkbox" name="${n}[allow_download]" value="1" checked />
                Enable Download Button
            </label>
            <label>
                <input type="hidden" name="${n}[allow_viewer]" value="0" />
                <input type="checkbox" name="${n}[allow_viewer]" value="1" checked />
                Enable Document Viewer
            </label>
        </p>
    </div>
    <button type="button" class="pl-btn-delete-sub button-link">
        <span class="dashicons dashicons-trash"></span>
    </button>
</div>`;
        },

        segment: function (type, label, segIdx, segId) {
            return `
<div class="pl-segment-row" data-index="${segIdx}" data-type="${type}">
    <div class="pl-segment-header">
        <span class="pl-drag-handle dashicons dashicons-menu" title="Drag to reorder"></span>
        <span class="pl-segment-type-badge">${label}</span>
        <input type="text"
               name="pl_segments[${segIdx}][title]"
               value=""
               placeholder="Segment Title"
               class="pl-segment-title-input" />
        <label class="pl-toggle-label">
            <input type="checkbox" name="pl_segments[${segIdx}][enabled]" value="1" checked />
            Visible
        </label>
        <button type="button" class="pl-btn-collapse button-link">
            <span class="dashicons dashicons-arrow-down-alt2"></span>
        </button>
        <button type="button" class="pl-btn-delete button-link">
            <span class="dashicons dashicons-trash"></span>
        </button>
        <input type="hidden" name="pl_segments[${segIdx}][id]"   value="${segId}" />
        <input type="hidden" name="pl_segments[${segIdx}][type]" value="${type}" />
        <input type="hidden" name="pl_segments[${segIdx}][collapsed]" value="0" class="pl-collapsed-input" />
    </div>
    <div class="pl-segment-body">
        ${getSegmentBodyHTML(type, segIdx)}
    </div>
</div>`;
        }
    };

    /**
     * Generate empty body HTML for a freshly added segment of a given type.
     */
    function getSegmentBodyHTML(type, segIdx) {
        switch (type) {
            case 'descriptive':
                return `
<p>
    <label>Sub-title</label>
    <input type="text" name="pl_segments[${segIdx}][subtitle]" value="" class="widefat" />
</p>
<p>
    <label>Summary Content (shown truncated in left panel)</label>
    <textarea name="pl_segments[${segIdx}][content]" rows="6" class="widefat"></textarea>
</p>
<p>
    <label>Detail Content (shown in right panel on "Show Detail")</label>
    <textarea name="pl_segments[${segIdx}][detail_content]" rows="8" class="widefat"></textarea>
</p>`;

            case 'media':
                return `
<div class="pl-slides-list" data-segment-index="${segIdx}"></div>
<button type="button" class="pl-btn-add-slide button" data-segment="${segIdx}">+ Add Slide</button>`;

            case 'metadata':
                return `
<div class="pl-meta-fields-list" data-segment-index="${segIdx}"></div>
<button type="button" class="pl-btn-add-meta-field button" data-segment="${segIdx}">+ Add Field</button>`;

            case 'team':
                return `
<div class="pl-team-list" data-segment-index="${segIdx}"></div>
<button type="button" class="pl-btn-add-member button" data-segment="${segIdx}">+ Add Member</button>`;

            case 'timeline':
                return `
<div class="pl-milestone-list" data-segment-index="${segIdx}"></div>
<button type="button" class="pl-btn-add-milestone button" data-segment="${segIdx}">+ Add Milestone</button>`;

            case 'documents':
                return `
<div class="pl-files-list" data-segment-index="${segIdx}"></div>
<button type="button" class="pl-btn-add-file button" data-segment="${segIdx}">+ Add File</button>`;

            default:
                return '';
        }
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    /**
     * After any sort / add / delete, walk all .pl-segment-row elements and
     * rewrite every name attribute index so the PHP $_POST array is contiguous.
     */
    function reindexSegments() {
        $('#pl-sortable-segments .pl-segment-row').each(function (newIdx) {
            const $row = $(this);
            $row.attr('data-index', newIdx);

            // Rewrite all [name] attributes that begin with pl_segments[N]
            $row.find('[name]').each(function () {
                const oldName = $(this).attr('name');
                // Replace the leading segment index only (first occurrence)
                const newName = oldName.replace(/^pl_segments\[\d+\]/, `pl_segments[${newIdx}]`);
                if (newName !== oldName) {
                    $(this).attr('name', newName);
                }
            });

            // Keep data-segment attrs on sub-item Add buttons in sync
            $row.find('[data-segment]').attr('data-segment', newIdx);

            // Keep data-segment-index attrs on sub-item lists in sync
            $row.find('[data-segment-index]').attr('data-segment-index', newIdx);
        });
    }

    /**
     * Reindex sub-items within a given list container (.pl-slides-list etc.)
     * so their PHP array keys stay contiguous after add / delete.
     *
     * @param {jQuery} $list  - the container (.pl-slides-list / .pl-meta-fields-list / …)
     * @param {string} subKey - the PHP key fragment: 'slides', 'fields', 'members', 'milestones', 'files'
     */
    function reindexSubItems($list, subKey) {
        const segIdx = $list.closest('.pl-segment-row').attr('data-index');
        $list.children('.pl-sub-row').each(function (newSubIdx) {
            $(this).find('[name]').each(function () {
                const oldName = $(this).attr('name');
                const newName = oldName.replace(
                    new RegExp(`\\[${subKey}\\]\\[\\d+\\]`),
                    `[${subKey}][${newSubIdx}]`
                );
                if (newName !== oldName) {
                    $(this).attr('name', newName);
                }
            });
        });
    }

    /** Map segment type → { listClass, subKey, templateFn, addBtnClass } */
    const subItemMeta = {
        media:     { listClass: 'pl-slides-list',      subKey: 'slides',     templateFn: 'slide',      addBtnClass: 'pl-btn-add-slide'       },
        metadata:  { listClass: 'pl-meta-fields-list', subKey: 'fields',     templateFn: 'metaField',  addBtnClass: 'pl-btn-add-meta-field'  },
        team:      { listClass: 'pl-team-list',        subKey: 'members',    templateFn: 'member',     addBtnClass: 'pl-btn-add-member'      },
        timeline:  { listClass: 'pl-milestone-list',   subKey: 'milestones', templateFn: 'milestone',  addBtnClass: 'pl-btn-add-milestone'   },
        documents: { listClass: 'pl-files-list',       subKey: 'files',      templateFn: 'file',       addBtnClass: 'pl-btn-add-file'        },
    };

    // ── Document ready ───────────────────────────────────────────────────────
    $(function () {

        // ── 1. Drag-drop: segment-level sort ──────────────────────────────
        $('#pl-sortable-segments').sortable({
            handle:      '.pl-drag-handle',
            placeholder: 'pl-segment-row ui-sortable-placeholder',
            tolerance:   'pointer',
            update: function () {
                reindexSegments();
            }
        });

        // ── 2. Drag-drop: sub-item sort (slides, fields, members, etc.) ──
        // We use event delegation via sortable on dynamically created lists.
        // Because lists are created dynamically we attach sortable on the
        // document level by re-initialising when a new sub-item list is added.
        function initSubSortable($list, subKey) {
            if ($list.hasClass('ui-sortable')) return; // already initialised
            $list.sortable({
                handle:    '.pl-drag-handle',
                tolerance: 'pointer',
                update: function () {
                    reindexSubItems($list, subKey);
                }
            });
        }

        // Init existing sub-item lists on page load
        $.each(subItemMeta, function (type, meta) {
            $('.' + meta.listClass).each(function () {
                initSubSortable($(this), meta.subKey);
            });
        });

        // ── 3. Collapse / expand segments ─────────────────────────────────
        $(document).on('click', '.pl-btn-collapse', function () {
            const $row = $(this).closest('.pl-segment-row');
            $row.toggleClass('pl-collapsed');
            // Persist collapsed state so it survives save/reload
            $row.find('.pl-collapsed-input').val( $row.hasClass('pl-collapsed') ? '1' : '0' );
        });

        // ── 4. Add segment ─────────────────────────────────────────────────
        $('#pl-btn-add-segment').on('click', function () {
            const type  = $('#pl-new-segment-type').val();
            const label = PL_Admin.segmentTypes[type] || type;
            const segId = 'seg_' + Date.now();
            const segIdx = $('#pl-sortable-segments .pl-segment-row').length;

            const html = templates.segment(type, label, segIdx, segId);
            const $row = $(html);
            $('#pl-sortable-segments').append($row);

            // Init sub-item sortable for the new list (if applicable)
            if (subItemMeta[type]) {
                const meta = subItemMeta[type];
                initSubSortable($row.find('.' + meta.listClass), meta.subKey);
            }

            // Smooth scroll to new row
            $('html, body').animate({ scrollTop: $row.offset().top - 40 }, 300);
        });

        // ── 5. Delete segment ─────────────────────────────────────────────
        $(document).on('click', '.pl-btn-delete', function () {
            if (!window.confirm(PL_Admin.confirmDelete)) return;
            $(this).closest('.pl-segment-row').remove();
            reindexSegments();
        });

        // ── 6. Add sub-items ──────────────────────────────────────────────

        // Slides (media segment)
        $(document).on('click', '.pl-btn-add-slide', function () {
            const segIdx  = $(this).data('segment');
            const $list   = $(this).siblings('.pl-slides-list');
            const subIdx  = $list.children('.pl-sub-row').length;
            const $newRow = $(templates.slide(segIdx, subIdx));
            $list.append($newRow);
            initSubSortable($list, 'slides');
        });

        // Metadata fields
        $(document).on('click', '.pl-btn-add-meta-field', function () {
            const segIdx  = $(this).data('segment');
            const $list   = $(this).siblings('.pl-meta-fields-list');
            const subIdx  = $list.children('.pl-sub-row').length;
            $list.append($(templates.metaField(segIdx, subIdx)));
            initSubSortable($list, 'fields');
        });

        // Team members
        $(document).on('click', '.pl-btn-add-member', function () {
            const segIdx  = $(this).data('segment');
            const $list   = $(this).siblings('.pl-team-list');
            const subIdx  = $list.children('.pl-sub-row').length;
            $list.append($(templates.member(segIdx, subIdx)));
            initSubSortable($list, 'members');
        });

        // Timeline milestones
        $(document).on('click', '.pl-btn-add-milestone', function () {
            const segIdx  = $(this).data('segment');
            const $list   = $(this).siblings('.pl-milestone-list');
            const subIdx  = $list.children('.pl-sub-row').length;
            $list.append($(templates.milestone(segIdx, subIdx)));
            initSubSortable($list, 'milestones');
        });

        // Document files
        $(document).on('click', '.pl-btn-add-file', function () {
            const segIdx  = $(this).data('segment');
            const $list   = $(this).siblings('.pl-files-list');
            const subIdx  = $list.children('.pl-sub-row').length;
            $list.append($(templates.file(segIdx, subIdx)));
            initSubSortable($list, 'files');
        });

        // ── 7. Delete sub-items ───────────────────────────────────────────
        $(document).on('click', '.pl-btn-delete-sub', function () {
            const $row  = $(this).closest('.pl-sub-row');
            const $list = $row.parent();

            // Detect which sub-key this list holds
            let subKey = null;
            if ($list.hasClass('pl-slides-list'))      subKey = 'slides';
            if ($list.hasClass('pl-meta-fields-list')) subKey = 'fields';
            if ($list.hasClass('pl-team-list'))        subKey = 'members';
            if ($list.hasClass('pl-milestone-list'))   subKey = 'milestones';
            if ($list.hasClass('pl-files-list'))       subKey = 'files';

            $row.remove();
            if (subKey) reindexSubItems($list, subKey);
        });

        // ── 8. WP Media picker — image / video ────────────────────────────
        $(document).on('click', '.pl-btn-select-media', function (e) {
            e.preventDefault();
            const $btn     = $(this);
            const $row     = $btn.closest('.pl-sub-row, .pl-segment-body');
            const $idInput = $row.find('.pl-media-id').first();
            const $preview = $row.find('.pl-media-preview').first();
            const $remove  = $row.find('.pl-btn-remove-media').first();

            const frame = wp.media({
                title:    'Select or Upload Media',
                button:   { text: 'Use this media' },
                multiple: false,
            });

            frame.on('select', function () {
                const attachment = frame.state().get('selection').first().toJSON();
                $idInput.val(attachment.id);

                // Show preview thumbnail if it's an image
                const thumb = attachment.sizes
                    ? (attachment.sizes.thumbnail
                        ? attachment.sizes.thumbnail.url
                        : attachment.url)
                    : attachment.url;

                if (attachment.type === 'image') {
                    $preview.attr('src', thumb).show();
                } else {
                    // For video, show filename instead of a broken img
                    $preview.hide();
                }
                $remove.show();
            });

            frame.open();
        });

        // Remove media
        $(document).on('click', '.pl-btn-remove-media', function (e) {
            e.preventDefault();
            const $row = $(this).closest('.pl-sub-row');
            $row.find('.pl-media-id').val('');
            $row.find('.pl-media-preview').attr('src', '').hide();
            $(this).hide();
        });

        // ── 9. WP Media picker — documents (file library) ─────────────────
        $(document).on('click', '.pl-btn-select-file', function (e) {
            e.preventDefault();
            const $btn      = $(this);
            const $row      = $btn.closest('.pl-sub-row');
            const $idInput  = $row.find('.pl-media-id');
            const $fileName = $row.find('.pl-file-name');

            const frame = wp.media({
                title:    'Select or Upload File',
                button:   { text: 'Use this file' },
                multiple: false,
                library:  { type: '' },   // allow all file types
            });

            frame.on('select', function () {
                const attachment = frame.state().get('selection').first().toJSON();
                $idInput.val(attachment.id);
                $fileName.text(attachment.filename || attachment.title || '');
                $row.find('.pl-btn-remove-file').show();
            });

            frame.open();
        });

        // Remove file
        $(document).on('click', '.pl-btn-remove-file', function (e) {
            e.preventDefault();
            const $row = $(this).closest('.pl-sub-row');
            $row.find('.pl-media-id').val('');
            $row.find('.pl-file-name').text('');
            $(this).hide();
        });

        // ── 10. Video URL toggle ──────────────────────────────────────────
        $(document).on('change', 'select[name*="[media_type]"]', function () {
            const $row    = $(this).closest('.pl-sub-row');
            const isVideo = $(this).val() === 'video_url';
            $row.find('.pl-video-url-row').toggle(isVideo);
        });

        // ── 11. WP Color pickers ──────────────────────────────────────────
        // Initialise all color pickers (existing and dynamically added ones).
        function initColorPickers($ctx) {
            $ctx.find('.pl-color-picker').each(function () {
                if (!$(this).hasClass('wp-color-picker')) {
                    $(this).wpColorPicker();
                }
            });
        }

        initColorPickers($(document));

        // Re-init if new segment rows are injected (unlikely to need color
        // pickers, but added for completeness / future segment types)
        $(document).on('pl:segmentAdded', function (e, $row) {
            initColorPickers($row);
        });

        // ── 12. Guard: confirm before leaving with unsaved changes ────────
        let isDirty = false;
        $(document).on('change input', '#pl-segments-wrap, #pl-project-settings-wrap, #pl-styling-wrap', function () {
            isDirty = true;
        });
        // The standard WP "Publish / Update" button clears the dirty flag
        $('#publish, #save-post').on('click', function () {
            isDirty = false;
        });
        $(window).on('beforeunload', function () {
            if (isDirty) {
                return 'You have unsaved changes. Leave without saving?';
            }
        });

    }); // end document ready

}(jQuery));
