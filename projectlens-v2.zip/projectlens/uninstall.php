<?php
/**
 * ProjectLens — Uninstall
 *
 * Fired automatically by WordPress when the plugin is deleted from the
 * Plugins screen.  Only runs when the user has opted in to data deletion
 * via the "Delete all data on uninstall" setting in ProjectLens → Global
 * Settings.  If that option is not set, the plugin is removed but all
 * project posts, taxonomies, and options are left intact.
 *
 * @package ProjectLens
 */

// WordPress calls this file directly; bail if it is accessed any other way.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// ── Respect the opt-in setting ─────────────────────────────────────────────
$global_opts = get_option( 'pl_global', [] );
if ( empty( $global_opts['delete_on_uninstall'] ) ) {
    // User did not opt in — leave all data intact.
    return;
}

// ── Delete all pl_project posts and their postmeta ────────────────────────
$project_ids = get_posts( [
    'post_type'      => 'pl_project',
    'post_status'    => 'any',
    'posts_per_page' => -1,
    'fields'         => 'ids',
] );

foreach ( $project_ids as $post_id ) {
    // wp_delete_post( $id, true ) bypasses trash and removes all post meta.
    wp_delete_post( (int) $post_id, true );
}

// ── Delete taxonomy terms ──────────────────────────────────────────────────
$taxonomies = [ 'pl_category', 'pl_status', 'pl_tag' ];

foreach ( $taxonomies as $taxonomy ) {
    $terms = get_terms( [
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
        'fields'     => 'ids',
    ] );

    if ( is_array( $terms ) ) {
        foreach ( $terms as $term_id ) {
            wp_delete_term( (int) $term_id, $taxonomy );
        }
    }
}

// ── Delete plugin options ──────────────────────────────────────────────────
delete_option( 'pl_global' );

// ── Flush rewrite rules so CPT slugs are removed ──────────────────────────
flush_rewrite_rules();
