=== ProjectLens ===
Contributors:       BhoomiTech Heritage and Development Foundation
Tags:               project management, portfolio, custom post type, segments, funding
Requires at least:  6.0
Tested up to:       7.0
Requires PHP:       8.0
Stable tag:         1.0.0
License:            GPL-2.0-or-later
License URI:        https://www.gnu.org/licenses/gpl-2.0.html

A full-featured development project showcase plugin with flexible segments, funding metadata, and an interactive 70/30 split layout.

== Description ==

ProjectLens lets you document and showcase development projects — from initial concept through to certification — using a structured, visually rich full-page layout that bypasses your theme entirely.

Each project is a custom post type with a flexible segment system. You choose which segment types to include, arrange them by drag-and-drop, and enable or disable them individually. The frontend renders a **70:30 split layout**: a scrollable project summary on the left, and an interactive detail panel on the right that loads content on demand — no page reloads.

= Core Features =

**Six segment types, all configurable per project:**

* **Descriptive** — subtitle, rich-text summary (word-limited), and a separate full detail view
* **Media Slider** — image or video carousel with captions, descriptions, and per-slide geo-location maps (OpenStreetMap / Leaflet)
* **Project Metadata** — custom key–value fields, shown as a summary table with full expansion
* **Team & Stakeholders** — member cards with avatar, role, email, and bio
* **Timeline & Milestones** — compact markers on the left, full timeline with status badges on the right
* **Documents & Downloads** — file count with type icons in summary, full download list in detail panel

**Project Settings & Funding Information:**

Covers the fields typically required for funded development projects — project code, status, location, funder, implementing and executing agencies, grant/contract number, budget (multi-currency), co-financing, disbursement, start/end/completion dates, and reporting period.

**Styling & Appearance panel:**

Per-project overrides for accent colour, heading colour, body text colour, background and panel backgrounds, border colour and radius, base and heading font sizes, font family (System, Inter, Georgia, Roboto), and button style (filled, outline, ghost).

**Global Settings:**

Plugin-wide defaults for styling, word limit, archive listing (projects per page, category and status filters), and map tile provider (OpenStreetMap, CartoDB Light, CartoDB Dark).

**Interactive 70:30 layout:**

* Desktop: side-by-side grid; detail panel is sticky
* Mobile: single column; tapping a thumbnail or "Show Detail" opens a full-screen detail view with a ← Back button
* Smooth fade transition between detail states
* Leaflet maps auto-initialise inside the detail panel for slides that carry geo-coordinates

= Who Is This For? =

Organisations and individuals who need to present funded projects — NGOs, development agencies, research institutions, government programmes — where a simple blog post or gallery is not enough.

== Installation ==

1. Upload the `projectlens` folder to the `/wp-content/plugins/` directory, **or** install directly through the WordPress Plugins screen (*Plugins → Add New Plugin → Upload Plugin*).
2. Activate the plugin through the *Plugins* screen.
3. Navigate to **ProjectLens → Add New Project** to create your first project.
4. Use **ProjectLens → Global Settings** to set plugin-wide defaults.

= Requirements =

* WordPress 6.0 or later (tested up to 7.0)
* PHP 8.0 or later
* jQuery (bundled with WordPress)
* jQuery UI Sortable (bundled with WordPress)
* WP Color Picker (bundled with WordPress)
* Internet access for Leaflet CDN (maps feature) and optional Google Fonts

== Frequently Asked Questions ==

= Does this work with the block editor (Gutenberg)? =

ProjectLens uses custom meta boxes and intentionally disables the block editor for `pl_project` posts to preserve the custom admin layout. Standard posts and pages on your site are unaffected.

= Will my project data survive a plugin update? =

Yes. All data is stored in standard WordPress post meta and options. Updates never touch existing data.

= What happens to my data if I delete the plugin? =

By default, nothing — your data is preserved so you can reinstall without loss. If you want all ProjectLens data removed on deletion, enable **"Delete all data on uninstall"** under *ProjectLens → Global Settings → Data & Uninstall* **before** deleting the plugin. This removes all `pl_project` posts, taxonomy terms, and plugin options permanently.

= Can I show projects in my theme's archive or listing pages? =

Yes. The plugin registers the `pl_project` custom post type with `has_archive => true`. The full-page template only activates on single project views; your theme handles archive/listing pages normally.

= How do I reorder segments? =

Open the project in the admin editor. In the **Project Segments** meta box, drag any segment row by the grip handle (☰) on the left. The new order is saved when you update the post.

= Can I add the same segment type more than once? =

Yes. Select the type from the "Add Segment" dropdown and click **+ Add Segment** as many times as needed. Each instance has its own title and content.

= Which map provider is used for geo-location? =

OpenStreetMap via the Leaflet library by default (no API key required). You can switch to CartoDB Light or CartoDB Dark under Global Settings → Map Tile Provider.

= Is this plugin translation-ready? =

Yes. All strings are wrapped in WordPress i18n functions using the `projectlens` text domain.

== Screenshots ==

1. Single project page — 70:30 desktop layout with the Media Slider segment active and a geo-location map loaded in the detail panel.
2. Project admin editor — Segment Manager meta box with drag-and-drop reordering and all six segment types.
3. Project Settings meta box — funding and identity fields.
4. Styling & Appearance panel — per-project colour and typography overrides.
5. Global Settings page — defaults, archive options, and map tile provider.
6. Mobile view — full-screen detail panel with ← Back navigation.

== Changelog ==

= 1.0.0 =
* Initial release.
* Six segment types: Descriptive, Media Slider, Project Metadata, Team & Stakeholders, Timeline & Milestones, Documents & Downloads.
* 70:30 split layout with sticky detail panel and mobile full-screen override.
* Drag-and-drop segment reordering in admin.
* WP Media Library integration for images, videos, and file attachments.
* Per-slide Leaflet geo-location maps (OpenStreetMap / CartoDB).
* Per-project Styling panel with WP Color Picker.
* Global Settings page with map tile provider selection.
* Full funding/project metadata fields covering common international norms.
* Safe uninstall: data preserved by default; opt-in deletion available in Global Settings.

== Upgrade Notice ==

= 1.0.0 =
Initial release — no upgrade steps required.

== Third-Party Libraries ==

* **Leaflet** (https://leafletjs.com/) — BSD-2-Clause license — loaded from unpkg CDN for geo-location maps on single project pages.
* **jQuery UI Sortable** — MIT license — bundled with WordPress core; used for drag-and-drop in the admin editor.
