<?php
/**
 * Plugin Name:       ProjectLens
 * Plugin URI:        https://github.com/BhoomiTech/projectlens
 * Description:       A full-featured development project showcase plugin with flexible segments, funding metadata, and an interactive 70/30 split layout.
 * Version:           1.0.0
 * Author:            BhoomiTech Heritage and Development Foundation
 * License:           GPL-2.0+
 * Text Domain:       projectlens
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PL_VERSION',     '1.0.0' );
define( 'PL_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'PL_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'PL_PLUGIN_FILE', __FILE__ );

require_once PL_PLUGIN_DIR . 'includes/class-pl-post-type.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-segment.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-meta-boxes.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-settings.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-demo-data.php';

/**
 * Bootstrap all plugin components.
 */
function pl_init() {
    PL_Post_Type::init();
    PL_Meta_Boxes::init();
    PL_Settings::init();
    PL_Demo_Data::init();
}
add_action( 'plugins_loaded', 'pl_init' );

/**
 * Enqueue frontend assets.
 */
function pl_enqueue_public_assets() {
    if ( ! is_singular( 'pl_project' ) ) return;

    wp_enqueue_style(
        'projectlens-public',
        PL_PLUGIN_URL . 'public/css/projectlens.css',
        [],
        PL_VERSION
    );

    // Leaflet (OpenStreetMap) for geo-location maps — bundled locally
    wp_enqueue_style( 'leaflet',
        PL_PLUGIN_URL . 'public/vendor/leaflet/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet',
        PL_PLUGIN_URL . 'public/vendor/leaflet/leaflet.js', [], '1.9.4', true );

    // Conditionally load Google Fonts based on the per-project font choice
    $google_fonts_map = [
        'inter'  => 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap',
        'roboto' => 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap',
    ];
    $post_id    = get_the_ID();
    $styling    = get_post_meta( $post_id, '_pl_styling', true ) ?: [];
    $font_key   = $styling['font_family'] ?? 'system';
    if ( isset( $google_fonts_map[ $font_key ] ) ) {
        wp_enqueue_style(
            'pl-google-font-' . sanitize_key( $font_key ),
            $google_fonts_map[ $font_key ],
            [],
            null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- external Google Fonts URL; versioning not applicable
        );
    }

    wp_enqueue_script(
        'projectlens-public',
        PL_PLUGIN_URL . 'public/js/projectlens.js',
        [ 'jquery', 'leaflet' ],
        PL_VERSION,
        true
    );

    wp_localize_script( 'projectlens-public', 'PL', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'pl_nonce' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'pl_enqueue_public_assets' );

/**
 * Enqueue admin assets.
 */
function pl_enqueue_admin_assets( $hook ) {
    global $post;
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) return;
    if ( ! $post || $post->post_type !== 'pl_project' ) return;

    wp_enqueue_media();

    wp_enqueue_style(
        'projectlens-admin',
        PL_PLUGIN_URL . 'admin/css/admin.css',
        [],
        PL_VERSION
    );

    wp_enqueue_script(
        'projectlens-admin',
        PL_PLUGIN_URL . 'admin/js/admin.js',
        [ 'jquery', 'jquery-ui-sortable', 'wp-color-picker' ],
        PL_VERSION,
        true
    );

    wp_enqueue_style( 'wp-color-picker' );

    wp_localize_script( 'projectlens-admin', 'PL_Admin', [
        'nonce'        => wp_create_nonce( 'pl_admin_nonce' ),
        'segmentTypes' => PL_Segment::get_type_labels(),
        'confirmDelete'=> __( 'Delete this segment? This cannot be undone.', 'projectlens' ),
    ]);
}
add_action( 'admin_enqueue_scripts', 'pl_enqueue_admin_assets' );

/**
 * Force full-page template for pl_project.
 */
function pl_load_project_template( $template ) {
    if ( is_singular( 'pl_project' ) ) {
        $plugin_template = PL_PLUGIN_DIR . 'templates/single-pl_project.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    return $template;
}
add_filter( 'template_include', 'pl_load_project_template' );

/**
 * Activation hook — flush rewrite rules.
 */
function pl_activate() {
    PL_Post_Type::register_cpt();
    flush_rewrite_rules();
}
register_activation_hook( PL_PLUGIN_FILE, 'pl_activate' );

/**
 * Deactivation hook.
 */
function pl_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook( PL_PLUGIN_FILE, 'pl_deactivate' );
