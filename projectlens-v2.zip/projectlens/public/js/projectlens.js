/**
 * ProjectLens — Frontend JS (v2)
 * Fixes: video slider display, map re-init on slide switch, media lightbox,
 *        team member individual detail panel, document viewer, "Show Details" removal.
 */
(function ($) {
    'use strict';

    // ── Read embedded data ─────────────────────────────────────────
    let segmentsData = [];
    let config = { tileUrl: '', mapZoom: 13 };

    try {
        const segEl = document.getElementById('pl-segments-data');
        const cfgEl = document.getElementById('pl-config-data');
        if (segEl) segmentsData = JSON.parse(segEl.textContent || '[]');
        if (cfgEl) config       = JSON.parse(cfgEl.textContent || '{}');
    } catch(e) { console.warn('ProjectLens: could not parse segment data', e); }

    // Index segments by id for fast lookup
    const segIndex = {};
    segmentsData.forEach(seg => { segIndex[seg.id] = seg; });

    // ── Detail panel elements ──────────────────────────────────────
    const $detailPanel  = $('#pl-detail-panel');
    const $detailContent= $('#pl-detail-content');
    const $summaryPanel = $('#pl-summary-panel');
    const $mobileBack   = $('#pl-mobile-back');
    const isMobile = () => window.innerWidth <= 768;

    // ── Utility: open/close detail panel on mobile ────────────────
    function openDetailPanel() {
        if (isMobile()) {
            $detailPanel.addClass('pl-detail-open');
            $('html, body').css('overflow', 'hidden');
        }
    }
    function closeDetailPanel() {
        $detailPanel.removeClass('pl-detail-open');
        $('html, body').css('overflow', '');
    }

    $mobileBack.on('click', closeDetailPanel);

    // ── Leaflet map initialisation ─────────────────────────────────
    // Track initialised map instances (not just IDs) so we can destroy+re-create
    const mapInstances = {};

    function destroyMapsIn($container) {
        $container.find('.pl-geo__map').each(function () {
            const mapId = $(this).attr('id');
            if (mapInstances[mapId]) {
                mapInstances[mapId].remove();
                delete mapInstances[mapId];
            }
        });
    }

    function initMaps() {
        if (typeof L === 'undefined') return;
        $detailContent.find('.pl-geo__map').each(function () {
            const $el   = $(this);
            const mapId = $el.attr('id');
            if (mapInstances[mapId]) return; // already live

            const lat   = parseFloat($el.data('lat'));
            const lng   = parseFloat($el.data('lng'));
            const label = $el.data('label') || '';
            if (isNaN(lat) || isNaN(lng)) return;

            setTimeout(function () {
                try {
                    const map = L.map(mapId, { scrollWheelZoom: false }).setView([lat, lng], config.mapZoom || 13);
                    L.tileLayer(config.tileUrl || 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '© OpenStreetMap contributors',
                        maxZoom: 19
                    }).addTo(map);
                    L.marker([lat, lng])
                        .addTo(map)
                        .bindPopup(label || (lat + ', ' + lng))
                        .openPopup();
                    mapInstances[mapId] = map;
                } catch(e) { /* container may not be visible yet */ }
            }, 80);
        });
    }

    // ── Lightbox ───────────────────────────────────────────────────
    function openLightbox(html) {
        // Remove existing
        $('#pl-lightbox').remove();

        const $lb = $('<div id="pl-lightbox" style="' +
            'position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:99999;' +
            'display:flex;align-items:center;justify-content:center;padding:20px;"></div>');

        const $inner = $('<div style="position:relative;max-width:92vw;max-height:92vh;"></div>');
        const $close = $('<button style="position:absolute;top:-36px;right:0;background:none;border:none;' +
            'color:#fff;font-size:28px;cursor:pointer;line-height:1;" title="Close">✕</button>');

        $inner.append($close).append(html);
        $lb.append($inner);
        $('body').append($lb);

        $close.on('click', closeLightbox);
        $lb.on('click', function (e) { if ($(e.target).is($lb)) closeLightbox(); });
        $(document).on('keydown.lb', function (e) { if (e.key === 'Escape') closeLightbox(); });
    }

    function closeLightbox() {
        $('#pl-lightbox').remove();
        $(document).off('keydown.lb');
    }

    // ── Main: load segment detail into right panel ─────────────────
    function loadDetail(segId, slideIndex, memberIndex) {
        const seg = segIndex[segId];
        if (!seg) return;

        // Destroy any live Leaflet maps before replacing HTML
        destroyMapsIn($detailContent);

        let html = buildDetailHTML(seg, slideIndex, memberIndex);
        $detailContent.html(html);

        // Mark active button
        $('.pl-btn-show-detail').removeClass('pl-active');
        $('[data-seg-id="' + segId + '"].pl-btn-show-detail').addClass('pl-active');

        openDetailPanel();
        initMaps();
        initDetailSlides(segId);
        $detailPanel.scrollTop(0);
    }

    // ── Build detail HTML from seg data ───────────────────────────
    function buildDetailHTML(seg, slideIndex, memberIndex) {
        switch (seg.type) {
            case 'descriptive': return buildDescriptiveDetail(seg);
            case 'media':       return buildMediaDetail(seg, slideIndex || 0);
            case 'metadata':    return buildMetadataDetail(seg);
            case 'team':
                // If a specific member index is provided, show individual detail
                if (typeof memberIndex === 'number') {
                    return buildSingleMemberDetail(seg, memberIndex);
                }
                return buildTeamDetail(seg);
            case 'timeline':    return buildTimelineDetail(seg);
            case 'documents':   return buildDocumentsDetail(seg);
            default:            return '<p>No detail available.</p>';
        }
    }

    function esc(str) {
        return $('<span>').text(str || '').html();
    }

    function buildDescriptiveDetail(seg) {
        let html = '<div class="pl-detail pl-detail--descriptive">';
        if (seg.title)          html += '<h2 class="pl-detail__title">' + esc(seg.title) + '</h2>';
        if (seg.subtitle)       html += '<p class="pl-detail__subtitle">' + esc(seg.subtitle) + '</p>';
        if (seg.detail_content) html += '<div class="pl-detail__body">' + seg.detail_content + '</div>';
        else if (seg.content)   html += '<div class="pl-detail__body">' + seg.content + '</div>';
        html += '</div>';
        return html;
    }

    function buildMediaDetail(seg, activeSlide) {
        const slides = seg.slides || [];
        let html = '<div class="pl-detail pl-detail--media">';
        html += '<h2 class="pl-detail__title">' + esc(seg.title) + '</h2>';
        html += '<div class="pl-detail-media__viewer">';

        slides.forEach(function (slide, si) {
            const active = (si === activeSlide);
            html += '<div class="pl-detail-slide" data-slide-index="' + si + '" style="' + (active ? '' : 'display:none;') + '">';
            html += '<div class="pl-detail-slide__media">';

            if (slide.media_type === 'image' && slide.media_url) {
                html += '<img src="' + esc(slide.media_url) + '" alt="' + esc(slide.caption) + '" '
                      + 'style="cursor:zoom-in;width:100%;border-radius:var(--pl-radius);" '
                      + 'class="pl-lightbox-trigger" data-lightbox-type="image" data-src="' + esc(slide.media_url) + '" />';
            } else if (slide.media_type === 'video_url' && slide.video_url) {
                const embedUrl = getEmbedUrl(slide.video_url);
                if (embedUrl) {
                    html += '<div class="pl-embed-wrap" style="cursor:pointer;" class="pl-lightbox-trigger" '
                          + 'data-lightbox-type="iframe" data-src="' + esc(embedUrl) + '">'
                          + '<iframe src="' + esc(embedUrl) + '" frameborder="0" allowfullscreen '
                          + 'style="width:100%;aspect-ratio:16/9;border-radius:var(--pl-radius);"></iframe></div>';
                }
            } else if (slide.media_type === 'video' && slide.media_url) {
                html += '<video controls style="width:100%;border-radius:var(--pl-radius);" '
                      + 'class="pl-lightbox-trigger" data-lightbox-type="video" data-src="' + esc(slide.media_url) + '">'
                      + '<source src="' + esc(slide.media_url) + '"></video>';
            }

            html += '</div>';
            if (slide.caption)     html += '<p class="pl-detail-slide__caption"><strong>' + esc(slide.caption) + '</strong></p>';
            if (slide.description) html += '<p class="pl-detail-slide__desc">' + esc(slide.description) + '</p>';

            // Geo map
            if (slide.geo_lat && slide.geo_lng) {
                const mapId = 'pl-map-' + seg.id + '-' + si;
                html += '<div class="pl-geo">'
                      + '<div class="pl-geo__map" id="' + mapId + '"'
                      + ' data-lat="' + esc(slide.geo_lat) + '"'
                      + ' data-lng="' + esc(slide.geo_lng) + '"'
                      + ' data-label="' + esc(slide.geo_label) + '"'
                      + ' style="height:180px;border-radius:var(--pl-radius);margin-top:10px;"></div>'
                      + '<p class="pl-geo__coords">📍 '
                      + (slide.geo_label ? esc(slide.geo_label) + ' — ' : '')
                      + esc(slide.geo_lat) + ', ' + esc(slide.geo_lng) + '</p>'
                      + '</div>';
            }

            html += '</div>'; // .pl-detail-slide
        });

        // Slide navigation dots
        if (slides.length > 1) {
            html += '<div class="pl-detail-slide-dots">';
            slides.forEach(function (_, si) {
                html += '<button class="pl-dot' + (si === activeSlide ? ' pl-dot--active' : '') + '" data-slide="' + si + '" aria-label="Slide ' + (si + 1) + '"></button>';
            });
            html += '</div>';
        }

        html += '</div></div>';
        html += '<style>.pl-detail-slide-dots{display:flex;gap:6px;justify-content:center;margin-top:12px;}'
              + '.pl-dot{width:8px;height:8px;border-radius:50%;background:var(--pl-border);border:none;cursor:pointer;padding:0;transition:background .15s;}'
              + '.pl-dot--active{background:var(--pl-accent);}</style>';
        return html;
    }

    function buildMetadataDetail(seg) {
        const fields = seg.fields || [];
        let html = '<div class="pl-detail pl-detail--metadata">';
        html += '<h2 class="pl-detail__title">' + esc(seg.title || 'Project Metadata') + '</h2>';
        html += '<dl class="pl-meta-table pl-meta-table--full">';
        fields.forEach(function (f) {
            html += '<div class="pl-meta-table__row"><dt>' + esc(f.label) + '</dt><dd>' + esc(f.value) + '</dd></div>';
        });
        html += '</dl></div>';
        return html;
    }

    // Show all members as cards (overview)
    function buildTeamDetail(seg) {
        const members = seg.members || [];
        let html = '<div class="pl-detail pl-detail--team">';
        html += '<h2 class="pl-detail__title">' + esc(seg.title || 'Team & Stakeholders') + '</h2>';
        html += '<p style="font-size:0.85em;color:var(--pl-body);margin-bottom:12px;">Click a member to view their profile.</p>';
        html += '<div class="pl-team-detail">';
        members.forEach(function (m, mi) {
            html += '<div class="pl-team-detail__card" style="cursor:pointer;" '
                  + 'data-seg-id="' + esc(seg.id) + '" data-member-index="' + mi + '">';
            if (m.avatar_url) {
                html += '<img src="' + esc(m.avatar_url) + '" class="pl-avatar pl-avatar--lg" alt="' + esc(m.name) + '" />';
            } else {
                html += '<div class="pl-avatar pl-avatar--lg pl-avatar--placeholder">' + esc((m.name || '?').charAt(0)) + '</div>';
            }
            html += '<div class="pl-team-detail__info">';
            html += '<strong>' + esc(m.name) + '</strong>';
            if (m.role) html += '<span class="pl-team-role">' + esc(m.role) + '</span>';
            html += '</div></div>';
        });
        html += '</div></div>';
        return html;
    }

    // Show a single member's full detail
    function buildSingleMemberDetail(seg, memberIndex) {
        const members = seg.members || [];
        const m = members[memberIndex];
        if (!m) return buildTeamDetail(seg);

        let html = '<div class="pl-detail pl-detail--team">';
        // Back link to team overview
        html += '<button class="pl-btn-back-team pl-btn-show-detail" data-seg-id="' + esc(seg.id) + '" '
              + 'style="margin-bottom:16px;display:inline-flex;align-items:center;gap:4px;">← All Members</button>';
        html += '<div style="display:flex;gap:16px;align-items:flex-start;">';
        if (m.avatar_url) {
            html += '<img src="' + esc(m.avatar_url) + '" class="pl-avatar pl-avatar--lg" '
                  + 'style="width:80px;height:80px;border-radius:50%;object-fit:cover;flex-shrink:0;" alt="' + esc(m.name) + '" />';
        } else {
            html += '<div class="pl-avatar pl-avatar--lg pl-avatar--placeholder" style="width:80px;height:80px;font-size:2em;flex-shrink:0;">'
                  + esc((m.name || '?').charAt(0)) + '</div>';
        }
        html += '<div>';
        html += '<h2 class="pl-detail__title" style="margin:0 0 4px;">' + esc(m.name || '') + '</h2>';
        if (m.role)  html += '<p class="pl-team-role" style="margin:0 0 8px;">' + esc(m.role) + '</p>';
        if (m.email) html += '<p><a href="mailto:' + esc(m.email) + '">' + esc(m.email) + '</a></p>';
        html += '</div></div>';
        if (m.bio)   html += '<p style="margin-top:16px;">' + esc(m.bio) + '</p>';
        html += '</div>';
        return html;
    }

    function buildTimelineDetail(seg) {
        const mss = seg.milestones || [];
        let html = '<div class="pl-detail pl-detail--timeline">';
        html += '<h2 class="pl-detail__title">' + esc(seg.title || 'Timeline & Milestones') + '</h2>';
        html += '<div class="pl-timeline-full">';
        mss.forEach(function (ms) {
            const status = ms.status || 'planned';
            html += '<div class="pl-timeline-full__item pl-ms-status--' + esc(status) + '">';
            html += '<div class="pl-timeline-full__line"><span class="pl-timeline-full__dot"></span></div>';
            html += '<div class="pl-timeline-full__content">';
            html += '<strong>' + esc(ms.title) + '</strong>';
            html += '<div class="pl-timeline-full__meta">';
            if (ms.date) html += '<span class="pl-ms-date">' + esc(ms.date) + '</span>';
            html += '<span class="pl-ms-badge pl-ms-badge--' + esc(status) + '">' + esc(status.charAt(0).toUpperCase() + status.slice(1)) + '</span>';
            html += '</div>';
            if (ms.description) html += '<p>' + esc(ms.description) + '</p>';
            html += '</div></div>';
        });
        html += '</div></div>';
        return html;
    }

    // ── Document viewer helpers ────────────────────────────────────
    const BROWSER_RENDERABLE = ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'mp4', 'webm', 'ogg', 'mp3', 'wav'];
    const FILE_ICONS = {
        pdf: '📄', doc: '📝', docx: '📝', xls: '📊', xlsx: '📊',
        ppt: '📊', pptx: '📊', zip: '📦', rar: '📦', txt: '📃',
        csv: '📊', mp4: '🎬', webm: '🎬', mp3: '🎵', wav: '🎵',
        jpg: '🖼️', jpeg: '🖼️', png: '🖼️', gif: '🖼️', svg: '🖼️',
        default: '📎'
    };

    function getFileExt(url) {
        if (!url) return '';
        const parts = url.split('?')[0].split('.');
        return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : '';
    }

    function buildDocumentsDetail(seg) {
        const files = seg.files || [];
        let html = '<div class="pl-detail pl-detail--documents">';
        html += '<h2 class="pl-detail__title">' + esc(seg.title || 'Documents & Downloads') + '</h2>';
        html += '<ul class="pl-file-list">';
        files.forEach(function (f, fi) {
            if (!f.file_url) return;
            const ext  = f.ext ? f.ext.toLowerCase() : getFileExt(f.file_url);
            const icon = FILE_ICONS[ext] || FILE_ICONS.default;
            html += '<li class="pl-file-list__item" style="cursor:pointer;" '
                  + 'data-seg-id="' + esc(seg.id) + '" data-file-index="' + fi + '">';
            html += '<div class="pl-file-list__icon">' + icon + '</div>';
            html += '<div class="pl-file-list__info"><strong>' + esc(f.label || f.file_name || 'File') + '</strong>';
            if (f.description) html += '<p>' + esc(f.description) + '</p>';
            if (ext)           html += '<span class="pl-file-ext">' + esc(ext.toUpperCase()) + '</span>';
            html += '</div>';
            html += '<a href="' + esc(f.file_url) + '" class="pl-btn-download" download>↓ Download</a>';
            html += '</li>';
        });
        html += '</ul></div>';
        return html;
    }

    function buildDocumentFileView(seg, fileIndex) {
        const files = seg.files || [];
        const f = files[fileIndex];
        if (!f || !f.file_url) return buildDocumentsDetail(seg);

        const ext = f.ext ? f.ext.toLowerCase() : getFileExt(f.file_url);
        const icon = FILE_ICONS[ext] || FILE_ICONS.default;
        const label = f.label || f.file_name || 'File';
        const renderable = BROWSER_RENDERABLE.includes(ext);

        let html = '<div class="pl-detail pl-detail--documents">';
        html += '<button class="pl-btn-back-docs pl-btn-show-detail" data-seg-id="' + esc(seg.id) + '" '
              + 'style="margin-bottom:16px;display:inline-flex;align-items:center;gap:4px;">← All Documents</button>';
        html += '<h2 class="pl-detail__title">' + esc(label) + '</h2>';
        if (f.description) html += '<p style="margin-bottom:12px;">' + esc(f.description) + '</p>';

        if (renderable) {
            if (['jpg','jpeg','png','gif','webp','svg'].includes(ext)) {
                html += '<img src="' + esc(f.file_url) + '" style="width:100%;border-radius:var(--pl-radius);margin-bottom:12px;" alt="' + esc(label) + '" />';
            } else if (['mp4','webm','ogg'].includes(ext)) {
                html += '<video controls style="width:100%;border-radius:var(--pl-radius);margin-bottom:12px;">'
                      + '<source src="' + esc(f.file_url) + '"></video>';
            } else if (['mp3','wav'].includes(ext)) {
                html += '<audio controls style="width:100%;margin-bottom:12px;">'
                      + '<source src="' + esc(f.file_url) + '"></audio>';
            } else if (ext === 'pdf') {
                html += '<iframe src="' + esc(f.file_url) + '" style="width:100%;height:420px;border:none;border-radius:var(--pl-radius);margin-bottom:12px;"></iframe>';
            }
        } else {
            html += '<div style="text-align:center;padding:40px 20px;">'
                  + '<div style="font-size:64px;margin-bottom:12px;">' + icon + '</div>'
                  + '<p style="color:var(--pl-body);">' + esc(ext.toUpperCase() || 'File') + ' — Preview not available in browser</p>'
                  + '</div>';
        }

        html += '<a href="' + esc(f.file_url) + '" class="pl-btn-download" download '
              + 'style="display:block;text-align:center;margin-top:8px;">↓ Download ' + esc(label) + '</a>';
        html += '</div>';
        return html;
    }

    // ── YouTube / Vimeo embed URL converter ────────────────────────
    function getEmbedUrl(url) {
        let m = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([A-Za-z0-9_-]{11})/);
        if (m) return 'https://www.youtube.com/embed/' + m[1] + '?rel=0';
        m = url.match(/vimeo\.com\/(\d+)/);
        if (m) return 'https://player.vimeo.com/video/' + m[1];
        return url;
    }

    // ── Detail slide dot navigation ────────────────────────────────
    function initDetailSlides(segId) {
        // Unbind previous to avoid stacking handlers
        $detailContent.off('click.dots').on('click.dots', '.pl-dot', function () {
            const idx    = parseInt($(this).data('slide'));
            const $dots  = $detailContent.find('.pl-dot');
            const $slides = $detailContent.find('.pl-detail-slide');

            // Destroy maps in the slide being hidden, allow re-init for new slide
            const $hiding = $slides.filter(':visible');
            destroyMapsIn($hiding);

            $slides.hide().eq(idx).show();
            $dots.removeClass('pl-dot--active').eq(idx).addClass('pl-dot--active');
            initMaps();
        });
    }

    // ── Event delegation: "Show Detail" buttons ────────────────────
    // (still used for descriptive, metadata, timeline — team now uses card click)
    $summaryPanel.on('click', '.pl-btn-show-detail', function () {
        const segId = $(this).data('seg-id');
        loadDetail(segId, 0);
    });

    // ── Event delegation: detail-panel back links ─────────────────
    // Both back-team and back-docs use .pl-btn-show-detail + data-seg-id
    $detailContent.on('click', '.pl-btn-show-detail', function () {
        const segId = $(this).data('seg-id');
        loadDetail(segId, 0);
    });

    // ── Event delegation: Media thumbnails in summary ─────────────
    $summaryPanel.on('click', '.pl-slide__thumb', function () {
        const segId      = $(this).data('seg-id');
        const slideIndex = parseInt($(this).data('slide-index')) || 0;
        loadDetail(segId, slideIndex);
    });

    // ── FIX Issue 5: Lightbox click on image/video in detail ──────
    $detailContent.on('click', '.pl-lightbox-trigger', function () {
        const type = $(this).data('lightbox-type');
        const src  = $(this).data('src');
        if (!src) return;

        let content = '';
        if (type === 'image') {
            content = '<img src="' + esc(src) + '" style="max-width:88vw;max-height:88vh;display:block;border-radius:6px;" />';
        } else if (type === 'video') {
            content = '<video controls autoplay style="max-width:88vw;max-height:88vh;border-radius:6px;">'
                    + '<source src="' + esc(src) + '"></video>';
        } else if (type === 'iframe') {
            content = '<div style="width:min(860px,88vw);aspect-ratio:16/9;">'
                    + '<iframe src="' + esc(src) + '" frameborder="0" allowfullscreen '
                    + 'style="width:100%;height:100%;"></iframe></div>';
        }

        if (content) openLightbox(content);
    });

    // ── FIX Issue 6: Clicking team member card → individual detail ─
    // In summary panel (avatar cards)
    $summaryPanel.on('click', '.pl-team-avatars__item', function () {
        const segId      = $(this).data('seg-id');
        const memberIndex = parseInt($(this).data('member-index'));
        if (!isNaN(memberIndex)) {
            loadDetail(segId, 0, memberIndex);
        } else {
            loadDetail(segId, 0);
        }
    });

    // In detail panel (team overview cards → individual detail)
    $detailContent.on('click', '.pl-team-detail__card', function () {
        const segId      = $(this).data('seg-id');
        const memberIndex = parseInt($(this).data('member-index'));
        if (!isNaN(memberIndex)) {
            loadDetail(segId, 0, memberIndex);
        }
    });

    // ── FIX Issue 7: Document item click → file viewer ────────────
    // ── FIX Issue 7: Document summary item click → file viewer ────
    $summaryPanel.on('click', '.pl-doc-summary-item', function () {
        const segId     = $(this).data('seg-id');
        const fileIndex = parseInt($(this).data('file-index'));
        const seg = segIndex[segId];
        if (!seg) return;

        destroyMapsIn($detailContent);
        $detailContent.html(buildDocumentFileView(seg, fileIndex));
        $detailPanel.scrollTop(0);
        openDetailPanel();

        // Re-bind back button
        $detailContent.off('click.docs-back').on('click.docs-back', '.pl-btn-show-detail', function () {
            loadDetail($(this).data('seg-id'), 0);
        });
    });

    // ── FIX Issue 7: Document summary — "Show All" button also triggers detail
    $summaryPanel.on('click', '.pl-docs-summary', function () {
        const segId = $(this).closest('[data-seg-id]').data('seg-id') ||
                      $(this).closest('.pl-seg').data('seg-id');
        loadDetail(segId, 0);
    });

    // Clicking doc in summary (the icon area or Show Detail button)
    // When the detail panel shows the docs list, clicking a file item shows the viewer
    $detailContent.on('click', '.pl-file-list__item', function () {
        const segId     = $(this).data('seg-id');
        const fileIndex = parseInt($(this).data('file-index'));
        const seg = segIndex[segId];
        if (!seg) return;

        destroyMapsIn($detailContent);
        $detailContent.html(buildDocumentFileView(seg, fileIndex));
        $detailPanel.scrollTop(0);

        // Re-bind back button
        $detailContent.off('click.docs-back').on('click.docs-back', '.pl-btn-show-detail', function () {
            loadDetail($(this).data('seg-id'), 0);
        });
    });

    // ── Window resize: reset mobile state if going desktop ────────
    $(window).on('resize', function () {
        if (!isMobile()) closeDetailPanel();
    });

    // ── On load: hydrate media_url / avatar_url from PHP-rendered DOM ──
    (function hydrateMediaUrls() {
        segmentsData.forEach(function (seg) {
            if (seg.type === 'media') {
                (seg.slides || []).forEach(function (slide, si) {
                    // For video_url slides, store the video_url in media_url if not set
                    if (slide.media_type === 'video_url' && slide.video_url && !slide.media_url) {
                        slide.media_url = slide.video_url;
                    }
                    // Pull full-size URL from PHP-rendered hidden slide in DOM
                    const $phpSlide = $('#pl-main .pl-detail-slide[data-slide-index="' + si + '"]');
                    if ($phpSlide.length) {
                        const imgSrc = $phpSlide.find('img').first().attr('src');
                        if (imgSrc && !slide.media_url) slide.media_url = imgSrc;
                    }
                    // Also check slider thumbnails for media_url
                    if (!slide.media_url) {
                        const $thumb = $summaryPanel.find('.pl-slide__thumb[data-slide-index="' + si + '"] img');
                        if ($thumb.length) slide.media_url = $thumb.first().attr('src');
                    }
                });
            }
            if (seg.type === 'team') {
                (seg.members || []).forEach(function (m, mi) {
                    if (!m.avatar_url) {
                        const $item = $summaryPanel.find('.pl-team-avatars__item').eq(mi);
                        const $img  = $item.find('img.pl-avatar');
                        if ($img.length) m.avatar_url = $img.attr('src');
                    }
                });
            }
            if (seg.type === 'documents') {
                (seg.files || []).forEach(function (f) {
                    // file_url needs to be in the JSON from PHP
                    // Ensure ext is set
                    if (!f.ext && f.file_url) {
                        f.ext = getFileExt(f.file_url);
                    }
                    if (!f.ext && f.file_name) {
                        f.ext = getFileExt(f.file_name);
                    }
                });
            }
        });
    })();

})(jQuery);
