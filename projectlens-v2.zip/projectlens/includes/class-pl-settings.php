<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Settings {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'add_settings_page' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
    }

    public static function add_settings_page() {
        add_submenu_page(
            'edit.php?post_type=pl_project',
            __( 'ProjectLens Settings', 'projectlens' ),
            __( 'Global Settings',      'projectlens' ),
            'manage_options',
            'projectlens-settings',
            [ __CLASS__, 'render_page' ]
        );
    }

    public static function register_settings() {
        register_setting( 'pl_global_settings', 'pl_global', [ __CLASS__, 'sanitize_global' ] );
    }

    public static function get( $key, $default = '' ) {
        $opts = get_option( 'pl_global', [] );
        return $opts[$key] ?? $default;
    }

    public static function render_page() {
        $opts = get_option( 'pl_global', [] );

        // ── Admin notices ──────────────────────────────────────────────────
        $notice = sanitize_key( wp_unslash( $_GET['pl_notice'] ?? '' ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only GET param for admin notice display; sanitized via sanitize_key()
        $notice_map = [
            /* translators: %s: URL to view the demo project */
            'demo_installed' => [ 'success', __( 'Demo project installed successfully. <a href="%s">View it →</a>', 'projectlens' ) ],
            'demo_exists'    => [ 'warning', __( 'Demo project already exists. Remove it first before reinstalling.', 'projectlens' ) ],
            'demo_removed'   => [ 'success', __( 'Demo project and all its data have been removed.', 'projectlens' ) ],
            'demo_error'     => [ 'error',   __( 'Could not create demo project. Please check server error logs.', 'projectlens' ) ],
        ];
        if ( $notice && isset( $notice_map[ $notice ] ) ) {
            [ $type, $message ] = $notice_map[ $notice ];
            if ( $notice === 'demo_installed' ) {
                $demo_id = get_option( PL_Demo_Data::OPTION_KEY );
                $message = sprintf( $message, $demo_id ? get_permalink( $demo_id ) : '#' );
            }
            printf(
                '<div class="notice notice-%s is-dismissible"><p>%s</p></div>',
                esc_attr( $type ),
                wp_kses( $message, [ 'a' => [ 'href' => [] ] ] )
            );
        }
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'ProjectLens — Global Settings', 'projectlens' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'pl_global_settings' ); ?>

                <h2><?php esc_html_e( 'Default Styling', 'projectlens' ); ?></h2>
                <p class="description"><?php esc_html_e( 'These defaults apply to all projects unless overridden in the individual project\'s Styling panel.', 'projectlens' ); ?></p>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Default Accent Color', 'projectlens'); ?></th>
                        <td><input type="text" name="pl_global[default_accent]" value="<?php echo esc_attr($opts['default_accent'] ?? '#2563eb'); ?>" class="pl-color-picker" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Default Font Size (px)', 'projectlens'); ?></th>
                        <td><input type="number" name="pl_global[default_font_size]" value="<?php echo esc_attr($opts['default_font_size'] ?? 15); ?>" min="12" max="22" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Default Word Limit', 'projectlens'); ?></th>
                        <td>
                            <input type="number" name="pl_global[default_word_limit]" value="<?php echo esc_attr($opts['default_word_limit'] ?? 60); ?>" min="10" max="500" />
                            <p class="description"><?php esc_html_e('Words shown before truncation in descriptive segments.','projectlens'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Default Border Radius (px)', 'projectlens'); ?></th>
                        <td><input type="number" name="pl_global[default_border_radius]" value="<?php echo esc_attr($opts['default_border_radius'] ?? 8); ?>" min="0" max="32" /></td>
                    </tr>
                </table>

                <h2><?php esc_html_e( 'Archive / Listing Settings', 'projectlens' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Projects Per Page', 'projectlens'); ?></th>
                        <td><input type="number" name="pl_global[per_page]" value="<?php echo esc_attr($opts['per_page'] ?? 12); ?>" min="1" max="100" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Show Category Filter', 'projectlens'); ?></th>
                        <td><label><input type="checkbox" name="pl_global[show_cat_filter]" value="1" <?php checked($opts['show_cat_filter'] ?? 1); ?> /> <?php esc_html_e('Yes','projectlens'); ?></label></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Show Status Filter', 'projectlens'); ?></th>
                        <td><label><input type="checkbox" name="pl_global[show_status_filter]" value="1" <?php checked($opts['show_status_filter'] ?? 1); ?> /> <?php esc_html_e('Yes','projectlens'); ?></label></td>
                    </tr>
                </table>

                <h2><?php esc_html_e( 'Map Settings', 'projectlens' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th><?php esc_html_e('Map Tile Provider', 'projectlens'); ?></th>
                        <td>
                            <select name="pl_global[map_tiles]">
                                <option value="osm" <?php selected($opts['map_tiles'] ?? 'osm','osm'); ?>><?php esc_html_e('OpenStreetMap (default)','projectlens'); ?></option>
                                <option value="carto_light" <?php selected($opts['map_tiles'] ?? '','carto_light'); ?>><?php esc_html_e('CartoDB Light','projectlens'); ?></option>
                                <option value="carto_dark"  <?php selected($opts['map_tiles'] ?? '','carto_dark');  ?>><?php esc_html_e('CartoDB Dark','projectlens'); ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e('Default Map Zoom', 'projectlens'); ?></th>
                        <td><input type="number" name="pl_global[map_zoom]" value="<?php echo esc_attr($opts['map_zoom'] ?? 13); ?>" min="1" max="20" /></td>
                    </tr>
                </table>

                <h2><?php esc_html_e( 'Data &amp; Uninstall', 'projectlens' ); ?></h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php esc_html_e( 'Delete all data on uninstall', 'projectlens' ); ?></th>
                        <td>
                            <label>
                                <input type="checkbox"
                                       name="pl_global[delete_on_uninstall]"
                                       value="1"
                                       <?php checked( $opts['delete_on_uninstall'] ?? 0 ); ?> />
                                <?php esc_html_e( 'Remove all ProjectLens projects, taxonomy terms, and settings when the plugin is deleted', 'projectlens' ); ?>
                            </label>
                            <p class="description" style="color:#b32d2e;font-weight:500;">
                                <?php esc_html_e( '⚠ Warning: this is permanent and cannot be undone. Leave unchecked to preserve your data if you reinstall the plugin later.', 'projectlens' ); ?>
                            </p>
                        </td>
                    </tr>
                </table>

                <?php submit_button(); ?>
            </form>
        </div><!-- /.wrap form -->

        <div class="wrap" style="margin-top:24px;">
            <h2><?php esc_html_e( 'Demo Data', 'projectlens' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Install a fully-populated sample project to preview all segment types and the 70/30 layout without creating content by hand. Safe to remove at any time.', 'projectlens' ); ?></p>

            <?php
            $demo_id   = get_option( PL_Demo_Data::OPTION_KEY );
            $demo_post = $demo_id ? get_post( $demo_id ) : null;
            $base_url  = admin_url( 'admin-post.php' );
            $nonce     = wp_create_nonce( 'pl_demo_action' );
            ?>

            <?php if ( $demo_post ) : ?>
                <p>
                    <strong><?php esc_html_e( 'Demo project is installed:', 'projectlens' ); ?></strong>
                    <a href="<?php echo esc_url( get_permalink( $demo_id ) ); ?>" target="_blank">
                        <?php echo esc_html( get_the_title( $demo_id ) ); ?>
                    </a>
                    &nbsp;|&nbsp;
                    <a href="<?php echo esc_url( get_edit_post_link( $demo_id ) ); ?>">
                        <?php esc_html_e( 'Edit in admin', 'projectlens' ); ?>
                    </a>
                </p>
                <form method="post" action="<?php echo esc_url( $base_url ); ?>" style="display:inline;">
                    <input type="hidden" name="action"   value="pl_remove_demo" />
                    <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
                    <button type="submit" class="button button-secondary"
                            onclick="return confirm('<?php esc_attr_e( 'Remove the demo project and all its data? This cannot be undone.', 'projectlens' ); ?>')">
                        <?php esc_html_e( 'Remove Demo Project', 'projectlens' ); ?>
                    </button>
                </form>
            <?php else : ?>
                <form method="post" action="<?php echo esc_url( $base_url ); ?>" style="display:inline;">
                    <input type="hidden" name="action"   value="pl_install_demo" />
                    <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
                    <button type="submit" class="button button-primary">
                        <?php esc_html_e( '+ Install Demo Project', 'projectlens' ); ?>
                    </button>
                </form>
            <?php endif; ?>
        </div>
        <?php
    }

    public static function sanitize_global( $raw ) {
        return [
            'default_accent'        => sanitize_hex_color( $raw['default_accent'] ?? '#2563eb' ) ?: '#2563eb',
            'default_font_size'     => absint( $raw['default_font_size']     ?? 15 ),
            'default_word_limit'    => absint( $raw['default_word_limit']    ?? 60 ),
            'default_border_radius' => absint( $raw['default_border_radius'] ?? 8  ),
            'per_page'              => absint( $raw['per_page']              ?? 12 ),
            'show_cat_filter'       => ! empty( $raw['show_cat_filter'] ) ? 1 : 0,
            'show_status_filter'    => ! empty( $raw['show_status_filter'] ) ? 1 : 0,
            'map_tiles'             => sanitize_key( $raw['map_tiles'] ?? 'osm' ),
            'map_zoom'              => absint( $raw['map_zoom'] ?? 13 ),
            'delete_on_uninstall'   => ! empty( $raw['delete_on_uninstall'] ) ? 1 : 0,
        ];
    }
}
