<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Post_Type {

    public static function init() {
        add_action( 'init', [ __CLASS__, 'register_cpt' ] );
        add_action( 'init', [ __CLASS__, 'register_taxonomies' ] );
        add_filter( 'post_updated_messages', [ __CLASS__, 'updated_messages' ] );
        add_filter( 'manage_pl_project_posts_columns',       [ __CLASS__, 'admin_columns' ] );
        add_action( 'manage_pl_project_posts_custom_column', [ __CLASS__, 'admin_column_content' ], 10, 2 );
    }

    public static function register_cpt() {
        $labels = [
            'name'               => __( 'Projects',            'projectlens' ),
            'singular_name'      => __( 'Project',             'projectlens' ),
            'add_new'            => __( 'Add New Project',     'projectlens' ),
            'add_new_item'       => __( 'Add New Project',     'projectlens' ),
            'edit_item'          => __( 'Edit Project',        'projectlens' ),
            'new_item'           => __( 'New Project',         'projectlens' ),
            'view_item'          => __( 'View Project',        'projectlens' ),
            'search_items'       => __( 'Search Projects',     'projectlens' ),
            'not_found'          => __( 'No projects found',   'projectlens' ),
            'not_found_in_trash' => __( 'No projects in trash','projectlens' ),
            'menu_name'          => __( 'ProjectLens',         'projectlens' ),
            'all_items'          => __( 'All Projects',        'projectlens' ),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => [ 'slug' => 'project', 'with_front' => false ],
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-portfolio',
            'supports'           => [ 'title', 'thumbnail', 'revisions' ],
            'show_in_rest'       => false, // We use custom meta boxes, not Gutenberg
        ];

        register_post_type( 'pl_project', $args );
    }

    public static function register_taxonomies() {
        // Project Category
        register_taxonomy( 'pl_category', 'pl_project', [
            'label'             => __( 'Project Categories', 'projectlens' ),
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'project-category' ],
        ]);

        // Project Status (Concept, Planning, Active, Completed, Certified)
        register_taxonomy( 'pl_status', 'pl_project', [
            'label'             => __( 'Project Status', 'projectlens' ),
            'hierarchical'      => false,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'project-status' ],
        ]);

        // Project Tags
        register_taxonomy( 'pl_tag', 'pl_project', [
            'label'        => __( 'Project Tags', 'projectlens' ),
            'hierarchical' => false,
            'show_ui'      => true,
            'rewrite'      => [ 'slug' => 'project-tag' ],
        ]);
    }

    public static function admin_columns( $columns ) {
        $new = [];
        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( $key === 'title' ) {
                $new['pl_project_code'] = __( 'Code',   'projectlens' );
                $new['pl_funder']       = __( 'Funder', 'projectlens' );
                $new['pl_budget']       = __( 'Budget', 'projectlens' );
            }
        }
        return $new;
    }

    public static function admin_column_content( $column, $post_id ) {
        $meta = get_post_meta( $post_id, '_pl_project_settings', true ) ?: [];
        switch ( $column ) {
            case 'pl_project_code':
                echo esc_html( $meta['project_code'] ?? '—' );
                break;
            case 'pl_funder':
                echo esc_html( $meta['funder_name'] ?? '—' );
                break;
            case 'pl_budget':
                $currency = $meta['budget_currency'] ?? 'USD';
                $amount   = $meta['budget_total']    ?? '';
                echo $amount ? esc_html( $currency . ' ' . number_format( (float) $amount ) ) : '—';
                break;
        }
    }

    public static function updated_messages( $messages ) {
        global $post;
        $messages['pl_project'] = [
            0  => '',
            1  => __( 'Project updated.', 'projectlens' ),
            2  => __( 'Custom field updated.', 'projectlens' ),
            3  => __( 'Custom field deleted.', 'projectlens' ),
            4  => __( 'Project updated.', 'projectlens' ),
            /* translators: %s: date and time of the revision */
            5  => isset( $_GET['revision'] ) ? sprintf( __( 'Project restored to revision from %s.', 'projectlens' ), wp_post_revision_title( (int) sanitize_text_field( wp_unslash( $_GET['revision'] ) ), false ) ) : false, // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- standard WP post_updated_messages pattern; revision ID is cast to int and used only for display
            6  => __( 'Project published.', 'projectlens' ),
            7  => __( 'Project saved.', 'projectlens' ),
            8  => __( 'Project submitted.', 'projectlens' ),
            9  => __( 'Project scheduled.', 'projectlens' ),
            10 => __( 'Project draft updated.', 'projectlens' ),
        ];
        return $messages;
    }
}
