<?php
/**
 * ProjectLens — Demo Data
 *
 * Installs a single fully-populated sample project so developers and
 * evaluators can see every segment type rendered immediately after
 * activation, without having to build content by hand.
 *
 * Triggered via the "Install Demo Data" button on the Global Settings page.
 * Safe to run multiple times — checks for an existing demo post first.
 *
 * @package ProjectLens
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Demo_Data {

    /** Option key that stores the demo post ID so we can find / remove it. */
    const OPTION_KEY = 'pl_demo_post_id';

    public static function init() {
        add_action( 'admin_post_pl_install_demo', [ __CLASS__, 'handle_install' ] );
        add_action( 'admin_post_pl_remove_demo',  [ __CLASS__, 'handle_remove'  ] );
    }

    // ── Install ──────────────────────────────────────────────────────────────

    public static function handle_install() {
        check_admin_referer( 'pl_demo_action' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );

        // Don't create duplicates
        $existing = get_option( self::OPTION_KEY );
        if ( $existing && get_post( $existing ) ) {
            wp_safe_redirect( add_query_arg(
                [ 'page' => 'projectlens-settings', 'pl_notice' => 'demo_exists' ],
                admin_url( 'edit.php?post_type=pl_project' )
            ) );
            exit;
        }

        $post_id = self::create_demo_post();

        if ( is_wp_error( $post_id ) ) {
            wp_safe_redirect( add_query_arg(
                [ 'page' => 'projectlens-settings', 'pl_notice' => 'demo_error' ],
                admin_url( 'edit.php?post_type=pl_project' )
            ) );
            exit;
        }

        update_option( self::OPTION_KEY, $post_id );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'projectlens-settings', 'pl_notice' => 'demo_installed' ],
            admin_url( 'edit.php?post_type=pl_project' )
        ) );
        exit;
    }

    // ── Remove ───────────────────────────────────────────────────────────────

    public static function handle_remove() {
        check_admin_referer( 'pl_demo_action' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );

        $post_id = get_option( self::OPTION_KEY );
        if ( $post_id && get_post( $post_id ) ) {
            wp_delete_post( (int) $post_id, true );
        }
        delete_option( self::OPTION_KEY );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'projectlens-settings', 'pl_notice' => 'demo_removed' ],
            admin_url( 'edit.php?post_type=pl_project' )
        ) );
        exit;
    }

    // ── Build the demo post ──────────────────────────────────────────────────

    private static function create_demo_post() {

        // ── Post ──────────────────────────────────────────────────────────
        $post_id = wp_insert_post( [
            'post_type'   => 'pl_project',
            'post_title'  => 'Brahmaputra Basin Integrated Water Resource Management Programme',
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        ], true );

        if ( is_wp_error( $post_id ) ) return $post_id;

        // ── Taxonomy terms ─────────────────────────────────────────────
        wp_set_object_terms( $post_id, 'Environmental Management', 'pl_category', false );
        wp_set_object_terms( $post_id, 'Active / Ongoing',         'pl_status',   false );
        wp_set_object_terms( $post_id, [ 'Water', 'Climate', 'Northeast India', 'ADB' ], 'pl_tag', false );

        // ── Project settings meta ──────────────────────────────────────
        update_post_meta( $post_id, '_pl_project_settings', [
            'project_code'         => 'BBIWRMP-2024-NE',
            'project_status'       => 'active',
            'short_description'    => 'A multi-phase programme to strengthen flood forecasting, riparian ecosystem restoration, and community-based water governance across the Brahmaputra basin in Assam and Arunachal Pradesh.',
            'location'             => 'Assam & Arunachal Pradesh, Northeast India',
            'country'              => 'India',
            'website'              => 'https://example.com/bbiwrmp',
            'start_date'           => '2022-04-01',
            'end_date'             => '2027-03-31',
            'completion_date'      => '',
            'reporting_period'     => 'Annual — FY 2024-25',
            'funder_name'          => 'Asian Development Bank (ADB)',
            'implementing_agency'  => 'Ministry of Jal Shakti, Government of India',
            'executing_agency'     => 'Brahmaputra Board',
            'grant_number'         => 'ADB-GRANT-0782-IND',
            'budget_currency'      => 'USD',
            'budget_total'         => 48500000,
            'grant_amount'         => 36000000,
            'cofinancing'          => 12500000,
            'disbursement'         => 17200000,
            'word_limit'           => 55,
            'show_header'          => 1,
            'default_detail'       => 'metadata',
        ] );

        // ── Styling meta ───────────────────────────────────────────────
        update_post_meta( $post_id, '_pl_styling', [
            'accent_color'      => '#0e7490',   // teal — water theme
            'heading_color'     => '#0c4a6e',
            'body_color'        => '#334155',
            'bg_color'          => '#f0f9ff',
            'panel_bg'          => '#ffffff',
            'border_color'      => '#bae6fd',
            'border_radius'     => 8,
            'font_size_base'    => 15,
            'font_size_heading' => 22,
            'btn_style'         => 'filled',
            'font_family'       => 'system',
        ] );

        // ── Segments ───────────────────────────────────────────────────
        $segments = [

            // ── 1. Descriptive — Programme Overview ─────────────────
            [
                'id'             => 'seg_demo_desc_1',
                'type'           => 'descriptive',
                'title'          => 'Programme Overview',
                'enabled'        => true,
                'subtitle'       => 'A five-year integrated programme across two states',
                'content'        => '<p>The Brahmaputra Basin Integrated Water Resource Management Programme (BBIWRMP) is a five-year initiative funded by the Asian Development Bank in partnership with the Government of India. The programme addresses the compounding challenges of seasonal flooding, river bank erosion, groundwater depletion, and the degradation of floodplain wetlands (beels) across the Brahmaputra valley.</p><p>Working in 14 districts of Assam and 6 districts of Arunachal Pradesh, the programme adopts a whole-of-basin approach that integrates structural flood-protection works with community-based natural resource management, real-time hydrological monitoring, and institutional capacity building at district and panchayat level.</p>',
                'detail_content' => '<h3>Background and Rationale</h3><p>The Brahmaputra is among the world\'s most dynamic and hazard-prone river systems, carrying one of the highest sediment loads globally. Annual flooding affects an average of 2.2 million hectares in Assam alone, displacing hundreds of thousands of people and destroying standing crops. Climate projections indicate that peak discharge events will become more frequent and more intense over the programme period.</p><p>Previous interventions have focused narrowly on embankments and drainage channels without addressing the upstream drivers of erosion or the downstream loss of wetland buffers. BBIWRMP takes a departure from this legacy approach by combining grey infrastructure upgrades with green-grey solutions — restoring riparian vegetation corridors, rehabilitating oxbow wetlands as natural retention zones, and supporting community-led river monitoring networks.</p><h3>Geographical Scope</h3><ul><li><strong>Assam:</strong> Dhemaji, Lakhimpur, Biswanath, Sonitpur, Darrang, Barpeta, Bongaigaon, Goalpara, South Salmara-Mankachar, Dhubri, Sivasagar, Jorhat, Majuli, and Kamrup (Rural)</li><li><strong>Arunachal Pradesh:</strong> West Siang, East Siang, Lower Siang, Lohit, Dibang Valley, and Namsai</li></ul><h3>Alignment with National Frameworks</h3><p>The programme is aligned with the National Water Policy 2012 (revised), the Jal Jeevan Mission, India\'s Nationally Determined Contributions under the Paris Agreement, and the Sendai Framework for Disaster Risk Reduction 2015-2030.</p>',
            ],

            // ── 2. Descriptive — Programme Objectives ───────────────
            [
                'id'             => 'seg_demo_desc_2',
                'type'           => 'descriptive',
                'title'          => 'Programme Objectives & Expected Outcomes',
                'enabled'        => true,
                'subtitle'       => 'Four outcome areas guiding implementation',
                'content'        => '<p>BBIWRMP is structured around four inter-linked outcome areas: (1) improved flood forecasting and early warning; (2) rehabilitated riparian ecosystems covering 18,000 hectares; (3) strengthened community water governance in 420 villages; and (4) enhanced institutional capacity of the Brahmaputra Board and state water departments.</p><p>By programme end, at least 1.8 million people in flood-vulnerable households are expected to benefit from improved early warning systems, and 320 community-based water user groups are projected to be formally registered and functional.</p>',
                'detail_content' => '<h3>Outcome 1 — Flood Forecasting and Early Warning</h3><p>Installation of 68 new automatic weather stations and 112 river-level gauges integrated into the existing Brahmaputra Board telemetry network. Development of a basin-scale hydrodynamic model with 6-hourly forecast capability and a lead time of 72 hours. Community alert dissemination via SMS, local FM radio, and village-level sirens in 180 gram panchayats.</p><h3>Outcome 2 — Riparian Ecosystem Rehabilitation</h3><p>Restoration of 18,000 hectares of degraded riparian land through native-species planting (Arjun, Hijal, Bhomora, Alder), assisted natural regeneration, and beel (wetland) rehabilitation in 34 identified sites. A payment-for-ecosystem-services pilot covering 6,200 hectares in Majuli and Dhubri districts.</p><h3>Outcome 3 — Community Water Governance</h3><p>Formation and capacity building of 320 Village Water and Sanitation Committees (VWSCs) with legal recognition under the Assam Panchayati Raj Act. Training of 2,400 community water monitors (at least 50% women) in basic hydrological observation, data collection, and first-response protocols.</p><h3>Outcome 4 — Institutional Capacity</h3><p>Upgrading of the Brahmaputra Board\'s data management infrastructure, including a new Flood Information Portal accessible to state and district disaster management authorities. Training of 380 government engineers and planners in integrated water resource management, climate adaptation planning, and green-grey infrastructure design.</p><h3>Key Performance Indicators</h3><table><thead><tr><th>Indicator</th><th>Baseline</th><th>Target (2027)</th></tr></thead><tbody><tr><td>Flood forecast lead time</td><td>24 hours</td><td>72 hours</td></tr><tr><td>Riparian land restored (ha)</td><td>0</td><td>18,000</td></tr><tr><td>Functional VWSCs</td><td>12</td><td>320</td></tr><tr><td>People with improved early warning</td><td>210,000</td><td>1,800,000</td></tr><tr><td>Women in governance roles</td><td>18%</td><td>50%</td></tr></tbody></table>',
            ],

            // ── 3. Descriptive — Environmental Safeguards ────────────
            [
                'id'             => 'seg_demo_desc_3',
                'type'           => 'descriptive',
                'title'          => 'Environmental & Social Safeguards',
                'enabled'        => true,
                'subtitle'       => 'ADB SPS 2009 — Category B environment, Category B involuntary resettlement',
                'content'        => '<p>The programme has been classified as Category B for both environment and involuntary resettlement under the ADB Safeguard Policy Statement 2009. An Initial Environmental Examination and a Resettlement Framework have been prepared and disclosed publicly. No physical displacement of households is anticipated; land requirements are limited to temporary use of marginal riverbank areas for construction access.</p><p>Indigenous Peoples are present in parts of the programme area in Arunachal Pradesh. An Indigenous Peoples Plan has been prepared in consultation with affected communities and is being implemented under the supervision of the programme\'s Social Development Specialist.</p>',
                'detail_content' => '<h3>Environmental Safeguards</h3><p>The Initial Environmental Examination (IEE) was conducted between October 2021 and February 2022 and covers all programme components. Key environmental risks identified include: temporary turbidity of watercourses during civil works; disturbance to aquatic habitats near embankment construction sites; risk of invasive species introduction during revegetation if non-native plant material is used; and cumulative impacts on the Kaziranga-Karbi Anglong Wildlife Corridor.</p><p>Mitigation measures incorporated into the Environmental Management Plan (EMP) include: silt fencing and sediment traps during all in-water works; a verified native-species nursery network for revegetation stock; a wildlife corridor sensitivity map shared with all civil works contractors; and quarterly environmental compliance monitoring by an independent environmental officer.</p><h3>Social Safeguards and Gender</h3><p>A Gender Action Plan (GAP) sets binding targets for women\'s participation: 50% of VWSC leadership positions, 40% of programme employment (construction and nursery operations), and 100% of community training sessions designed to accommodate women\'s attendance constraints. Progress against the GAP is reported semi-annually to ADB.</p><h3>Grievance Redress Mechanism</h3><p>A two-tier Grievance Redress Mechanism (GRM) is operational at village level (VWSC-based) and district level (District Project Implementation Unit). A toll-free hotline and a dedicated email address are available to affected persons. All grievances are logged, tracked, and reported quarterly. As of the latest reporting period, 23 grievances have been received, 21 resolved, and 2 under active review.</p>',
            ],

            // ── 4. Media Slider ──────────────────────────────────────
            [
                'id'      => 'seg_demo_media',
                'type'    => 'media',
                'title'   => 'Field Photography — Sites and Communities',
                'enabled' => true,
                'slides'  => [
                    [
                        'media_id'    => 0,
                        'media_type'  => 'image',
                        'video_url'   => '',
                        'caption'     => 'Brahmaputra River at Tezpur Ghat',
                        'description' => 'The main channel at Tezpur during the 2023 pre-monsoon survey. Channel width at this cross-section is approximately 4.2 km. The sandbar visible in the mid-channel has shifted 380 m westward since 2018, illustrating the high lateral mobility characteristic of the river system.',
                        'geo_lat'     => '26.6340',
                        'geo_lng'     => '92.7936',
                        'geo_label'   => 'Tezpur Ghat, Sonitpur District, Assam',
                    ],
                    [
                        'media_id'    => 0,
                        'media_type'  => 'image',
                        'video_url'   => '',
                        'caption'     => 'Beel Rehabilitation — Sone Beel, Karimganj',
                        'description' => 'Sone Beel is one of the largest seasonal wetlands in Northeast India. Under Output 2.3 of the programme, a 340-hectare block is being rehabilitated through removal of invasive water hyacinth, restoration of inlet channels, and planting of native floating macrophytes. This image shows the cleared zone after the first phase of manual removal (March 2024).',
                        'geo_lat'     => '24.6617',
                        'geo_lng'     => '92.3875',
                        'geo_label'   => 'Sone Beel, Karimganj District, Assam',
                    ],
                    [
                        'media_id'    => 0,
                        'media_type'  => 'image',
                        'video_url'   => '',
                        'caption'     => 'Automatic Weather Station Installation — Pasighat',
                        'description' => 'One of 68 new automatic weather stations being commissioned under the Flood Forecasting component. This unit, at Pasighat in East Siang district, measures air temperature, humidity, wind speed and direction, rainfall, and solar radiation at 15-minute intervals, transmitting data via GPRS to the Brahmaputra Board data centre in Guwahati.',
                        'geo_lat'     => '28.0663',
                        'geo_lng'     => '95.3367',
                        'geo_label'   => 'Pasighat, East Siang District, Arunachal Pradesh',
                    ],
                    [
                        'media_id'    => 0,
                        'media_type'  => 'image',
                        'video_url'   => '',
                        'caption'     => 'VWSC Training Session — Majuli Island',
                        'description' => 'Village Water and Sanitation Committee training session at Kamalabari, Majuli. Participants (62% women in this cohort) are being trained in basic river observation, use of the programme\'s mobile alert app, and community-level flood preparedness protocols. Majuli, the world\'s largest river island, is a priority area due to its acute vulnerability to erosion and flooding.',
                        'geo_lat'     => '26.9476',
                        'geo_lng'     => '94.1682',
                        'geo_label'   => 'Kamalabari, Majuli District, Assam',
                    ],
                    [
                        'media_id'    => 0,
                        'media_type'  => 'video_url',
                        'video_url'   => 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                        'caption'     => 'Programme Overview — Documentary Short (5 min)',
                        'description' => 'A five-minute documentary produced by the programme communications team during the 2024 mid-term field visit. Features community voices from Dhemaji, Majuli, and Pasighat, and includes drone footage of the Brahmaputra channel and beel rehabilitation sites.',
                        'geo_lat'     => '27.4728',
                        'geo_lng'     => '94.9120',
                        'geo_label'   => 'Dhemaji District, Assam',
                    ],
                ],
            ],

            // ── 5. Team & Stakeholders ───────────────────────────────
            [
                'id'      => 'seg_demo_team',
                'type'    => 'team',
                'title'   => 'Programme Team & Key Stakeholders',
                'enabled' => true,
                'members' => [
                    [
                        'avatar_id' => 0,
                        'name'      => 'Dr Priyanka Borah',
                        'role'      => 'Programme Director, Brahmaputra Board',
                        'email'     => 'p.borah@brahmaputraboard.gov.in',
                        'bio'       => 'Dr Borah is a senior hydraulic engineer with 22 years of experience in fluvial geomorphology and integrated flood management in the Brahmaputra basin. She holds a PhD from IIT Guwahati and has led three previous ADB-funded programmes in Northeast India. She provides overall strategic direction and is the primary interface with the Ministry of Jal Shakti.',
                    ],
                    [
                        'avatar_id' => 0,
                        'name'      => 'Rajan Phukan',
                        'role'      => 'Deputy Programme Manager — Infrastructure',
                        'email'     => 'r.phukan@brahmaputraboard.gov.in',
                        'bio'       => 'Rajan is a civil engineer specialising in river training works and embankment design. He oversees all Component 1 civil works contracts, manages relations with the eight civil works contractors currently active in Assam, and chairs the monthly Site Supervision Committee. He has 16 years of experience with the Brahmaputra Board.',
                    ],
                    [
                        'avatar_id' => 0,
                        'name'      => 'Meghali Konwar',
                        'role'      => 'Social Development & Gender Specialist',
                        'email'     => 'm.konwar@ingo-partner.org',
                        'bio'       => 'Meghali is seconded to the Programme Management Unit from a national NGO partner. She is responsible for implementing the Gender Action Plan, overseeing community consultation processes, managing the Grievance Redress Mechanism, and coordinating with the 14 district-level social mobilisation teams. She is fluent in Assamese, Bodo, and Hindi.',
                    ],
                    [
                        'avatar_id' => 0,
                        'name'      => 'Tarun Gogoi',
                        'role'      => 'Hydrology & Early Warning Lead',
                        'email'     => 't.gogoi@brahmaputraboard.gov.in',
                        'bio'       => 'Tarun leads the hydrological modelling team and is responsible for commissioning the 68-station automatic weather network and integrating it with the existing telemetry infrastructure. He manages the contract with the hydrodynamic modelling consultancy and coordinates with the India Meteorological Department and the Central Water Commission on forecasting protocols.',
                    ],
                    [
                        'avatar_id' => 0,
                        'name'      => 'Arundhati Devi',
                        'role'      => 'Ecosystem Restoration Coordinator',
                        'email'     => 'a.devi@forestdept.assam.gov.in',
                        'bio'       => 'Arundhati is deputed from the Assam Forest Department and coordinates the riparian revegetation and beel rehabilitation activities under Output 2. She manages relationships with the 14 district forest divisions involved in the programme, oversees the native-species nursery network (currently 6 operational nurseries with a combined capacity of 2.4 million seedlings per year), and supervises the Payment for Ecosystem Services pilot.',
                    ],
                    [
                        'avatar_id' => 0,
                        'name'      => 'Sanjay Krishnamurthy',
                        'role'      => 'ADB Project Officer (Water)',
                        'email'     => 's.krishnamurthy@adb.org',
                        'bio'       => 'Sanjay is the designated Project Officer at the ADB India Resident Mission and is responsible for supervision, compliance monitoring, and disbursement processing on behalf of the Bank. He conducts bi-annual review missions and chairs the Joint Programme Review Committee. He has 14 years of experience in ADB\'s South Asia Department.',
                    ],
                ],
            ],

            // ── 6. Timeline & Milestones ─────────────────────────────
            [
                'id'         => 'seg_demo_timeline',
                'type'       => 'timeline',
                'title'      => 'Programme Timeline & Milestones',
                'enabled'    => true,
                'milestones' => [
                    [
                        'title'       => 'Loan Negotiations Completed',
                        'date'        => '2021-11-18',
                        'status'      => 'completed',
                        'description' => 'Loan and grant agreements between the Government of India and ADB signed in New Delhi. Total financing envelope confirmed at USD 48.5 million (USD 36 million ADB loan, USD 12.5 million Government of India co-financing).',
                    ],
                    [
                        'title'       => 'Programme Management Unit Established',
                        'date'        => '2022-04-01',
                        'status'      => 'completed',
                        'description' => 'PMU formally constituted within the Brahmaputra Board in Guwahati. Key staff recruited, offices fitted out, and programme financial management system configured. Inception workshop held on 14–15 April 2022 with 180 participants from state departments, district administrations, NGO partners, and ADB.',
                    ],
                    [
                        'title'       => 'Baseline Survey Completed',
                        'date'        => '2022-10-31',
                        'status'      => 'completed',
                        'description' => 'Household baseline survey covering 4,200 households in 140 programme villages across 14 Assam districts completed by the contracted survey firm. Biophysical baseline assessments (riparian vegetation, beel hydrology, channel morphology) finalised for all 34 target wetland sites.',
                    ],
                    [
                        'title'       => 'First Civil Works Contracts Awarded',
                        'date'        => '2023-03-15',
                        'status'      => 'completed',
                        'description' => 'Four civil works contracts for embankment upgrading and anti-erosion revetments in Dhemaji, Lakhimpur, Barpeta, and Goalpara districts awarded following international competitive bidding. Combined contract value: USD 14.2 million. Mobilisation of contractors commenced April 2023.',
                    ],
                    [
                        'title'       => 'Automatic Weather Station Network — Phase 1 Live',
                        'date'        => '2023-08-01',
                        'status'      => 'completed',
                        'description' => '34 of 68 automatic weather stations commissioned and transmitting real-time data to the Brahmaputra Board data centre. Phase 1 covers the upper basin (Arunachal Pradesh) and upper Assam reaches. Integration with the India Meteorological Department\'s national network completed. First operational 48-hour flood forecast issued 22 August 2023.',
                    ],
                    [
                        'title'       => 'Mid-Term Review Mission',
                        'date'        => '2024-09-30',
                        'status'      => 'completed',
                        'description' => 'ADB-led mid-term review mission conducted 23 September – 4 October 2024. Mission rated overall programme implementation as Satisfactory. Key recommendations: accelerate VWSC formation in lagging districts; revise nursery procurement schedule to ensure adequate seedling supply for the 2025 planting season; strengthen monitoring and evaluation data flows from district to PMU.',
                    ],
                    [
                        'title'       => 'Full AWS Network Commissioned',
                        'date'        => '2024-12-31',
                        'status'      => 'completed',
                        'description' => 'All 68 automatic weather stations and 112 river-level gauges operational. Full 72-hour hydrodynamic forecast capability achieved and validated against historical flood events. Real-time data portal accessible to all state and district disaster management authorities.',
                    ],
                    [
                        'title'       => '200 VWSCs Registered and Functional',
                        'date'        => '2025-06-30',
                        'status'      => 'active',
                        'description' => 'Target of 200 Village Water and Sanitation Committees legally registered under the Assam Panchayati Raj Act and completing foundational governance training. Current status: 163 registered, 37 in the registration pipeline. On track for June 2025 milestone.',
                    ],
                    [
                        'title'       => 'Riparian Restoration — 10,000 ha Milestone',
                        'date'        => '2025-11-30',
                        'status'      => 'planned',
                        'description' => 'Cumulative 10,000 hectares of riparian land under active restoration or completed. Milestone requires successful 2025 planting season (monsoon planting window: June–August) achieving at least 70% survival rate for plantings completed in previous seasons.',
                    ],
                    [
                        'title'       => 'Payment for Ecosystem Services Pilot — Evaluation',
                        'date'        => '2026-03-31',
                        'status'      => 'planned',
                        'description' => 'Independent evaluation of the 6,200-hectare PES pilot in Majuli and Dhubri districts. Findings will inform a Government of India decision on whether to scale the PES mechanism to the full programme area under a future phase.',
                    ],
                    [
                        'title'       => 'All 320 VWSCs Functional',
                        'date'        => '2026-09-30',
                        'status'      => 'planned',
                        'description' => 'Full target of 320 registered and functional Village Water and Sanitation Committees achieved, covering all 420 programme villages. At least 50% of VWSC leadership positions held by women.',
                    ],
                    [
                        'title'       => 'Programme Completion and Final Evaluation',
                        'date'        => '2027-03-31',
                        'status'      => 'planned',
                        'description' => 'Programme completion report submitted to ADB. Independent final evaluation conducted. Handover of all infrastructure assets to Brahmaputra Board and state government. Project Completion Report approved and lessons learned documented for future phase design.',
                    ],
                ],
            ],

            // ── 7. Documents & Downloads ─────────────────────────────
            [
                'id'      => 'seg_demo_documents',
                'type'    => 'documents',
                'title'   => 'Programme Documents & Downloads',
                'enabled' => true,
                'files'   => [
                    [
                        'file_id'     => 0,
                        'label'       => 'Programme Framework Document (PFD)',
                        'description' => 'The foundational planning document covering programme rationale, theory of change, results framework, implementation arrangements, and financing plan. Approved by ADB Board, November 2021. PDF, 148 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Initial Environmental Examination (IEE)',
                        'description' => 'ADB-required environmental assessment covering all programme components. Includes baseline ecological surveys, impact prediction, Environmental Management Plan, and monitoring protocols. Disclosed publicly per ADB Access to Information Policy. PDF, 312 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Resettlement Framework & Indigenous Peoples Plan',
                        'description' => 'Combined safeguards document covering involuntary resettlement risk management and the Indigenous Peoples Plan for affected communities in Arunachal Pradesh. Prepared in compliance with ADB SPS 2009. PDF, 94 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Annual Progress Report — FY 2023-24',
                        'description' => 'Comprehensive annual progress report covering physical and financial progress against all programme outputs, safeguard compliance status, Gender Action Plan progress, and issues/risks log for FY 2023-24. Submitted to ADB June 2024. PDF, 76 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Mid-Term Review Mission Aide-Mémoire',
                        'description' => 'Official record of findings, ratings, and agreed actions from the ADB mid-term review mission (September–October 2024). Includes an updated implementation schedule and revised disbursement projections. PDF, 38 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Flood Forecasting System — Technical Specifications',
                        'description' => 'Technical specifications and calibration report for the 68-station automatic weather network and the Brahmaputra basin hydrodynamic model. Prepared by the modelling consultancy (DHI) and reviewed by the Central Water Commission. PDF, 210 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Gender Action Plan (GAP) — Progress Report Q3 FY2024-25',
                        'description' => 'Quarterly progress update against all Gender Action Plan indicators. Reports on VWSC gender composition, programme employment statistics, and training participation disaggregated by sex. Excel workbook with supporting narrative. XLSX, 24 pages.',
                    ],
                    [
                        'file_id'     => 0,
                        'label'       => 'Community Training Manual — Water Monitor Handbook',
                        'description' => 'Field-ready handbook for community water monitors trained under Output 3. Covers basic river observation protocols, the mobile alert app, first-response checklists, and contacts. Produced in English, Assamese, and Bodo. PDF, 56 pages.',
                    ],
                ],
            ],

        ]; // end $segments

        update_post_meta( $post_id, '_pl_segments', $segments );

        return $post_id;
    }
}
