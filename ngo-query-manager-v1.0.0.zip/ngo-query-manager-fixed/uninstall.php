<?php
/**
 * NGO Query Manager – Uninstall
 *
 * Fired when the plugin is deleted from the WordPress admin (Plugins → Delete).
 * NOT triggered by deactivation.
 *
 * Removes:
 *   • All four custom database tables
 *   • Every wp_options entry created by the plugin
 *   • Media-library attachments that were uploaded as video recordings
 *     (attachment post + physical files on disk)
 *   • The transient used for quota caching (if any future version adds one)
 *   • Flushed rewrite rules so the nqm-query endpoint is gone
 *
 * @package NGO_Query_Manager
 * @since   1.0.0
 */

// WordPress safety check – abort if called directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

/*
 * Respect the admin setting: only delete data if the checkbox was ticked.
 * Default is 1 (delete) to preserve original behaviour on fresh installs.
 */
$nqm_delete_data = (int) get_option( 'nqm_delete_data_on_uninstall', 1 );

if ( ! $nqm_delete_data ) {
    // Admin chose to keep the data — skip everything except the option cleanup.
    // Flush rewrite rules so the front-end endpoints are removed.
    flush_rewrite_rules();
    exit;
}

global $wpdb;

/* ═══════════════════════════════════════════════════════════════════════
 * 1. REMOVE CUSTOM TABLES
 * ═══════════════════════════════════════════════════════════════════════ */

$tables = [
    $wpdb->prefix . 'nqm_feedback',      // Must drop before nqm_queries (references it logically)
    $wpdb->prefix . 'nqm_responses',     // Same – references nqm_queries
    $wpdb->prefix . 'nqm_video_ledger',  // References nqm_queries
    $wpdb->prefix . 'nqm_queries',       // Parent table – last
];

foreach ( $tables as $table ) {
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
    $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
}

/* ═══════════════════════════════════════════════════════════════════════
 * 2. DELETE wp_options ENTRIES
 * ═══════════════════════════════════════════════════════════════════════ */

$options = [
    // General settings
    'nqm_admin_email_notify',
    'nqm_from_email',
    'nqm_from_name',
    'nqm_query_sources',
    'nqm_respondent_roles',

    // Video settings
    'nqm_video_max_duration',
    'nqm_video_global_allocation',

    // Transients (future-proofing)
    '_transient_nqm_video_quota',
    '_transient_timeout_nqm_video_quota',
    '_site_transient_nqm_video_quota',
    '_site_transient_timeout_nqm_video_quota',
];

foreach ( $options as $option ) {
    delete_option( $option );
    // Also remove from site options in case the plugin was ever network-activated
    delete_site_option( $option );
}

/* ═══════════════════════════════════════════════════════════════════════
 * 3. REMOVE VIDEO ATTACHMENTS FROM THE MEDIA LIBRARY
 *
 * Query video recordings were uploaded to the WP media library with
 * no parent post (post_parent = 0) and have the MIME type video/*.
 * We identify them via the _nqm_video meta key that should be stamped
 * on upload (or fall back to MIME type + source pattern).
 *
 * This step is intentionally conservative:
 *   – Only deletes attachments explicitly tagged as NQM uploads.
 *   – Falls back to a MIME + meta scan if the tag is not present
 *     (covers recordings made before the meta was added).
 *
 * If the site admin wants to keep the video files they should export
 * them before uninstalling. The README documents this.
 * ═══════════════════════════════════════════════════════════════════════ */

// Collect attachment IDs tagged with our meta key.
$tagged_ids = get_posts( [
    'post_type'      => 'attachment',
    'post_status'    => 'any',
    'posts_per_page' => -1,
    'fields'         => 'ids',
    'meta_query'     => [
        [
            'key'     => '_nqm_video',
            'compare' => 'EXISTS',
        ],
    ],
] );

// Also collect any attachment IDs that were stored in the queries table
// before we dropped it – we already dropped the table, so instead we
// query the media library for video/* items whose source URL includes
// our known upload sub-path pattern (best-effort only).
//
// Safer approach: we store video attachment IDs in a transient during
// deactivation for use here. If that transient exists, use it.
$stored_video_ids = get_option( '_nqm_video_attachment_ids', [] );
delete_option( '_nqm_video_attachment_ids' );

$attachment_ids = array_unique(
    array_merge(
        is_array( $tagged_ids )      ? $tagged_ids      : [],
        is_array( $stored_video_ids ) ? $stored_video_ids : []
    )
);

foreach ( $attachment_ids as $att_id ) {
    $att_id = (int) $att_id;
    if ( $att_id > 0 ) {
        // wp_delete_attachment( $id, true ) removes the DB row AND the
        // physical files (full size + all generated thumbnails/sizes).
        wp_delete_attachment( $att_id, true );
    }
}

/* ═══════════════════════════════════════════════════════════════════════
 * 4. MULTISITE: REPEAT FOR EVERY BLOG IN THE NETWORK
 *    (only runs if this is a network-active plugin)
 * ═══════════════════════════════════════════════════════════════════════ */

if ( is_multisite() ) {
    $blog_ids = $wpdb->get_col( "SELECT blog_id FROM {$wpdb->blogs}" ); // phpcs:ignore

    foreach ( $blog_ids as $blog_id ) {
        switch_to_blog( (int) $blog_id );

        // Repeat options cleanup per blog
        foreach ( $options as $option ) {
            delete_option( $option );
        }

        // Repeat table drops per blog (each site has its own prefix)
        $site_tables = [
            $wpdb->prefix . 'nqm_feedback',
            $wpdb->prefix . 'nqm_responses',
            $wpdb->prefix . 'nqm_video_ledger',
            $wpdb->prefix . 'nqm_queries',
        ];
        foreach ( $site_tables as $table ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.SchemaChange,WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query( "DROP TABLE IF EXISTS `{$table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }

        // Repeat video attachment cleanup per blog
        $site_tagged = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => [
                [
                    'key'     => '_nqm_video',
                    'compare' => 'EXISTS',
                ],
            ],
        ] );
        $site_stored = get_option( '_nqm_video_attachment_ids', [] );
        delete_option( '_nqm_video_attachment_ids' );

        $site_att_ids = array_unique(
            array_merge(
                is_array( $site_tagged ) ? $site_tagged : [],
                is_array( $site_stored ) ? $site_stored : []
            )
        );
        foreach ( $site_att_ids as $att_id ) {
            $att_id = (int) $att_id;
            if ( $att_id > 0 ) {
                wp_delete_attachment( $att_id, true );
            }
        }

        restore_current_blog();
    }
}

/* ═══════════════════════════════════════════════════════════════════════
 * 5. FLUSH REWRITE RULES
 *    The nqm-query endpoint was added in NQM_Post_Types::register_rewrite().
 *    Flushing removes it from the stored rewrite-rules option.
 * ═══════════════════════════════════════════════════════════════════════ */

flush_rewrite_rules();
