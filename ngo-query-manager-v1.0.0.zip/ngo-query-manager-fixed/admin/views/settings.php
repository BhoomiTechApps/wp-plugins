<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap nqm-admin">
    <h1><?php esc_html_e('NGO Query Manager – Settings','ngo-query-manager'); ?></h1>
    <?php if ( isset($_GET['saved']) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('Settings saved.','ngo-query-manager'); ?></p></div><?php endif; ?>

    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <?php wp_nonce_field('nqm_save_settings'); ?>
        <input type="hidden" name="action" value="nqm_save_settings">

        <h2><?php esc_html_e('Email Notifications','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Notify Admin on Submission','ngo-query-manager'); ?></th>
                <td><label><input type="checkbox" name="nqm_admin_email_notify" value="1" <?php checked(1, get_option('nqm_admin_email_notify',1)); ?>> <?php esc_html_e('Send email to site admin when a query is submitted','ngo-query-manager'); ?></label></td>
            </tr>
        <tr>
            <th><?php esc_html_e('Notify Submitter on Response','ngo-query-manager'); ?></th>
            <td><label><input type="checkbox" name="nqm_notify_response_attach" value="1" <?php checked(1, get_option('nqm_notify_response_attach',1)); ?>> <?php esc_html_e('Send email notification to submitter when a response is posted','ngo-query-manager'); ?></label></td>
        </tr>
        <tr>
            <th><?php esc_html_e('Response Attachments via Email','ngo-query-manager'); ?></th>
            <td>
                <p class="description"><?php esc_html_e('When submitter email notifications are enabled, any files attached to a response will be sent as email attachments. When notifications are disabled, files are uploaded to the Media Library and a download link is included in the response.','ngo-query-manager'); ?></p>
            </td>
        </tr>
            <tr>
                <th><label for="nqm_from_name"><?php esc_html_e('From Name','ngo-query-manager'); ?></label></th>
                <td><input type="text" id="nqm_from_name" name="nqm_from_name" class="regular-text" value="<?php echo esc_attr(get_option('nqm_from_name', get_bloginfo('name'))); ?>"></td>
            </tr>
            <tr>
                <th><label for="nqm_from_email"><?php esc_html_e('From Email','ngo-query-manager'); ?></label></th>
                <td><input type="email" id="nqm_from_email" name="nqm_from_email" class="regular-text" value="<?php echo esc_attr(get_option('nqm_from_email', get_option('admin_email'))); ?>"></td>
            </tr>
        </table>

        <h2><?php esc_html_e('Video Recording','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_video_max_duration"><?php esc_html_e('Max Recording Duration (seconds)','ngo-query-manager'); ?></label></th>
                <td><input type="number" id="nqm_video_max_duration" name="nqm_video_max_duration" min="10" max="600" value="<?php echo (int)get_option('nqm_video_max_duration',60); ?>">
                <p class="description"><?php esc_html_e('Default clip length limit per submission.','ngo-query-manager'); ?></p></td>
            </tr>
            <tr>
                <th><label for="nqm_video_global_allocation"><?php esc_html_e('Global Video Bank (seconds)','ngo-query-manager'); ?></label></th>
                <td><input type="number" id="nqm_video_global_allocation" name="nqm_video_global_allocation" min="60" value="<?php echo (int)get_option('nqm_video_global_allocation',3600); ?>">
                <p class="description"><?php printf( esc_html__('Total seconds available. Currently used: %d s, Available: %d s','ngo-query-manager'), NQM_Database::get_used_seconds(), NQM_Database::get_available_seconds() ); ?></p></td>
            </tr>
        </table>

        <h2><?php esc_html_e('Query Sources','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_query_sources"><?php esc_html_e('Sources (one per line)','ngo-query-manager'); ?></label></th>
                <td><textarea id="nqm_query_sources" name="nqm_query_sources" rows="6" class="large-text"><?php
                    echo esc_textarea( implode("\n", (array)get_option('nqm_query_sources',[])) );
                ?></textarea>
                <p class="description"><?php esc_html_e('Use underscore for spaces, e.g. project_partner','ngo-query-manager'); ?></p></td>
            </tr>
        </table>

        <h2><?php esc_html_e( 'Page Configuration', 'ngo-query-manager' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_respond_page_id"><?php esc_html_e( 'Respond Page', 'ngo-query-manager' ); ?></label></th>
                <td>
                    <?php
                    wp_dropdown_pages( [
                        'name'              => 'nqm_respond_page_id',
                        'id'                => 'nqm_respond_page_id',
                        'selected'          => (int) get_option( 'nqm_respond_page_id', 0 ),
                        'show_option_none'  => __( '— select a page —', 'ngo-query-manager' ),
                        'option_none_value' => '0',
                    ] );
                    ?>
                    <p class="description"><?php esc_html_e( 'The page containing the [nqm_dorespond] shortcode. Respondents are linked here from their query list.', 'ngo-query-manager' ); ?></p>
                </td>
            </tr>
        </table>

        <h2><?php esc_html_e('Respondent Roles','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Roles that may claim and respond to queries','ngo-query-manager'); ?></th>
                <td>
                <?php
                $saved_roles = (array) get_option('nqm_respondent_roles', []);
                foreach ($all_roles as $slug => $name) :
                    if ($slug === 'administrator') continue;
                ?>
                <label style="display:block; margin-bottom:4px;">
                    <input type="checkbox" name="nqm_respondent_roles[]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug,$saved_roles)); ?>>
                    <?php echo esc_html(translate_user_role($name)); ?>
                </label>
                <?php endforeach; ?>
                </td>
            </tr>
        </table>


        <h2><?php esc_html_e('Uninstall Options','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Delete All Data on Uninstall','ngo-query-manager'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="nqm_delete_data_on_uninstall" value="1" <?php checked(1, get_option('nqm_delete_data_on_uninstall',1)); ?>>
                        <?php esc_html_e('Remove all query data, tables, and settings when the plugin is deleted','ngo-query-manager'); ?>
                    </label>
                    <p class="description" style="color:#b32d2e;"><?php esc_html_e('Warning: if unchecked, your data will be preserved when the plugin is uninstalled, but it will not be automatically cleaned up.','ngo-query-manager'); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button( __('Save Settings','ngo-query-manager') ); ?>
    </form>
</div>
