<?php
/**
 * Horizontal navigation bar shared across all 4 NQM front-end pages.
 * Shown at the top of every shortcode output.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$nqm_nav_pages = [
    'nqm_page_submit' => __( 'SUBMIT',      'ngo-query-manager' ),
    'nqm_page_status' => __( 'CHECK STATUS','ngo-query-manager' ),
    'nqm_page_list'   => __( 'LIST ALL',    'ngo-query-manager' ),
    'nqm_page_respond'=> __( 'RESPOND',     'ngo-query-manager' ),
];

$current_url = ( is_ssl() ? 'https' : 'http' ) . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$current_id  = get_queried_object_id();
?>
<nav class="nqm-top-nav" aria-label="<?php esc_attr_e( 'Query Manager Navigation', 'ngo-query-manager' ); ?>">
    <?php foreach ( $nqm_nav_pages as $option_key => $label ) :
        $pid  = (int) get_option( $option_key, 0 );
        $href = $pid ? get_permalink( $pid ) : '#';
        $active = ( $pid && $pid === $current_id ) ? ' nqm-nav-active' : '';
    ?>
    <a href="<?php echo esc_url( $href ); ?>" class="nqm-nav-link<?php echo esc_attr( $active ); ?>">
        <?php echo esc_html( $label ); ?>
    </a>
    <?php endforeach; ?>
</nav>
