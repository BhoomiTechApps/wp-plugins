/**
 * ICB Frontend Extension – frontend.js
 *
 * Drives the [icb_frontend] shortcode widget.
 * Respects the icbfe_vars.access map injected server-side; all feature
 * branches are gated behind the same flags that PHP used to render (or
 * hide) the corresponding HTML elements, so JS is a second line of
 * enforcement, not the only one.
 *
 * Depends on: jQuery, icbfe-avro-parser (window.ICB_Transliterator)
 */
/* global jQuery, icbfe_vars */
(function ($) {
    'use strict';

    // ── Shorthand helpers ─────────────────────────────────────────────────────
    const access    = icbfe_vars.access    || {};
    const strings   = icbfe_vars.strings   || {};
    const ajaxurl   = icbfe_vars.ajaxurl;
    const nonce     = icbfe_vars.nonce;

    // State
    let unresolvedConflicts  = [];
    let preApprovedSafeWords = [];
    let userResolutionMap    = {};

    // ── Boot: initialise controls from server-provided config/lexicon ─────────

    function boot() {
        if (access.config_view) {
            populateConfigFields();
        }
        if (access.lexicon_view) {
            populateLexiconTables();
        }
    }

    // ── Tab navigation ────────────────────────────────────────────────────────

    $(document).on('click', '.icbfe-tab-btn', function () {
        const tab = $(this).data('tab');
        $('.icbfe-tab-btn').removeClass('icbfe-tab-active').attr('aria-selected', 'false');
        $(this).addClass('icbfe-tab-active').attr('aria-selected', 'true');
        $('.icbfe-tab-pane').removeClass('icbfe-tab-pane--active');
        $('#icbfe-tab-' + tab).addClass('icbfe-tab-pane--active');
    });

    // ── Notice helper ─────────────────────────────────────────────────────────

    function showNotice(type, msg, area) {
        const $area = $(area || '#icbfe-notice-area');
        const $n    = $('<div class="icbfe-notice icbfe-notice-' + type + '">' + msg + '</div>');
        $area.html($n);
        if (type !== 'error') {
            setTimeout(function () { $n.fadeOut(400, function () { $(this).remove(); }); }, 5000);
        }
    }

    // ── 1. Live Transliteration ───────────────────────────────────────────────
    // Gated on access.live_transliterate (typing + native preview).
    // access.workspace_submit is a separate, stricter permission for corpus writes.

    if (access.live_transliterate) {
        $('#icbfe-input-container').on('input propertychange', function () {
            const text = $(this).val();
            if ($('#icbfe-transliterate-toggle').is(':checked') && window.ICB_Transliterator) {
                $('#icbfe-preview-container').val(window.ICB_Transliterator.convert(text));
            } else {
                $('#icbfe-preview-container').val(text);
            }
        });

        $('#icbfe-transliterate-toggle').on('change', function () {
            const raw = $('#icbfe-input-container').val();
            if ($(this).is(':checked') && window.ICB_Transliterator) {
                $('#icbfe-preview-container').val(window.ICB_Transliterator.convert(raw));
            } else {
                $('#icbfe-preview-container').val(raw);
            }
        });
    }

    // Live test bar (workspace tab)
    $('#icbfe-live-test-input').on('input propertychange', function () {
        const out = (window.ICB_Transliterator)
            ? window.ICB_Transliterator.convert($(this).val())
            : $(this).val();
        $('#icbfe-live-test-output').text(out || '—');
    });

    // ── 2. Analyse & Save ────────────────────────────────────────────────────

    $(document).on('click', '#icbfe-process-btn', function () {
        if (!access.workspace_submit) {
            showNotice('error', strings.no_access || 'You do not have permission to submit text.');
            return;
        }

        const textToProcess = $('#icbfe-preview-container').val().trim();
        if (!textToProcess) {
            showNotice('error', 'Please paste or type some text first.');
            return;
        }

        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icbfe-spinner"></span> ' + (strings.processing || 'Processing…'));
        $('#icbfe-notice-area').empty();

        $.post(ajaxurl, {
            action: 'icbfe_process_text',
            text:   textToProcess,
            nonce:  nonce,
        })
        .done(function (response) {
            if (!response.success) {
                showNotice('error', 'Server error: ' + (response.data.message || 'Unknown error.'));
                return;
            }

            const d = response.data;

            if (d.status === 'completed') {
                const msg = (strings.success_saved || 'Saved %d new word(s) to the corpus.').replace('%d', d.inserted);
                showNotice('success', '✔ ' + msg);
                clearWorkspace();

            } else if (d.status === 'completed_partial') {
                showNotice('info', '✔ ' + d.message);
                clearWorkspace();

            } else if (d.status === 'requires_review' && access.conflict_resolution) {
                renderConflictModal(d.conflicts, d.safe_words);
            }
        })
        .fail(function () {
            showNotice('error', strings.network_error || 'Network error – please try again.');
        })
        .always(function () {
            $btn.prop('disabled', false).text('Analyse & Save');
        });
    });

    // ── 3. Conflict-resolution modal ─────────────────────────────────────────

    function renderConflictModal(conflicts, safeWords) {
        unresolvedConflicts  = conflicts;
        preApprovedSafeWords = safeWords;
        userResolutionMap    = {};

        const $tbody = $('#icbfe-conflict-rows').empty();

        conflicts.forEach(function (c, index) {
            const badgeClass = c.percentage >= 90 ? 'badge-high' : c.percentage >= 80 ? 'badge-medium' : 'badge-low';
            const row = `<tr>
                <td class="icbfe-cm-word">${$('<span>').text(c.new_word).html()}</td>
                <td class="icbfe-cm-word">${$('<span>').text(c.old_word).html()}</td>
                <td><span class="icbfe-similarity-badge ${badgeClass}">${c.percentage}%</span></td>
                <td>
                    <div class="icbfe-action-btn-group" data-index="${index}">
                        <label class="icbfe-btn-label" data-index="${index}" data-value="keep_old">
                            <input type="radio" name="icbfe-action-${index}" value="keep_old"> Keep Old
                        </label>
                        <label class="icbfe-btn-label" data-index="${index}" data-value="replace_with_new">
                            <input type="radio" name="icbfe-action-${index}" value="replace_with_new"> Replace
                        </label>
                        <label class="icbfe-btn-label" data-index="${index}" data-value="keep_both">
                            <input type="radio" name="icbfe-action-${index}" value="keep_both"> Keep Both
                        </label>
                    </div>
                </td>
            </tr>`;
            $tbody.append(row);
        });

        $('#icbfe-modal-count').text(
            conflicts.length + ' conflict(s) · ' + safeWords.length + ' word(s) queued'
        );
        $('#icbfe-submit-resolution-btn').prop('disabled', true);
        $('#icbfe-conflict-modal').show().attr('aria-hidden', 'false');
        // Trap focus after brief delay
        setTimeout(function () { $('#icbfe-conflict-modal .icbfe-modal').focus(); }, 50);
    }

    // Resolution button labels
    $(document).on('click', '.icbfe-btn-label', function () {
        const index = $(this).data('index');
        const value = $(this).data('value');

        $(this).closest('.icbfe-action-btn-group')
               .find('.icbfe-btn-label').removeClass('is-selected');
        $(this).addClass('is-selected');
        $(this).find('input[type="radio"]').prop('checked', true);

        userResolutionMap[index] = {
            new_word: unresolvedConflicts[index].new_word,
            old_word: unresolvedConflicts[index].old_word,
            decision: value,
        };

        if (Object.keys(userResolutionMap).length === unresolvedConflicts.length) {
            $('#icbfe-submit-resolution-btn').prop('disabled', false);
        }
    });

    // Cancel
    $(document).on('click', '#icbfe-cancel-modal-btn', function () {
        if (confirm('Discard this batch? No changes will be saved.')) {
            closeModal();
        }
    });

    // Backdrop click
    $(document).on('click', '.icbfe-modal-overlay', function (e) {
        if ($(e.target).hasClass('icbfe-modal-overlay')) {
            if (confirm('Discard this batch? No changes will be saved.')) {
                closeModal();
            }
        }
    });

    // Escape key
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape' && $('#icbfe-conflict-modal').is(':visible')) {
            if (confirm('Discard this batch? No changes will be saved.')) {
                closeModal();
            }
        }
    });

    function closeModal() {
        $('#icbfe-conflict-modal').hide().attr('aria-hidden', 'true');
    }

    // Commit resolutions
    $(document).on('click', '#icbfe-submit-resolution-btn', function () {
        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icbfe-spinner"></span> Saving…');

        $.post(ajaxurl, {
            action:      'icbfe_save_resolved_corpus',
            resolutions: userResolutionMap,
            safe_words:  preApprovedSafeWords,
            nonce:       nonce,
        })
        .done(function (response) {
            if (response.success) {
                closeModal();
                clearWorkspace();
                showNotice('success',
                    '✔ Corpus updated — added <strong>' + response.data.inserted +
                    '</strong> word(s), updated <strong>' + response.data.updated + '</strong> entry/entries.'
                );
            } else {
                showNotice('error', 'Save failed: ' + response.data.message);
                $btn.prop('disabled', false).text('Commit Approved Selections');
            }
        })
        .fail(function () {
            showNotice('error', strings.network_error || 'Network error – please try again.');
            $btn.prop('disabled', false).text('Commit Approved Selections');
        });
    });

    // ── 4. Config tab ─────────────────────────────────────────────────────────

    function populateConfigFields() {
        const cfg = icbfe_vars.parser_config || {};
        if (typeof cfg !== 'object') return;

        // Booleans
        const boolMap = {
            'icbfe-cfg-android-autocap':   'android_autocap_fix',
            'icbfe-cfg-normalize-unicode': 'normalize_unicode',
            'icbfe-cfg-strip-hasanta':     'strip_hasanta',
            'icbfe-cfg-preserve-anusvara': 'preserve_anusvara',
            'icbfe-cfg-preserve-visarga':  'preserve_visarga',
        };
        $.each(boolMap, function (id, key) {
            $('#' + id).prop('checked', !!cfg[key]);
        });

        // Numerics
        if (cfg.similarity_threshold !== undefined) {
            $('#icbfe-cfg-threshold').val(cfg.similarity_threshold);
        }
        if (cfg.min_word_length !== undefined) {
            $('#icbfe-cfg-min-word-length').val(cfg.min_word_length);
        }

        // Text
        if (cfg.hosonto_key !== undefined) {
            $('#icbfe-cfg-hosonto-key').val(cfg.hosonto_key);
        }
        if (cfg.cluster_breaker_key !== undefined) {
            $('#icbfe-cfg-cluster-breaker').val(cfg.cluster_breaker_key);
        }
    }

    function collectConfigData() {
        const data = {};
        $('[data-cfg-key]').each(function () {
            const key  = $(this).data('cfg-key');
            const type = this.type;
            data[key]  = (type === 'checkbox') ? $(this).is(':checked') : $(this).val();
        });
        data.android_autocap_fix   = $('#icbfe-cfg-android-autocap').is(':checked');
        data.similarity_threshold  = parseInt($('#icbfe-cfg-threshold').val(), 10)     || 75;
        data.min_word_length       = parseInt($('#icbfe-cfg-min-word-length').val(), 10) || 2;
        data.hosonto_key           = $('#icbfe-cfg-hosonto-key').val()       || "'";
        data.cluster_breaker_key   = $('#icbfe-cfg-cluster-breaker').val()   || 'o';
        return data;
    }

    $(document).on('click', '#icbfe-save-config-btn', function () {
        if (!access.config_edit) { return; }
        const $btn = $(this);
        $btn.prop('disabled', true).text('Saving…');

        $.post(ajaxurl, {
            action: 'icbfe_save_config',
            config: JSON.stringify(collectConfigData()),
            nonce:  nonce,
        })
        .done(function (r) {
            if (r.success) {
                showNotice('success', '✔ ' + r.data.message, '#icbfe-config-notice-area');
            } else {
                showNotice('error', r.data.message, '#icbfe-config-notice-area');
            }
        })
        .fail(function () { showNotice('error', 'Network error.', '#icbfe-config-notice-area'); })
        .always(function () { $btn.prop('disabled', false).text('Save Configuration'); });
    });

    $(document).on('click', '#icbfe-reset-config-btn', function () {
        if (!access.config_edit) { return; }
        if (!confirm('Reset parser configuration to plugin defaults?')) { return; }

        $.post(ajaxurl, { action: 'icbfe_reset_config', nonce: nonce })
        .done(function (r) {
            if (r.success) {
                icbfe_vars.parser_config = r.data.settings;
                populateConfigFields();
                showNotice('success', '✔ ' + r.data.message, '#icbfe-config-notice-area');
            }
        });
    });

    // ── 5. Lexicon tab ────────────────────────────────────────────────────────

    function populateLexiconTables() {
        const lexicon = icbfe_vars.lexicon || icbfe_vars.defaultLexicon || {};
        const groups  = ['vowels', 'modifiers', 'consonants', 'numerics_specials'];

        groups.forEach(function (group) {
            const $tbody = $('#icbfe-lex-tbody-' + group).empty();
            const map    = lexicon[group] || {};
            let count    = 0;

            $.each(map, function (roman, indic) {
                $tbody.append(buildLexRow(roman, indic, group));
                count++;
            });

            $('#icbfe-lex-count-' + group).text('(' + count + ')');
        });
    }

    function buildLexRow(roman, indic, group) {
        const editable  = access.lexicon_edit;
        const romanHtml = editable
            ? `<input type="text" class="icbfe-lex-roman small-text" value="${$('<span>').text(roman).html()}" maxlength="8">`
            : `<span class="icbfe-lex-roman-val">${$('<span>').text(roman).html()}</span>`;
        const indicHtml = editable
            ? `<input type="text" class="icbfe-lex-indic small-text icbfe-lex-indic-input" value="${$('<span>').text(indic).html()}" maxlength="8">`
            : `<span class="icbfe-lex-indic-val">${$('<span>').text(indic).html()}</span>`;
        const deleteBtn = editable
            ? `<button type="button" class="button-link icbfe-lex-delete-row" title="Remove row" data-group="${group}">✕</button>`
            : '';
        return `<tr data-group="${group}">${
            '<td>' + romanHtml + '</td>' +
            '<td>' + indicHtml + '</td>' +
            (editable ? '<td>' + deleteBtn + '</td>' : '')
        }</tr>`;
    }

    // Add row
    $(document).on('click', '.icbfe-lex-add-row', function () {
        const group  = $(this).data('group');
        const $tbody = $('#icbfe-lex-tbody-' + group);
        $tbody.append(buildLexRow('', '', group));
        $tbody.find('tr:last input:first').focus();
    });

    // Delete row
    $(document).on('click', '.icbfe-lex-delete-row', function () {
        $(this).closest('tr').remove();
    });

    // Accordion
    $(document).on('click', '.icbfe-accordion-trigger', function () {
        const $item = $(this).closest('.icbfe-accordion-item');
        const open  = $item.hasClass('icbfe-accordion-item--open');
        $item.toggleClass('icbfe-accordion-item--open', !open);
        $(this).attr('aria-expanded', !open);
        $item.find('.icbfe-accordion-body').first().toggle(!open);
    });

    function collectLexiconData() {
        const out    = {};
        const groups = ['vowels', 'modifiers', 'consonants', 'numerics_specials'];

        groups.forEach(function (group) {
            out[group] = {};
            $('#icbfe-lex-tbody-' + group + ' tr').each(function () {
                const roman = $(this).find('.icbfe-lex-roman').val();
                const indic = $(this).find('.icbfe-lex-indic').val();
                if (roman !== undefined && roman !== '') {
                    out[group][roman] = indic || '';
                }
            });
        });
        return out;
    }

    $(document).on('click', '#icbfe-save-lexicon-btn', function () {
        if (!access.lexicon_edit) { return; }
        const $btn = $(this);
        $btn.prop('disabled', true).text('Saving…');

        $.post(ajaxurl, {
            action:  'icbfe_save_lexicon',
            lexicon: JSON.stringify(collectLexiconData()),
            nonce:   nonce,
        })
        .done(function (r) {
            if (r.success) {
                icbfe_vars.lexicon = r.data.lexicon;
                showNotice('success', '✔ ' + r.data.message, '#icbfe-lexicon-notice-area');
            } else {
                showNotice('error', r.data.message, '#icbfe-lexicon-notice-area');
            }
        })
        .fail(function () { showNotice('error', 'Network error.', '#icbfe-lexicon-notice-area'); })
        .always(function () { $btn.prop('disabled', false).text('Save Lexicon'); });
    });

    $(document).on('click', '#icbfe-reset-lexicon-btn', function () {
        if (!access.lexicon_edit) { return; }
        if (!confirm('Reset lexicon to plugin defaults?')) { return; }

        $.post(ajaxurl, { action: 'icbfe_reset_lexicon', nonce: nonce })
        .done(function (r) {
            if (r.success) {
                icbfe_vars.lexicon = r.data.lexicon;
                populateLexiconTables();
                showNotice('success', '✔ ' + r.data.message, '#icbfe-lexicon-notice-area');
            }
        });
    });

    // ── Utility ───────────────────────────────────────────────────────────────

    function clearWorkspace() {
        $('#icbfe-input-container, #icbfe-preview-container').val('');
    }

    // ── Init ──────────────────────────────────────────────────────────────────

    $(document).ready(function () {
        boot();
    });

}(jQuery));
