<?php
/**
 * ICBFE_Shortcode – registers [icb_frontend] and renders the front-end UI.
 *
 * Usage in any post/page:
 *   [icb_frontend]
 *
 * The rendered widget respects the Access Control settings configured by the
 * administrator.  Administrators always see the full interface.
 *
 * The shortcode enqueues its own lightweight CSS/JS and reuses the parent
 * plugin's avro-parser.js for live transliteration.
 */
class ICBFE_Shortcode {

    public function __construct() {
        add_shortcode( 'icb_frontend', [ $this, 'render' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue_assets' ] );
    }

    // ── Asset enqueueing ──────────────────────────────────────────────────────

    /**
     * Enqueue front-end assets only on pages that actually use the shortcode.
     * We check the post content at the earliest possible hook; on archive/other
     * pages the assets are skipped entirely.
     */
    public function maybe_enqueue_assets() {
        global $post;
        if (
            ! is_a( $post, 'WP_Post' ) ||
            ! has_shortcode( $post->post_content, 'icb_frontend' )
        ) {
            return;
        }

        // Parent plugin's avro parser (transliterator)
        $parent_url = plugins_url( '/', dirname( __FILE__ ) );
        // Resolve path relative to parent plugin directory
        $parent_dir = WP_PLUGIN_DIR . '/indic-corpus-bulder-1x/';
        $avro_url   = plugins_url( 'assets/js/avro-parser.js', $parent_dir . 'indic-corpus-builder.php' );

        wp_enqueue_script(
            'icbfe-avro-parser',
            $avro_url,
            [],
            '2.3.0',
            true
        );

        wp_enqueue_script(
            'icbfe-frontend',
            ICBFE_PLUGIN_URL . 'assets/js/frontend.js',
            [ 'jquery', 'icbfe-avro-parser' ],
            ICBFE_VERSION,
            true
        );

        // Build the JS payload
        $access  = ICBFE_Access::current_user_map();
        $is_admin_user = current_user_can( 'manage_options' );

        if ( class_exists( 'ICB_Config' ) ) {
            $parser_config  = ICB_Config::all();
            $lexicon        = ICB_Config::get_lexicon();
            $default_lexicon = ICB_Config::DEFAULT_LEXICON;
        } else {
            $parser_config  = [];
            $lexicon        = [];
            $default_lexicon = [];
        }

        wp_add_inline_script(
            'icbfe-frontend',
            'var icbfe_vars = ' . wp_json_encode( [
                'ajaxurl'        => admin_url( 'admin-ajax.php' ),
                'nonce'          => wp_create_nonce( 'icbfe_nonce' ),
                'access'         => $access,
                'is_admin'       => $is_admin_user,
                'is_logged_in'   => is_user_logged_in(),
                'parser_config'  => $parser_config,
                'lexicon'        => $lexicon,
                'defaultLexicon' => $default_lexicon,
                'login_url'      => wp_login_url( get_permalink() ),
                'strings'        => [
                    'login_prompt'   => __( 'Please log in to submit words to the corpus.', 'icb-frontend-extension' ),
                    'no_access'      => __( 'You do not have permission to use this feature.', 'icb-frontend-extension' ),
                    'processing'     => __( 'Processing…', 'icb-frontend-extension' ),
                    'success_saved'  => __( 'Saved %d new word(s) to the corpus.', 'icb-frontend-extension' ),
                    'network_error'  => __( 'Network error – please try again.', 'icb-frontend-extension' ),
                ],
            ] ) . ';',
            'before'
        );

        wp_enqueue_style(
            'icbfe-frontend-style',
            ICBFE_PLUGIN_URL . 'assets/css/frontend.css',
            [],
            ICBFE_VERSION
        );
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render( $atts ): string {
        // Dependency guard
        if ( ! class_exists( 'ICB_Config' ) ) {
            return '<p class="icbfe-error">'
                 . esc_html__( 'Indic Corpus Builder plugin is required but not active.', 'icb-frontend-extension' )
                 . '</p>';
        }

        $access = ICBFE_Access::current_user_map();

        // If the user can't even see the workspace or config/lexicon, show a
        // friendly message instead of a blank widget.
        if (
            ! $access['workspace_view'] &&
            ! $access['config_view'] &&
            ! $access['lexicon_view']
        ) {
            return $this->render_no_access();
        }

        ob_start();
        $this->render_widget( $access );
        return ob_get_clean();
    }

    // ── No-access placeholder ─────────────────────────────────────────────────

    private function render_no_access(): string {
        $login_url = wp_login_url( get_permalink() );
        ob_start();
        ?>
        <div class="icbfe-wrap icbfe-no-access">
            <div class="icbfe-lock-icon">🔒</div>
            <h3><?php esc_html_e( 'Access Restricted', 'icb-frontend-extension' ); ?></h3>
            <?php if ( ! is_user_logged_in() ) : ?>
                <p>
                    <?php esc_html_e( 'Please log in to access the Indic Corpus Builder.', 'icb-frontend-extension' ); ?>
                </p>
                <a href="<?php echo esc_url( $login_url ); ?>" class="icbfe-btn icbfe-btn--primary">
                    <?php esc_html_e( 'Log In', 'icb-frontend-extension' ); ?>
                </a>
            <?php else : ?>
                <p><?php esc_html_e( 'You do not have permission to access this tool.', 'icb-frontend-extension' ); ?></p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    // ── Main widget ───────────────────────────────────────────────────────────

    private function render_widget( array $access ): void {
        global $wpdb;
        $table_name  = $wpdb->prefix . 'custom_corpus';
        // Guard: table may not exist if parent plugin was never activated
        $total_words = (int) $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" )
            ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" )
            : 0;

        $show_workspace = $access['workspace_view'];
        $show_config    = $access['config_view'];
        $show_lexicon   = $access['lexicon_view'];

        // Determine default active tab based on what's visible
        $active_tab = $show_workspace ? 'workspace' : ( $show_config ? 'config' : 'lexicon' );
        ?>
        <div class="icbfe-wrap" id="icbfe-root">

            <div class="icbfe-header">
                <h2 class="icbfe-title">
                    <?php esc_html_e( 'Indic Corpus Builder', 'icb-frontend-extension' ); ?>
                    <span class="icbfe-lang-badge">অ · ক · ব</span>
                </h2>
                <p class="icbfe-subtitle">
                    <?php esc_html_e( 'Paste Assamese or Bengali text, resolve near-duplicate conflicts, and grow your lexical corpus.', 'icb-frontend-extension' ); ?>
                </p>
            </div>

            <!-- Tab navigation (only tabs the user can access) -->
            <div class="icbfe-tab-nav" role="tablist">
                <?php if ( $show_workspace ) : ?>
                <button class="icbfe-tab-btn <?php echo $active_tab === 'workspace' ? 'icbfe-tab-active' : ''; ?>"
                        data-tab="workspace" role="tab"
                        aria-selected="<?php echo $active_tab === 'workspace' ? 'true' : 'false'; ?>">
                    ✏️ <?php esc_html_e( 'Corpus Workspace', 'icb-frontend-extension' ); ?>
                </button>
                <?php endif; ?>

                <?php if ( $show_config ) : ?>
                <button class="icbfe-tab-btn <?php echo $active_tab === 'config' ? 'icbfe-tab-active' : ''; ?>"
                        data-tab="config" role="tab"
                        aria-selected="<?php echo $active_tab === 'config' ? 'true' : 'false'; ?>">
                    ⚙️ <?php esc_html_e( 'Parser Configuration', 'icb-frontend-extension' ); ?>
                </button>
                <?php endif; ?>

                <?php if ( $show_lexicon ) : ?>
                <button class="icbfe-tab-btn <?php echo $active_tab === 'lexicon' ? 'icbfe-tab-active' : ''; ?>"
                        data-tab="lexicon" role="tab"
                        aria-selected="<?php echo $active_tab === 'lexicon' ? 'true' : 'false'; ?>">
                    🔡 <?php esc_html_e( 'Lexicon Mapping', 'icb-frontend-extension' ); ?>
                </button>
                <?php endif; ?>
            </div><!-- .icbfe-tab-nav -->

            <div id="icbfe-notice-area" role="status" aria-live="polite"></div>

            <!-- ── Tab: Workspace ──────────────────────────────────────────── -->
            <?php if ( $show_workspace ) : ?>
            <div id="icbfe-tab-workspace"
                 class="icbfe-tab-pane <?php echo $active_tab === 'workspace' ? 'icbfe-tab-pane--active' : ''; ?>"
                 role="tabpanel">

                <?php if ( $access['corpus_stats_view'] ) : ?>
                <div class="icbfe-stats-bar">
                    <span class="icbfe-stat-chip">
                        📚 <?php esc_html_e( 'Corpus size:', 'icb-frontend-extension' ); ?>
                        <strong><?php echo number_format( $total_words ); ?> <?php esc_html_e( 'words', 'icb-frontend-extension' ); ?></strong>
                    </span>
                    <?php if ( class_exists( 'ICB_Config' ) ) : ?>
                    <span class="icbfe-stat-chip">
                        🎯 <?php esc_html_e( 'Conflict threshold:', 'icb-frontend-extension' ); ?>
                        <strong><?php echo esc_html( ICB_Config::get( 'similarity_threshold' ) ); ?>%</strong>
                    </span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="icbfe-workspace">
                    <div class="icbfe-panel">
                        <label for="icbfe-input-container">
                            <?php esc_html_e( 'Input (Roman / Native)', 'icb-frontend-extension' ); ?>
                        </label>
                        <textarea
                            id="icbfe-input-container"
                            placeholder="<?php esc_attr_e( 'Paste text here — Roman transliteration or native Assamese/Bengali script…', 'icb-frontend-extension' ); ?>"
                            <?php echo ( ! $access['live_transliterate'] ) ? 'readonly' : ''; ?>
                        ></textarea>
                    </div>
                    <div class="icbfe-panel">
                        <label for="icbfe-preview-container">
                            <?php esc_html_e( 'Preview (Native Script)', 'icb-frontend-extension' ); ?>
                        </label>
                        <textarea
                            id="icbfe-preview-container"
                            placeholder="<?php esc_attr_e( 'Converted script will appear here…', 'icb-frontend-extension' ); ?>"
                            readonly
                        ></textarea>
                    </div>
                </div><!-- .icbfe-workspace -->

                <div class="icbfe-action-bar">
                    <?php if ( $access['transliterate_toggle'] ) : ?>
                    <label class="icbfe-toggle-wrap" for="icbfe-transliterate-toggle">
                        <input type="checkbox" id="icbfe-transliterate-toggle" checked>
                        <?php esc_html_e( 'Enable live Roman → Indic transliteration', 'icb-frontend-extension' ); ?>
                    </label>
                    <?php endif; ?>

                    <?php if ( $access['workspace_submit'] ) : ?>
                    <?php /* Full access: show Analyse & Save */ ?>
                    <button type="button" id="icbfe-process-btn" class="icbfe-btn icbfe-btn--primary">
                        <?php esc_html_e( 'Analyse & Save', 'icb-frontend-extension' ); ?>
                    </button>
                    <?php elseif ( $access['live_transliterate'] && ! is_user_logged_in() ) : ?>
                    <?php /* Guest: can type + preview freely, prompt to log in to save */ ?>
                    <a href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>"
                       class="icbfe-btn icbfe-btn--secondary">
                        🔒 <?php esc_html_e( 'Log in to save to corpus', 'icb-frontend-extension' ); ?>
                    </a>
                    <?php elseif ( $access['live_transliterate'] ) : ?>
                    <?php /* Logged-in user with preview access but corpus write restricted */ ?>
                    <span class="icbfe-read-only-badge">
                        👁 <?php esc_html_e( 'Preview only – saving restricted', 'icb-frontend-extension' ); ?>
                    </span>
                    <?php else : ?>
                    <?php /* No interaction permitted at all */ ?>
                    <span class="icbfe-read-only-badge">
                        👁 <?php esc_html_e( 'Read-only access', 'icb-frontend-extension' ); ?>
                    </span>
                    <?php endif; ?>
                </div><!-- .icbfe-action-bar -->

                <?php if ( $access['live_test'] ) : ?>
                <div class="icbfe-live-test-bar">
                    <label for="icbfe-live-test-input" class="icbfe-live-test-label">
                        ⚡ <?php esc_html_e( 'Live test (Roman input):', 'icb-frontend-extension' ); ?>
                    </label>
                    <input type="text" id="icbfe-live-test-input"
                           placeholder="<?php esc_attr_e( 'e.g. amar sonar bangla', 'icb-frontend-extension' ); ?>">
                    <span id="icbfe-live-test-output" class="icbfe-live-output">—</span>
                </div>
                <?php endif; ?>

            </div><!-- #icbfe-tab-workspace -->
            <?php endif; // workspace_view ?>

            <!-- ── Tab: Parser Configuration (view-only or editable) ──────── -->
            <?php if ( $show_config ) : ?>
            <div id="icbfe-tab-config"
                 class="icbfe-tab-pane <?php echo $active_tab === 'config' ? 'icbfe-tab-pane--active' : ''; ?>"
                 role="tabpanel">

                <?php if ( ! $access['config_edit'] ) : ?>
                <div class="icbfe-read-only-notice">
                    👁 <?php esc_html_e( 'You are viewing the parser configuration in read-only mode.', 'icb-frontend-extension' ); ?>
                </div>
                <?php endif; ?>

                <div id="icbfe-config-notice-area" role="status" aria-live="polite"></div>

                <div class="icbfe-config-grid">
                    <!-- Card: Input Corrections -->
                    <div class="icbfe-config-card">
                        <div class="icbfe-config-card-header">
                            <h3><?php esc_html_e( 'Input Corrections', 'icb-frontend-extension' ); ?></h3>
                        </div>
                        <div class="icbfe-config-card-body">
                            <label class="icbfe-cfg-row">
                                <input type="checkbox" id="icbfe-cfg-android-autocap"
                                       <?php echo $access['config_edit'] ? '' : 'disabled'; ?>>
                                <span><?php esc_html_e( 'Android auto-capitalisation fix', 'icb-frontend-extension' ); ?></span>
                            </label>
                        </div>
                    </div>

                    <!-- Card: Conflict Threshold -->
                    <div class="icbfe-config-card">
                        <div class="icbfe-config-card-header">
                            <h3><?php esc_html_e( 'Conflict Detection', 'icb-frontend-extension' ); ?></h3>
                        </div>
                        <div class="icbfe-config-card-body">
                            <label class="icbfe-cfg-field-label" for="icbfe-cfg-threshold">
                                <?php esc_html_e( 'Similarity threshold (%)', 'icb-frontend-extension' ); ?>
                            </label>
                            <input type="number" id="icbfe-cfg-threshold"
                                   min="0" max="100" step="1"
                                   <?php echo $access['config_edit'] ? '' : 'readonly'; ?>>
                        </div>
                    </div>

                    <!-- Card: Tokenisation -->
                    <div class="icbfe-config-card">
                        <div class="icbfe-config-card-header">
                            <h3><?php esc_html_e( 'Tokenisation', 'icb-frontend-extension' ); ?></h3>
                        </div>
                        <div class="icbfe-config-card-body icbfe-cfg-checks">
                            <?php
                            $bool_fields = [
                                'normalize_unicode' => 'Normalize Unicode (NFC)',
                                'strip_hasanta'     => 'Strip word-final hasanta',
                                'preserve_anusvara' => 'Preserve anusvara',
                                'preserve_visarga'  => 'Preserve visarga',
                            ];
                            foreach ( $bool_fields as $id => $label ) : ?>
                            <label class="icbfe-cfg-row">
                                <input type="checkbox" id="icbfe-cfg-<?php echo esc_attr( str_replace( '_', '-', $id ) ); ?>"
                                       data-cfg-key="<?php echo esc_attr( $id ); ?>"
                                       <?php echo $access['config_edit'] ? '' : 'disabled'; ?>>
                                <span><?php echo esc_html__( $label, 'icb-frontend-extension' ); ?></span>
                            </label>
                            <?php endforeach; ?>
                            <div class="icbfe-cfg-field-row" style="margin-top:10px;">
                                <label class="icbfe-cfg-field-label" for="icbfe-cfg-min-word-length">
                                    <?php esc_html_e( 'Min word length', 'icb-frontend-extension' ); ?>
                                </label>
                                <input type="number" id="icbfe-cfg-min-word-length"
                                       min="1" max="20" step="1"
                                       <?php echo $access['config_edit'] ? '' : 'readonly'; ?>>
                            </div>
                        </div>
                    </div>

                    <!-- Card: Special Keys -->
                    <div class="icbfe-config-card">
                        <div class="icbfe-config-card-header">
                            <h3><?php esc_html_e( 'Special Keys', 'icb-frontend-extension' ); ?></h3>
                        </div>
                        <div class="icbfe-config-card-body">
                            <div class="icbfe-cfg-field-row">
                                <label class="icbfe-cfg-field-label" for="icbfe-cfg-hosonto-key">
                                    <?php esc_html_e( 'Hosonto key', 'icb-frontend-extension' ); ?>
                                </label>
                                <input type="text" id="icbfe-cfg-hosonto-key"
                                       maxlength="3"
                                       <?php echo $access['config_edit'] ? '' : 'readonly'; ?>>
                            </div>
                            <div class="icbfe-cfg-field-row" style="margin-top:10px;">
                                <label class="icbfe-cfg-field-label" for="icbfe-cfg-cluster-breaker">
                                    <?php esc_html_e( 'Cluster-breaker key', 'icb-frontend-extension' ); ?>
                                </label>
                                <input type="text" id="icbfe-cfg-cluster-breaker"
                                       maxlength="3"
                                       <?php echo $access['config_edit'] ? '' : 'readonly'; ?>>
                            </div>
                        </div>
                    </div>
                </div><!-- .icbfe-config-grid -->

                <?php if ( $access['config_edit'] ) : ?>
                <div class="icbfe-action-bar">
                    <button type="button" id="icbfe-reset-config-btn" class="icbfe-btn icbfe-btn--secondary">
                        ↺ <?php esc_html_e( 'Reset to Defaults', 'icb-frontend-extension' ); ?>
                    </button>
                    <button type="button" id="icbfe-save-config-btn" class="icbfe-btn icbfe-btn--primary">
                        <?php esc_html_e( 'Save Configuration', 'icb-frontend-extension' ); ?>
                    </button>
                </div>
                <?php endif; ?>

            </div><!-- #icbfe-tab-config -->
            <?php endif; // config_view ?>

            <!-- ── Tab: Lexicon Mapping (view-only or editable) ────────────── -->
            <?php if ( $show_lexicon ) : ?>
            <div id="icbfe-tab-lexicon"
                 class="icbfe-tab-pane <?php echo $active_tab === 'lexicon' ? 'icbfe-tab-pane--active' : ''; ?>"
                 role="tabpanel">

                <?php if ( ! $access['lexicon_edit'] ) : ?>
                <div class="icbfe-read-only-notice">
                    👁 <?php esc_html_e( 'You are viewing the lexicon in read-only mode.', 'icb-frontend-extension' ); ?>
                </div>
                <?php endif; ?>

                <div id="icbfe-lexicon-notice-area" role="status" aria-live="polite"></div>

                <div class="icbfe-lexicon-accordion" id="icbfe-lexicon-accordion">
                    <?php
                    $groups = [
                        'vowels'            => 'Vowels',
                        'modifiers'         => 'Vowel Modifiers (Maatraa)',
                        'consonants'        => 'Consonants',
                        'numerics_specials' => 'Numerics & Special Characters',
                    ];
                    $first = true;
                    foreach ( $groups as $group_id => $group_label ) : ?>
                    <div class="icbfe-accordion-item <?php echo $first ? 'icbfe-accordion-item--open' : ''; ?>"
                         data-group="<?php echo esc_attr( $group_id ); ?>">
                        <button type="button" class="icbfe-accordion-trigger"
                                aria-expanded="<?php echo $first ? 'true' : 'false'; ?>">
                            <span class="icbfe-accordion-title">
                                <?php echo esc_html__( $group_label, 'icb-frontend-extension' ); ?>
                                <span class="icbfe-lexicon-count" id="icbfe-lex-count-<?php echo esc_attr( $group_id ); ?>"></span>
                            </span>
                            <span class="icbfe-accordion-chevron" aria-hidden="true">▾</span>
                        </button>
                        <div class="icbfe-accordion-body" <?php echo $first ? '' : 'hidden'; ?>>
                            <table class="icbfe-lexicon-table">
                                <thead>
                                    <tr>
                                        <th><?php esc_html_e( 'Roman key', 'icb-frontend-extension' ); ?></th>
                                        <th><?php esc_html_e( 'Indic glyph', 'icb-frontend-extension' ); ?></th>
                                        <?php if ( $access['lexicon_edit'] ) : ?><th></th><?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody id="icbfe-lex-tbody-<?php echo esc_attr( $group_id ); ?>"></tbody>
                            </table>
                            <?php if ( $access['lexicon_edit'] ) : ?>
                            <button type="button" class="icbfe-btn icbfe-btn--small icbfe-lex-add-row"
                                    data-group="<?php echo esc_attr( $group_id ); ?>"
                                    style="margin-top:8px;">
                                + <?php esc_html_e( 'Add Row', 'icb-frontend-extension' ); ?>
                            </button>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php $first = false; endforeach; ?>
                </div><!-- .icbfe-lexicon-accordion -->

                <?php if ( $access['lexicon_edit'] ) : ?>
                <div class="icbfe-action-bar">
                    <button type="button" id="icbfe-reset-lexicon-btn" class="icbfe-btn icbfe-btn--secondary">
                        ↺ <?php esc_html_e( 'Reset to Defaults', 'icb-frontend-extension' ); ?>
                    </button>
                    <button type="button" id="icbfe-save-lexicon-btn" class="icbfe-btn icbfe-btn--primary">
                        <?php esc_html_e( 'Save Lexicon', 'icb-frontend-extension' ); ?>
                    </button>
                </div>
                <?php endif; ?>

            </div><!-- #icbfe-tab-lexicon -->
            <?php endif; // lexicon_view ?>

        </div><!-- .icbfe-wrap -->

        <!-- ── Conflict Resolution Modal ─────────────────────────────────── -->
        <?php if ( $access['conflict_resolution'] ) : ?>
        <div id="icbfe-conflict-modal" class="icbfe-modal-overlay" style="display:none;"
             role="dialog" aria-modal="true" aria-labelledby="icbfe-modal-title">
            <div class="icbfe-modal">
                <div class="icbfe-modal-header">
                    <h3 id="icbfe-modal-title">
                        <?php esc_html_e( 'Linguistic Conflict Resolution', 'icb-frontend-extension' ); ?>
                    </h3>
                    <p><?php esc_html_e( 'These incoming words closely match existing entries. Review each pair.', 'icb-frontend-extension' ); ?></p>
                </div>
                <div class="icbfe-modal-body">
                    <table class="icbfe-conflict-table">
                        <thead>
                            <tr>
                                <th><?php esc_html_e( 'New Word', 'icb-frontend-extension' ); ?></th>
                                <th><?php esc_html_e( 'Existing Match', 'icb-frontend-extension' ); ?></th>
                                <th><?php esc_html_e( 'Similarity', 'icb-frontend-extension' ); ?></th>
                                <th><?php esc_html_e( 'Action', 'icb-frontend-extension' ); ?></th>
                            </tr>
                        </thead>
                        <tbody id="icbfe-conflict-rows"></tbody>
                    </table>
                </div>
                <div class="icbfe-modal-footer">
                    <span id="icbfe-modal-count" class="icbfe-modal-count"></span>
                    <div class="icbfe-modal-actions">
                        <button type="button" id="icbfe-cancel-modal-btn" class="icbfe-btn icbfe-btn--secondary">
                            <?php esc_html_e( 'Discard Batch', 'icb-frontend-extension' ); ?>
                        </button>
                        <button type="button" id="icbfe-submit-resolution-btn"
                                class="icbfe-btn icbfe-btn--primary" disabled>
                            <?php esc_html_e( 'Commit Approved Selections', 'icb-frontend-extension' ); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php
    }
}
