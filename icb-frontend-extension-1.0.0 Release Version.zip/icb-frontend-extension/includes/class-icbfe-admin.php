<?php
/**
 * ICBFE_Admin – registers the Access Control Manager settings page under the
 * parent plugin's admin menu, and enqueues the admin UI assets.
 *
 * Menu location:
 *   Corpus Builder → Frontend Access Control
 *
 * The page lets the administrator independently configure permissions for two
 * user tiers:
 *   • Subscribers  – any logged-in user (regardless of WP role, as long as
 *                    they cannot manage_options)
 *   • Guests       – unauthenticated / not-logged-in visitors
 *
 * Administrators always have full access and are never shown in this matrix.
 */
class ICBFE_Admin {

    const ADMIN_SLUG = 'icbfe-access-control';

    public function __construct() {
        add_action( 'admin_menu',            [ $this, 'register_submenu'  ], 20 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets'    ] );
        add_action( 'wp_ajax_icbfe_admin_save_access',  [ $this, 'handle_save_access'  ] );
        add_action( 'wp_ajax_icbfe_admin_reset_access', [ $this, 'handle_reset_access' ] );
    }

    // ── Menu ──────────────────────────────────────────────────────────────────

    public function register_submenu(): void {
        add_submenu_page(
            'indic-corpus-builder',          // parent slug
            __( 'Frontend Access Control', 'icb-frontend-extension' ),
            __( 'Frontend Access', 'icb-frontend-extension' ),
            'manage_options',
            self::ADMIN_SLUG,
            [ $this, 'render_page' ]
        );
    }

    // ── Assets ────────────────────────────────────────────────────────────────

    public function enqueue_assets( string $hook ): void {
        // WP builds the hook as: {parent_slug}_page_{submenu_slug}
        // parent slug uses dashes → underscores in the hook name
        if ( $hook !== 'corpus-builder_page_' . self::ADMIN_SLUG &&
             strpos( $hook, self::ADMIN_SLUG ) === false ) return;

        wp_enqueue_style(
            'icbfe-admin-style',
            ICBFE_PLUGIN_URL . 'assets/css/admin.css',
            [],
            ICBFE_VERSION
        );

        wp_enqueue_script(
            'icbfe-admin-script',
            ICBFE_PLUGIN_URL . 'assets/js/admin.js',
            [ 'jquery' ],
            ICBFE_VERSION,
            true
        );

        wp_add_inline_script(
            'icbfe-admin-script',
            'var icbfe_admin_vars = ' . wp_json_encode( [
                'nonce'          => wp_create_nonce( 'icbfe_admin_nonce' ),
                'access'         => ICBFE_Access::all(),
                'feature_labels' => ICBFE_Access::FEATURE_LABELS,
                'defaults'       => ICBFE_Access::DEFAULTS,
                'strings'        => [
                    'saved'   => __( 'Access control settings saved.', 'icb-frontend-extension' ),
                    'reset'   => __( 'Access control reset to defaults.', 'icb-frontend-extension' ),
                    'error'   => __( 'Save failed. Please try again.', 'icb-frontend-extension' ),
                    'confirm_reset' => __( 'Reset all permissions to plugin defaults? This cannot be undone.', 'icb-frontend-extension' ),
                ],
            ] ) . ';',
            'before'
        );
    }

    // ── Render ────────────────────────────────────────────────────────────────

    public function render_page(): void {
        $access = ICBFE_Access::all();
        $labels = ICBFE_Access::FEATURE_LABELS;
        ?>
        <div class="wrap icbfe-admin-wrap">

            <h1 class="icbfe-admin-title">
                <?php esc_html_e( 'Frontend Access Control', 'icb-frontend-extension' ); ?>
                <span class="icbfe-admin-badge">ICB Extension</span>
            </h1>

            <p class="icbfe-admin-intro">
                <?php esc_html_e( 'Control which features of the [icb_frontend] shortcode are available to each type of visitor. Administrators always have full access and cannot be restricted here.', 'icb-frontend-extension' ); ?>
            </p>

            <div id="icbfe-admin-notice" class="icbfe-admin-notice" style="display:none;"></div>

            <div class="icbfe-access-manager">

                <!-- ── Legend ──────────────────────────────────────────────── -->
                <div class="icbfe-am-legend">
                    <span class="icbfe-am-tier-badge icbfe-am-tier--admin">
                        🛡 <?php esc_html_e( 'Administrator', 'icb-frontend-extension' ); ?>
                    </span>
                    <span class="icbfe-am-legend-note">
                        <?php esc_html_e( '— Always full access (not configurable)', 'icb-frontend-extension' ); ?>
                    </span>
                    <span class="icbfe-am-tier-badge icbfe-am-tier--subscriber">
                        👤 <?php esc_html_e( 'Subscriber', 'icb-frontend-extension' ); ?>
                    </span>
                    <span class="icbfe-am-legend-note">
                        <?php esc_html_e( '— Any logged-in user without admin rights', 'icb-frontend-extension' ); ?>
                    </span>
                    <span class="icbfe-am-tier-badge icbfe-am-tier--guest">
                        🌐 <?php esc_html_e( 'Guest', 'icb-frontend-extension' ); ?>
                    </span>
                    <span class="icbfe-am-legend-note">
                        <?php esc_html_e( '— Unauthenticated / not logged-in visitors', 'icb-frontend-extension' ); ?>
                    </span>
                </div>

                <!-- ── Access Matrix ───────────────────────────────────────── -->
                <div class="icbfe-am-table-wrap">
                    <table class="icbfe-am-table widefat" id="icbfe-access-table">
                        <thead>
                            <tr>
                                <th class="icbfe-am-col-feature">
                                    <?php esc_html_e( 'Feature', 'icb-frontend-extension' ); ?>
                                </th>
                                <th class="icbfe-am-col-tier icbfe-am-col--admin">
                                    <span class="icbfe-am-tier-badge icbfe-am-tier--admin">
                                        🛡 <?php esc_html_e( 'Admin', 'icb-frontend-extension' ); ?>
                                    </span>
                                </th>
                                <th class="icbfe-am-col-tier icbfe-am-col--subscriber">
                                    <span class="icbfe-am-tier-badge icbfe-am-tier--subscriber">
                                        👤 <?php esc_html_e( 'Subscriber', 'icb-frontend-extension' ); ?>
                                    </span>
                                </th>
                                <th class="icbfe-am-col-tier icbfe-am-col--guest">
                                    <span class="icbfe-am-tier-badge icbfe-am-tier--guest">
                                        🌐 <?php esc_html_e( 'Guest', 'icb-frontend-extension' ); ?>
                                    </span>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Group rows by conceptual section for readability
                            $sections = [
                                __( 'Workspace', 'icb-frontend-extension' ) => [
                                    'workspace_view', 'live_transliterate',
                                    'workspace_submit', 'transliterate_toggle',
                                    'conflict_resolution', 'corpus_stats_view',
                                ],
                                __( 'Parser Configuration', 'icb-frontend-extension' ) => [
                                    'config_view', 'config_edit',
                                ],
                                __( 'Lexicon Mapping', 'icb-frontend-extension' ) => [
                                    'lexicon_view', 'lexicon_edit',
                                ],
                                __( 'Tools', 'icb-frontend-extension' ) => [
                                    'live_test',
                                ],
                            ];

                            foreach ( $sections as $section_label => $features ) :
                            ?>
                            <tr class="icbfe-am-section-row">
                                <td colspan="4" class="icbfe-am-section-label">
                                    <?php echo esc_html( $section_label ); ?>
                                </td>
                            </tr>
                            <?php foreach ( $features as $feature ) : ?>
                            <tr class="icbfe-am-feature-row" data-feature="<?php echo esc_attr( $feature ); ?>">
                                <td class="icbfe-am-feature-name">
                                    <?php echo esc_html( $labels[ $feature ] ?? $feature ); ?>
                                </td>
                                <!-- Admin: always checked, always disabled -->
                                <td class="icbfe-am-cell icbfe-am-cell--admin">
                                    <label class="icbfe-am-toggle icbfe-am-toggle--locked">
                                        <input type="checkbox" checked disabled>
                                        <span class="icbfe-am-toggle-track"></span>
                                    </label>
                                </td>
                                <!-- Subscriber -->
                                <td class="icbfe-am-cell icbfe-am-cell--subscriber">
                                    <label class="icbfe-am-toggle">
                                        <input type="checkbox"
                                               class="icbfe-perm-toggle"
                                               data-tier="subscriber"
                                               data-feature="<?php echo esc_attr( $feature ); ?>"
                                               <?php checked( ! empty( $access['subscriber'][ $feature ] ) ); ?>>
                                        <span class="icbfe-am-toggle-track"></span>
                                    </label>
                                </td>
                                <!-- Guest -->
                                <td class="icbfe-am-cell icbfe-am-cell--guest">
                                    <label class="icbfe-am-toggle">
                                        <input type="checkbox"
                                               class="icbfe-perm-toggle"
                                               data-tier="guest"
                                               data-feature="<?php echo esc_attr( $feature ); ?>"
                                               <?php checked( ! empty( $access['guest'][ $feature ] ) ); ?>>
                                        <span class="icbfe-am-toggle-track"></span>
                                    </label>
                                </td>
                            </tr>
                            <?php endforeach; endforeach; ?>
                        </tbody>
                    </table>
                </div><!-- .icbfe-am-table-wrap -->

                <!-- ── Dependency note ────────────────────────────────────── -->
                <p class="icbfe-am-dep-note">
                    <strong><?php esc_html_e( 'Note:', 'icb-frontend-extension' ); ?></strong>
                    <?php esc_html_e( 'Enabling an "edit" permission automatically implies the corresponding "view" permission. If you enable submission without conflict resolution, conflicting words will be silently skipped.', 'icb-frontend-extension' ); ?>
                </p>

                <!-- ── Action bar ─────────────────────────────────────────── -->
                <div class="icbfe-am-action-bar">
                    <button type="button" id="icbfe-admin-reset-btn" class="button button-secondary">
                        ↺ <?php esc_html_e( 'Reset to Defaults', 'icb-frontend-extension' ); ?>
                    </button>
                    <button type="button" id="icbfe-admin-save-btn" class="button button-primary">
                        <?php esc_html_e( 'Save Access Settings', 'icb-frontend-extension' ); ?>
                    </button>
                </div>

            </div><!-- .icbfe-access-manager -->

            <!-- ── Shortcode reference ──────────────────────────────────── -->
            <div class="icbfe-shortcode-info card">
                <h2><?php esc_html_e( 'Shortcode Usage', 'icb-frontend-extension' ); ?></h2>
                <p><?php esc_html_e( 'Paste the following shortcode into any post or page to embed the Indic Corpus Builder tool on the front end:', 'icb-frontend-extension' ); ?></p>
                <code class="icbfe-shortcode-sample">[icb_frontend]</code>
                <p class="description">
                    <?php esc_html_e( 'The widget automatically adapts its controls to the current visitor\'s role and the permissions you configure above.', 'icb-frontend-extension' ); ?>
                </p>
            </div>

        </div><!-- .wrap -->
        <?php
    }

    // ── AJAX: Save access settings ────────────────────────────────────────────

    public function handle_save_access(): void {
        check_ajax_referer( 'icbfe_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ], 403 );
        }

        $raw  = isset( $_POST['access'] ) ? stripslashes( $_POST['access'] ) : '';
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Invalid access payload.' ] );
        }

        ICBFE_Access::save( $data );

        wp_send_json_success( [
            'message' => __( 'Access control settings saved.', 'icb-frontend-extension' ),
            'access'  => ICBFE_Access::all(),
        ] );
    }

    // ── AJAX: Reset access settings ───────────────────────────────────────────

    public function handle_reset_access(): void {
        check_ajax_referer( 'icbfe_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ], 403 );
        }

        ICBFE_Access::reset();

        wp_send_json_success( [
            'message' => __( 'Access control reset to defaults.', 'icb-frontend-extension' ),
            'access'  => ICBFE_Access::all(),
        ] );
    }
}
