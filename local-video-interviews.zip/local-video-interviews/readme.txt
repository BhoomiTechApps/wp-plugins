=== BhoomiTech LVI ===
Contributors: BhoomiTech Heritage and Development Foundation
Tags: video, interviews, async, recording, media
Requires at least: 5.8
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 6.0.1
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A widescreen 16:9 async video interview plugin with moderation, star ratings, email notifications, and upload progress tracking.

== Description ==

BhoomiTech LVI (Local Video Interviews) is a full-featured asynchronous video interview plugin for WordPress. It lets site visitors submit interview questions, allows registered users to record and upload video responses directly in the browser, and gives administrators full control via a moderation dashboard.

**Key Features:**

* Widescreen 16:9 webcam recording with a configurable per-question time limit
* Lightbox-based question submission and response recording forms
* PRG (Post/Redirect/Get) pattern prevents duplicate form submissions
* Global recording budget with real-time capacity display
* Admin moderation pipeline (allow / disallow questions individually or in bulk)
* Authenticated star-rating system (one vote per user, per question)
* Email notifications on question submission and video response upload
* YouTube archive URL fallback for deleted media files
* Upload progress tracking
* REST API endpoints for video submission and star ratings
* Cookie-based guest session tokens for anonymous users

== Installation ==

1. Upload the `local-video-interviews` folder to the `/wp-content/plugins/` directory, or install the plugin through the WordPress Plugins screen directly.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. Go to **Interview Questions → Global Settings** to configure the recording budget, default question duration, questions per page, and email notification preferences.
4. Add the shortcode `[local_interview]` to any page or post where you want the interview board to appear.

== Frequently Asked Questions ==

= What browsers support webcam recording? =

Webcam recording requires a browser that supports the MediaRecorder API (Chrome 49+, Firefox 25+, Edge 79+, Safari 14.1+). Mobile browsers may have limited support.

= How does the global recording budget work? =

Each interview question has a maximum recording duration (in seconds). The global budget is the total of all open (unanswered) questions' time limits. When the budget is full, new question submissions are blocked until existing questions are answered or removed.

= Can guests (non-logged-in users) submit questions? =

Yes. Guest submissions require a name and a valid email address. The plugin uses a cookie-based session token to track guest activity without relying on IP addresses.

= How do I assign a question to a specific user? =

In the admin area, open any **Interview Question** post and use the **Assigned Registered User** dropdown in the Question Metadata & Moderation Console metabox.

= Where are uploaded videos stored? =

Videos are stored in the WordPress Media Library as standard attachments.

== Screenshots ==

1. Frontend interview board with question list, status badges, and recording controls.
2. Admin Global Settings page showing active allocation metrics.
3. Admin metabox with moderation controls, user assignment, and community ratings.

== Changelog ==

= 6.0.1 =
* Security hardening: all output properly escaped via WordPress escaping functions.
* Security hardening: all `$_POST`, `$_COOKIE`, and `$_REQUEST` inputs validated, unslashed, and sanitized before use.
* Added `wp_unslash()` calls before sanitization throughout to comply with WordPress coding standards.
* Nonce field for meta box now uses `sanitize_key()` before verification.
* Direct database query on deactivation suppressed with inline phpcs comment explaining intent.
* Added GPL-2.0-or-later license declaration to plugin header.

= 6.0.0 =
* Initial public release.

== Upgrade Notice ==

= 6.0.1 =
Security and standards update. All output escaping and input sanitization has been tightened to meet WordPress.org plugin repository requirements. Upgrade recommended for all users.
