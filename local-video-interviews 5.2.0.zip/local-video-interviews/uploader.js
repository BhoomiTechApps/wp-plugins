document.addEventListener('DOMContentLoaded', () => {
    const rootBox = document.getElementById('lvi-playlist-container');
    if (!rootBox) return; 

    const monitor = document.getElementById('lvi-video-monitor');
    const btnRec = document.getElementById('lvi-trigger-rec');
    const btnStop = document.getElementById('lvi-trigger-stop');
    const spinner = document.getElementById('lvi-process-spinner');
    const listWrapper = document.getElementById('lvi-question-queue-list');
    const activeText = document.getElementById('lvi-focused-question-text');
    const overlay = document.getElementById('lvi-overlay-announcer');
    const announcerMsg = document.getElementById('lvi-announcer-msg');
    const liveIndicator = document.getElementById('lvi-rec-timer');
    const noteArea = document.getElementById('lvi-teleprompter-notes');
    const btnToggleCam = document.getElementById('lvi-toggle-camera');

    const restEndpoint = rootBox.getAttribute('data-root');
    const authNonce = rootBox.getAttribute('data-nonce');
    const queueItems = document.querySelectorAll('.lvi-queue-item');

    let activeIndex = null;
    let activePostId = null;
    let currentLimitSeconds = 60; 
    let mediaRecorder = null;
    let recordedChunks = [];
    let cameraStream = null;
    let countdownInterval = null;

    // Device tracking hardware pools
    let videoDevices = [];
    let currentDeviceIndex = 0;

    // Initialize Video Peripheral Processing Pipeline
    function initCameraStream(constraints = { video: { aspectRatio: 1.7777777778 }, audio: true }) {
        // Stop any active components before re-allocating new tracking tracks
        if (cameraStream) {
            cameraStream.getTracks().forEach(track => track.stop());
        }

        return navigator.mediaDevices.getUserMedia(constraints)
            .then(stream => {
                cameraStream = stream;
                monitor.srcObject = stream;
                overlay.style.display = 'none';
                
                // Mirror layout optimization engine for front-facing devices
                const videoTrack = stream.getVideoTracks()[0];
                const trackSettings = videoTrack ? videoTrack.getSettings() : null;
                if (trackSettings && trackSettings.facingMode === 'environment') {
                    monitor.style.transform = 'scaleX(1)';
                } else {
                    monitor.style.transform = 'scaleX(-1)';
                }

                // Enumerate and cache device arrays if not already built
                if (videoDevices.length === 0) {
                    navigator.mediaDevices.enumerateDevices()
                        .then(devices => {
                            videoDevices = devices.filter(d => d.kind === 'videoinput');
                            if (videoDevices.length > 1) {
                                btnToggleCam.style.display = 'flex';
                                // Find current index matching active track parameters
                                if (trackSettings && trackSettings.deviceId) {
                                    const matchIdx = videoDevices.findIndex(d => d.deviceId === trackSettings.deviceId);
                                    if (matchIdx !== -1) currentDeviceIndex = matchIdx;
                                }
                            }
                        });
                }
            });
    }

    // Initial load block invocation
    initCameraStream()
        .then(() => {
            selectFirstAvailableTask();
        })
        .catch(err => {
            announcerMsg.innerHTML = "<strong style='color:#ef4444;'>Webcam Access Blocked:</strong> Grant secure video peripheral tracking authorization keys inside your browser settings.";
        });

    // Hardware Cycling Intercept Handler
    btnToggleCam.addEventListener('click', () => {
        if (videoDevices.length < 2 || (mediaRecorder && mediaRecorder.state === 'recording')) return;

        currentDeviceIndex = (currentDeviceIndex + 1) % videoDevices.length;
        const targetDevice = videoDevices[currentDeviceIndex];

        const updatedConstraints = {
            video: {
                deviceId: { exact: targetDevice.deviceId },
                aspectRatio: 1.7777777778
            },
            audio: true
        };

        overlay.style.display = 'flex';
        announcerMsg.innerText = "Reallocating streaming input context data feeds...";
        
        initCameraStream(updatedConstraints)
            .catch(() => {
                // Failover baseline execution string
                initCameraStream({ video: true, audio: true });
            });
    });

    function selectFirstAvailableTask() {
        let targets = Array.from(queueItems);
        let firstPendingMe = targets.find(item => item.getAttribute('data-allowed') === 'true' && item.getAttribute('data-done') === 'false');
        
        if (firstPendingMe) {
            activateTaskRow(firstPendingMe);
        } else {
            if (targets.length > 0) activateTaskRow(targets[0]);
        }
    }

    function activateTaskRow(element) {
        queueItems.forEach(i => i.style.borderColor = '#e2e8f0');
        
        activeIndex = parseInt(element.getAttribute('data-idx'));
        activePostId = element.getAttribute('data-postid');
        currentLimitSeconds = parseInt(element.getAttribute('data-limit')) || 60;
        
        const isDone = element.getAttribute('data-done') === 'true';
        const isAllowed = element.getAttribute('data-allowed') === 'true';
        const isUnallocated = element.getAttribute('data-unallocated') === 'true';
        const assignedTargetUser = element.getAttribute('data-user');
        const fullText = element.querySelector('.lvi-q-body-text').innerText;

        element.style.borderColor = '#2271b1';
        activeText.innerText = fullText;
        noteArea.value = "";

        if (isDone) {
            btnRec.style.display = 'none'; btnStop.style.display = 'none'; overlay.style.display = 'flex';
            announcerMsg.innerHTML = "<span>🔒 <strong>Slot Closed</strong><br><small>This question has already been answered.</small></span>";
        } else if (isUnallocated) {
            btnRec.style.display = 'none'; btnStop.style.display = 'none'; overlay.style.display = 'flex';
            announcerMsg.innerHTML = "<span>⚡ <strong>Unallocated Task</strong><br><small>Click \"Claim Slot\" on this row card to open your video recording interface console.</small></span>";
        } else if (!isAllowed) {
            btnRec.style.display = 'none'; btnStop.style.display = 'none'; overlay.style.display = 'flex';
            announcerMsg.innerHTML = `<span>🔒 <strong>Locked Track Slot</strong><br><small>Recording authorization belongs to: <strong>@${assignedTargetUser}</strong></small></span>`;
        } else {
            overlay.style.display = 'none';
            btnRec.style.display = 'inline-block';
            btnRec.innerText = `Record Answer (${currentLimitSeconds}s Max)`;
            btnStop.style.display = 'none';
            spinner.style.display = 'none';
            if (videoDevices.length > 1) btnToggleCam.style.display = 'flex';
        }
    }

    listWrapper.addEventListener('click', (e) => {
        const itemRow = e.target.closest('.lvi-queue-item');
        if (!itemRow || (mediaRecorder && mediaRecorder.state === 'recording')) return;
        activateTaskRow(itemRow);
    });

    btnRec.addEventListener('click', () => {
        recordedChunks = [];
        let mimePreference = 'video/webm;codecs=vp8,opus';
        if (!MediaRecorder.isTypeSupported(mimePreference)) mimePreference = 'video/mp4';

        try {
            mediaRecorder = new MediaRecorder(cameraStream, { mimeType: mimePreference });
        } catch(e) {
            mediaRecorder = new MediaRecorder(cameraStream);
        }

        mediaRecorder.ondataavailable = (e) => {
            if (e.data && e.data.size > 0) recordedChunks.push(e.data);
        };

        mediaRecorder.onstop = () => { processSegmentUpload(); };
        mediaRecorder.start(1000);
        
        btnRec.style.display = 'none';
        btnStop.style.display = 'inline-block';
        btnToggleCam.style.display = 'none'; // Lock hardware toggling during ingestion passes
        liveIndicator.style.display = 'flex';

        let remaining = currentLimitSeconds;
        btnStop.innerText = `Stop Recording (${remaining}s)`;

        countdownInterval = setInterval(() => {
            remaining--;
            if (remaining > 0) {
                btnStop.innerText = `Stop Recording (${remaining}s)`;
            } else {
                clearInterval(countdownInterval);
                if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
            }
        }, 1000);
    });

    btnStop.addEventListener('click', () => {
        clearInterval(countdownInterval);
        if (mediaRecorder && mediaRecorder.state !== 'inactive') {
            mediaRecorder.stop();
        }
    });

    function processSegmentUpload() {
        liveIndicator.style.display = 'none';
        btnStop.style.display = 'none';
        spinner.style.display = 'flex';
        overlay.style.display = 'flex';
        announcerMsg.innerText = "Transmitting response data arrays directly to WordPress repository...";

        const compiledBlob = new Blob(recordedChunks, { type: mediaRecorder.mimeType || 'video/webm' });
        const formatExt = mediaRecorder.mimeType.includes('mp4') ? 'mp4' : 'webm';
        
        const payloadTitle = `lvi-response-stream-Q${activePostId}`;
        const outputFilename = `${payloadTitle}.${formatExt}`;

        const dataForm = new FormData();
        dataForm.append('file', compiledBlob, outputFilename);
        dataForm.append('title', payloadTitle);

        fetch(`${restEndpoint}wp/v2/media`, {
            method: 'POST',
            headers: { 'X-WP-Nonce': authNonce },
            body: dataForm
        })
        .then(async res => {
            if (!res.ok) {
                const parseErr = await res.json();
                throw new Error(parseErr?.message || `HTTP Link Error: ${res.status}`);
            }
            return res.json();
        })
        .then(mediaObject => {
            // Target the custom proxy namespace route to bypass core dashboard constraints
            return fetch(`${restEndpoint}lvi/v1/submit-response`, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': authNonce,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    post_id: activePostId,
                    media_id: mediaObject.id
                })
            });
        })
        .then(async res => {
            if (!res.ok) {
                const parseErr = await res.json();
                throw new Error(parseErr?.message || "Failed to update custom post type metadata indicators.");
            }
            window.location.reload();
        })
        .catch(err => {
            spinner.style.display = 'none';
            overlay.style.display = 'none';
            if (videoDevices.length > 1) btnToggleCam.style.display = 'flex';
            alert(`File Transfer Tracking Trace Error: ${err.message}`);
            btnRec.style.display = 'inline-block';
        });
    }
});