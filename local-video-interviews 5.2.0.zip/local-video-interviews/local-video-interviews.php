<?php
/**
 * Plugin Name: Local Video Interviews (Enterprise Edition)
 * Description: Widescreen 16:9 async framework with lightbox forms, PRG session-based clean redirection blocks, robust admin moderation pipelines, media-locked revocation safeguards, and authenticated star-rating aggregates.
 * Version: 5.2.0
 * Author: BhoomiTech Heritage and Development Foundation
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// 1. CORE DATABASE UNIT INITIALIZATION
add_action( 'init', 'lvi_register_question_cpt' );
function lvi_register_question_cpt() {
    $labels = array(
        'name'               => 'Interview Questions',
        'singular_name'      => 'Interview Question',
        'menu_name'          => 'Interview Board',
        'add_new_item'       => 'Add New Question',
        'edit_item'          => 'Edit Question Properties',
        'all_items'          => 'All Questions',
    );
    $args = array(
        'labels'             => $labels,
        'public'             => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'capability_type'    => 'post',
        'has_archive'        => false,
        'hierarchical'       => false,
        'supports'           => array( 'title' ), 
        'show_in_rest'       => true, 
        'menu_icon'          => 'dashicons-video-camera',
    );
    register_post_type( 'interview_question', $args );
}

// 2. CAPACITY & POOL CONFIGURATION CONSOLE
add_action('admin_menu', 'lvi_add_admin_menu');
function lvi_add_admin_menu() {
    add_submenu_page('edit.php?post_type=interview_question', 'Global Pool Budget', 'Time Pool Settings', 'manage_options', 'lvi-pool-settings', 'lvi_render_pool_settings');
}

function lvi_render_pool_settings() {
    if (!current_user_can('manage_options')) return;

    if (isset($_POST['lvi_save_pool']) && check_admin_referer('lvi_pool_nonce')) {
        update_option('lvi_global_time_budget', absint($_POST['lvi_global_budget']));
        update_option('lvi_default_q_duration', absint($_POST['lvi_default_duration']));
        echo '<div class="updated"><p>Capacity pool parameters synchronized.</p></div>';
    }

    $global_budget = get_option('lvi_global_time_budget', 1200); 
    $default_duration = get_option('lvi_default_q_duration', 60); 
    $current_allocated_pool = lvi_get_total_allocated_seconds();
    $remaining_pool = $global_budget - $current_allocated_pool;
    ?>
    <div class="wrap">
        <h1>Media Flooding Restraint Management</h1>
        <div class="notice notice-info inline" style="margin-top:15px; padding:15px;">
            <p style="font-size:14px; margin:0 0 8px 0;"><strong>Active Allocation Metrics:</strong></p>
            <ul style="margin:0; padding-left:20px;">
                <li>Total Pool Storage Capacity: <strong><?php echo $global_budget; ?> seconds</strong></li>
                <li>Currently Reserved by Open Tasks: <strong style="color:#cca100;"><?php echo $current_allocated_pool; ?> seconds</strong></li>
                <li>Remaining Space for New Submissions: <strong style="color:#46b450;"><?php echo max(0, $remaining_pool); ?> seconds</strong></li>
            </ul>
        </div>
        <form method="post" action="" style="margin-top:20px;">
            <?php wp_nonce_field('lvi_pool_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th>Global Pool Limit (Seconds)</th>
                    <td><input type="number" name="lvi_global_budget" value="<?php echo esc_attr($global_budget); ?>" class="regular-text"></td>
                </tr>
                <tr>
                    <th>Default Question Length (Seconds)</th>
                    <td><input type="number" name="lvi_default_duration" value="<?php echo esc_attr($default_duration); ?>" class="small-text"> seconds</td>
                </tr>
            </table>
            <input type="submit" name="lvi_save_pool" class="button button-primary" value="Save Pool Configuration">
        </form>
    </div>
    <?php
}

function lvi_get_total_allocated_seconds() {
    $active_questions = get_posts(array(
        'post_type'      => 'interview_question',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_query'     => array(
            array('key' => '_lvi_status', 'value' => 'open', 'compare' => '=')
        )
    ));
    $total = 0;
    foreach ($active_questions as $q) {
        $q_limit = get_post_meta($q->ID, '_lvi_time_limit', true);
        $total += !empty($q_limit) ? absint($q_limit) : absint(get_option('lvi_default_q_duration', 60));
    }
    return $total;
}

// 3. ADMINISTRATIVE WORKSPACE MODERATION PANEL (METABOX)
add_action( 'add_meta_boxes', 'lvi_add_assignment_meta_box' );
function lvi_add_assignment_meta_box() {
    add_meta_box( 'lvi_assignment_meta', 'Question Metadata & Moderation Console', 'lvi_render_meta_box_callback', 'interview_question', 'normal', 'high' );
}

function lvi_render_meta_box_callback( $post ) {
    wp_nonce_field( 'lvi_save_meta_box_data', 'lvi_meta_box_nonce' );
    
    $current_allocation = get_post_meta( $post->ID, '_lvi_assigned_user', true );
    $current_status     = get_post_meta( $post->ID, '_lvi_status', true );
    $q_time_limit       = get_post_meta( $post->ID, '_lvi_time_limit', true );
    
    $moderation         = get_post_meta( $post->ID, '_lvi_moderation', true );
    if (!$moderation) { $moderation = ($post->post_status === 'pending') ? 'disallowed' : 'allowed'; }
    
    $mod_reason         = get_post_meta( $post->ID, '_lvi_disallow_reason', true );
    $attached_video_id  = get_post_meta( $post->ID, '_lvi_attached_video_id', true );
    
    $rating_sum         = (int) get_post_meta( $post->ID, '_lvi_rating_sum', true );
    $rating_count       = (int) get_post_meta( $post->ID, '_lvi_rating_count', true );
    $avg_rating         = $rating_count > 0 ? round($rating_sum / $rating_count, 1) : 0;
    
    if ( ! $current_status ) $current_status = 'open';
    if ( empty($q_time_limit) ) $q_time_limit = get_option('lvi_default_q_duration', 60);

    $users = get_users( array( 'fields' => array( 'user_login' ) ) );
    ?>
    <table class="form-table">
        <tr style="background:#f0f6e3;"><th colspan="2"><strong>Moderation & Verification Pipeline</strong></th></tr>
        <tr>
            <th>Moderation Status</th>
            <td>
                <select name="lvi_moderation" style="font-weight:bold;">
                    <option value="allowed" <?php selected( $moderation, 'allowed' ); ?>>✓ Allowed / Visible on Frontend Workflow</option>
                    <option value="disallowed" <?php selected( $moderation, 'disallowed' ); ?>>❌ Disallowed / Place to Pending Review & Hide</option>
                </select>
            </td>
        </tr>
        <tr>
            <th>Reason for Disallowance</th>
            <td>
                <input type="text" name="lvi_disallow_reason" value="<?php echo esc_attr($mod_reason); ?>" class="large-text" placeholder="e.g., Off-topic question...">
            </td>
        </tr>
        <tr style="background:#f7f9fa;"><th colspan="2"><strong>Assignment Details</strong></th></tr>
        <tr>
            <th>Assigned Registered User</th>
            <td>
                <select name="lvi_assigned_user">
                    <option value="">-- Open Allocation Pool --</option>
                    <?php foreach ( $users as $u ) : ?>
                        <option value="<?php echo esc_attr( $u->user_login ); ?>" <?php selected( $current_allocation, $u->user_login ); ?>><?php echo esc_html( $u->user_login ); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th>Recording Limit (Seconds)</th>
            <td><input type="number" name="lvi_time_limit" value="<?php echo esc_attr($q_time_limit); ?>" class="small-text"> seconds</td>
        </tr>
        <tr>
            <th>Current Status State</th>
            <td>
                <select name="lvi_status">
                    <option value="open" <?php selected( $current_status, 'open' ); ?>>● Open / Unanswered</option>
                    <option value="closed" <?php selected( $current_status, 'closed' ); ?>>🔒 Closed / Answered</option>
                </select>
            </td>
        </tr>
        <tr>
            <th>Community Evaluation</th>
            <td>
                <strong>⭐ <?php echo $avg_rating; ?> / 5.0</strong> (Calculated from <?php echo $rating_count; ?> registered reviews)
            </td>
        </tr>
        <tr>
            <th>Attached Media Artifact</th>
            <td>
                <?php if ( $attached_video_id && wp_get_attachment_url($attached_video_id) ) : ?>
                    <span style="color:#46b450; font-weight:bold;">✓ Video File Linked (ID: <?php echo $attached_video_id; ?>)</span><br>
                    <a href="<?php echo esc_url(wp_get_attachment_url($attached_video_id)); ?>" target="_blank">Download or Review Uploaded Stream Asset</a>
                <?php else: ?>
                    <span style="color:#cca100;">No video responses linked yet.</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <?php
}

add_action( 'save_post', 'lvi_save_question_meta_data' );
function lvi_save_question_meta_data( $post_id ) {
    if ( ! isset( $_POST['lvi_meta_box_nonce'] ) || ! wp_verify_nonce( $_POST['lvi_meta_box_nonce'], 'lvi_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['lvi_assigned_user'] ) ) update_post_meta( $post_id, '_lvi_assigned_user', sanitize_text_field( $_POST['lvi_assigned_user'] ) );
    if ( isset( $_POST['lvi_time_limit'] ) ) update_post_meta( $post_id, '_lvi_time_limit', absint( $_POST['lvi_time_limit'] ) );
    if ( isset( $_POST['lvi_status'] ) ) update_post_meta( $post_id, '_lvi_status', sanitize_text_field( $_POST['lvi_status'] ) );
    if ( isset( $_POST['lvi_disallow_reason'] ) ) update_post_meta( $post_id, '_lvi_disallow_reason', sanitize_text_field( $_POST['lvi_disallow_reason'] ) );
    
    if ( isset( $_POST['lvi_moderation'] ) ) {
        $mod_choice = sanitize_text_field( $_POST['lvi_moderation'] );
        update_post_meta( $post_id, '_lvi_moderation', $mod_choice );
        
        remove_action( 'save_post', 'lvi_save_question_meta_data' );
        if ( $mod_choice === 'disallowed' ) {
            wp_update_post( array( 'ID' => $post_id, 'post_status' => 'pending' ) );
        } else {
            wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
        }
        add_action( 'save_post', 'lvi_save_question_meta_data' );
    }
}

// Helper tracking context key builder to segregate session feedback states safely
function lvi_get_user_session_token() {
    if ( is_user_logged_in() ) {
        return 'lvi_user_' . get_current_user_id();
    }
    return 'lvi_guest_' . md5($_SERVER['REMOTE_ADDR'] . $_SERVER['HTTP_USER_AGENT']);
}

// STRICT FRONTEND ISOLATION FOR RESPONDENT ROLES
add_action('admin_init', 'lvi_restrict_dashboard_access');
function lvi_restrict_dashboard_access() {
    if (defined('DOING_AJAX') && DOING_AJAX) return;
    
    if (current_user_can('read') && !current_user_can('manage_options')) {
        wp_safe_redirect(home_url());
        exit;
    }
}

// 4. SHORTCODE ENGINE INTERACTIVE INTERFACE
add_shortcode('local_interview', 'lvi_render_interview_playlist_system');
function lvi_render_interview_playlist_system() {
    $current_user = wp_get_current_user();
    $current_username = is_user_logged_in() ? $current_user->user_login : '';
    $session_key = lvi_get_user_session_token();

    // INTERCEPT ENGINE A: Post-Redirect-Get (PRG) Framework driven by Transient Memory Pools
    if ( isset( $_POST['lvi_add_front_q'] ) && check_admin_referer( 'lvi_front_q_nonce' ) ) {
        $q_content = sanitize_textarea_field( $_POST['lvi_question_text'] );
        $alloc_to  = sanitize_text_field( $_POST['lvi_target_user'] );
        $sub_name  = sanitize_text_field( $_POST['lvi_submitter_name'] );
        $sub_email = sanitize_email( $_POST['lvi_submitter_email'] );

        $global_budget  = get_option('lvi_global_time_budget', 1200);
        $default_length = get_option('lvi_default_q_duration', 60);
        $current_used   = lvi_get_total_allocated_seconds();

        $baseline_clean_url = home_url($GLOBALS['wp']->request) . '/';

        if ( !empty($q_content) && is_email($sub_email) && !empty($sub_name) ) {
            if ( ($current_used + $default_length) <= $global_budget ) {
                $new_id = wp_insert_post( array(
                    'post_title'  => $q_content,
                    'post_type'   => 'interview_question',
                    'post_status' => 'publish'
                ) );
                if ( $new_id ) {
                    update_post_meta( $new_id, '_lvi_assigned_user', $alloc_to );
                    update_post_meta( $new_id, '_lvi_time_limit', $default_length );
                    update_post_meta( $new_id, '_lvi_status', 'open' );
                    update_post_meta( $new_id, '_lvi_moderation', 'allowed' ); 
                    update_post_meta( $new_id, '_lvi_guest_name', $sub_name );
                    update_post_meta( $new_id, '_lvi_guest_email', $sub_email );
                    
                    set_transient('lvi_status_msg_' . $session_key, 'success', 45);
                    wp_safe_redirect($baseline_clean_url);
                    exit;
                }
            } else {
                set_transient('lvi_status_msg_' . $session_key, 'overflow', 45);
                wp_safe_redirect($baseline_clean_url);
                exit;
            }
        } else {
            set_transient('lvi_status_msg_' . $session_key, 'invalid', 45);
            wp_safe_redirect($baseline_clean_url);
            exit;
        }
    }

    // INTERCEPT ENGINE B: Claim Assignment Action Handler
    if ( is_user_logged_in() && isset( $_POST['lvi_claim_question'] ) && check_admin_referer( 'lvi_claim_nonce' ) ) {
        $target_claim_id = absint( $_POST['question_id'] );
        if ( get_post_status($target_claim_id) === 'publish' && empty( get_post_meta( $target_claim_id, '_lvi_assigned_user', true ) ) ) {
            update_post_meta( $target_claim_id, '_lvi_assigned_user', $current_username );
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        }
    }

    // INTERCEPT ENGINE C: Revoke Assignment Action Handler
    if ( is_user_logged_in() && isset( $_POST['lvi_revoke_question'] ) && check_admin_referer( 'lvi_revoke_nonce' ) ) {
        $target_revoke_id = absint( $_POST['question_id'] );
        $attached_video_id = get_post_meta( $target_revoke_id, '_lvi_attached_video_id', true );
        $current_db_status = get_post_meta( $target_revoke_id, '_lvi_status', true );
        $existing_owner    = get_post_meta( $target_revoke_id, '_lvi_assigned_user', true );
        $has_active_file = ( $attached_video_id && wp_get_attachment_url($attached_video_id) );

        if ( ! $has_active_file && $current_db_status !== 'closed' && strcasecmp( $existing_owner, $current_username ) === 0 ) {
            update_post_meta( $target_revoke_id, '_lvi_assigned_user', '' ); 
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        } else {
            set_transient('lvi_status_msg_' . $session_key, 'revokelocked', 45);
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        }
    }

    // Fetch and instantly clean up session feedback alerts
    $active_feedback_msg = get_transient('lvi_status_msg_' . $session_key);
    if ( $active_feedback_msg ) {
        delete_transient('lvi_status_msg_' . $session_key);
    }

    wp_enqueue_script('lvi-playlist-recorder', plugin_dir_url(__FILE__) . 'uploader.js', array(), time(), true);
    $all_registered_users = get_users( array( 'fields' => array( 'user_login' ) ) );

    $query_args = array(
        'post_type'      => 'interview_question',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'order'          => 'ASC'
    );

    if ( ! is_user_logged_in() ) {
        $query_args['meta_query'] = array(
            array(
                'key'   => '_lvi_status',
                'value' => 'closed',
                'compare' => '='
            )
        );
    }

    $questions_posts = get_posts( $query_args );
    ob_start();
    ?>
    <div style="max-width: 700px; margin: 20px auto; font-family: -apple-system, BlinkMacSystemFont, sans-serif; display: flex; flex-direction: column; gap: 20px;">
        
        <?php if ( $active_feedback_msg ) : ?>
            <?php if ( $active_feedback_msg === 'success' ) : ?>
                <div style="padding:14px; background:#e6f6eb; border:1px solid #46b450; color:#1d5628; border-radius:6px; font-size:13px;">✓ Question successfully appended to the pipeline registry timeline.</div>
            <?php elseif ( $active_feedback_msg === 'overflow' ) : ?>
                <div style="padding:14px; background:#fcf1f1; border:1px solid #d63636; color:#d63636; border-radius:6px; font-size:13px;"><strong>Submission Blocked:</strong> Platform recording capacity limits reached.</div>
            <?php elseif ( $active_feedback_msg === 'invalid' ) : ?>
                <div style="padding:14px; background:#fcf1f1; border:1px solid #d63636; color:#d63636; border-radius:6px; font-size:13px;"><strong>Error:</strong> Please fill in all required configuration text strings.</div>
            <?php elseif ( $active_feedback_msg === 'revokelocked' ) : ?>
                <div style="padding:14px; background:#fcf1f1; border:1px solid #d63636; color:#d63636; border-radius:6px; font-size:13px;"><strong>Revocation Blocked:</strong> This assignment is frozen because a video response has been saved to the Media Library.</div>
            <?php endif; ?>
        <?php endif; ?>

        <div style="display:flex; justify-content:space-between; align-items:center; background:#f8fafc; border:1px solid #e2e8f0; padding:15px 20px; border-radius:12px;">
            <div>
                <h4 style="margin:0 0 2px 0; font-size:14px; color:#1e293b; font-weight:bold;">Have an Inquiry?</h4>
                <p style="margin:0; font-size:12px; color:#64748b;">Submit a question prompt for registered members to record an answer.</p>
            </div>
            <button id="lvi-open-modal-trigger" style="background:#2271b1; color:#fff; border:none; padding:10px 18px; border-radius:6px; font-size:13px; font-weight:bold; cursor:pointer;" onclick="document.getElementById('lvi-submission-lightbox').style.display='flex';">➕ Add Question Prompt</button>
        </div>

        <div id="lvi-submission-lightbox" style="position:fixed; inset:0; background:rgba(15,23,42,0.6); backdrop-filter:blur(4px); z-index:99999; display:none; align-items:center; justify-content:center; padding:20px;">
            <div style="background: #fff; width: 100%; max-width: 520px; border-radius: 12px; padding: 25px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.15); display:flex; flex-direction:column; gap:15px; position:relative; border: 1px solid #e2e8f0;">
                <button style="position:absolute; top:15px; right:15px; background:none; border:none; font-size:20px; cursor:pointer; color:#64748b;" onclick="document.getElementById('lvi-submission-lightbox').style.display='none';">✕</button>
                <h3 style="margin: 0; font-size: 16px; color: #1e293b; font-weight: bold;">Submit Interview Request</h3>
                <form method="post" action="">
                    <?php wp_nonce_field( 'lvi_front_q_nonce' ); ?>
                    <div style="margin-bottom: 12px;">
                        <label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">Question Text / Prompt *</label>
                        <textarea name="lvi_question_text" rows="3" style="width:100%; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:13px; font-family:inherit;" required placeholder="What specific information are you requesting?"></textarea>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 12px;">
                        <div>
                            <label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">Your Full Name *</label>
                            <input type="text" name="lvi_submitter_name" style="width:100%; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:13px;" required placeholder="e.g., Jane Doe">
                        </div>
                        <div>
                            <label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">Your Valid Email ID *</label>
                            <input type="email" name="lvi_submitter_email" style="width:100%; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:13px;" required placeholder="name@domain.com">
                        </div>
                    </div>
                    <div style="margin-bottom: 15px;">
                        <label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">Allocate Target Responder (Optional)</label>
                        <select name="lvi_target_user" style="width:100%; border:1px solid #cbd5e1; border-radius:6px; padding:8px; font-size:13px; background:#fff; font-family:inherit;">
                            <option value="">-- Open Community Claim Allocation --</option>
                            <?php foreach ( $all_registered_users as $ru ) : ?>
                                <option value="<?php echo esc_attr( $ru->user_login ); ?>">@<?php echo esc_html( $ru->user_login ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div style="display:flex; justify-content:flex-end; gap:10px;">
                        <button type="button" style="background:#cbd5e1; color:#334155; border:none; padding:8px 14px; border-radius:6px; font-size:13px; font-weight:bold; cursor:pointer;" onclick="document.getElementById('lvi-submission-lightbox').style.display='none';">Cancel</button>
                        <input type="submit" name="lvi_add_front_q" value="Publish to Board" style="background: #2271b1; color: #fff; border: none; padding: 8px 16px; border-radius: 6px; font-size: 13px; font-weight: bold; cursor: pointer;">
                    </div>
                </form>
            </div>
        </div>

        <?php if ( is_user_logged_in() ) : ?>
            <div id="lvi-playlist-container" 
                 data-root="<?php echo esc_url_raw(rest_url()); ?>"
                 data-nonce="<?php echo esc_attr(wp_create_nonce('wp_rest')); ?>"
                 style="background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 20px rgba(15,23,42,0.06); display: flex; flex-direction: column; gap: 20px; border:1px solid #e2e8f0;">
                
                <div style="position: relative; width: 100%; aspect-ratio: 16/9; background: #090d16; border-radius: 8px; overflow: hidden; box-shadow: inset 0 0 40px rgba(0,0,0,0.85);">
                    <video id="lvi-video-monitor" autoplay muted playsinline style="width: 100%; height: 100%; object-fit: cover; transform: scaleX(-1);"></video>
                    
                    <button id="lvi-toggle-camera" style="display: none; position: absolute; top: 15px; right: 15px; width: 36px; height: 36px; background: rgba(15, 23, 42, 0.75); border: 1px solid rgba(255, 255, 255, 0.25); color: #fff; border-radius: 50%; cursor: pointer; z-index: 100; align-items: center; justify-content: center; font-size: 16px; transition: background 0.2s;" title="Switch Camera" onmouseover="this.style.background='rgba(34, 113, 177, 0.9)'" onmouseout="this.style.background='rgba(15, 23, 42, 0.75)'">
                        🔄
                    </button>

                    <div id="lvi-rec-timer" style="position: absolute; top: 15px; left: 15px; background: rgba(220,38,38,0.9); color: #fff; padding: 4px 10px; border-radius: 4px; font-weight: bold; font-size: 12px; display: none; align-items: center; gap: 6px;">
                        <span style="width: 8px; height: 8px; background: #fff; border-radius: 50%; display: inline-block; animation: pulse 1s infinite alternate;"></span> LIVE REC
                    </div>
                    <div id="lvi-overlay-announcer" style="position: absolute; inset: 0; background: rgba(15,23,42,0.8); display: flex; flex-direction: column; align-items: center; justify-content: center; color: #fff; padding: 20px; text-align: center;">
                        <p id="lvi-announcer-msg" style="margin: 0; font-size: 14px;">Initializing camera stream assets...</p>
                    </div>
                </div>

                <div style="display: flex; gap: 10px; min-height: 44px; justify-content: center;">
                    <button id="lvi-trigger-rec" style="display: none; background: #dc2626; color: #fff; border: none; padding: 10px 24px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 14px;">Record Answer</button>
                    <button id="lvi-trigger-stop" style="display: none; background: #0f172a; color: #fff; border: none; padding: 10px 24px; border-radius: 6px; font-weight: bold; cursor: pointer; font-size: 14px;">Finish & Save Response</button>
                    <div id="lvi-process-spinner" style="display: none; align-items: center; color: #2271b1; font-weight: 600; font-size: 14px;">Transmitting media stream binary array structures...</div>
                </div>

                <div id="lvi-active-focus-zone" style="background: #f8fafc; padding: 20px; border-radius: 8px; border-top: 4px solid #2271b1; display: flex; flex-direction: column; gap: 12px;">
                    <div>
                        <h4 style="margin: 0 0 4px 0; color: #64748b; font-size: 11px; text-transform: uppercase; font-weight: bold; letter-spacing:0.5px;">Focused Target Prompt</h4>
                        <div id="lvi-focused-question-text" style="font-size: 14px; font-weight: 600; color: #0f172a; line-height: 1.4;">Select an entry block from the timeline registry.</div>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 5px;">
                        <label for="lvi-teleprompter-notes" style="font-size: 11px; font-weight: 600; color: #64748b;">Optional Teleprompter Reader Notes:</label>
                        <textarea id="lvi-teleprompter-notes" rows="3" style="width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 8px; font-size: 13px; color: #334155; resize: vertical; font-family:inherit;" placeholder="Paste reference scripts here to read while looking at the camera lens..."></textarea>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div id="lvi-playlist-global-board" 
             data-root="<?php echo esc_url_raw(rest_url()); ?>" 
             data-nonce="<?php echo esc_attr(wp_create_nonce('wp_rest')); ?>"
             style="background: #fff; padding: 25px; border-radius: 12px; box-shadow: 0 4px 20px rgba(15,23,42,0.06); border:1px solid #e2e8f0;">
            
            <h3 style="margin: 0 0 15px 0; font-size: 15px; color: #1e293b; font-weight: bold;">
                <?php echo is_user_logged_in() ? 'Timeline Pipeline Queue' : 'Published Video Responses Archive'; ?>
            </h3>
            
            <div id="lvi-question-queue-list" style="display: flex; flex-direction: column; gap: 10px; max-height: 450px; overflow-y: auto; padding-right:4px;">
                <?php 
                if ( empty( $questions_posts ) ) {
                    echo '<p style="color:#64748b; font-size:13px; text-align:center; padding:20px;">No verified video responses are currently listed on the tracking board.</p>';
                }

                foreach ( $questions_posts as $index => $q_post ) : 
                    $assigned_user     = get_post_meta( $q_post->ID, '_lvi_assigned_user', true );
                    $current_status    = get_post_meta( $q_post->ID, '_lvi_status', true );
                    $q_limit           = get_post_meta( $q_post->ID, '_lvi_time_limit', true );
                    $attached_video_id = get_post_meta( $q_post->ID, '_lvi_attached_video_id', true );
                    
                    $rating_sum        = (int) get_post_meta( $q_post->ID, '_lvi_rating_sum', true );
                    $rating_count      = (int) get_post_meta( $q_post->ID, '_lvi_rating_count', true );
                    $avg_rating        = $rating_count > 0 ? round($rating_sum / $rating_count, 1) : 0;
                    
                    if (empty($q_limit)) $q_limit = get_option('lvi_default_q_duration', 60);
                    
                    $is_done           = ( $current_status === 'closed' );
                    $is_assigned_to_me = ( ! empty( $assigned_user ) && strcasecmp( $assigned_user, $current_username ) === 0 );
                    $is_unallocated    = empty( $assigned_user );
                    
                    $video_url         = ($is_done && $attached_video_id) ? wp_get_attachment_url($attached_video_id) : '';
                    $has_file          = !empty($video_url);

                    if ( $is_done ) {
                        $status_label = '🔒 Answered by @' . esc_html($assigned_user); 
                        $badge_color = '#475569'; $can_record = 'false'; $item_bg = '#f8fafc'; $item_border = '#cbd5e1';
                    } elseif ( $is_unallocated ) {
                        $status_label = '● Open Target'; $badge_color = '#2271b1'; $can_record = 'false'; $item_bg = '#fff'; $item_border = '#b4fee4';
                    } elseif ( ! $is_assigned_to_me ) {
                        $status_label = '🔒 Claimed by @' . esc_html( $assigned_user ); $badge_color = '#d97706'; $can_record = 'false'; $item_bg = '#fffbeb'; $item_border = '#fef3c7';
                    } else {
                        $status_label = '✓ Assigned to You'; $badge_color = '#16a34a'; $can_record = 'true'; $item_bg = '#f0fdf4'; $item_border = '#bbf7d0';
                    }
                    ?>
                    <div class="lvi-queue-item" 
                         data-postid="<?php echo $q_post->ID; ?>"
                         data-idx="<?php echo $index; ?>" 
                         data-done="<?php echo $is_done ? 'true' : 'false'; ?>"
                         data-allowed="<?php echo $can_record; ?>"
                         data-limit="<?php echo esc_attr($q_limit); ?>"
                         data-unallocated="<?php echo $is_unallocated ? 'true' : 'false'; ?>"
                         data-user="<?php echo esc_attr( $is_unallocated ? 'Nobody' : $assigned_user ); ?>"
                         data-videourl="<?php echo esc_url($video_url); ?>"
                         style="background: <?php echo $item_bg; ?>; border: 1px solid <?php echo $item_border; ?>; padding: 14px; border-radius: 8px; cursor: pointer; transition: all 0.15s ease; display:flex; flex-direction:column; gap:5px;">
                        
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <span style="font-size: 10px; font-weight: bold; color: #64748b; letter-spacing:0.3px;">BOUND: <?php echo $q_limit; ?>s</span>
                            
                            <div style="display:flex; align-items:center; gap:8px;">
                                <?php if ($is_done && $rating_count > 0) : ?>
                                    <span style="font-size: 11px; font-weight: bold; color: #b45309; background: #fef3c7; padding: 2px 6px; border-radius: 4px;">⭐ <?php echo $avg_rating; ?></span>
                                <?php endif; ?>
                                <span class="lvi-badge" style="font-size: 11px; font-weight: bold; color: <?php echo $badge_color; ?>;">
                                    <?php echo $status_label; ?>
                                </span>
                            </div>
                        </div>

                        <div class="lvi-q-body-text" style="font-size: 13px; color: #334155; font-weight: 500; line-height:1.4;">
                            <?php echo esc_html( $q_post->post_title ); ?>
                        </div>

                        <div style="display:flex; gap:8px; align-items:center; margin-top:4px;" onclick="event.stopPropagation();">
                            <?php if ( is_user_logged_in() && $is_unallocated && ! $is_done ) : ?>
                                <form method="post" action="" style="margin:0;">
                                    <?php wp_nonce_field( 'lvi_claim_nonce' ); ?>
                                    <input type="hidden" name="question_id" value="<?php echo $q_post->ID; ?>">
                                    <input type="submit" name="lvi_claim_question" value="⚡ Claim Slot" style="background:#2271b1; color:#fff; border:none; padding:5px 10px; border-radius:4px; font-size:11px; font-weight:bold; cursor:pointer;">
                                </form>
                            <?php endif; ?>

                            <?php if ( is_user_logged_in() && $is_assigned_to_me && ! $is_done && ! $has_file ) : ?>
                                <form method="post" action="" style="margin:0;">
                                    <?php wp_nonce_field( 'lvi_revoke_nonce' ); ?>
                                    <input type="hidden" name="question_id" value="<?php echo $q_post->ID; ?>">
                                    <input type="submit" name="lvi_revoke_question" value="↩ Revoke Assignment" style="background:#64748b; color:#fff; border:none; padding:5px 10px; border-radius:4px; font-size:11px; font-weight:bold; cursor:pointer;" onmouseover="this.style.background='#dc2626'" onmouseout="this.style.background='#64748b'">
                                </form>
                            <?php endif; ?>

                            <?php if ( $is_done && $has_file ) : ?>
                                <button class="lvi-view-response-trigger" 
                                        data-src="<?php echo esc_url($video_url); ?>" 
                                        data-postid="<?php echo $q_post->ID; ?>"
                                        style="background: #1e293b; color: #fff; border: none; padding: 5px 10px; border-radius: 4px; font-size: 11px; font-weight: bold; cursor: pointer; display: inline-flex; align-items: center; gap: 4px;"
                                        onclick="lviLaunchVideoPlaybackModal(this.getAttribute('data-src'), this.getAttribute('data-postid'));">
                                    👁 View Response & Rate
                                </button>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <div id="lvi-playback-lightbox" style="position:fixed; inset:0; background:rgba(9,13,22,0.85); backdrop-filter:blur(5px); z-index:999999; display:none; align-items:center; justify-content:center; padding:20px;" onclick="lviCloseVideoPlaybackModal();">
        <div style="width:100%; max-width:760px; background:#1e293b; border-radius:12px; overflow:hidden; position:relative; box-shadow:0 25px 50px -12px rgba(0,0,0,0.5); display:flex; flex-direction:column;" onclick="event.stopPropagation();">
            <button style="position:absolute; top:12px; right:15px; background:rgba(255,255,255,0.2); border:none; color:#fff; font-size:14px; font-weight:bold; width:28px; height:28px; border-radius:50%; cursor:pointer; display:flex; align-items:center; justify-content:center; z-index:10;" onclick="lviCloseVideoPlaybackModal();">✕</button>
            
            <div style="width:100%; aspect-ratio:16/9; background:#000;">
                <video id="lvi-playback-node" controls style="width:100%; height:100%; object-fit:contain;"></video>
            </div>

            <div id="lvi-rating-panel-area" style="background:#0f172a; padding:15px 20px; display:flex; justify-content:space-between; align-items:center; border-top:1px solid #334155;">
                <div>
                    <h5 style="margin:0; color:#fff; font-size:13px; font-weight:600;">Evaluate this Community Stream Response</h5>
                    <p style="margin:2px 0 0 0; color:#94a3b8; font-size:11px;">Your selection helps filter high-quality information aggregates.</p>
                </div>
                
                <div style="display:flex; align-items:center; gap:12px;">
                    <?php if ( is_user_logged_in() ) : ?>
                        <div class="lvi-stars-input-row" style="display:flex; gap:4px; flex-direction:row-reverse;">
                            <span class="lvi-star-node" data-val="5" style="font-size:24px; color:#475569; cursor:pointer; transition:color 0.1s ease;">★</span>
                            <span class="lvi-star-node" data-val="4" style="font-size:24px; color:#475569; cursor:pointer; transition:color 0.1s ease;">★</span>
                            <span class="lvi-star-node" data-val="3" style="font-size:24px; color:#475569; cursor:pointer; transition:color 0.1s ease;">★</span>
                            <span class="lvi-star-node" data-val="2" style="font-size:24px; color:#475569; cursor:pointer; transition:color 0.1s ease;">★</span>
                            <span class="lvi-star-node" data-val="1" style="font-size:24px; color:#475569; cursor:pointer; transition:color 0.1s ease;">★</span>
                        </div>
                        <div id="lvi-rating-status-text" style="font-size:12px; font-weight:bold; color:#38bdf8; min-width:80px; text-align:right;"></div>
                    <?php else : ?>
                        <span style="font-size:12px; font-weight:600; color:#94a3b8; background:#1e293b; padding:6px 12px; border-radius:6px; border:1px solid #334155;">
                            🔒 Please log in to submit a rating
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <style>
        .lvi-star-node:hover, .lvi-star-node:hover ~ .lvi-star-node { color: #f59e0b !important; }
        .lvi-star-node.selected, .lvi-star-node.selected ~ .lvi-star-node { color: #fbbf24 !important; }
        @keyframes pulse { from { opacity: 0.4; } to { opacity: 1; } }
    </style>

    <script>
    let lviActivePlaybackPostId = null;

    function lviLaunchVideoPlaybackModal(videoUrl, postId) {
        const modal = document.getElementById('lvi-playback-lightbox');
        const video = document.getElementById('lvi-playback-node');
        const statusText = document.getElementById('lvi-rating-status-text');
        
        lviActivePlaybackPostId = postId;
        
        if(statusText) statusText.innerText = "";
        document.querySelectorAll('.lvi-star-node').forEach(el => el.classList.remove('selected'));

        if(modal && video) {
            video.src = videoUrl;
            modal.style.display = 'flex';
            video.play();
        }
    }

    function lviCloseVideoPlaybackModal() {
        const modal = document.getElementById('lvi-playback-lightbox');
        const video = document.getElementById('lvi-playback-node');
        if(modal && video) {
            video.pause();
            video.src = "";
            modal.style.display = 'none';
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        const globalBoard = document.getElementById('lvi-playlist-global-board');
        if(!globalBoard) return;
        
        const restRoot = globalBoard.getAttribute('data-root');
        const restNonce = globalBoard.getAttribute('data-nonce');

        document.querySelectorAll('.lvi-star-node').forEach(star => {
            star.addEventListener('click', function() {
                const scoreValue = parseInt(this.getAttribute('data-val'));
                const statusText = document.getElementById('lvi-rating-status-text');
                
                document.querySelectorAll('.lvi-star-node').forEach(el => el.classList.remove('selected'));
                this.classList.add('selected');

                if (statusText) statusText.innerText = "Saving...";

                fetch(`${restRoot}lvi/v1/rate`, {
                    method: 'POST',
                    headers: {
                        'X-WP-Nonce': restNonce,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        post_id: lviActivePlaybackPostId,
                        rating: scoreValue
                    })
                })
                .then(res => res.json())
                .then(data => {
                    if(data.success) {
                        if (statusText) statusText.style.color = "#46b450";
                        if (statusText) statusText.innerText = "Saved! ⭐";
                        setTimeout(() => { window.location.reload(); }, 800);
                    } else {
                        if (statusText) statusText.innerText = data.message || "Error";
                    }
                })
                .catch(err => {
                    if (statusText) statusText.innerText = "Error Connection";
                });
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}

// 5. REST API ENDPOINTS REGISTRATION
add_action('rest_api_init', 'lvi_register_rest_metadata_fields');
function lvi_register_rest_metadata_fields() {
    register_rest_field('interview_question', 'meta', array(
        'get_callback' => function($post_arr) {
            return array(
                '_lvi_status'            => get_post_meta($post_arr['id'], '_lvi_status', true),
                '_lvi_attached_video_id' => get_post_meta($post_arr['id'], '_lvi_attached_video_id', true)
            );
        },
        'update_callback' => function($meta_dict, $post_obj) {
            if ( ! is_array( $meta_dict ) ) return;
            foreach ($meta_dict as $k => $v) {
                if ($k === '_lvi_status' && $v === 'open') {
                    $has_file = get_post_meta($post_obj->ID, '_lvi_attached_video_id', true);
                    if ($has_file) continue; 
                }
                update_post_meta($post_obj->ID, $k, sanitize_text_field($v));
            }
            return true;
        }
    ));

    register_rest_route('lvi/v1', '/rate', array(
        'methods'             => 'POST',
        'callback'            => 'lvi_process_rest_star_rating',
        'permission_callback' => function() {
            return is_user_logged_in(); 
        }
    ));

    // CUSTOM METADATA UPDATE ROUTE BYPASSING NATIVE CPT EDIT RESTRICTIONS FOR RESPONDENTS
    register_rest_route('lvi/v1', '/submit-response', array(
        'methods'             => 'POST',
        'callback'            => 'lvi_handle_frontend_meta_update',
        'permission_callback' => function() {
            return is_user_logged_in();
        }
    ));
}

function lvi_process_rest_star_rating($request) {
    $params  = $request->get_json_params();
    $post_id = isset($params['post_id']) ? absint($params['post_id']) : 0;
    $rating  = isset($params['rating']) ? absint($params['rating']) : 0;

    if (!$post_id || get_post_type($post_id) !== 'interview_question' || $rating < 1 || $rating > 5) {
        return new WP_Error('lvi_invalid_payload', 'Invalid tracking parameter references provided.', array('status' => 400));
    }

    $current_sum   = (int) get_post_meta($post_id, '_lvi_rating_sum', true);
    $current_count = (int) get_post_meta($post_id, '_lvi_rating_count', true);

    update_post_meta($post_id, '_lvi_rating_sum', $current_sum + $rating);
    update_post_meta($post_id, '_lvi_rating_count', $current_count + 1);

    return rest_ensure_response(array('success' => true));
}

function lvi_handle_frontend_meta_update($request) {
    $params   = $request->get_json_params();
    $post_id  = isset($params['post_id']) ? absint($params['post_id']) : 0;
    $media_id = isset($params['media_id']) ? absint($params['media_id']) : 0;
    
    if (!$post_id || !$media_id) {
        return new WP_Error('lvi_missing_data', 'Invalid metadata tracking payload data.', array('status' => 400));
    }

    $current_user = wp_get_current_user();
    $assigned_owner = get_post_meta($post_id, '_lvi_assigned_user', true);

    if (strcasecmp($assigned_owner, $current_user->user_login) !== 0) {
        return new WP_Error('lvi_unauthorized_owner', 'You do not hold active assignment rights for this slot.', array('status' => 403));
    }

    update_post_meta($post_id, '_lvi_status', 'closed');
    update_post_meta($post_id, '_lvi_attached_video_id', $media_id);

    return rest_ensure_response(array('success' => true));
}