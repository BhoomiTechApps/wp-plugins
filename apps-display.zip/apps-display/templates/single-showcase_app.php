<?php
/**
 * Single Application Template
 * Used when "Use Plugin Template" is enabled in settings.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

get_header();

$opts        = get_option( 'asc_settings', [] );
$show_sidebar = ( $opts['show_sidebar'] ?? '0' ) === '1';
$post_id     = get_the_ID();
$meta        = ASC_Shortcode::get_meta( $post_id );
$thumbnail   = get_the_post_thumbnail_url( $post_id, 'full' );
$screenshots = $meta['asc_screenshots'] ? explode( ',', $meta['asc_screenshots'] ) : [];
$cats        = get_the_terms( $post_id, 'app_category' ) ?: [];
$tags        = get_the_terms( $post_id, 'app_tag' )      ?: [];
$statuses    = get_the_terms( $post_id, 'app_status' )   ?: [];
$badge_text  = $meta['asc_badge_text'];
$badge_color = $meta['asc_badge_color'] ?: ( $opts['accent_color'] ?? '#4f46e5' );
$accent      = $opts['accent_color'] ?? '#4f46e5';
?>

<style>
.asc-single { --asc-accent: <?php echo esc_attr( $accent ); ?>; }
</style>

<div class="asc-single <?php echo $show_sidebar ? 'asc-single--has-sidebar' : ''; ?>">

    <!-- Hero -->
    <div class="asc-single__hero" <?php if ( $thumbnail ) echo 'style="background-image:url(' . esc_url( $thumbnail ) . ')"'; ?>>
        <div class="asc-single__hero-overlay">
            <div class="asc-single__hero-inner">
                <?php if ( $cats ) : ?>
                <div class="asc-single__cats">
                    <?php foreach ( $cats as $cat ) : ?>
                    <a href="<?php echo esc_url( get_term_link( $cat ) ); ?>" class="asc-single__cat-link"><?php echo esc_html( $cat->name ); ?></a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <h1 class="asc-single__title"><?php the_title(); ?></h1>

                <?php if ( $meta['asc_short_desc'] ) : ?>
                <p class="asc-single__tagline"><?php echo esc_html( $meta['asc_short_desc'] ); ?></p>
                <?php endif; ?>

                <div class="asc-single__hero-actions">
                    <?php if ( $meta['asc_app_url'] ) : ?>
                    <a href="<?php echo esc_url( $meta['asc_app_url'] ); ?>" class="asc-single__btn asc-single__btn--primary" target="_blank" rel="noopener">
                        🚀 <?php esc_html_e( 'View Live App', 'apps-display' ); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ( $meta['asc_demo_url'] ) : ?>
                    <a href="<?php echo esc_url( $meta['asc_demo_url'] ); ?>" class="asc-single__btn" target="_blank" rel="noopener">
                        🎬 <?php esc_html_e( 'Watch Demo', 'apps-display' ); ?>
                    </a>
                    <?php endif; ?>
                    <?php if ( $meta['asc_repo_url'] ) : ?>
                    <a href="<?php echo esc_url( $meta['asc_repo_url'] ); ?>" class="asc-single__btn asc-single__btn--ghost" target="_blank" rel="noopener">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577v-2.165c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0 1 12 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.63-5.37-12-12-12z"/></svg>
                        <?php esc_html_e( 'Source Code', 'apps-display' ); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Main content area -->
    <div class="asc-single__wrap">

        <main class="asc-single__main">

            <!-- Meta pills row -->
            <div class="asc-single__meta-row">
                <?php if ( $meta['asc_version'] ) : ?>
                <div class="asc-single__meta-pill">
                    <span class="asc-single__meta-label"><?php esc_html_e( 'Version', 'apps-display' ); ?></span>
                    <span class="asc-single__meta-value">v<?php echo esc_html( $meta['asc_version'] ); ?></span>
                </div>
                <?php endif; ?>
                <?php if ( $meta['asc_release_date'] ) : ?>
                <div class="asc-single__meta-pill">
                    <span class="asc-single__meta-label"><?php esc_html_e( 'Released', 'apps-display' ); ?></span>
                    <span class="asc-single__meta-value"><?php echo esc_html( date_i18n( get_option('date_format'), strtotime( $meta['asc_release_date'] ) ) ); ?></span>
                </div>
                <?php endif; ?>
                <?php if ( $meta['asc_tech_stack'] ) : ?>
                <div class="asc-single__meta-pill">
                    <span class="asc-single__meta-label"><?php esc_html_e( 'Stack', 'apps-display' ); ?></span>
                    <span class="asc-single__meta-value"><?php echo esc_html( $meta['asc_tech_stack'] ); ?></span>
                </div>
                <?php endif; ?>
                <?php if ( $meta['asc_author_name'] ) : ?>
                <div class="asc-single__meta-pill">
                    <span class="asc-single__meta-label"><?php esc_html_e( 'Author', 'apps-display' ); ?></span>
                    <span class="asc-single__meta-value">
                        <?php if ( $meta['asc_author_url'] ) : ?>
                        <a href="<?php echo esc_url( $meta['asc_author_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $meta['asc_author_name'] ); ?></a>
                        <?php else : ?>
                        <?php echo esc_html( $meta['asc_author_name'] ); ?>
                        <?php endif; ?>
                    </span>
                </div>
                <?php endif; ?>
                <?php foreach ( $statuses as $st ) : ?>
                <div class="asc-single__meta-pill">
                    <span class="asc-single__meta-label"><?php esc_html_e( 'Status', 'apps-display' ); ?></span>
                    <span class="asc-status-pill asc-status-<?php echo esc_attr( $st->slug ); ?>"><?php echo esc_html( $st->name ); ?></span>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Description -->
            <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
            <div class="asc-single__content">
                <?php the_content(); ?>
            </div>
            <?php endwhile; endif; ?>

            <!-- Screenshots -->
            <?php if ( $screenshots ) : ?>
            <div class="asc-single__screenshots">
                <h2><?php esc_html_e( 'Screenshots', 'apps-display' ); ?></h2>
                <div class="asc-screenshots-grid">
                    <?php foreach ( $screenshots as $img_id ) :
                        $img_id  = (int) $img_id;
                        $full    = wp_get_attachment_image_url( $img_id, 'large' );
                        $thumb   = wp_get_attachment_image_url( $img_id, 'medium' );
                        $alt     = get_post_meta( $img_id, '_wp_attachment_image_alt', true );
                        if ( ! $full ) continue;
                    ?>
                    <a href="<?php echo esc_url( $full ); ?>" class="asc-screenshot-item" data-lightbox="asc-screenshots">
                        <img src="<?php echo esc_url( $thumb ); ?>" alt="<?php echo esc_attr( $alt ); ?>" loading="lazy">
                        <span class="asc-screenshot-zoom">🔍</span>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Tags -->
            <?php if ( $tags ) : ?>
            <div class="asc-single__tags-section">
                <strong><?php esc_html_e( 'Tags:', 'apps-display' ); ?></strong>
                <?php foreach ( $tags as $tag ) : ?>
                <a href="<?php echo esc_url( get_term_link( $tag ) ); ?>" class="asc-tag"><?php echo esc_html( $tag->name ); ?></a>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

        </main>

        <!-- Sidebar -->
        <?php if ( $show_sidebar ) : ?>
        <aside class="asc-single__sidebar">
            <div class="asc-single__sidebar-card">
                <h3><?php esc_html_e( 'Quick Links', 'apps-display' ); ?></h3>
                <ul class="asc-single__links">
                    <?php if ( $meta['asc_app_url'] ) : ?>
                    <li><a href="<?php echo esc_url( $meta['asc_app_url'] ); ?>" target="_blank" rel="noopener">🚀 <?php esc_html_e( 'Live App', 'apps-display' ); ?></a></li>
                    <?php endif; ?>
                    <?php if ( $meta['asc_demo_url'] ) : ?>
                    <li><a href="<?php echo esc_url( $meta['asc_demo_url'] ); ?>" target="_blank" rel="noopener">🎬 <?php esc_html_e( 'Demo', 'apps-display' ); ?></a></li>
                    <?php endif; ?>
                    <?php if ( $meta['asc_repo_url'] ) : ?>
                    <li><a href="<?php echo esc_url( $meta['asc_repo_url'] ); ?>" target="_blank" rel="noopener">💻 <?php esc_html_e( 'Source Code', 'apps-display' ); ?></a></li>
                    <?php endif; ?>
                </ul>
            </div>
            <?php if ( $badge_text ) : ?>
            <div class="asc-single__sidebar-card">
                <span class="asc-badge-large" style="background:<?php echo esc_attr( $badge_color ); ?>"><?php echo esc_html( $badge_text ); ?></span>
            </div>
            <?php endif; ?>
            <?php if ( is_active_sidebar( 'asc-sidebar' ) ) : ?>
            <div class="asc-single__sidebar-card">
                <?php dynamic_sidebar( 'asc-sidebar' ); ?>
            </div>
            <?php endif; ?>
        </aside>
        <?php endif; ?>

    </div><!-- /.asc-single__wrap -->

    <!-- Back link -->
    <div class="asc-single__back">
        <a href="<?php echo esc_url( get_post_type_archive_link( 'showcase_app' ) ); ?>" class="asc-single__btn asc-single__btn--ghost">
            ← <?php esc_html_e( 'Back to All Apps', 'apps-display' ); ?>
        </a>
    </div>

</div><!-- /.asc-single -->

<?php get_footer(); ?>
