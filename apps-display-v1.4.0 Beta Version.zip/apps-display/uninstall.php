<?php
/**
 * Uninstall — Apps Display
 *
 * Fired when the user clicks "Delete" on the Plugins screen.
 * Removes ALL plugin data only when the user has explicitly confirmed
 * deletion via the "Delete data on uninstall" setting.
 *
 * Data removed (when confirmed):
 *   - Plugin settings option (asc_settings)
 *   - The "delete data" flag option (asc_delete_on_uninstall)
 *   - All showcase_app posts and their post-meta (asc_*)
 *   - All app_category, app_tag, app_status terms and their meta
 *
 * WordPress only runs this file when the plugin is deleted (not just
 * deactivated), so no extra capability check is needed beyond the
 * WP_UNINSTALL_PLUGIN constant guard below.
 */

// WordPress sets this constant before calling uninstall.php.
// If it is not set, someone accessed this file directly — abort.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// ── Respect the user's choice ────────────────────────────────────────
// Only wipe data if the admin explicitly opted in via Settings.
if ( ! get_option( 'asc_delete_on_uninstall' ) ) {
    return;
}

// ── Remove plugin settings ───────────────────────────────────────────
delete_option( 'asc_settings' );
delete_option( 'asc_delete_on_uninstall' );

// ── Remove all showcase_app posts and their meta ─────────────────────
$post_ids = get_posts( [
    'post_type'      => 'showcase_app',
    'post_status'    => 'any',
    'posts_per_page' => -1,
    'fields'         => 'ids',
] );

foreach ( $post_ids as $post_id ) {
    // Delete all asc_* post-meta keys first, then the post itself.
    // wp_delete_post( $id, true ) already deletes post-meta, but being
    // explicit here ensures nothing is missed if WP internals change.
    $meta_keys = [
        'asc_app_url', 'asc_repo_url', 'asc_demo_url',
        'asc_version', 'asc_tech_stack', 'asc_release_date',
        'asc_author_name', 'asc_author_url',
        'asc_badge_text', 'asc_badge_color',
        'asc_screenshots', 'asc_featured', 'asc_sort_order',
        'asc_short_desc',
    ];
    foreach ( $meta_keys as $key ) {
        delete_post_meta( $post_id, $key );
    }

    // Force-delete the post (bypasses trash).
    wp_delete_post( $post_id, true );
}

// ── Remove all plugin taxonomies and their terms ─────────────────────
$taxonomies = [ 'app_category', 'app_tag', 'app_status' ];

foreach ( $taxonomies as $taxonomy ) {
    $terms = get_terms( [
        'taxonomy'   => $taxonomy,
        'hide_empty' => false,
        'fields'     => 'ids',
    ] );

    if ( is_array( $terms ) ) {
        foreach ( $terms as $term_id ) {
            wp_delete_term( $term_id, $taxonomy );
        }
    }
}

// ── Flush rewrite rules so CPT slugs are released ────────────────────
flush_rewrite_rules();
