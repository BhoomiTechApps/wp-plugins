/* global jQuery, ascData */
(function ($) {
    'use strict';

    $(document).ready(function () {

        $('.asc-showcase').each(function () {
            var $wrap     = $(this);
            var $grid     = $wrap.find('.asc-grid');
            var $spinner  = $wrap.find('.asc-spinner');
            var $count    = $wrap.find('.asc-count');
            var $loadBtn  = $wrap.find('.asc-load-more');
            var $activeFR = $wrap.find('.asc-active-filters');

            // ── Read initial state from data attributes ────────────────
            var state = {
                layout:   $wrap.data('layout')   || 'grid',
                columns:  parseInt($wrap.data('columns'))   || 3,
                perPage:  parseInt($wrap.data('per-page'))  || 12,
                orderby:  $wrap.data('orderby')  || 'date',
                order:    $wrap.data('order')    || 'DESC',
                search:   '',
                filters:  {},
                page:     1,
                maxPages: parseInt($loadBtn.data('max')) || 1,
                loading:  false,
                // vis map: decoded once from data-vis attribute
                vis:      $wrap.data('vis') || {},
            };

            // Apply correct layout class on init (fix #1 & #3)
            applyLayoutClasses( state.layout, state.columns );

            // ── Search ─────────────────────────────────────────────────
            var searchTimer;
            $wrap.on('input', '.asc-search', function () {
                clearTimeout(searchTimer);
                var val = $(this).val();
                searchTimer = setTimeout(function () {
                    state.search = val;
                    state.page   = 1;
                    doFetch(false);
                }, 380);
            });

            $wrap.on('keydown', '.asc-search', function (e) {
                if (e.key === 'Escape') {
                    $(this).val('');
                    state.search = '';
                    state.page   = 1;
                    doFetch(false);
                }
            });

            // ── Sort ────────────────────────────────────────────────────
            $wrap.on('change', '.asc-sort-select', function () {
                var parts     = $(this).val().split('-');
                state.orderby = parts[0];
                state.order   = parts[1] || 'DESC';
                state.page    = 1;
                doFetch(false);
            });

            // ── Layout toggle (fix #3) ──────────────────────────────────
            // Only changes CSS — no AJAX needed. Columns from state are applied.
            $wrap.on('click', '.asc-layout-btn', function () {
                var newLayout = $(this).data('layout');
                state.layout  = newLayout;
                $wrap.find('.asc-layout-btn').removeClass('active');
                $(this).addClass('active');
                applyLayoutClasses( newLayout, state.columns );
                // Re-stamp layout class on each card (list vs grid card CSS differs)
                $grid.find('.asc-card')
                    .removeClass('asc-layout-grid asc-layout-list')
                    .addClass('asc-layout-' + newLayout);
            });

            // ── Filter panel toggle ─────────────────────────────────────
            $wrap.on('click', '.asc-filter-toggle', function () {
                $wrap.find('.asc-filter-panel').slideToggle(180);
                $(this).toggleClass('active');
            });

            // ── Filter chips ────────────────────────────────────────────
            $wrap.on('click', '.asc-chip', function () {
                var $chip = $(this);
                var tax   = $chip.data('tax');
                var term  = String($chip.data('term') || '');

                $chip.closest('.asc-filter-chips').find('.asc-chip').removeClass('active');
                $chip.addClass('active');

                if ( term === '' ) {
                    delete state.filters[tax];
                } else {
                    state.filters[tax] = term;
                }
            });

            $wrap.on('click', '.asc-apply-filter', function () {
                state.page = 1;
                doFetch(false);
                renderActiveFilterTags();
            });

            $wrap.on('click', '.asc-clear-filter', function () {
                state.filters = {};
                state.page    = 1;
                $wrap.find('.asc-chip').removeClass('active');
                $wrap.find('.asc-chip[data-term=""]').addClass('active');
                doFetch(false);
                renderActiveFilterTags();
            });

            $wrap.on('click', '.asc-active-filter-tag button', function () {
                var tax = $(this).closest('.asc-active-filter-tag').data('tax');
                delete state.filters[tax];
                $wrap.find('.asc-chip[data-tax="' + tax + '"]').removeClass('active');
                $wrap.find('.asc-chip[data-tax="' + tax + '"][data-term=""]').addClass('active');
                state.page = 1;
                doFetch(false);
                renderActiveFilterTags();
            });

            // ── Load More ────────────────────────────────────────────────
            $wrap.on('click', '.asc-load-more', function () {
                state.page++;
                doFetch(true);
            });

            // ── Core AJAX fetch ──────────────────────────────────────────
            function doFetch(append) {
                if (state.loading) return;
                state.loading = true;
                $grid.addClass('asc-loading');
                $spinner.show();
                if (!append) $loadBtn.hide();

                $.ajax({
                    url:    ascData.ajaxUrl,
                    method: 'POST',
                    data: {
                        action:   'asc_filter_apps',
                        nonce:    ascData.nonce,
                        search:   state.search,
                        orderby:  state.orderby,
                        order:    state.order,
                        paged:    state.page,
                        per_page: state.perPage,
                        columns:  state.columns,
                        layout:   state.layout,
                        filters:  JSON.stringify(state.filters),
                        vis:      JSON.stringify(state.vis),
                    },
                    success: function (res) {
                        if (!res.success) return;
                        var data = res.data;

                        if (append) {
                            var $new = $(data.html);
                            $new.css({ opacity: 0, transform: 'translateY(16px)' });
                            $grid.append($new);
                            $new.each(function (i) {
                                var $c = $(this);
                                setTimeout(function () {
                                    $c.css({ transition: 'opacity .3s ease, transform .3s ease',
                                             opacity: 1, transform: 'translateY(0)' });
                                }, i * 60);
                            });
                        } else {
                            $grid.html(data.html);
                        }

                        // Re-apply layout classes after HTML swap (fix #1 & #3)
                        applyLayoutClasses( state.layout, state.columns );
                        $grid.find('.asc-card')
                            .removeClass('asc-layout-grid asc-layout-list')
                            .addClass('asc-layout-' + state.layout);

                        var n = parseInt(data.found) || 0;
                        $count.text(n === 1 ? '1 app' : n + ' apps');

                        state.maxPages = parseInt(data.max_pages) || 1;
                        if (state.page < state.maxPages) {
                            $loadBtn.show().data('max', state.maxPages);
                        } else {
                            $loadBtn.hide();
                        }
                    },
                    error: function () {
                        console.error('[App Showcase] AJAX error');
                    },
                    complete: function () {
                        state.loading = false;
                        $grid.removeClass('asc-loading');
                        $spinner.hide();
                    }
                });
            }

            // ── Apply layout + column CSS (fix #1) ──────────────────────
            // Sets the layout class AND the --asc-columns CSS var on the wrapper,
            // which drives grid-template-columns in CSS.
            function applyLayoutClasses(layout, columns) {
                $wrap.removeClass('asc-layout-grid asc-layout-list');
                $wrap.addClass('asc-layout-' + layout);
                // Always keep --asc-columns in sync — this is what drives the
                // grid-template-columns: repeat(var(--asc-columns), 1fr) rule.
                $wrap[0].style.setProperty('--asc-columns', columns);
                // In list mode columns don't apply, but keep value consistent.
            }

            // ── Active filter tag pills ──────────────────────────────────
            function renderActiveFilterTags() {
                $activeFR.empty();
                $.each(state.filters, function (tax, term) {
                    var label = tax.replace('app_', '').replace('_', ' ') + ': ' + term;
                    $activeFR.append(
                        $('<span class="asc-active-filter-tag">')
                            .attr('data-tax', tax)
                            .text(label)
                            .append(
                                $('<button aria-label="Remove filter">&times;</button>')
                            )
                    );
                });
            }

        }); // each showcase

    }); // ready

}(jQuery));
