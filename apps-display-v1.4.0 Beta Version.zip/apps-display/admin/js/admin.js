/* global jQuery, wp */
(function ($) {
    'use strict';

    /* ── Color pickers ──────────────────────────────────────────── */
    $(document).ready(function () {

        $('.asc-color-picker').wpColorPicker();

        /* ── Media gallery uploader ─────────────────────────────── */
        var mediaFrame;

        $('#asc-gallery-add').on('click', function (e) {
            e.preventDefault();

            if (mediaFrame) {
                mediaFrame.open();
                return;
            }

            mediaFrame = wp.media({
                title: 'Select Screenshots',
                button: { text: 'Add to Gallery' },
                multiple: true,
                library: { type: 'image' }
            });

            mediaFrame.on('select', function () {
                var attachments = mediaFrame.state().get('selection').toJSON();
                attachments.forEach(function (attachment) {
                    addThumbToGallery(attachment.id, attachment.sizes.thumbnail
                        ? attachment.sizes.thumbnail.url
                        : attachment.url);
                });
                updateGalleryInput();
            });

            mediaFrame.open();
        });

        /* Remove image from gallery */
        $(document).on('click', '.asc-remove-img', function () {
            $(this).closest('.asc-gallery-thumb').remove();
            updateGalleryInput();
        });

        function addThumbToGallery(id, url) {
            // Avoid duplicates
            if ($('#asc-gallery-preview [data-id="' + id + '"]').length) return;
            var html = '<div class="asc-gallery-thumb" data-id="' + id + '">'
                     + '<img src="' + url + '">'
                     + '<span class="asc-remove-img dashicons dashicons-no-alt"></span>'
                     + '</div>';
            $('#asc-gallery-preview').append(html);
        }

        function updateGalleryInput() {
            var ids = [];
            $('#asc-gallery-preview .asc-gallery-thumb').each(function () {
                ids.push($(this).data('id'));
            });
            $('#asc_screenshots').val(ids.join(','));
        }

        /* ── Settings page tabs ─────────────────────────────────── */
        $('.asc-tab').on('click', function () {
            var tab = $(this).data('tab');
            $('.asc-tab').removeClass('active');
            $(this).addClass('active');
            $('.asc-tab-panel').removeClass('active');
            $('#asc-tab-' + tab).addClass('active');
        });

        /* Persist active tab in sessionStorage */
        var savedTab = sessionStorage.getItem('asc_active_tab');
        if (savedTab) {
            $('.asc-tab[data-tab="' + savedTab + '"]').trigger('click');
        }

        $('.asc-tab').on('click', function () {
            sessionStorage.setItem('asc_active_tab', $(this).data('tab'));
        });

    });

}(jQuery));
