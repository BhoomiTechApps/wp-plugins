<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Taxonomy {

    public static function register() {

        // ── Category taxonomy ────────────────────────────────────────
        register_taxonomy( 'app_category', 'showcase_app', [
            'labels' => [
                'name'              => __( 'App Categories',    'apps-display' ),
                'singular_name'     => __( 'App Category',      'apps-display' ),
                'search_items'      => __( 'Search Categories', 'apps-display' ),
                'all_items'         => __( 'All Categories',    'apps-display' ),
                'edit_item'         => __( 'Edit Category',     'apps-display' ),
                'add_new_item'      => __( 'Add New Category',  'apps-display' ),
                'menu_name'         => __( 'Categories',        'apps-display' ),
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-category' ],
            'show_in_rest'      => true,
        ]);

        // ── Tag taxonomy ─────────────────────────────────────────────
        register_taxonomy( 'app_tag', 'showcase_app', [
            'labels' => [
                'name'          => __( 'App Tags',    'apps-display' ),
                'singular_name' => __( 'App Tag',     'apps-display' ),
                'search_items'  => __( 'Search Tags', 'apps-display' ),
                'all_items'     => __( 'All Tags',    'apps-display' ),
                'edit_item'     => __( 'Edit Tag',    'apps-display' ),
                'add_new_item'  => __( 'Add New Tag', 'apps-display' ),
                'menu_name'     => __( 'Tags',        'apps-display' ),
            ],
            'hierarchical'      => false,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-tag' ],
            'show_in_rest'      => true,
        ]);

        // ── Status taxonomy ──────────────────────────────────────────
        register_taxonomy( 'app_status', 'showcase_app', [
            'labels' => [
                'name'          => __( 'App Statuses', 'apps-display' ),
                'singular_name' => __( 'App Status',   'apps-display' ),
                'all_items'     => __( 'All Statuses', 'apps-display' ),
                'add_new_item'  => __( 'Add Status',   'apps-display' ),
                'menu_name'     => __( 'Statuses',     'apps-display' ),
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-status' ],
            'show_in_rest'      => true,
        ]);
    }
}
