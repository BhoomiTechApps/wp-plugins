<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Post_Type {

    public static function register() {
        $labels = [
            'name'               => __( 'Applications',          'apps-display' ),
            'singular_name'      => __( 'Application',           'apps-display' ),
            'menu_name'          => __( 'Apps Display',          'apps-display' ),
            'add_new'            => __( 'Add New App',           'apps-display' ),
            'add_new_item'       => __( 'Add New Application',   'apps-display' ),
            'edit_item'          => __( 'Edit Application',      'apps-display' ),
            'new_item'           => __( 'New Application',       'apps-display' ),
            'view_item'          => __( 'View Application',      'apps-display' ),
            'search_items'       => __( 'Search Applications',   'apps-display' ),
            'not_found'          => __( 'No applications found', 'apps-display' ),
            'not_found_in_trash' => __( 'No applications in trash', 'apps-display' ),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'menu_icon'          => 'dashicons-layout',
            'menu_position'      => 25,
            'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
            'has_archive'        => true,
            'rewrite'            => [ 'slug' => 'apps' ],
            'show_in_rest'       => true,
        ];

        register_post_type( 'showcase_app', $args );
    }
}
