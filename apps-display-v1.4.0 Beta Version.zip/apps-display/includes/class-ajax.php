<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Ajax {

    public static function filter_apps() {
        check_ajax_referer( 'asc_nonce', 'nonce' );

        $search   = sanitize_text_field( wp_unslash( $_POST['search']   ?? '' ) );
        $orderby  = sanitize_key(        wp_unslash( $_POST['orderby']  ?? 'date' ) );
        $order    = strtoupper( sanitize_key( wp_unslash( $_POST['order'] ?? 'DESC' ) ) );
        $paged    = max( 1, intval( wp_unslash( $_POST['paged']    ?? 1 ) ) );
        $per_page = max( 1, intval( wp_unslash( $_POST['per_page'] ?? 12 ) ) );
        $layout_raw = sanitize_key( wp_unslash( $_POST['layout'] ?? '' ) );
        $layout   = in_array( $layout_raw, ['grid','list'] ) ? $layout_raw : 'grid';
        $columns  = max( 1, min( 6, intval( wp_unslash( $_POST['columns'] ?? 3 ) ) ) );
        $opts     = get_option( 'asc_settings', [] );

        // Visibility map sent as JSON from the frontend state
        $vis_raw = sanitize_text_field( wp_unslash( $_POST['vis'] ?? '{}' ) );
        $vis     = json_decode( wp_unslash( $vis_raw ), true );

        // Sanitise vis: only allow known keys, cast to bool
        $allowed_keys = array_keys( ASC_Shortcode::card_fields() );
        $clean_vis    = [];
        foreach ( $allowed_keys as $k ) {
            if ( isset( $vis[ $k ] ) ) {
                $clean_vis[ $k ] = (bool) $vis[ $k ];
            }
        }
        // If nothing was passed, fall back to global settings
        if ( empty( $clean_vis ) ) {
            foreach ( ASC_Shortcode::card_fields() as $key => $cfg ) {
                $global_val       = $opts[ $key ] ?? $cfg['default'];
                $clean_vis[ $key ] = ( $global_val === '1' || $global_val === 1 );
            }
        }

        $filters_raw      = sanitize_text_field( wp_unslash( $_POST['filters'] ?? '{}' ) );
        $taxonomy_filters = json_decode( wp_unslash( $filters_raw ), true );

        $args = [
            'post_type'      => 'showcase_app',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
        ];

        if ( $orderby === 'sort_order' ) {
            $args['meta_key'] = 'asc_sort_order';
            $args['orderby']  = 'meta_value_num';
        } elseif ( $orderby === 'rand' ) {
            $args['orderby'] = 'rand';
        } else {
            $args['orderby'] = in_array( $orderby, ['date','title','modified'] ) ? $orderby : 'date';
        }
        $args['order'] = ( $order === 'ASC' ) ? 'ASC' : 'DESC';

        if ( $search ) $args['s'] = $search;

        $tax_query = [];
        foreach ( (array) $taxonomy_filters as $tax => $term_slug ) {
            if ( ! $term_slug ) continue;
            if ( ! in_array( $tax, [ 'app_category', 'app_tag', 'app_status' ] ) ) continue;
            $tax_query[] = [ 'taxonomy' => sanitize_key( $tax ), 'field' => 'slug', 'terms' => sanitize_text_field( $term_slug ) ];
        }
        if ( count( $tax_query ) > 1 ) $tax_query['relation'] = 'AND';
        if ( $tax_query ) $args['tax_query'] = $tax_query;

        $query = new WP_Query( $args );

        ob_start();
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                ASC_Shortcode::render_card( get_the_ID(), $layout, $opts, $clean_vis );
            }
            wp_reset_postdata();
        } else {
            echo '<div class="asc-no-results"><span class="asc-no-results-icon">&#128269;</span><p>'
               . esc_html__( 'No applications found.', 'apps-display' )
               . '</p></div>';
        }
        $html = ob_get_clean();

        wp_send_json_success([
            'html'      => $html,
            'found'     => $query->found_posts,
            'max_pages' => $query->max_num_pages,
            'paged'     => $paged,
            'columns'   => $columns,   // echo back so JS can update --asc-columns
        ]);
    }
}
