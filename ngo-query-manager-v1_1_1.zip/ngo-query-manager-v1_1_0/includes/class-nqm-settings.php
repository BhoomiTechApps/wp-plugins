<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Settings {

    public static function init() {
        add_action( 'admin_init', [ __CLASS__, 'register' ] );
    }

    public static function register() {
        /* General */
        register_setting( 'nqm_general', 'nqm_delete_data_on_uninstall', [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_notify_response_attach',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_admin_email_notify',      [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_from_email',               [ 'type' => 'string',  'sanitize_callback' => 'sanitize_email' ] );
        register_setting( 'nqm_general', 'nqm_from_name',                [ 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( 'nqm_general', 'nqm_query_sources',            [ 'sanitize_callback' => [ __CLASS__, 'sanitize_array' ] ] );
        register_setting( 'nqm_general', 'nqm_respond_page_id',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_page_admin',         [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_respondent_roles',         [ 'sanitize_callback' => [ __CLASS__, 'sanitize_array' ] ] );

        /* Video */
        register_setting( 'nqm_video',   'nqm_video_max_duration',       [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_video',   'nqm_video_global_allocation',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );

        /* Appearance */
        register_setting( 'nqm_appearance', 'nqm_theme_color', [ 'type' => 'string', 'sanitize_callback' => 'sanitize_hex_color', 'default' => '#2c5f2e' ] );
        register_setting( 'nqm_appearance', 'nqm_font_size',   [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field',  'default' => '1rem'   ] );
    }

    /**
     * Build the :root CSS variable block from saved appearance settings.
     * Returns a CSS string for use with wp_add_inline_style() — this is
     * appended directly after the <link> tag for nqm-public, guaranteeing
     * it overrides the static fallback values in public.css.
     */
    public static function build_css_vars() {
        $color = sanitize_hex_color( get_option( 'nqm_theme_color', '#2c5f2e' ) );
        if ( ! $color ) $color = '#2c5f2e';
        $font_size = sanitize_text_field( get_option( 'nqm_font_size', '.85rem' ) );

        list( $r, $g, $b ) = sscanf( ltrim( $color, '#' ), '%02x%02x%02x' );
        $light      = sprintf( 'rgb(%d,%d,%d)', min(255,(int)($r*0.12+255*0.88)), min(255,(int)($g*0.12+255*0.88)), min(255,(int)($b*0.12+255*0.88)) );
        $dark       = sprintf( 'rgb(%d,%d,%d)', max(0,(int)($r*0.68)), max(0,(int)($g*0.68)), max(0,(int)($b*0.68)) );
        $focus_ring = sprintf( 'rgba(%d,%d,%d,0.18)', $r, $g, $b );

        return ":root{--nqm-green:{$color};--nqm-green-light:{$light};--nqm-primary:{$color};--nqm-primary-dark:{$dark};--nqm-focus-ring:{$focus_ring};--nqm-font-size-base:{$font_size};}";
    }

    public static function sanitize_array( $input ) {
        if ( ! is_array( $input ) ) {
            $input = array_map( 'trim', explode( "\n", $input ) );
        }
        return array_filter( array_map( 'sanitize_text_field', $input ) );
    }

    /* ── Getters ──────────────────────────────────────────────── */
    public static function get( $key, $default = '' ) {
        return get_option( $key, $default );
    }

    public static function get_query_sources() {
        $sources = get_option( 'nqm_query_sources', [] );
        if ( empty( $sources ) ) {
            $sources = [ 'project_partner', 'funding_agency', 'beneficiary', 'government_body', 'general_public' ];
        }
        return $sources;
    }

    public static function get_respondent_roles() {
        $roles = get_option( 'nqm_respondent_roles', [] );
        if ( empty( $roles ) ) {
            $roles = [ 'editor', 'author' ];
        }
        // Administrators can always respond from the frontend regardless of saved roles.
        $roles = (array) $roles;
        if ( ! in_array( 'administrator', $roles, true ) ) {
            $roles[] = 'administrator';
        }
        return $roles;
    }

    public static function video_max_duration() {
        return (int) get_option( 'nqm_video_max_duration', 60 );
    }

    public static function video_global_allocation() {
        return (int) get_option( 'nqm_video_global_allocation', 3600 );
    }
}
