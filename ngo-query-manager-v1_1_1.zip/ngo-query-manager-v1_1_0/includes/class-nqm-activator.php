<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Activator {

    public static function activate() {
        NQM_Database::create_tables();
        self::set_defaults();
        self::create_pages();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    /**
     * Create the four front-end pages if they don't already exist.
     * Stores each page ID in options so shortcodes and menus can reference them.
     */
    private static function create_pages() {
        $pages = [
            'nqm_page_submit' => [
                'title'     => __( 'Submit a Query', 'ngo-query-manager' ),
                'shortcode' => '[nqm_dosubmit]',
                'slug'      => 'submit-query',
            ],
            'nqm_page_status' => [
                'title'     => __( 'Check Query Status', 'ngo-query-manager' ),
                'shortcode' => '[nqm_qsearch]',
                'slug'      => 'check-query-status',
            ],
            'nqm_page_list' => [
                'title'     => __( 'My Queries', 'ngo-query-manager' ),
                'shortcode' => '[nqm_qlist]',
                'slug'      => 'my-queries',
            ],
            'nqm_page_respond' => [
                'title'     => __( 'Respond to Query', 'ngo-query-manager' ),
                'shortcode' => '[nqm_dorespond]',
                'slug'      => 'respond-to-query',
            ],
            'nqm_page_admin' => [
                'title'     => __( 'Query Manager Admin', 'ngo-query-manager' ),
                'shortcode' => '[nqm_admin_panel]',
                'slug'      => 'query-manager-admin',
            ],
        ];

        foreach ( $pages as $option_key => $page ) {
            $existing_id = (int) get_option( $option_key, 0 );

            // Check if the stored page still exists
            if ( $existing_id && get_post( $existing_id ) ) {
                continue;
            }

            // Also check by slug to avoid duplicates on re-activation
            $existing_by_slug = get_page_by_path( $page['slug'] );
            if ( $existing_by_slug ) {
                update_option( $option_key, $existing_by_slug->ID );
                continue;
            }

            $page_id = wp_insert_post( [
                'post_title'   => $page['title'],
                'post_content' => $page['shortcode'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => $page['slug'],
                'comment_status' => 'closed',
            ] );

            if ( $page_id && ! is_wp_error( $page_id ) ) {
                update_option( $option_key, $page_id );
            }
        }

        // Keep the legacy nqm_respond_page_id option in sync
        $respond_id = (int) get_option( 'nqm_page_respond', 0 );
        if ( $respond_id ) {
            update_option( 'nqm_respond_page_id', $respond_id );
        }
    }

    private static function set_defaults() {
        $defaults = [
            'nqm_video_max_duration'      => 60,
            'nqm_video_global_allocation' => 3600,
            'nqm_admin_email_notify'      => 1,
            'nqm_notify_response_attach'  => 1,   // new: email attachments when notify is on
            'nqm_delete_data_on_uninstall'=> 1,   // new: uninstall option
            'nqm_from_email'              => get_option( 'admin_email' ),
            'nqm_from_name'               => get_bloginfo( 'name' ),
            'nqm_query_sources'           => [
                'project_partner',
                'funding_agency',
                'beneficiary',
                'government_body',
                'general_public',
            ],
            'nqm_respondent_roles'        => [ 'editor', 'author' ],
        ];
        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $value );
            }
        }
    }
}
