<?php
/**
 * ICBFE_Access – single source of truth for all front-end permission settings.
 *
 * Two user tiers are managed here:
 *   'subscriber' – logged-in users with the WP 'subscriber' role (or any role
 *                  below 'editor', i.e. anyone who cannot manage_options)
 *   'guest'      – unauthenticated (not logged-in) visitors
 *
 * For each tier a flat map of feature-flags controls exactly what is visible
 * and interactive in the [icb_frontend] shortcode output.
 *
 * Administrators (manage_options) always get full access and are never subject
 * to these restrictions.
 *
 * Feature keys (used both here and in JS):
 *   workspace_view          – can see the Corpus Workspace tab at all
 *   live_transliterate      – can type Roman input and view the Native Script preview
 *   workspace_submit        – can click "Analyse & Save" to add words to the corpus
 *                             (requires live_transliterate; does NOT imply it)
 *   transliterate_toggle    – can toggle live Roman→Indic transliteration
 *   conflict_resolution     – can see and resolve near-duplicate conflicts
 *   config_view             – can see the Parser Configuration tab
 *   config_edit             – can change and save parser settings
 *   lexicon_view            – can see the Lexicon Mapping tab
 *   lexicon_edit            – can change and save lexicon entries
 *   corpus_stats_view       – can see the corpus-size / threshold stat bar
 *   live_test               – can use the live transliteration test input
 */
class ICBFE_Access {

    const OPTION_KEY = 'icbfe_access_control';

    /**
     * Default permissions shipped with the plugin.
     * Subscribers get read + workspace submit; Guests are view-only.
     */
    const DEFAULTS = [
        'subscriber' => [
            'workspace_view'       => true,
            'live_transliterate'   => true,   // type Roman input + view Native preview
            'workspace_submit'     => true,   // Analyse & Save (corpus write)
            'transliterate_toggle' => true,
            'conflict_resolution'  => true,
            'config_view'          => false,
            'config_edit'          => false,
            'lexicon_view'         => false,
            'lexicon_edit'         => false,
            'corpus_stats_view'    => true,
            'live_test'            => true,
        ],
        'guest' => [
            'workspace_view'       => true,
            'live_transliterate'   => true,   // guests may type + preview freely
            'workspace_submit'     => false,  // but cannot save to corpus
            'transliterate_toggle' => true,
            'conflict_resolution'  => false,
            'config_view'          => false,
            'config_edit'          => false,
            'lexicon_view'         => false,
            'lexicon_edit'         => false,
            'corpus_stats_view'    => true,
            'live_test'            => true,
        ],
    ];

    // Human-readable labels used in the admin UI
    const FEATURE_LABELS = [
        'workspace_view'       => 'View Corpus Workspace tab',
        'live_transliterate'   => 'Type Roman input & view Native Script preview',
        'workspace_submit'     => 'Submit text to corpus (Analyse & Save)',
        'transliterate_toggle' => 'Toggle live transliteration',
        'conflict_resolution'  => 'Resolve near-duplicate conflicts',
        'config_view'          => 'View Parser Configuration tab',
        'config_edit'          => 'Edit & save parser settings',
        'lexicon_view'         => 'View Lexicon Mapping tab',
        'lexicon_edit'         => 'Edit & save lexicon entries',
        'corpus_stats_view'    => 'See corpus size / stats bar',
        'live_test'            => 'Use live transliteration test',
    ];

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Load the saved access map, filling any missing keys from DEFAULTS.
     */
    public static function all(): array {
        $raw = get_option( self::OPTION_KEY, null );
        if ( $raw === null ) {
            return self::DEFAULTS;
        }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) {
            return self::DEFAULTS;
        }
        // Merge each tier to ensure new feature keys always exist
        $merged = self::DEFAULTS;
        foreach ( [ 'subscriber', 'guest' ] as $tier ) {
            if ( isset( $decoded[ $tier ] ) && is_array( $decoded[ $tier ] ) ) {
                foreach ( $decoded[ $tier ] as $key => $val ) {
                    if ( array_key_exists( $key, self::DEFAULTS[ $tier ] ) ) {
                        $merged[ $tier ][ $key ] = (bool) $val;
                    }
                }
            }
        }
        return $merged;
    }

    /**
     * Check whether the current user can use a specific feature.
     *
     * @param string $feature   One of the feature keys defined above.
     * @return bool
     */
    public static function current_user_can_feature( string $feature ): bool {
        // Administrators always have full access
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }

        $map  = self::all();
        $tier = is_user_logged_in() ? 'subscriber' : 'guest';

        return (bool) ( $map[ $tier ][ $feature ] ?? false );
    }

    /**
     * Return the access map for the current visitor (not admin).
     * Used to build the JS icbfe_vars payload.
     */
    public static function current_user_map(): array {
        if ( current_user_can( 'manage_options' ) ) {
            // Grant all features
            $all = [];
            foreach ( array_keys( self::DEFAULTS['subscriber'] ) as $key ) {
                $all[ $key ] = true;
            }
            return $all;
        }

        $map  = self::all();
        $tier = is_user_logged_in() ? 'subscriber' : 'guest';
        return $map[ $tier ];
    }

    /**
     * Persist a new access map.
     *
     * @param array $data  Array with keys 'subscriber' and 'guest', each an
     *                     associative array of feature => bool.
     * @return bool
     */
    public static function save( array $data ): bool {
        $clean = [];
        foreach ( [ 'subscriber', 'guest' ] as $tier ) {
            $clean[ $tier ] = [];
            foreach ( array_keys( self::DEFAULTS[ $tier ] ) as $feature ) {
                $clean[ $tier ][ $feature ] = ! empty( $data[ $tier ][ $feature ] );
            }
        }
        $encoded = wp_json_encode( $clean );
        // Use delete + add instead of update_option so the write always
        // succeeds even when the new value is identical to the stored value.
        // update_option() returns false on a no-op equality check, which was
        // silently causing settings to appear saved while the DB was untouched.
        delete_option( self::OPTION_KEY );
        return (bool) add_option( self::OPTION_KEY, $encoded, '', 'no' );
    }

    /** Reset to plugin defaults. */
    public static function reset(): void {
        delete_option( self::OPTION_KEY );
    }
}
