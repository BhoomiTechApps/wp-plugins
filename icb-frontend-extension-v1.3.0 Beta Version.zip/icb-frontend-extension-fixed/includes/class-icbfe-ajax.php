<?php
/**
 * ICBFE_Ajax – front-end AJAX handlers for the ICB Frontend Extension.
 *
 * All actions are registered for both logged-in (wp_ajax_) and
 * non-logged-in (wp_ajax_nopriv_) users so that guests can also
 * trigger read-only / permitted operations.  Every handler re-checks
 * the Access Control map before doing anything, so the server-side
 * enforcement mirrors the UI-level hiding.
 *
 * Actions registered:
 *   icbfe_process_text          – tokenise + conflict-check submitted text
 *   icbfe_save_resolved_corpus  – commit conflict resolutions
 *   icbfe_save_config           – save parser configuration (if permitted)
 *   icbfe_reset_config          – reset parser configuration (if permitted)
 *   icbfe_save_lexicon          – save lexicon map (if permitted)
 *   icbfe_reset_lexicon         – reset lexicon map (if permitted)
 *   icbfe_get_state             – return current corpus stats + config (for refresh)
 */
class ICBFE_Ajax {

    public function __construct() {
        $actions = [
            'icbfe_process_text'         => 'handle_process_text',
            'icbfe_save_resolved_corpus' => 'handle_save_resolved_corpus',
            'icbfe_save_config'          => 'handle_save_config',
            'icbfe_reset_config'         => 'handle_reset_config',
            'icbfe_save_lexicon'         => 'handle_save_lexicon',
            'icbfe_reset_lexicon'        => 'handle_reset_lexicon',
            'icbfe_get_state'            => 'handle_get_state',
            'icbfe_download_corpus'      => 'handle_download_corpus',
            'icbfe_clear_corpus'         => 'handle_clear_corpus',
        ];

        foreach ( $actions as $action => $method ) {
            add_action( 'wp_ajax_' . $action,        [ $this, $method ] );
            add_action( 'wp_ajax_nopriv_' . $action, [ $this, $method ] );
        }
    }

    // ── Shared helpers ────────────────────────────────────────────────────────

    /** Send no-cache headers so browsers never serve stale AJAX responses. */
    private function no_cache_headers(): void {
        nocache_headers(); // WP built-in: sets Cache-Control, Pragma, Expires
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0, post-check=0, pre-check=0', true );
        header( 'Pragma: no-cache', true );
        header( 'Expires: Thu, 01 Jan 1970 00:00:00 GMT', true );
    }

    /** Verify nonce and abort with JSON error on failure. */
    private function verify_nonce(): void {
        $this->no_cache_headers();
        $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
        if ( ! wp_verify_nonce( $nonce, 'icbfe_nonce' ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
        }
    }

    /**
     * Gate a feature – aborts with JSON error when the current user is not
     * permitted to use $feature.
     */
    private function require_feature( string $feature ): void {
        if ( ! ICBFE_Access::current_user_can_feature( $feature ) ) {
            wp_send_json_error( [ 'message' => 'You do not have permission to use this feature.' ], 403 );
        }
    }

    // ── Process text ─────────────────────────────────────────────────────────

    public function handle_process_text(): void {
        $this->verify_nonce();
        $this->require_feature( 'workspace_submit' );

        if ( ! class_exists( 'ICB_Processor' ) || ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin (Indic Corpus Builder) is not active.' ] );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_corpus';

        $raw_text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
        if ( empty( $raw_text ) ) {
            wp_send_json_error( [ 'message' => 'Empty text submitted.' ] );
        }

        $input_words = ICB_Processor::tokenize_indic_text( $raw_text );
        $threshold   = (float) ICB_Config::get( 'similarity_threshold' );

        $conflicts   = [];
        $clean_saves = [];

        $existing_words = $wpdb->get_col( "SELECT word FROM $table_name" ) ?: [];

        foreach ( $input_words as $new_word ) {
            if ( in_array( $new_word, $existing_words, true ) ) {
                continue; // exact duplicate – skip silently
            }

            $has_conflict = false;
            foreach ( $existing_words as $old_word ) {
                $similarity = ICB_Processor::get_grapheme_similarity( $new_word, $old_word );
                if ( $similarity >= $threshold && $similarity < 100 ) {
                    $conflicts[]  = [
                        'new_word'   => $new_word,
                        'old_word'   => $old_word,
                        'percentage' => round( $similarity, 1 ),
                    ];
                    $has_conflict = true;
                    break;
                }
            }

            if ( ! $has_conflict ) {
                $clean_saves[] = $new_word;
            }
        }

        // No conflicts: auto-save
        if ( empty( $conflicts ) ) {
            $inserted = 0;
            foreach ( $clean_saves as $word ) {
                $rows = $wpdb->insert( $table_name, [ 'word' => $word, 'added_at' => current_time( 'mysql' ) ] );
                if ( $rows ) {
                    $inserted++;
                    $existing_words[] = $word; // keep in-request list fresh
                }
            }
            wp_send_json_success( [ 'status' => 'completed', 'inserted' => $inserted ] );
        }

        // Conflicts found: send back for human review
        // If user lacks conflict_resolution permission, auto-save clean words only
        if ( ! ICBFE_Access::current_user_can_feature( 'conflict_resolution' ) ) {
            $inserted = 0;
            foreach ( $clean_saves as $word ) {
                $rows = $wpdb->insert( $table_name, [ 'word' => $word, 'added_at' => current_time( 'mysql' ) ] );
                if ( $rows ) {
                    $inserted++;
                }
            }
            wp_send_json_success( [
                'status'   => 'completed_partial',
                'inserted' => $inserted,
                'skipped'  => count( $conflicts ),
                'message'  => sprintf(
                    /* translators: 1: inserted count, 2: skipped count */
                    __( 'Saved %1$d word(s). %2$d near-duplicate(s) were skipped (conflict resolution not available for your account).', 'icb-frontend-extension' ),
                    $inserted,
                    count( $conflicts )
                ),
            ] );
        }

        wp_send_json_success( [
            'status'     => 'requires_review',
            'conflicts'  => $conflicts,
            'safe_words' => $clean_saves,
        ] );
    }

    // ── Save resolved corpus ──────────────────────────────────────────────────

    public function handle_save_resolved_corpus(): void {
        $this->verify_nonce();
        $this->require_feature( 'workspace_submit' );
        $this->require_feature( 'conflict_resolution' );

        if ( ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin is not active.' ] );
        }

        global $wpdb;
        $table_name   = $wpdb->prefix . 'custom_corpus';
        $resolutions  = isset( $_POST['resolutions'] ) ? (array) $_POST['resolutions'] : [];
        $safe_words   = isset( $_POST['safe_words'] )  ? (array) $_POST['safe_words']  : [];
        $current_time = current_time( 'mysql' );

        $inserted_count = 0;
        $updated_count  = 0;

        foreach ( $safe_words as $clean_word ) {
            $clean_word = sanitize_text_field( trim( $clean_word ) );
            if ( empty( $clean_word ) ) continue;
            $rows = $wpdb->query( $wpdb->prepare(
                "INSERT IGNORE INTO $table_name (word, added_at) VALUES (%s, %s)",
                $clean_word, $current_time
            ) );
            if ( $rows ) $inserted_count++;
        }

        foreach ( $resolutions as $packet ) {
            if ( ! isset( $packet['decision'] ) ) continue;
            $decision = sanitize_key( $packet['decision'] );
            $new_word = sanitize_text_field( trim( $packet['new_word'] ) );
            $old_word = sanitize_text_field( trim( $packet['old_word'] ) );

            switch ( $decision ) {
                case 'keep_old':
                    break;

                case 'replace_with_new':
                    $rows = $wpdb->update(
                        $table_name,
                        [ 'word' => $new_word, 'added_at' => $current_time ],
                        [ 'word' => $old_word ],
                        [ '%s', '%s' ], [ '%s' ]
                    );
                    if ( $rows !== false ) $updated_count++;
                    break;

                case 'keep_both':
                    $rows = $wpdb->query( $wpdb->prepare(
                        "INSERT IGNORE INTO $table_name (word, added_at) VALUES (%s, %s)",
                        $new_word, $current_time
                    ) );
                    if ( $rows ) $inserted_count++;
                    break;
            }
        }

        wp_send_json_success( [
            'message'  => 'Corpus updated successfully.',
            'inserted' => $inserted_count,
            'updated'  => $updated_count,
        ] );
    }

    // ── Save config ───────────────────────────────────────────────────────────

    public function handle_save_config(): void {
        $this->verify_nonce();
        $this->require_feature( 'config_edit' );

        if ( ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin is not active.' ] );
        }

        $raw  = isset( $_POST['config'] ) ? stripslashes( $_POST['config'] ) : '';
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Invalid configuration payload.' ] );
        }

        ICB_Config::save( $data );

        wp_send_json_success( [
            'message'  => 'Parser configuration saved.',
            'settings' => ICB_Config::all(),
        ] );
    }

    // ── Reset config ──────────────────────────────────────────────────────────

    public function handle_reset_config(): void {
        $this->verify_nonce();
        $this->require_feature( 'config_edit' );

        if ( ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin is not active.' ] );
        }

        ICB_Config::reset();

        wp_send_json_success( [
            'message'  => 'Parser configuration reset to defaults.',
            'settings' => ICB_Config::all(),
        ] );
    }

    // ── Save lexicon ──────────────────────────────────────────────────────────

    public function handle_save_lexicon(): void {
        $this->verify_nonce();
        $this->require_feature( 'lexicon_edit' );

        if ( ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin is not active.' ] );
        }

        $raw  = isset( $_POST['lexicon'] ) ? stripslashes( $_POST['lexicon'] ) : '';
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Invalid lexicon payload.' ] );
        }

        ICB_Config::save_lexicon( $data );

        wp_send_json_success( [
            'message' => 'Custom lexicon saved.',
            'lexicon' => ICB_Config::get_lexicon(),
        ] );
    }

    // ── Reset lexicon ─────────────────────────────────────────────────────────

    public function handle_reset_lexicon(): void {
        $this->verify_nonce();
        $this->require_feature( 'lexicon_edit' );

        if ( ! class_exists( 'ICB_Config' ) ) {
            wp_send_json_error( [ 'message' => 'Parent plugin is not active.' ] );
        }

        ICB_Config::reset_lexicon();

        wp_send_json_success( [
            'message' => 'Custom lexicon reset to defaults.',
            'lexicon' => ICB_Config::DEFAULT_LEXICON,
        ] );
    }

    // ── Get state ─────────────────────────────────────────────────────────────

    /**
     * Lightweight endpoint to refresh corpus stats + current config without
     * a full page reload.  Available to all users (read-only payload).
     */
    public function handle_get_state(): void {
        $this->verify_nonce();

        global $wpdb;
        $table_name  = $wpdb->prefix . 'custom_corpus';
        $table_exists = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) === $table_name );
        $total_words  = $table_exists
            ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" )
            : 0;

        wp_send_json_success( [
            'corpus_size'   => $total_words,
            'parser_config' => class_exists( 'ICB_Config' ) ? ICB_Config::all()       : [],
            'lexicon'       => class_exists( 'ICB_Config' ) ? ICB_Config::get_lexicon() : [],
            'access'        => ICBFE_Access::current_user_map(),
        ] );
    }

    // ── Download full corpus ──────────────────────────────────────────────────

    /**
     * Stream the entire corpus as a UTF-8 plain-text file, one word per line.
     * Restricted to administrators (manage_options) only; non-admins receive
     * a 403 JSON error even if they somehow discover the action name.
     */
    public function handle_download_corpus(): void {
        $this->verify_nonce();

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Administrator access required.' ], 403 );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_corpus';

        $table_exists = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) === $table_name );
        if ( ! $table_exists ) {
            wp_send_json_error( [ 'message' => 'Corpus table does not exist.' ] );
        }

        $words = $wpdb->get_col( "SELECT word FROM $table_name ORDER BY added_at ASC, word ASC" );
        if ( $words === null ) {
            wp_send_json_error( [ 'message' => 'Failed to retrieve corpus data.' ] );
        }

        $filename = 'corpus-' . gmdate( 'Y-m-d' ) . '.txt';

        // Drain all output buffers so WP or server cannot inject extra content.
        while ( ob_get_level() > 0 ) {
            ob_end_clean();
        }

        // Use a custom X-header as an unambiguous signal to the JS download
        // handler that this is a file response (not a JSON error), regardless
        // of how different WP/server setups might set Content-Type.
        header( 'X-ICBFE-Download: corpus' );
        header( 'Content-Type: text/plain; charset=UTF-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true );
        header( 'Pragma: no-cache', true );
        header( 'Expires: Thu, 01 Jan 1970 00:00:00 GMT', true );
        header( 'X-Content-Type-Options: nosniff' );

        // Output BOM for Excel compatibility, then one word per line.
        // NOTE: do NOT use esc_html() here — this is a plain-text file, not HTML.
        // esc_html() would corrupt words containing &, <, >, etc.
        echo "\xEF\xBB\xBF"; // UTF-8 BOM
        foreach ( $words as $word ) {
            echo $word . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        }

        exit;
    }

    // ── Clear full corpus ─────────────────────────────────────────────────────

    /**
     * Truncate the entire corpus table.
     * Restricted to administrators (manage_options) only.
     */
    public function handle_clear_corpus(): void {
        $this->verify_nonce();

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Administrator access required.' ], 403 );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'custom_corpus';

        $table_exists = ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $table_name ) ) === $table_name );
        if ( ! $table_exists ) {
            wp_send_json_error( [ 'message' => 'Corpus table does not exist.' ] );
        }

        $result = $wpdb->query( "TRUNCATE TABLE $table_name" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        if ( $result === false ) {
            wp_send_json_error( [ 'message' => 'Failed to clear corpus.' ] );
        }

        wp_send_json_success( [
            'message'     => 'Corpus cleared successfully.',
            'corpus_size' => 0,
        ] );
    }
}
