<?php
/**
 * Uninstall ICB Frontend Extension
 *
 * Runs automatically when the plugin is deleted via the WordPress admin.
 * Removes all options written by this plugin so a fresh install always
 * starts from clean defaults.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit; // Security: block direct access
}

delete_option( 'icbfe_access_control' );
delete_option( 'icbfe_version' );
