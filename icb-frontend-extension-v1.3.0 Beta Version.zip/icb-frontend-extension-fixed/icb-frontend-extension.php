<?php
/**
 * Plugin Name: ICB Frontend Extension
 * Plugin URI:  https://bhoomitechfoundation.org/apps/indic-corpus-builder
 * Description: Adds a [icb_frontend] shortcode that exposes the Indic Corpus Builder
 *              to front-end visitors with a fully configurable access-control layer.
 *              Administrators retain full access; Subscribers and Guests get only the
 *              features the administrator permits.
 * Version:     1.0.1
 * Author:      BhoomiTech Heritage and Development Foundation
 * License:     GPL-2.0+
 * Requires at least: 6.0
 * Tested up to:      7.0
 * Requires PHP:      8.0
 * Text Domain:       icb-frontend-extension
 *
 * Requires Plugin:   indic-corpus-builder (slug: indic-corpus-bulder-1x)
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Constants ─────────────────────────────────────────────────────────────────
define( 'ICBFE_VERSION',    '1.0.1' );
define( 'ICBFE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'ICBFE_PLUGIN_URL', plugins_url( '/', __FILE__ ) );

// ── Dependency check ──────────────────────────────────────────────────────────
add_action( 'admin_notices', 'icbfe_check_parent_plugin' );

function icbfe_check_parent_plugin() {
    if ( ! class_exists( 'ICB_Config' ) ) {
        echo '<div class="notice notice-error"><p>'
           . '<strong>ICB Frontend Extension</strong> requires the '
           . '<em>Indic Corpus Builder</em> plugin to be installed and active.'
           . '</p></div>';
    }
}

// ── Autoload ──────────────────────────────────────────────────────────────────
require_once ICBFE_PLUGIN_DIR . 'includes/class-icbfe-access.php';
require_once ICBFE_PLUGIN_DIR . 'includes/class-icbfe-shortcode.php';
require_once ICBFE_PLUGIN_DIR . 'includes/class-icbfe-ajax.php';
require_once ICBFE_PLUGIN_DIR . 'includes/class-icbfe-admin.php';

// ── Boot ──────────────────────────────────────────────────────────────────────
add_action( 'init', function () {
    new ICBFE_Shortcode();
} );

new ICBFE_Ajax();
new ICBFE_Admin();

// ── Activation: create options defaults ───────────────────────────────────────
register_activation_hook( __FILE__, 'icbfe_activate' );

function icbfe_activate() {
    $installed_version = get_option( 'icbfe_version', null );

    if ( $installed_version === null ) {
        // Truly fresh install (or post-uninstall reinstall) — write clean defaults.
        update_option( ICBFE_Access::OPTION_KEY, wp_json_encode( ICBFE_Access::DEFAULTS ) );
    }
    // If version exists, this is a reactivation — preserve existing settings.

    // Always stamp the current version so we can detect fresh installs vs reactivations.
    update_option( 'icbfe_version', ICBFE_VERSION );
}

// ── Deactivation ──────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, 'icbfe_deactivate' );

function icbfe_deactivate() {
    // Intentionally leaves options intact so settings survive reactivation.
}
