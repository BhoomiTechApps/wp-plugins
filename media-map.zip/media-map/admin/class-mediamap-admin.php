<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Admin {

    public static function init() {
        add_action( 'admin_menu',           [ __CLASS__, 'register_menus'   ] );
        add_action( 'admin_init',           [ __CLASS__, 'register_settings'] );
        add_action( 'admin_enqueue_scripts',[ __CLASS__, 'enqueue_assets'   ] );
        add_action( 'admin_notices',        [ __CLASS__, 'pending_notice'   ] );
    }

    /* ------------------------------------------------------------------
       Menus
    ------------------------------------------------------------------ */
    public static function register_menus(): void {
        add_menu_page(
            __( 'Media Map', 'media-map' ),
            __( 'Media Map', 'media-map' ),
            'manage_options',
            'mediamap',
            [ __CLASS__, 'page_submissions' ],
            'dashicons-location-alt',
            30
        );
        add_submenu_page(
            'mediamap',
            __( 'Submissions', 'media-map' ),
            __( 'Submissions', 'media-map' ),
            'manage_options',
            'mediamap-submissions',
            [ __CLASS__, 'page_submissions' ]
        );
        add_submenu_page(
            'mediamap',
            __( 'Map Settings', 'media-map' ),
            __( 'Map Settings', 'media-map' ),
            'manage_options',
            'mediamap-settings',
            [ __CLASS__, 'page_settings' ]
        );
        add_submenu_page(
            'mediamap',
            __( 'Marker Styles', 'media-map' ),
            __( 'Marker Styles', 'media-map' ),
            'manage_options',
            'mediamap-markers',
            [ __CLASS__, 'page_markers' ]
        );
        add_submenu_page(
            'mediamap',
            __( 'Import / Export', 'media-map' ),
            __( 'Import / Export', 'media-map' ),
            'manage_options',
            'mediamap-import-export',
            [ __CLASS__, 'page_import_export' ]
        );
    }

    /* ------------------------------------------------------------------
       Settings Registration
    ------------------------------------------------------------------ */
    public static function register_settings(): void {
        // ---- Map Settings group ----
        $map_text_fields = [
            'mediamap_basemap_url', 'mediamap_basemap_attribution', 'mediamap_panel_text_size',
        ];
        $map_int_fields = [
            'mediamap_min_zoom','mediamap_max_zoom','mediamap_default_height','mediamap_rate_limit',
            'mediamap_default_zoom',
        ];
        $map_float_fields = [
            'mediamap_default_lat', 'mediamap_default_lng',
        ];
        $map_bool_fields = [
            'mediamap_zoom_bound','mediamap_fullscreen','mediamap_cluster_markers',
            'mediamap_notify_admin','mediamap_notify_user',
        ];
        foreach ( $map_text_fields as $f ) {
            register_setting( 'mediamap_map_settings', $f, 'sanitize_text_field' );
        }
        foreach ( $map_int_fields as $f ) {
            register_setting( 'mediamap_map_settings', $f, 'absint' );
        }
        foreach ( $map_float_fields as $f ) {
            register_setting( 'mediamap_map_settings', $f, 'floatval' );
        }
        foreach ( $map_bool_fields as $f ) {
            register_setting( 'mediamap_map_settings', $f, 'absint' );
        }

        // ---- Marker Styles group (separate so saving markers never touches map booleans) ----
        $marker_text_fields = [
            'mediamap_marker_image','mediamap_marker_video','mediamap_marker_audio',
            'mediamap_marker_text','mediamap_marker_pending',
            'mediamap_icon_image','mediamap_icon_video','mediamap_icon_audio',
            'mediamap_icon_text','mediamap_icon_pending',
        ];
        foreach ( $marker_text_fields as $f ) {
            register_setting( 'mediamap_marker_settings', $f, 'sanitize_text_field' );
        }
    }

    /* ------------------------------------------------------------------
       Enqueue admin assets
    ------------------------------------------------------------------ */
    public static function enqueue_assets( string $hook ): void {
        if ( strpos( $hook, 'mediamap' ) === false ) return;
        wp_enqueue_style(
            'mediamap-admin',
            MEDIAMAP_PLUGIN_URL . 'assets/css/admin.css',
            [], MEDIAMAP_VERSION
        );
        wp_enqueue_script(
            'mediamap-admin-js',
            MEDIAMAP_PLUGIN_URL . 'assets/js/admin.js',
            [ 'jquery' ], MEDIAMAP_VERSION, true
        );
        wp_localize_script( 'mediamap-admin-js', 'MediaMapAdmin', [
            'nonce'   => wp_create_nonce( 'mediamap_admin' ),
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'i18n'    => [
                'confirmDelete'  => __( 'Delete this submission? This cannot be undone.', 'media-map' ),
                'confirmApprove' => __( 'Approve this submission?', 'media-map' ),
                'confirmReject'  => __( 'Reject this submission?', 'media-map' ),
                // Import/Export page strings (moved from inline script — Issue #10)
                'preparing'      => __( 'Preparing…', 'media-map' ),
                'exportFailed'   => __( 'Export failed.', 'media-map' ),
                'rowsExported'   => __( 'rows exported.', 'media-map' ),
                'requestFailed'  => __( 'Request failed.', 'media-map' ),
                'chooseFile'     => __( 'Please choose a file first.', 'media-map' ),
                'importing'      => __( 'Importing…', 'media-map' ),
                'importFailed'   => __( 'Import failed.', 'media-map' ),
                'imported'       => __( 'imported', 'media-map' ),
                'skipped'        => __( 'skipped (duplicates)', 'media-map' ),
                'errors'         => __( 'errors.', 'media-map' ),
            ],
            // Import/Export nonce already in 'nonce' above — same mediamap_admin action.
        ] );
    }

    /* ------------------------------------------------------------------
       Admin notice for pending submissions  (Issue #6 — use $wpdb->prepare)
    ------------------------------------------------------------------ */
    public static function pending_notice(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        global $wpdb;

        $cache_key = 'mediamap_pending_count';
        $count     = wp_cache_get( $cache_key, 'mediamap' );
        if ( false === $count ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $count = (int) $wpdb->get_var(
                $wpdb->prepare(
                    'SELECT COUNT(*) FROM %i WHERE status = %s',
                    $wpdb->prefix . 'mediamap_submissions',
                    'pending'
                )
            );
            wp_cache_set( $cache_key, $count, 'mediamap', 60 );
        }
        if ( (int) $count < 1 ) return;
        $url = admin_url( 'admin.php?page=mediamap-submissions&status=pending' );
        printf(
            '<div class="notice notice-warning is-dismissible"><p>' .
            /* translators: %d = count, %s = URL */
            esc_html__( 'Media Map: %d submission(s) awaiting approval.', 'media-map' ) .
            ' <a href="%s">' . esc_html__( 'Review now', 'media-map' ) . '</a></p></div>',
			absint( $count ), esc_url( $url )
        );
    }

    /* ------------------------------------------------------------------
       Page: Submissions
    ------------------------------------------------------------------ */
    public static function page_submissions(): void {
        $status  = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
        $search  = isset( $_GET['s'] )      ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
        $paged   = isset( $_GET['paged'] )  ? max( 1, (int) $_GET['paged'] ) : 1;
        $per     = 20;
        $offset  = ( $paged - 1 ) * $per;

        $result  = MediaMap_Post_Type::admin_list( [
            'status' => $status,
            'search' => $search,
            'limit'  => $per,
            'offset' => $offset,
        ] );
        $rows    = $result['rows'];
        $total   = $result['total'];
        $pages   = (int) ceil( $total / $per );
        ?>
        <div class="wrap mediamap-admin-wrap">
            <h1 class="wp-heading-inline"><?php esc_html_e( 'Media Map — Submissions', 'media-map' ); ?></h1>
            <hr class="wp-header-end">

            <ul class="subsubsub">
                <?php
                $statuses = [ '' => __( 'All', 'media-map' ), 'pending' => __( 'Pending', 'media-map' ), 'approved' => __( 'Approved', 'media-map' ), 'rejected' => __( 'Rejected', 'media-map' ) ];
                foreach ( $statuses as $s => $label ) {
                    $url   = admin_url( 'admin.php?page=mediamap-submissions' . ( $s ? "&status={$s}" : '' ) );
                    $class = $status === $s ? 'current' : '';
                    echo "<li><a href='" . esc_url( $url ) . "' class='" . esc_attr( $class ) . "'>" . esc_html( $label ) . "</a> | </li>";
                }
                ?>
            </ul>

            <form method="get">
                <input type="hidden" name="page" value="mediamap-submissions">
                <?php if ( $status ) : ?><input type="hidden" name="status" value="<?php echo esc_attr( $status ); ?>"><?php endif; ?>
                <p class="search-box">
                    <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'Search…', 'media-map' ); ?>">
                    <button type="submit" class="button"><?php esc_html_e( 'Search', 'media-map' ); ?></button>
                </p>
            </form>

            <table class="wp-list-table widefat fixed striped mediamap-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'ID', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'User', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Place', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Type', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Media URL', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Description', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'media-map' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( empty( $rows ) ) : ?>
                    <tr><td colspan="9"><?php esc_html_e( 'No submissions found.', 'media-map' ); ?></td></tr>
                <?php else : ?>
                    <?php foreach ( $rows as $row ) : ?>
                    <tr id="mediamap-row-<?php echo (int) $row->id; ?>">
                        <td><?php echo (int) $row->id; ?></td>
                        <td><?php echo esc_html( $row->user_login ?? '—' ); ?></td>
                        <td><?php echo esc_html( $row->place_name ?: "{$row->lat}, {$row->lng}" ); ?></td>
                        <td><span class="mediamap-type-badge mediamap-type-<?php echo esc_attr( $row->media_type ); ?>"><?php echo esc_html( ucfirst( $row->media_type ) ); ?></span></td>
                        <td><?php if ( $row->media_url ) : ?><a href="<?php echo esc_url( $row->media_url ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'View', 'media-map' ); ?></a><?php else : ?>—<?php endif; ?></td>
                        <td><?php echo esc_html( wp_trim_words( $row->description, 12 ) ); ?></td>
                        <td><span class="mediamap-status-badge mediamap-status-<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span>
                            <?php if ( $row->status === 'rejected' && $row->rejection_note ) : ?>
                                <span class="mediamap-admin-note" title="<?php echo esc_attr( $row->rejection_note ); ?>">&#9432;</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( date_i18n( get_option('date_format'), strtotime( $row->submitted_at ) ) ); ?></td>
                        <td class="mediamap-row-actions">
                            <?php if ( $row->status === 'pending' ) : ?>
                            <button class="button button-primary button-small mediamap-approve-btn" data-id="<?php echo (int) $row->id; ?>"><?php esc_html_e( 'Approve', 'media-map' ); ?></button>
                            <button class="button button-small mediamap-reject-btn" data-id="<?php echo (int) $row->id; ?>"><?php esc_html_e( 'Reject', 'media-map' ); ?></button>
                            <?php elseif ( $row->status === 'approved' ) : ?>
                            <button class="button button-small mediamap-reject-btn" data-id="<?php echo (int) $row->id; ?>"><?php esc_html_e( 'Revoke', 'media-map' ); ?></button>
                            <?php elseif ( $row->status === 'rejected' ) : ?>
                            <button class="button button-primary button-small mediamap-approve-btn" data-id="<?php echo (int) $row->id; ?>"><?php esc_html_e( 'Re-approve', 'media-map' ); ?></button>
                            <?php endif; ?>
                            <button class="button button-link-delete button-small mediamap-delete-btn" data-id="<?php echo (int) $row->id; ?>"><?php esc_html_e( 'Delete', 'media-map' ); ?></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>

            <?php if ( $pages > 1 ) : ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    echo wp_kses_post( paginate_links( [
						'base'    => add_query_arg( 'paged', '%#%' ),
						'format'  => '',
						'current' => $paged,
						'total'   => $pages,
					] ) );
                    ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Reject Modal -->
            <div id="mediamap-reject-modal" style="display:none;">
                <div class="mediamap-modal-inner">
                    <h2><?php esc_html_e( 'Reject Submission', 'media-map' ); ?></h2>
                    <label><?php esc_html_e( 'Optional rejection reason (sent to user):', 'media-map' ); ?></label>
                    <textarea id="mediamap-reject-note" rows="3" style="width:100%;"></textarea>
                    <p>
                        <button class="button button-primary" id="mediamap-reject-confirm"><?php esc_html_e( 'Confirm Reject', 'media-map' ); ?></button>
                        <button class="button" id="mediamap-reject-cancel"><?php esc_html_e( 'Cancel', 'media-map' ); ?></button>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    /* ------------------------------------------------------------------
       Page: Map Settings  (Issue #11 — removed redundant/misleading nonce block)
    ------------------------------------------------------------------ */
    public static function page_settings(): void {
        ?>
        <div class="wrap mediamap-admin-wrap">
            <h1><?php esc_html_e( 'Media Map — Map Settings', 'media-map' ); ?></h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'mediamap_map_settings' ); ?>
                <table class="form-table mediamap-settings-table">
                    <tr>
                        <th><?php esc_html_e( 'Default Map Center', 'media-map' ); ?></th>
                        <td>
                            <label><?php esc_html_e( 'Latitude:', 'media-map' ); ?>
                                <input type="number" step="any" min="-90" max="90" name="mediamap_default_lat"
                                       style="width:120px;"
                                       value="<?php echo esc_attr( get_option( 'mediamap_default_lat', 20 ) ); ?>" />
                            </label>
                            &nbsp;&nbsp;
                            <label><?php esc_html_e( 'Longitude:', 'media-map' ); ?>
                                <input type="number" step="any" min="-180" max="180" name="mediamap_default_lng"
                                       style="width:120px;"
                                       value="<?php echo esc_attr( get_option( 'mediamap_default_lng', 0 ) ); ?>" />
                            </label>
                            <p class="description"><?php esc_html_e( 'The map will open centred on these coordinates when there are no markers, or when "Zoom Bound to Content" is disabled.', 'media-map' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Default Zoom Level', 'media-map' ); ?></th>
                        <td>
                            <input type="number" name="mediamap_default_zoom" min="1" max="18"
                                   value="<?php echo (int) get_option( 'mediamap_default_zoom', 3 ); ?>" />
                            <p class="description"><?php esc_html_e( 'Initial zoom when the map first loads (before fitting to markers). 1 = world, 18 = street level.', 'media-map' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Basemap Tile URL', 'media-map' ); ?></th>
                        <td>
                            <input type="text" name="mediamap_basemap_url" class="large-text"
                                   value="<?php echo esc_attr( get_option( 'mediamap_basemap_url' ) ); ?>" />
                            <p class="description"><?php esc_html_e( 'Standard Leaflet tile URL template, e.g. https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', 'media-map' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Basemap Attribution', 'media-map' ); ?></th>
                        <td><input type="text" name="mediamap_basemap_attribution" class="large-text"
                                   value="<?php echo esc_attr( get_option( 'mediamap_basemap_attribution' ) ); ?>" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Min Zoom Level', 'media-map' ); ?></th>
                        <td><input type="number" name="mediamap_min_zoom" min="1" max="18"
                                   value="<?php echo (int) get_option( 'mediamap_min_zoom', 2 ); ?>" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Max Zoom Level', 'media-map' ); ?></th>
                        <td><input type="number" name="mediamap_max_zoom" min="2" max="22"
                                   value="<?php echo (int) get_option( 'mediamap_max_zoom', 19 ); ?>" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Default Map Height (px)', 'media-map' ); ?></th>
                        <td><input type="number" name="mediamap_default_height" min="200" max="2000"
                                   value="<?php echo (int) get_option( 'mediamap_default_height', 500 ); ?>" /></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Zoom Bound to Content', 'media-map' ); ?></th>
                        <td><label><input type="checkbox" name="mediamap_zoom_bound" value="1" <?php checked( 1, get_option('mediamap_zoom_bound',1) ); ?> />
                            <?php esc_html_e( 'Automatically fit map view to approved markers', 'media-map' ); ?></label></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Fullscreen Button', 'media-map' ); ?></th>
                        <td><label><input type="checkbox" name="mediamap_fullscreen" value="1" <?php checked( 1, get_option('mediamap_fullscreen',1) ); ?> />
                            <?php esc_html_e( 'Show fullscreen toggle on the map', 'media-map' ); ?></label></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Cluster Markers', 'media-map' ); ?></th>
                        <td><label><input type="checkbox" name="mediamap_cluster_markers" value="1" <?php checked( 1, get_option('mediamap_cluster_markers',1) ); ?> />
                            <?php esc_html_e( 'Group nearby markers into clusters (recommended for dense maps)', 'media-map' ); ?></label></td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Submission Rate Limit (per hour)', 'media-map' ); ?></th>
                        <td>
                            <input type="number" name="mediamap_rate_limit" min="0" max="100"
                                   value="<?php echo (int) get_option( 'mediamap_rate_limit', 5 ); ?>" />
                            <p class="description"><?php esc_html_e( 'Maximum submissions per user per hour. Set to 0 to disable.', 'media-map' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Email Notifications', 'media-map' ); ?></th>
                        <td>
                            <label><input type="checkbox" name="mediamap_notify_admin" value="1" <?php checked( 1, get_option('mediamap_notify_admin',1) ); ?> />
                            <?php esc_html_e( 'Notify admin of new submissions', 'media-map' ); ?></label><br>
                            <label><input type="checkbox" name="mediamap_notify_user" value="1" <?php checked( 1, get_option('mediamap_notify_user',1) ); ?> />
                            <?php esc_html_e( 'Notify user on approval / rejection', 'media-map' ); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th><?php esc_html_e( 'Panel Text Size', 'media-map' ); ?></th>
                        <td>
                            <select name="mediamap_panel_text_size">
                                <?php
                                $current_size = get_option( 'mediamap_panel_text_size', 'medium' );
                                $sizes = [
                                    'small'  => __( 'Small (0.8em)', 'media-map' ),
                                    'medium' => __( 'Medium (1em — default)', 'media-map' ),
                                    'large'  => __( 'Large (1.15em)', 'media-map' ),
                                    'xlarge' => __( 'Extra Large (1.3em)', 'media-map' ),
                                ];
                                foreach ( $sizes as $val => $label ) :
                                ?>
                                <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $current_size, $val ); ?>>
                                    <?php echo esc_html( $label ); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description"><?php esc_html_e( 'Controls the font size of text inside the info panel. Reduce if your themes base font size makes panel content too large.', 'media-map' ); ?></p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /* ------------------------------------------------------------------
       Page: Marker Styles
    ------------------------------------------------------------------ */
    public static function page_markers(): void {
        $types = [
            'image'   => __( 'Image Marker',   'media-map' ),
            'video'   => __( 'Video Marker',   'media-map' ),
            'audio'   => __( 'Audio Marker',   'media-map' ),
            'text'    => __( 'Text Marker',    'media-map' ),
            'pending' => __( 'Pending Marker', 'media-map' ),
        ];
        ?>
        <div class="wrap mediamap-admin-wrap">
            <h1><?php esc_html_e( 'Media Map — Marker Styles', 'media-map' ); ?></h1>
            <p class="description"><?php esc_html_e( 'Set a colour for each marker type, or supply a custom icon URL / data-URI to override the default SVG pin entirely.', 'media-map' ); ?></p>
            <form method="post" action="options.php">
                <?php settings_fields( 'mediamap_marker_settings' ); ?>
                <table class="form-table mediamap-settings-table">
                <?php
                $marker_defaults = [
                    'image'   => '#EAB308',
                    'video'   => '#EF4444',
                    'audio'   => '#8B5CF6',
                    'text'    => '#D1D5DB',
                    'pending' => '#FFFFFF',
                ];
                foreach ( $types as $key => $label ) :
                    $default_color = $marker_defaults[ $key ] ?? '#888888';
                ?>
                    <tr>
                        <th><?php echo esc_html( $label ); ?></th>
                        <td>
                            <label><?php esc_html_e( 'Colour:', 'media-map' ); ?>
                                <input type="color" name="mediamap_marker_<?php echo esc_attr( $key ); ?>"
                                       value="<?php echo esc_attr( get_option( "mediamap_marker_{$key}", $default_color ) ); ?>" />
                            </label>
                            &nbsp;&nbsp;
                            <label><?php esc_html_e( 'Custom Icon URL (leave blank for default):', 'media-map' ); ?>
                                <input type="url" class="regular-text" name="mediamap_icon_<?php echo esc_attr( $key ); ?>"
                                       value="<?php echo esc_attr( get_option( "mediamap_icon_{$key}", '' ) ); ?>"
                                       placeholder="https://…" />
                            </label>
                            <div class="mediamap-marker-preview" data-color="<?php echo esc_attr( get_option( "mediamap_marker_{$key}", $default_color ) ); ?>" data-type="<?php echo esc_attr( $key ); ?>"></div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /* ------------------------------------------------------------------
       Page: Import / Export  (Issue #10 — inline script removed; JS logic
       moved to admin.js; strings passed via wp_localize_script above)
    ------------------------------------------------------------------ */
    public static function page_import_export(): void {
        ?>
        <div class="wrap mediamap-admin-wrap">
            <h1><?php esc_html_e( 'Media Map — Import / Export', 'media-map' ); ?></h1>

            <!-- ===== EXPORT ===== -->
            <h2><?php esc_html_e( 'Export Submissions', 'media-map' ); ?></h2>
            <p><?php esc_html_e( 'Download all submissions as a file. Use this to back up data or migrate to another site.', 'media-map' ); ?></p>
            <table class="form-table mediamap-settings-table">
                <tr>
                    <th><?php esc_html_e( 'Status Filter', 'media-map' ); ?></th>
                    <td>
                        <select id="mediamap-export-status">
                            <option value=""><?php esc_html_e( 'All', 'media-map' ); ?></option>
                            <option value="approved"><?php esc_html_e( 'Approved only', 'media-map' ); ?></option>
                            <option value="pending"><?php esc_html_e( 'Pending only', 'media-map' ); ?></option>
                            <option value="rejected"><?php esc_html_e( 'Rejected only', 'media-map' ); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Format', 'media-map' ); ?></th>
                    <td>
                        <label><input type="radio" name="mediamap-export-format" value="json" checked /> JSON</label>
                        &nbsp;&nbsp;
                        <label><input type="radio" name="mediamap-export-format" value="csv" /> CSV</label>
                    </td>
                </tr>
            </table>
            <p>
                <button type="button" class="button button-primary" id="mediamap-export-btn">
                    <?php esc_html_e( 'Download Export', 'media-map' ); ?>
                </button>
                <span id="mediamap-export-msg" style="margin-left:10px;"></span>
            </p>

            <hr>

            <!-- ===== IMPORT ===== -->
            <h2><?php esc_html_e( 'Import Submissions', 'media-map' ); ?></h2>
            <p><?php esc_html_e( 'Upload a previously exported JSON or CSV file to add submissions to this site.', 'media-map' ); ?></p>
            <p class="description">
                <?php esc_html_e( 'Imported submissions will be set to "pending" status by default so you can review them before they appear on the map. Duplicate URLs are skipped automatically.', 'media-map' ); ?>
            </p>
            <table class="form-table mediamap-settings-table">
                <tr>
                    <th><?php esc_html_e( 'File', 'media-map' ); ?></th>
                    <td>
                        <input type="file" id="mediamap-import-file" accept=".json,.csv" />
                        <p class="description"><?php esc_html_e( 'Accepted formats: .json (exported from this plugin), .csv (exported from this plugin).', 'media-map' ); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><?php esc_html_e( 'Import Status', 'media-map' ); ?></th>
                    <td>
                        <select id="mediamap-import-status">
                            <option value="pending"><?php esc_html_e( 'Pending (recommended)', 'media-map' ); ?></option>
                            <option value="approved"><?php esc_html_e( 'Approved — publish immediately', 'media-map' ); ?></option>
                        </select>
                    </td>
                </tr>
            </table>
            <p>
                <button type="button" class="button button-primary" id="mediamap-import-btn">
                    <?php esc_html_e( 'Import File', 'media-map' ); ?>
                </button>
                <span id="mediamap-import-msg" style="margin-left:10px;"></span>
            </p>
            <div id="mediamap-import-results" style="margin-top:12px;"></div>
        </div>
        <?php
    }
}
