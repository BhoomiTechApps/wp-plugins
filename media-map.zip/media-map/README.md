# Media Map — WordPress Plugin

An interactive Leaflet-based map that lets registered users submit multimedia content pinned to real-world coordinates, with full admin approval workflow.

---

## Installation

1. Copy the `media-map-plugin` folder into `/wp-content/plugins/`.
2. Activate **Media Map** from *WordPress Admin → Plugins*.
3. Use the shortcode `[mediamap]` in any page or post to display the map.
4. Visit **Media Map → Map Settings** and **Marker Styles** to configure.

---

## Shortcode

```
[mediamap]
[mediamap height="600"]
[mediamap height="400" class="my-custom-class"]
```

| Attribute | Default             | Description                 |
|-----------|---------------------|-----------------------------|
| `height`  | from admin settings | Map height in pixels        |
| `class`   | *(empty)*           | Extra CSS class on wrapper  |

---

## Features

### Frontend (logged-in users only)
- **Place Search** — Nominatim-powered search with autocomplete suggestions.
- **Click-to-pin** — Click anywhere on the map to drop a draggable location marker.
- **Media URL submission** — Paste any URL from hundreds of platforms; the plugin auto-detects whether it is an image, video, or audio.
- **Text-only submissions** — Omit the URL for a text note.
- **Pending markers** — Your own awaiting-approval submissions appear immediately with a distinctive cross/X marker (coloured differently from approved content).
- **My Submissions panel** — Lists all your submissions with status, edit (pending only), and delete controls.
- **Rate limiting** — Configurable cap on submissions per user per hour.
- **Duplicate URL detection** — Warns if the same URL has already been submitted.

### Map display
- **Leaflet 1.9** with OpenStreetMap basemap by default.
- **Nominatim place search** built in.
- **Current user location** button (bottom-right).
- **Zoom controls** (top-left).
- **Marker clustering** for dense maps (optional).
- **Fullscreen** toggle (optional).
- **Zoom-to-bounds** on load (optional).

### Info panel (below map)
- Opens when a marker is clicked.
- Shows a **thumbnail** on the left (YouTube preview, direct image, or placeholder icon for audio/video/image).
- **Description text** and place name on the right.
- Click a **video/image thumbnail** → opens in a full-screen **lightbox**.
- Click an **audio thumbnail** → opens inline audio player (HTML5 or embed for SoundCloud/Spotify).
- Text-only submissions show only the description.

### Admin
- **Submissions page** — filterable by status (All / Pending / Approved / Rejected), searchable, paginated.
- **Approve** — one click; user is notified by email.
- **Reject** — optional rejection note sent to user.
- **Re-approve / Revoke** — change status at any time.
- **Bulk delete**.
- **Admin notice** on the WP dashboard when pending items exist.

### Admin settings
| Page | Options |
|------|---------|
| Map Settings | Basemap tile URL, attribution, min/max zoom, map height, zoom-bound-to-content, fullscreen button, marker clustering, rate limit, email notifications |
| Marker Styles | Per-type colour picker + custom icon URL for Image, Video, Audio, Text, Pending markers |

### Email notifications
- Admin notified on every new submission.
- User notified on approval or rejection (with optional reason).
- Both can be toggled independently.

---

## Supported Platforms (auto-detected)

**Video:** YouTube, Vimeo, Dailymotion, Twitch, TikTok, Facebook Watch, Twitter/X, Reddit, Streamable, Wistia, Loom, TED, Bilibili, Rumble, Odysee, Brightcove, Panopto, and more.

**Audio:** Spotify, SoundCloud, Apple Podcasts, Anchor, Bandcamp, Mixcloud, Audiomack, Buzzsprout, Podbean, Simplecast, Transistor, Audius, and more.

**Image:** Imgur, Flickr, Unsplash, Pexels, Pixabay, Shutterstock, 500px, DeviantArt, ArtStation, Behance, Dribbble, Giphy, Tenor, Cloudinary, ImgBB, PostImages, and more — plus direct image file URLs (.jpg, .png, .gif, .webp, .avif…).

---

## File Structure

```
media-map-plugin/
├── media-map.php                        ← Plugin entry point
├── includes/
│   ├── class-mediamap-install.php       ← Activation, DB creation, default options
│   ├── class-mediamap-post-type.php     ← DB helpers (insert, list, approve, etc.)
│   ├── class-mediamap-settings.php      ← Settings getter
│   ├── class-mediamap-ajax.php          ← All AJAX handlers
│   ├── class-mediamap-shortcode.php     ← [mediamap] shortcode & form HTML
│   └── class-mediamap-notifications.php ← Email notifications
├── admin/
│   └── class-mediamap-admin.php         ← Admin menus, pages, settings registration
├── frontend/
│   └── class-mediamap-frontend.php      ← Frontend asset enqueueing & localisation
└── assets/
    ├── css/
    │   ├── frontend.css
    │   └── admin.css
    └── js/
        ├── frontend.js                  ← Map, markers, form, lightbox, audio player
        └── admin.js                     ← Admin table actions (approve/reject/delete)
```

---

## Database Tables

### `wp_mediamap_submissions`
| Column | Type | Notes |
|--------|------|-------|
| id | BIGINT PK | Auto-increment |
| user_id | BIGINT | WP user ID |
| lat / lng | DECIMAL(10,7) | Coordinates |
| place_name | VARCHAR(500) | From Nominatim |
| media_type | ENUM | image / video / audio / text |
| media_url | TEXT | Original URL |
| description | TEXT | User's text |
| status | ENUM | pending / approved / rejected |
| rejection_note | TEXT | Admin's optional note |
| url_hash | VARCHAR(64) | SHA-256 for duplicate detection |
| submitted_at | DATETIME | |
| reviewed_at | DATETIME | |
| reviewed_by | BIGINT | Admin user ID |

### `wp_mediamap_rate_log`
Tracks submission timestamps per user for rate limiting.

---

## Requirements
- WordPress 6.2+
- PHP 7.4+
- MySQL 5.7+ / MariaDB 10.3+
- No extra PHP packages required.
