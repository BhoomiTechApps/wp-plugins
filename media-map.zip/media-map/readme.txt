=== Media Map ===
Contributors: bhoomitechfoundation
Tags: map, leaflet, media, submissions, interactive
Requires at least: 6.2
Tested up to: 7.0
Stable tag: 1.4.0
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Interactive Leaflet map with user-submitted multimedia content, admin approval workflow, and full frontend/backend management.

== Description ==

Media Map lets registered users submit multimedia content (images, videos, audio, or text notes) pinned to real-world coordinates. Admins review and approve submissions before they appear publicly on the map.

**Key features:**

* Interactive Leaflet map embedded via shortcode `[mediamap]`
* Users can search for places, drop a pin, and submit a media URL or text note
* Auto-detection of media type from hundreds of platforms (YouTube, Spotify, Imgur, etc.)
* Admin approval workflow — submissions are held as pending until reviewed
* Email notifications for admins (new submission) and users (approved/rejected)
* Marker clustering for dense maps
* Fullscreen toggle
* Per-user rate limiting (configurable submissions per hour)
* Import/export submissions as JSON or CSV
* Fully translatable (text domain: `media-map`)

== Installation ==

1. Upload the `media-map` folder to the `/wp-content/plugins/` directory.
2. Activate **Media Map** from *WordPress Admin → Plugins*.
3. Add the shortcode `[mediamap]` to any page or post.
4. Configure the map via **Media Map → Map Settings** and **Media Map → Marker Styles**.

== Frequently Asked Questions ==

= How do I display the map? =

Add `[mediamap]` to any page or post. You can optionally set a custom height: `[mediamap height="600"]`.

= Do users need to be logged in to submit? =

Yes. Only logged-in users can submit content. Anyone can view the map.

= Can I limit how many submissions a user makes? =

Yes — go to **Media Map → Map Settings** and set the **Submission Rate Limit** (submissions per hour per user). Set to 0 to disable limiting.

= Where is the data stored? =

Submissions are stored in two custom database tables: `{prefix}mediamap_submissions` and `{prefix}mediamap_rate_log`.

= How do I export my data? =

Go to **Media Map → Import / Export** and choose JSON or CSV format.

== Screenshots ==

1. The frontend map with approved markers and the submission form.
2. The admin submissions list with approve/reject actions.
3. The Map Settings admin page.
4. The Marker Styles admin page.
5. The Import/Export admin page.

== Changelog ==

= 1.4.0 =
* Initial public release.
* Interactive Leaflet map with multimedia submission support.
* Admin approval workflow with email notifications.
* Import/Export (JSON and CSV).
* Marker clustering and fullscreen support.
* Configurable per-user rate limiting.
