<?php
/**
 * Uninstall routine for Media Map.
 *
 * Drops custom tables and removes all plugin options when
 * the user deletes the plugin from the WordPress admin.
 *
 * @package MediaMap
 */

// Only run when WordPress itself triggers an uninstall.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Drop custom tables.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}mediamap_submissions" );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}mediamap_rate_log" );

// Remove all plugin options.
$mediamap_options = [
	'mediamap_basemap_url',
	'mediamap_basemap_attribution',
	'mediamap_min_zoom',
	'mediamap_max_zoom',
	'mediamap_zoom_bound',
	'mediamap_fullscreen',
	'mediamap_default_height',
	'mediamap_cluster_markers',
	'mediamap_rate_limit',
	'mediamap_notify_admin',
	'mediamap_notify_user',
	'mediamap_marker_image',
	'mediamap_marker_video',
	'mediamap_marker_audio',
	'mediamap_marker_text',
	'mediamap_marker_pending',
	'mediamap_icon_image',
	'mediamap_icon_video',
	'mediamap_icon_audio',
	'mediamap_icon_text',
	'mediamap_icon_pending',
	'mediamap_panel_text_size',
	'mediamap_default_lat',
	'mediamap_default_lng',
	'mediamap_default_zoom',
];

foreach ( $mediamap_options as $mediamap_opt ) {
	delete_option( $mediamap_opt );
}
