<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Frontend {

    private static bool $enqueued = false;

    public static function init() {
        // Assets are enqueued on demand by the shortcode renderer.
    }

    public static function enqueue_assets(): void {
        if ( self::$enqueued ) return;
        self::$enqueued = true;

        $settings = MediaMap_Settings::get_all();

        // ---- Leaflet core (bundled) ----
        wp_enqueue_style(
            'leaflet',
            MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet/leaflet.min.css',
            [], '1.9.4'
        );
        wp_enqueue_script(
            'leaflet',
            MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet/leaflet.min.js',
            [], '1.9.4', true
        );

        // ---- Marker Cluster (bundled) ----
        if ( $settings['cluster_markers'] ) {
            wp_enqueue_style(
                'leaflet-cluster-css',
                MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet-markercluster/MarkerCluster.css',
                [ 'leaflet' ], '1.5.3'
            );
            wp_enqueue_style(
                'leaflet-cluster-default',
                MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet-markercluster/MarkerCluster.Default.css',
                [ 'leaflet-cluster-css' ], '1.5.3'
            );
            wp_enqueue_script(
                'leaflet-cluster',
                MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet-markercluster/leaflet.markercluster.min.js',
                [ 'leaflet' ], '1.5.3', true
            );
        }

        // ---- Leaflet Fullscreen (bundled) ----
        if ( $settings['fullscreen'] ) {
            wp_enqueue_style(
                'leaflet-fullscreen-css',
                MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet-fullscreen/Control.FullScreen.css',
                [ 'leaflet' ], '2.4.0'
            );
            wp_enqueue_script(
                'leaflet-fullscreen',
                MEDIAMAP_PLUGIN_URL . 'assets/vendor/leaflet-fullscreen/Control.FullScreen.js',
                [ 'leaflet' ], '2.4.0', true
            );
        }

        // ---- Plugin CSS ----
        wp_enqueue_style(
            'mediamap-frontend',
            MEDIAMAP_PLUGIN_URL . 'assets/css/frontend.css',
            [ 'leaflet' ], MEDIAMAP_VERSION
        );

        // ---- Plugin JS ----
        wp_enqueue_script(
            'mediamap-frontend',
            MEDIAMAP_PLUGIN_URL . 'assets/js/frontend.js',
            [ 'leaflet', 'jquery' ], MEDIAMAP_VERSION, true
        );

        // ---- Panel text size: inject inline CSS ----
        $size_map = [
            'small'  => '0.8em',
            'medium' => '1em',
            'large'  => '1.15em',
            'xlarge' => '1.3em',
        ];
        $panel_size_key = $settings['panel_text_size'] ?? 'medium';
        $panel_font_size = $size_map[ $panel_size_key ] ?? '1em';
        $inline_css = ".mediamap-info-panel { font-size: {$panel_font_size}; }";
        wp_add_inline_style( 'mediamap-frontend', $inline_css );

        // ---- Localize config ----
        wp_localize_script( 'mediamap-frontend', 'MediaMapConfig', [
            'ajaxurl'      => admin_url( 'admin-ajax.php' ),
            'nonce_submit' => wp_create_nonce( 'mediamap_submit' ),
            'nonce_public' => wp_create_nonce( 'mediamap_public' ),
            'nonce_user'   => wp_create_nonce( 'mediamap_user' ),
            'logged_in'    => is_user_logged_in(),
            'settings'     => $settings,
            'i18n'         => [
                'clickToPin'    => __( 'Click on the map to place your pin.', 'media-map' ),
                'pinPlaced'     => __( 'Pin placed at', 'media-map' ),
                'submitting'    => __( 'Submitting…', 'media-map' ),
                'detectingType' => __( 'Detecting media type…', 'media-map' ),
                'pendingMarker' => __( 'Your submission (pending approval)', 'media-map' ),
                'confirmDelete' => __( 'Delete this submission?', 'media-map' ),
                'noLocation'    => __( 'Please select a location on the map first.', 'media-map' ),
                'noContent'     => __( 'Please provide a URL or description.', 'media-map' ),
                'searching'     => __( 'Searching…', 'media-map' ),
                'noResults'     => __( 'No places found.', 'media-map' ),
                'pendingTitle'  => __( 'Submission Awaiting Approval', 'media-map' ),
                'pendingMessage'=> __( 'This submission is awaiting admin approval and cannot be viewed yet.', 'media-map' ),
            ],
        ] );
    }
}
