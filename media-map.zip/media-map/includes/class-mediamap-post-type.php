<?php
defined( 'ABSPATH' ) || exit;

/**
 * Registers nothing as a CPT; the plugin stores submissions in a custom table.
 * This class provides helper DB methods consumed across the plugin.
 */
class MediaMap_Post_Type {

    public static function init() {
        // No CPT needed – all data lives in custom table.
    }

    /* ------------------------------------------------------------------
       DB Helpers
    ------------------------------------------------------------------ */

    public static function get_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'mediamap_submissions';
    }

    public static function get_rate_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'mediamap_rate_log';
    }

    /** Fetch a single submission by ID. */
    public static function get( int $id ): ?object {
        global $wpdb;

        $cache_key = 'mediamap_submission_' . $id;
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return $cached ?: null;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $row = $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM %i WHERE id = %d', self::get_table(), $id
        ) );
        wp_cache_set( $cache_key, $row ?: '', 'mediamap', 300 );
        return $row;
    }

    /**
     * Fetch all approved submissions (for map display).
     */
    public static function get_approved(): array {
        global $wpdb;

        $cache_key = 'mediamap_approved';
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return $cached;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $results = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, lat, lng, place_name, media_type, media_url, description, submitted_at
                 FROM %i
                 WHERE status = %s
                 ORDER BY submitted_at DESC',
                self::get_table(),
                'approved'
            )
        );
        $results = $results ?: [];
        wp_cache_set( $cache_key, $results, 'mediamap', 120 );
        return $results;
    }

    /**
     * Fetch pending submissions visible to a user (their own) or all (admin).
     */
    public static function get_pending( int $user_id = 0 ): array {
        global $wpdb;
        $t = self::get_table();

        $cache_key = 'mediamap_pending_' . $user_id;
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return $cached;
        }

        if ( $user_id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $results = $wpdb->get_results( $wpdb->prepare(
                'SELECT * FROM %i WHERE status = %s AND user_id = %d ORDER BY submitted_at DESC',
                $t,
                'pending',
                $user_id
            ) );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT s.*, u.user_login FROM %i s
                     LEFT JOIN ' . $wpdb->users . ' u ON u.ID = s.user_id
                     WHERE s.status = %s
                     ORDER BY s.submitted_at DESC',
                    $t,
                    'pending'
                )
            );
        }

        $results = $results ?: [];
        wp_cache_set( $cache_key, $results, 'mediamap', 60 );
        return $results;
    }

    /** Paginated list for admin. */
    public static function admin_list( array $args = [] ): array {
        global $wpdb;
        $t      = self::get_table();
        $status = isset( $args['status'] ) ? $args['status'] : '';
        $search = isset( $args['search'] ) ? '%' . $wpdb->esc_like( $args['search'] ) . '%' : '';
        $limit  = isset( $args['limit']  ) ? (int) $args['limit']  : 20;
        $offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;

        $where  = '1=1';
        $params = [];
        if ( $status ) {
            $where   .= ' AND s.status = %s';
            $params[] = $status;
        }
        if ( $search ) {
            $where   .= ' AND (s.description LIKE %s OR s.place_name LIKE %s OR u.user_login LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }

        $cache_key = 'mediamap_admin_list_' . md5( $status . $search . $limit . $offset );
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return $cached;
        }

        $count_params = array_merge( [ $t ], $params );
        $count_sql    = "SELECT COUNT(*) FROM %i s LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE {$where}";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
        $total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$count_params ) );

        $params[] = $limit;
        $params[] = $offset;
        $list_sql = "SELECT s.*, u.user_login
        FROM %i s
        LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id
        WHERE {$where}
        ORDER BY s.submitted_at DESC
        LIMIT %d OFFSET %d";
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.PreparedSQL.NotPrepared
        $rows = $wpdb->get_results( $wpdb->prepare( $list_sql, ...array_merge( [ $t ], $params ) ) );
        $rows = $rows ?: [];

        $result = compact( 'rows', 'total' );
        wp_cache_set( $cache_key, $result, 'mediamap', 60 );
        return $result;
    }

    /** Insert a new submission. Returns inserted ID or WP_Error. */
    public static function insert( array $data ) {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $result = $wpdb->insert( self::get_table(), [
            'user_id'      => (int)   $data['user_id'],
            'lat'          => (float) $data['lat'],
            'lng'          => (float) $data['lng'],
            'place_name'   => sanitize_text_field( $data['place_name'] ?? '' ),
            'media_type'   => sanitize_key( $data['media_type'] ),
            'media_url'    => esc_url_raw( $data['media_url'] ?? '' ),
            'description'  => sanitize_textarea_field( $data['description'] ?? '' ),
            'url_hash'     => $data['media_url'] ? hash( 'sha256', $data['media_url'] ) : '',
            'status'       => 'pending',
            'submitted_at' => current_time( 'mysql' ),
        ] );

        if ( false === $result ) {
            return new WP_Error( 'db_error', $wpdb->last_error );
        }

        // Bust caches after write.
        wp_cache_delete( 'mediamap_approved', 'mediamap' );
        wp_cache_delete( 'mediamap_pending_0', 'mediamap' );
        wp_cache_delete( 'mediamap_pending_' . (int) $data['user_id'], 'mediamap' );

        return $wpdb->insert_id;
    }

    /** Update status */
    public static function update_status( int $id, string $status, string $note = '', int $reviewer = 0 ): bool {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $ok = (bool) $wpdb->update( self::get_table(), [
            'status'         => $status,
            'rejection_note' => $note,
            'reviewed_at'    => current_time( 'mysql' ),
            'reviewed_by'    => $reviewer,
        ], [ 'id' => $id ] );

        if ( $ok ) {
            wp_cache_delete( 'mediamap_submission_' . $id, 'mediamap' );
            wp_cache_delete( 'mediamap_approved', 'mediamap' );
            wp_cache_delete( 'mediamap_pending_0', 'mediamap' );
        }

        return $ok;
    }

    /** Delete a submission */
    public static function delete( int $id ): bool {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $ok = (bool) $wpdb->delete( self::get_table(), [ 'id' => $id ] );

        if ( $ok ) {
            wp_cache_delete( 'mediamap_submission_' . $id, 'mediamap' );
            wp_cache_delete( 'mediamap_approved', 'mediamap' );
            wp_cache_delete( 'mediamap_pending_0', 'mediamap' );
        }

        return $ok;
    }

    /** Rate limit check: how many submissions has this user made in the last hour? */
    public static function count_recent( int $user_id ): int {
        global $wpdb;
        // Rate-limit counts must always be fresh — intentionally not cached.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        return (int) $wpdb->get_var( $wpdb->prepare(
            'SELECT COUNT(*) FROM %i WHERE user_id = %d AND submitted_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)',
            self::get_rate_table(), $user_id
        ) );
    }

    public static function log_submission( int $user_id ): void {
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $wpdb->insert( self::get_rate_table(), [
            'user_id'      => $user_id,
            'submitted_at' => current_time( 'mysql' ),
        ] );
    }

    /** Check if URL was already submitted */
    public static function url_exists( string $url ): bool {
        global $wpdb;
        $hash      = hash( 'sha256', $url );
        $cache_key = 'mediamap_url_exists_' . $hash;
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return (bool) $cached;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $count = $wpdb->get_var( $wpdb->prepare(
            'SELECT COUNT(*) FROM %i WHERE url_hash = %s', self::get_table(), $hash
        ) );
        $exists = (int) $count > 0;
        wp_cache_set( $cache_key, $exists ? 1 : 0, 'mediamap', 300 );
        return $exists;
    }

    /** User's own submissions (all statuses) */
    public static function get_user_submissions( int $user_id ): array {
        global $wpdb;

        $cache_key = 'mediamap_user_submissions_' . $user_id;
        $cached    = wp_cache_get( $cache_key, 'mediamap' );
        if ( false !== $cached ) {
            return $cached;
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $results = $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM %i WHERE user_id = %d ORDER BY submitted_at DESC',
            self::get_table(), $user_id
        ) );
        $results = $results ?: [];
        wp_cache_set( $cache_key, $results, 'mediamap', 120 );
        return $results;
    }

    /** Update a pending submission (user edit) */
    public static function update_submission( int $id, array $data ): bool {
        global $wpdb;
        $row = self::get( $id );
        if ( ! $row || $row->status !== 'pending' ) {
            return false;
        }
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
        $ok = (bool) $wpdb->update( self::get_table(), [
            'place_name'  => sanitize_text_field( $data['place_name'] ?? $row->place_name ),
            'media_type'  => sanitize_key( $data['media_type'] ?? $row->media_type ),
            'media_url'   => esc_url_raw( $data['media_url'] ?? $row->media_url ),
            'description' => sanitize_textarea_field( $data['description'] ?? $row->description ),
        ], [ 'id' => $id ] );

        if ( $ok ) {
            wp_cache_delete( 'mediamap_submission_' . $id, 'mediamap' );
            wp_cache_delete( 'mediamap_pending_0', 'mediamap' );
            wp_cache_delete( 'mediamap_pending_' . (int) $row->user_id, 'mediamap' );
            wp_cache_delete( 'mediamap_user_submissions_' . (int) $row->user_id, 'mediamap' );
        }

        return $ok;
    }
}
