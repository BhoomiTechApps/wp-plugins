<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Ajax {

    public static function init() {
        // Frontend submission
        add_action( 'wp_ajax_mediamap_submit',        [ __CLASS__, 'handle_submit'        ] );
        // Map data
        add_action( 'wp_ajax_mediamap_get_markers',   [ __CLASS__, 'handle_get_markers'   ] );
        add_action( 'wp_ajax_nopriv_mediamap_get_markers', [ __CLASS__, 'handle_get_markers' ] );
        // User: edit own pending
        add_action( 'wp_ajax_mediamap_edit',          [ __CLASS__, 'handle_edit'          ] );
        // User: delete own submission
        add_action( 'wp_ajax_mediamap_delete_own',    [ __CLASS__, 'handle_delete_own'    ] );
        // Admin: approve
        add_action( 'wp_ajax_mediamap_approve',       [ __CLASS__, 'handle_approve'       ] );
        // Admin: reject
        add_action( 'wp_ajax_mediamap_reject',        [ __CLASS__, 'handle_reject'        ] );
        // Admin: delete
        add_action( 'wp_ajax_mediamap_admin_delete',  [ __CLASS__, 'handle_admin_delete'  ] );
        // Admin: export
        add_action( 'wp_ajax_mediamap_export',        [ __CLASS__, 'handle_export'        ] );
        // Admin: import
        add_action( 'wp_ajax_mediamap_import',        [ __CLASS__, 'handle_import'        ] );
    }

    /* ------------------------------------------------------------------
       Helpers
    ------------------------------------------------------------------ */
    private static function json_success( $data = [] ): void {
        wp_send_json_success( $data );
    }

    private static function json_error( string $msg, int $code = 400 ): void {
        wp_send_json_error( [ 'message' => $msg ], $code );
    }

    /**
     * Verify nonce. All handlers call this before touching $_POST,
     * so PHPCS nonce-verification ignores below are intentional —
     * check_ajax_referer() is called here, upstream of every read.
     */
    private static function verify( string $action ): void {
        check_ajax_referer( $action, 'nonce' );
    }

    /**
     * Detect media type from URL.
     * Returns 'image' | 'video' | 'audio' | 'text' | '' (unknown/undetectable).
     */
    public static function detect_media_type( string $url ): string {
        $url_lower = strtolower( $url );

        // ---- Video platforms ----
        $video_hosts = [
            'youtube.com', 'youtu.be', 'vimeo.com', 'dailymotion.com',
            'twitch.tv', 'facebook.com/watch', 'fb.watch', 'tiktok.com',
            'instagram.com/reel', 'instagram.com/tv', 'twitter.com', 'x.com',
            'reddit.com', 'streamable.com', 'wistia.com', 'loom.com',
            'ted.com', 'bilibili.com', 'rumble.com', 'odysee.com',
            'peertube', 'brightcove.com', 'jwplayer.com', 'vidyard.com',
            'kaltura.com', 'panopto.com', 'sproutvideo.com', 'ustream.tv',
        ];
        foreach ( $video_hosts as $host ) {
            if ( strpos( $url_lower, $host ) !== false ) return 'video';
        }

        // ---- Audio platforms ----
        $audio_hosts = [
            'spotify.com', 'soundcloud.com', 'anchor.fm', 'podcasts.apple.com',
            'open.spotify.com', 'bandcamp.com', 'mixcloud.com', 'audiomack.com',
            'buzzsprout.com', 'simplecast.com', 'transistor.fm', 'podbean.com',
            'overcast.fm', 'pocketcasts.com', 'audius.co', 'hearthis.at',
            'reverbnation.com', 'last.fm',
        ];
        foreach ( $audio_hosts as $host ) {
            if ( strpos( $url_lower, $host ) !== false ) return 'audio';
        }

        // ---- Image platforms ----
        $image_hosts = [
            'imgur.com', 'flickr.com', 'unsplash.com', 'pexels.com',
            'pixabay.com', 'shutterstock.com', 'gettyimages.com',
            '500px.com', 'deviantart.com', 'artstation.com', 'behance.net',
            'dribbble.com', 'instagram.com', 'pinterest.com', 'giphy.com',
            'tenor.com', 'gfycat.com', 'photobucket.com', 'imageshack.com',
            'postimages.org', 'freeimagehosting.net', 'cloudinary.com',
            'imgbb.com', 'ibb.co',
        ];
        foreach ( $image_hosts as $host ) {
            if ( strpos( $url_lower, $host ) !== false ) return 'image';
        }

        // ---- File extension fallback ----
        $path = wp_parse_url( $url, PHP_URL_PATH );
        if ( $path ) {
            $ext    = pathinfo( $path, PATHINFO_EXTENSION );
            $images = [ 'jpg','jpeg','png','gif','webp','svg','bmp','tiff','avif' ];
            $videos = [ 'mp4','webm','ogg','ogv','mov','avi','mkv','flv','wmv' ];
            $audios = [ 'mp3','wav','flac','aac','ogg','oga','m4a','opus','wma' ];
            if ( in_array( $ext, $images, true ) ) return 'image';
            if ( in_array( $ext, $videos, true ) ) return 'video';
            if ( in_array( $ext, $audios, true ) ) return 'audio';
        }

        return ''; // Could not detect
    }

    /* ------------------------------------------------------------------
       Handler: Submit
    ------------------------------------------------------------------ */
    public static function handle_submit(): void {
        // Nonce verified via self::verify() — phpcs:ignore WordPress.Security.NonceVerification.Missing
        self::verify( 'mediamap_submit' );

        if ( ! is_user_logged_in() ) {
            self::json_error( __( 'You must be logged in to submit.', 'media-map' ), 403 );
        }

        $user_id = get_current_user_id();

        // Rate limit
        $limit = (int) get_option( 'mediamap_rate_limit', 5 );
        if ( $limit > 0 && MediaMap_Post_Type::count_recent( $user_id ) >= $limit ) {
            self::json_error( sprintf(
                /* translators: %d = maximum number of submissions allowed per hour */
                __( 'Submission limit reached. You may submit up to %d times per hour.', 'media-map' ),
                $limit
            ), 429 );
        }

        // Nonce already verified above via check_ajax_referer().
        // phpcs:disable WordPress.Security.NonceVerification.Missing
        $lat         = isset( $_POST['lat'] )         ? (float) $_POST['lat']                                         : null;
        $lng         = isset( $_POST['lng'] )         ? (float) $_POST['lng']                                         : null;
        $place_name  = isset( $_POST['place_name'] )  ? sanitize_text_field( wp_unslash( $_POST['place_name'] ) )     : '';
        $media_url   = isset( $_POST['media_url'] )   ? esc_url_raw( trim( wp_unslash( $_POST['media_url'] ) ) )      : '';
        $description = isset( $_POST['description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['description'] ) ) : '';
        $media_type  = isset( $_POST['media_type'] )  ? sanitize_key( wp_unslash( $_POST['media_type'] ) )            : '';
        // phpcs:enable WordPress.Security.NonceVerification.Missing

        if ( $lat === null || $lng === null ) {
            self::json_error( __( 'A map location is required.', 'media-map' ) );
        }
        if ( empty( $description ) && empty( $media_url ) ) {
            self::json_error( __( 'Please provide either a URL or a description.', 'media-map' ) );
        }

        // Validate / auto-detect media type
        $allowed_types = [ 'image', 'video', 'audio', 'text' ];
        if ( ! $media_url ) {
            $media_type = 'text';
        } else {
            if ( $media_type && ! in_array( $media_type, $allowed_types, true ) ) {
                self::json_error( __( 'Invalid media type.', 'media-map' ) );
            }
            if ( ! $media_type || $media_type === 'text' ) {
                $detected = self::detect_media_type( $media_url );
                $media_type = $detected ?: 'image';
            }
        }

        // Duplicate URL check
        if ( $media_url && MediaMap_Post_Type::url_exists( $media_url ) ) {
            self::json_error( __( 'This URL has already been submitted. It may be awaiting approval.', 'media-map' ) );
        }

        $insert_id = MediaMap_Post_Type::insert( compact( 'user_id','lat','lng','place_name','media_type','media_url','description' ) );
        if ( is_wp_error( $insert_id ) ) {
            self::json_error( $insert_id->get_error_message(), 500 );
        }

        MediaMap_Post_Type::log_submission( $user_id );
        MediaMap_Notifications::on_new_submission( $insert_id );

        self::json_success( [ 'message' => __( 'Submission received. It will appear on the map after admin approval.', 'media-map' ) ] );
    }

    /* ------------------------------------------------------------------
       Handler: Get Markers
    ------------------------------------------------------------------ */
    public static function handle_get_markers(): void {
        check_ajax_referer( 'mediamap_public', 'nonce' );

        $approved = MediaMap_Post_Type::get_approved();
        $markers  = [];
        foreach ( $approved as $row ) {
            $markers[] = [
                'id'     => (int)   $row->id,
                'lat'    => (float) $row->lat,
                'lng'    => (float) $row->lng,
                'place'  => $row->place_name,
                'type'   => $row->media_type,
                'url'    => $row->media_url,
                'desc'   => $row->description,
                'status' => 'approved',
            ];
        }

        // Pending markers for the current user (shown as pending on their own view)
        if ( is_user_logged_in() ) {
            $pending = MediaMap_Post_Type::get_pending( get_current_user_id() );
            foreach ( $pending as $row ) {
                $markers[] = [
                    'id'     => (int)   $row->id,
                    'lat'    => (float) $row->lat,
                    'lng'    => (float) $row->lng,
                    'place'  => $row->place_name,
                    'type'   => $row->media_type,
                    'url'    => $row->media_url,
                    'desc'   => $row->description,
                    'status' => 'pending',
                ];
            }
        }

        wp_send_json_success( $markers );
    }

    /* ------------------------------------------------------------------
       Handler: Edit own pending
    ------------------------------------------------------------------ */
    public static function handle_edit(): void {
        self::verify( 'mediamap_user' );
        if ( ! is_user_logged_in() ) self::json_error( 'Unauthorized', 403 );

        // Nonce already verified above via check_ajax_referer().
        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $id = (int) wp_unslash( $_POST['id'] ?? 0 );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        $row = MediaMap_Post_Type::get( $id );
        if ( ! $row || (int) $row->user_id !== get_current_user_id() ) {
            self::json_error( __( 'Not found or not yours.', 'media-map' ), 403 );
        }
        if ( $row->status !== 'pending' ) {
            self::json_error( __( 'Only pending submissions can be edited.', 'media-map' ) );
        }

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $updated = MediaMap_Post_Type::update_submission( $id, [
            'place_name'  => sanitize_text_field(     wp_unslash( $_POST['place_name']  ?? '' ) ),
            'media_type'  => sanitize_key(            wp_unslash( $_POST['media_type']  ?? $row->media_type ) ),
            'media_url'   => esc_url_raw( trim(       wp_unslash( $_POST['media_url']   ?? '' ) ) ),
            'description' => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
        ] );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        $updated ? self::json_success() : self::json_error( __( 'Update failed.', 'media-map' ), 500 );
    }

    /* ------------------------------------------------------------------
       Handler: Delete own
    ------------------------------------------------------------------ */
    public static function handle_delete_own(): void {
        self::verify( 'mediamap_user' );
        if ( ! is_user_logged_in() ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $id = (int) wp_unslash( $_POST['id'] ?? 0 );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        $row = MediaMap_Post_Type::get( $id );
        if ( ! $row || (int) $row->user_id !== get_current_user_id() ) {
            self::json_error( __( 'Not found or not yours.', 'media-map' ), 403 );
        }

        MediaMap_Post_Type::delete( $id ) ? self::json_success() : self::json_error( 'Delete failed.', 500 );
    }

    /* ------------------------------------------------------------------
       Handler: Admin Approve
    ------------------------------------------------------------------ */
    public static function handle_approve(): void {
        self::verify( 'mediamap_admin' );
        if ( ! current_user_can( 'manage_options' ) ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $id = (int) wp_unslash( $_POST['id'] ?? 0 );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        $ok = MediaMap_Post_Type::update_status( $id, 'approved', '', get_current_user_id() );
        if ( $ok ) {
            MediaMap_Notifications::on_approved( $id );
            self::json_success();
        } else {
            self::json_error( 'Failed.', 500 );
        }
    }

    /* ------------------------------------------------------------------
       Handler: Admin Reject
    ------------------------------------------------------------------ */
    public static function handle_reject(): void {
        self::verify( 'mediamap_admin' );
        if ( ! current_user_can( 'manage_options' ) ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $id   = (int) wp_unslash( $_POST['id'] ?? 0 );
        $note = sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        $ok = MediaMap_Post_Type::update_status( $id, 'rejected', $note, get_current_user_id() );
        if ( $ok ) {
            MediaMap_Notifications::on_rejected( $id, $note );
            self::json_success();
        } else {
            self::json_error( 'Failed.', 500 );
        }
    }

    /* ------------------------------------------------------------------
       Handler: Admin Delete
    ------------------------------------------------------------------ */
    public static function handle_admin_delete(): void {
        self::verify( 'mediamap_admin' );
        if ( ! current_user_can( 'manage_options' ) ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $id = (int) wp_unslash( $_POST['id'] ?? 0 );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        MediaMap_Post_Type::delete( $id ) ? self::json_success() : self::json_error( 'Failed.', 500 );
    }

    /* ------------------------------------------------------------------
       Handler: Export
    ------------------------------------------------------------------ */
    public static function handle_export(): void {
        self::verify( 'mediamap_admin' );
        if ( ! current_user_can( 'manage_options' ) ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $status = sanitize_key( wp_unslash( $_POST['status'] ?? '' ) );
        $format = sanitize_key( wp_unslash( $_POST['format'] ?? 'json' ) );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        if ( ! in_array( $format, [ 'json', 'csv' ], true ) ) {
            self::json_error( 'Invalid format.' );
        }

        global $wpdb;
        $t = MediaMap_Post_Type::get_table();

        if ( $status ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT id, user_id, lat, lng, place_name, media_type, media_url, description, status, submitted_at, reviewed_at
                    FROM %i WHERE status = %s ORDER BY submitted_at ASC',
                    $t,
                    $status
                ),
                ARRAY_A
            );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $rows = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT id, user_id, lat, lng, place_name, media_type, media_url, description, status, submitted_at, reviewed_at
                    FROM %i ORDER BY submitted_at ASC',
                    $t
                ),
                ARRAY_A
            );
        }

        $timestamp = gmdate( 'Y-m-d_His' );
        $label     = $status ?: 'all';

        if ( $format === 'json' ) {
            $content  = wp_json_encode( $rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
            $filename = "mediamap-export-{$label}-{$timestamp}.json";
        } else {
            $cols   = [ 'id','user_id','lat','lng','place_name','media_type','media_url','description','status','submitted_at','reviewed_at' ];
            $lines  = [];
            $lines[] = implode( ',', array_map( [ __CLASS__, 'csv_cell' ], $cols ) );
            foreach ( $rows as $r ) {
                $line = [];
                foreach ( $cols as $col ) {
                    $line[] = self::csv_cell( (string) ( $r[ $col ] ?? '' ) );
                }
                $lines[] = implode( ',', $line );
            }
            $content  = implode( "\r\n", $lines );
            $filename = "mediamap-export-{$label}-{$timestamp}.csv";
        }

        self::json_success( [
            'content'  => $content,
            'filename' => $filename,
            'count'    => count( $rows ),
        ] );
    }

    private static function csv_cell( string $val ): string {
        return '"' . str_replace( '"', '""', $val ) . '"';
    }

    /* ------------------------------------------------------------------
       Handler: Import
    ------------------------------------------------------------------ */
    public static function handle_import(): void {
        self::verify( 'mediamap_admin' );
        if ( ! current_user_can( 'manage_options' ) ) self::json_error( 'Unauthorized', 403 );

        // phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput
        $raw_content  = wp_unslash( $_POST['content']  ?? '' );
        $filename     = sanitize_file_name( wp_unslash( $_POST['filename'] ?? '' ) );
        $force_status = sanitize_key( wp_unslash( $_POST['status']   ?? 'pending' ) );
        // phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput

        if ( ! in_array( $force_status, [ 'pending', 'approved' ], true ) ) {
            $force_status = 'pending';
        }

        $ext  = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        $rows = [];

        if ( $ext === 'json' ) {
            $decoded = json_decode( $raw_content, true );
            if ( ! is_array( $decoded ) ) {
                self::json_error( __( 'Invalid JSON file.', 'media-map' ) );
            }
            $rows = $decoded;
        } elseif ( $ext === 'csv' ) {
            $lines = preg_split( '/\r\n|\r|\n/', trim( $raw_content ) );
            if ( count( $lines ) < 2 ) self::json_error( __( 'CSV file is empty or has no data rows.', 'media-map' ) );
            $headers = self::csv_parse_line( $lines[0] );
            for ( $i = 1; $i < count( $lines ); $i++ ) {
                if ( trim( $lines[ $i ] ) === '' ) continue;
                $values = self::csv_parse_line( $lines[ $i ] );
                $row    = [];
                foreach ( $headers as $k => $header ) {
                    $row[ trim( $header ) ] = $values[ $k ] ?? '';
                }
                $rows[] = $row;
            }
        } else {
            self::json_error( __( 'Unsupported file type. Please upload a .json or .csv file.', 'media-map' ) );
        }

        $imported = 0;
        $skipped  = 0;
        $errors   = 0;

        foreach ( $rows as $r ) {
            $lat         = isset( $r['lat'] )         ? (float) $r['lat']                                : null;
            $lng         = isset( $r['lng'] )         ? (float) $r['lng']                                : null;
            $media_url   = isset( $r['media_url'] )   ? esc_url_raw( trim( $r['media_url'] ) )           : '';
            $media_type  = isset( $r['media_type'] )  ? sanitize_key( $r['media_type'] )                 : 'text';
            $place_name  = isset( $r['place_name'] )  ? sanitize_text_field( $r['place_name'] )          : '';
            $description = isset( $r['description'] ) ? sanitize_textarea_field( $r['description'] )     : '';
            $user_id     = isset( $r['user_id'] )     ? (int) $r['user_id']                              : 0;

            if ( $lat === null || $lng === null ) {
                $errors++;
                continue;
            }

            if ( $media_url && MediaMap_Post_Type::url_exists( $media_url ) ) {
                $skipped++;
                continue;
            }

            $allowed_types = [ 'image', 'video', 'audio', 'text' ];
            if ( ! in_array( $media_type, $allowed_types, true ) ) {
                $media_type = 'text';
            }

            global $wpdb;
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
            $result = $wpdb->insert( MediaMap_Post_Type::get_table(), [
                'user_id'      => $user_id,
                'lat'          => $lat,
                'lng'          => $lng,
                'place_name'   => $place_name,
                'media_type'   => $media_type,
                'media_url'    => $media_url,
                'description'  => $description,
                'url_hash'     => $media_url ? hash( 'sha256', $media_url ) : '',
                'status'       => $force_status,
                'submitted_at' => current_time( 'mysql' ),
            ] );

            if ( false === $result ) {
                $errors++;
            } else {
                $imported++;
            }
        }

        self::json_success( compact( 'imported', 'skipped', 'errors' ) );
    }

    private static function csv_parse_line( string $line ): array {
        $result = [];
        $len    = strlen( $line );
        $i      = 0;
        while ( $i < $len ) {
            if ( $line[ $i ] === '"' ) {
                $i++;
                $field = '';
                while ( $i < $len ) {
                    if ( $line[ $i ] === '"' ) {
                        if ( $i + 1 < $len && $line[ $i + 1 ] === '"' ) {
                            $field .= '"';
                            $i += 2;
                        } else {
                            $i++;
                            break;
                        }
                    } else {
                        $field .= $line[ $i++ ];
                    }
                }
                $result[] = $field;
                if ( $i < $len && $line[ $i ] === ',' ) $i++;
            } else {
                $end = strpos( $line, ',', $i );
                if ( $end === false ) {
                    $result[] = substr( $line, $i );
                    break;
                }
                $result[] = substr( $line, $i, $end - $i );
                $i = $end + 1;
            }
        }
        return $result;
    }
}
