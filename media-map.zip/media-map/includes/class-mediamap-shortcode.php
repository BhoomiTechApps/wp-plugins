<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Shortcode {

    public static function init() {
        add_shortcode( 'mediamap', [ __CLASS__, 'render' ] );
    }

    public static function render( $atts ): string {
        $atts = shortcode_atts( [
            'height' => get_option( 'mediamap_default_height', 500 ),
            'class'  => '',
        ], $atts, 'mediamap' );

        // Enqueue assets
        MediaMap_Frontend::enqueue_assets();

        $height   = (int) $atts['height'];
        $extra    = esc_attr( $atts['class'] );
        $map_id   = 'mediamap-' . wp_unique_id();

        ob_start();
        ?>
		<div class="mediamap-wrap <?php echo esc_attr( $extra ); ?>" data-map-id="<?php echo esc_attr( $map_id ); ?>">

            <?php /* ---- Submission search — above map ---- */ ?>
            <div class="mediamap-sub-search-bar" id="<?php echo esc_attr( $map_id ); ?>-sub-search" aria-label="<?php esc_attr_e( 'Search submissions', 'media-map' ); ?>">
                <div class="mediamap-sub-search-inner">
                    <span class="mediamap-sub-search-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                            <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.156a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/>
                        </svg>
                    </span>
                    <input type="text"
                           class="mediamap-sub-search-input"
                           placeholder="<?php esc_attr_e( 'Search submissions by description or place name…', 'media-map' ); ?>"
                           autocomplete="off"
                           aria-autocomplete="list"
                           aria-expanded="false" />
                    <button class="mediamap-sub-search-clear" aria-label="<?php esc_attr_e( 'Clear search', 'media-map' ); ?>" style="display:none;">&#215;</button>
                </div>
                <ul class="mediamap-sub-search-results" role="listbox" style="display:none;"></ul>
            </div>
            <div id="<?php echo esc_attr( $map_id ); ?>"
                 class="mediamap-canvas"
                 style="height:<?php echo absint( $height ); ?>px; width:100%; position:relative; z-index:1;">
            </div>
            <div class="mediamap-info-panel" id="<?php echo esc_attr( $map_id ); ?>-panel">
                <div class="mediamap-panel-inner">
                    <p class="mediamap-panel-hint"><?php esc_html_e( 'Click a marker to see details.', 'media-map' ); ?></p>
                </div>
            </div>
            <?php if ( is_user_logged_in() ) : ?>
            <div class="mediamap-submit-wrap" id="<?php echo esc_attr( $map_id ); ?>-submit">
                <?php self::render_submit_form( $map_id ); ?>
            </div>
            <?php else : ?>
            <p class="mediamap-login-notice">
                <?php printf(
					/* translators: %s = URL of the login page */
                    wp_kses( __( '<a href="%s">Log in</a> to add content to the map.', 'media-map' ), [ 'a' => [ 'href' => [] ] ] ),
                    esc_url( self::get_login_url() )
                ); ?>
            </p>
            <?php endif; ?>

            <?php if ( is_user_logged_in() ) : ?>
            <div class="mediamap-my-submissions" id="<?php echo esc_attr( $map_id ); ?>-my">
                <?php self::render_my_submissions(); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function render_submit_form( string $map_id ): void {
        ?>
        <div class="mediamap-form-toggle">
            <button type="button" class="mediamap-btn mediamap-btn-primary mediamap-toggle-form">
                &#43; <?php esc_html_e( 'Add to Map', 'media-map' ); ?>
            </button>
        </div>
        <div class="mediamap-form-container" style="display:none;">
            <h3><?php esc_html_e( 'Add a Location', 'media-map' ); ?></h3>
            <p class="mediamap-form-hint">
                <?php esc_html_e( 'Search for a place or click directly on the map to pin a location, then fill in the details below.', 'media-map' ); ?>
            </p>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Search Place', 'media-map' ); ?></label>
                <input type="text" class="mediamap-place-search" placeholder="<?php esc_attr_e( 'Type a place name…', 'media-map' ); ?>" />
                <div class="mediamap-place-results"></div>
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Selected Coordinates', 'media-map' ); ?></label>
                <input type="text" class="mediamap-coords-display" readonly placeholder="<?php esc_attr_e( 'Click map or search to set', 'media-map' ); ?>" />
                <input type="hidden" class="mediamap-lat-input" />
                <input type="hidden" class="mediamap-lng-input" />
                <input type="hidden" class="mediamap-place-name-input" />
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Media URL', 'media-map' ); ?></label>
                <input type="url" class="mediamap-url-input" placeholder="<?php esc_attr_e( 'https://… (image, video, audio) — leave blank for text only', 'media-map' ); ?>" />
                <small><?php esc_html_e( 'Supports: YouTube, Vimeo, TikTok, SoundCloud, Spotify, Flickr, Imgur, and hundreds more.', 'media-map' ); ?></small>
                <div class="mediamap-url-feedback"></div>
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Description', 'media-map' ); ?></label>
                <textarea class="mediamap-desc-input" rows="3" placeholder="<?php esc_attr_e( 'Describe this location…', 'media-map' ); ?>"></textarea>
            </div>
            <div class="mediamap-form-actions">
                <button type="button" class="mediamap-btn mediamap-btn-primary mediamap-submit-btn">
                    <?php esc_html_e( 'Submit for Approval', 'media-map' ); ?>
                </button>
                <button type="button" class="mediamap-btn mediamap-btn-secondary mediamap-cancel-btn">
                    <?php esc_html_e( 'Cancel', 'media-map' ); ?>
                </button>
            </div>
            <div class="mediamap-form-feedback"></div>
        </div>
        <?php
    }

    /**
     * Return the best login URL: prefer a custom login page registered by
     * a membership/user-management plugin (e.g. WooCommerce, Ultimate Member,
     * ProfilePress, Theme My Login, BuddyPress, etc.) over the default
     * wp-login.php, so the user stays on the site's branded login form.
     *
     * Detection order:
     *  1. Filter `mediamap_login_url` – lets other plugins or themes override.
     *  2. WooCommerce my-account page.
     *  3. Ultimate Member login page.
     *  4. ProfilePress login URL.
     *  5. Theme My Login page.
     *  6. Page whose slug matches a common convention (login, sign-in, etc.).
     *  7. Fallback: WordPress default wp_login_url().
     */
    private static function get_login_url(): string {
        $redirect = (string) get_permalink();

        // 1. Allow full override via filter.
        $filtered = apply_filters( 'mediamap_login_url', '', $redirect );
        if ( $filtered ) {
            return (string) $filtered;
        }

        // 2. WooCommerce my-account page (acts as login when logged out).
        if ( function_exists( 'wc_get_page_id' ) ) {
            $wc_page_id = wc_get_page_id( 'myaccount' );
            if ( $wc_page_id > 0 ) {
                return add_query_arg( 'redirect_to', urlencode( $redirect ), get_permalink( $wc_page_id ) );
            }
        }

        // 3. Ultimate Member login page.
        if ( function_exists( 'um_get_core_page' ) ) {
            $um_url = um_get_core_page( 'login' );
            if ( $um_url ) {
                return add_query_arg( 'redirect_to', urlencode( $redirect ), $um_url );
            }
        }

        // 4. ProfilePress login page.
        if ( function_exists( 'ppress_get_login_url' ) ) {
            return (string) ppress_get_login_url( $redirect );
        }

        // 5. Theme My Login.
        if ( function_exists( 'tml_get_action_url' ) ) {
            $tml_url = tml_get_action_url( 'login' );
            if ( $tml_url ) {
                return add_query_arg( 'redirect_to', urlencode( $redirect ), $tml_url );
            }
        }

        // 6. Page slug convention – look for common login page slugs.
        $common_slugs = [ 'login', 'sign-in', 'signin', 'member-login', 'account', 'my-account', 'user-login' ];
        foreach ( $common_slugs as $slug ) {
            $page = get_page_by_path( $slug );
            if ( $page && $page->post_status === 'publish' ) {
                return add_query_arg( 'redirect_to', urlencode( $redirect ), get_permalink( $page->ID ) );
            }
        }

        // 7. Fallback: native WordPress login.
        return wp_login_url( $redirect );
    }

    private static function render_my_submissions(): void {
        $subs = MediaMap_Post_Type::get_user_submissions( get_current_user_id() );
        if ( empty( $subs ) ) return;
        ?>
        <div class="mediamap-my-subs-toggle">
            <button type="button" class="mediamap-btn mediamap-btn-ghost mediamap-toggle-my-subs">
                <?php esc_html_e( 'My Submissions', 'media-map' ); ?>
                <span class="mediamap-badge"><?php echo count( $subs ); ?></span>
            </button>
        </div>
        <div class="mediamap-my-subs-list" style="display:none;">
            <table class="mediamap-my-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Place', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Type', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'media-map' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $subs as $s ) : ?>
                    <tr data-sub-id="<?php echo (int) $s->id; ?>">
                        <td><?php echo esc_html( $s->place_name ?: "{$s->lat}, {$s->lng}" ); ?></td>
                        <td><?php echo esc_html( ucfirst( $s->media_type ) ); ?></td>
                        <td><span class="mediamap-status mediamap-status-<?php echo esc_attr( $s->status ); ?>"><?php echo esc_html( ucfirst( $s->status ) ); ?></span></td>
                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $s->submitted_at ) ) ); ?></td>
                        <td>
                            <?php if ( $s->status === 'pending' ) : ?>
                            <button class="mediamap-btn-link mediamap-edit-own" data-id="<?php echo (int) $s->id; ?>"><?php esc_html_e( 'Edit', 'media-map' ); ?></button>
                            <?php endif; ?>
                            <button class="mediamap-btn-link mediamap-del-own" data-id="<?php echo (int) $s->id; ?>"><?php esc_html_e( 'Delete', 'media-map' ); ?></button>
                            <?php if ( $s->status === 'rejected' && $s->rejection_note ) : ?>
                            <span class="mediamap-rejection-note" title="<?php echo esc_attr( $s->rejection_note ); ?>">&#9432;</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
