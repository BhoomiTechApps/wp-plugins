/* global MediaMapAdmin, jQuery */
( function ( $, cfg ) {
    'use strict';

    let rejectTargetId = null;

    $( document ).on( 'click', '.mediamap-approve-btn', function () {
        if ( ! confirm( cfg.i18n.confirmApprove ) ) return;
        const id  = $( this ).data( 'id' );
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_approve', nonce: cfg.nonce, id: id }, function ( r ) {
            if ( r.success ) {
                $row.find( '.mediamap-status-badge' ).text( 'Approved' ).removeClass( 'mediamap-status-pending mediamap-status-rejected' ).addClass( 'mediamap-status-approved' );
                $row.find( '.mediamap-approve-btn' ).remove();
                $row.find( '.mediamap-reject-btn' ).text( 'Revoke' );
            } else {
                alert( 'Error: ' + ( r.data && r.data.message ? r.data.message : 'Unknown error' ) );
            }
        } );
    } );

    $( document ).on( 'click', '.mediamap-reject-btn', function () {
        rejectTargetId = $( this ).data( 'id' );
        $( '#mediamap-reject-note' ).val( '' );
        $( '#mediamap-reject-modal' ).dialog( {
            title:  cfg.i18n.confirmReject,
            modal:  true,
            width:  480,
            buttons: {},
        } );
        $( '#mediamap-reject-modal' ).show();
    } );

    $( document ).on( 'click', '#mediamap-reject-confirm', function () {
        const id   = rejectTargetId;
        const note = $( '#mediamap-reject-note' ).val();
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_reject', nonce: cfg.nonce, id: id, note: note }, function ( r ) {
            $( '#mediamap-reject-modal' ).hide();
            if ( r.success ) {
                $row.find( '.mediamap-status-badge' ).text( 'Rejected' ).removeClass( 'mediamap-status-pending mediamap-status-approved' ).addClass( 'mediamap-status-rejected' );
                $row.find( '.mediamap-approve-btn, .mediamap-reject-btn' ).remove();
                const $td = $row.find( '.mediamap-row-actions' );
                $td.prepend( '<button class="button button-primary button-small mediamap-approve-btn" data-id="' + id + '">Re-approve</button> ' );
                $td.prepend( '<button class="button button-link-delete button-small mediamap-delete-btn" data-id="' + id + '">Delete</button> ' );
            }
        } );
    } );

    $( document ).on( 'click', '#mediamap-reject-cancel', function () {
        $( '#mediamap-reject-modal' ).hide();
    } );

    $( document ).on( 'click', '.mediamap-delete-btn', function () {
        if ( ! confirm( cfg.i18n.confirmDelete ) ) return;
        const id  = $( this ).data( 'id' );
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_admin_delete', nonce: cfg.nonce, id: id }, function ( r ) {
            if ( r.success ) $row.fadeOut( 200, function () { $( this ).remove(); } );
        } );
    } );

    // Colour preview on marker settings page
    $( 'input[type=color]' ).on( 'input change', function () {
        const $row = $( this ).closest( 'tr' );
        $row.find( '.mediamap-marker-preview' ).css( 'background', $( this ).val() );
    } ).trigger( 'input' );

    // ---- Import / Export page (Issue #10: moved from inline <script>) ----
    if ( $( '#mediamap-export-btn' ).length ) {

        $( '#mediamap-export-btn' ).on( 'click', function () {
            var status = $( '#mediamap-export-status' ).val();
            var format = $( 'input[name="mediamap-export-format"]:checked' ).val();
            $( '#mediamap-export-msg' ).text( cfg.i18n.preparing );

            $.post( cfg.ajaxurl, {
                action : 'mediamap_export',
                nonce  : cfg.nonce,
                status : status,
                format : format
            }, function ( resp ) {
                if ( ! resp.success ) {
                    $( '#mediamap-export-msg' ).text( resp.data.message || cfg.i18n.exportFailed );
                    return;
                }
                var content  = resp.data.content;
                var filename = resp.data.filename;
                var mime     = format === 'csv' ? 'text/csv' : 'application/json';
                var blob = new Blob( [ content ], { type: mime } );
                var url  = URL.createObjectURL( blob );
                var a    = document.createElement( 'a' );
                a.href     = url;
                a.download = filename;
                document.body.appendChild( a );
                a.click();
                document.body.removeChild( a );
                URL.revokeObjectURL( url );
                $( '#mediamap-export-msg' ).text( resp.data.count + ' ' + cfg.i18n.rowsExported );
            } ).fail( function () {
                $( '#mediamap-export-msg' ).text( cfg.i18n.requestFailed );
            } );
        } );

        $( '#mediamap-import-btn' ).on( 'click', function () {
            var file = $( '#mediamap-import-file' )[ 0 ].files[ 0 ];
            if ( ! file ) {
                $( '#mediamap-import-msg' ).text( cfg.i18n.chooseFile );
                return;
            }
            var reader = new FileReader();
            reader.onload = function ( e ) {
                var importStatus = $( '#mediamap-import-status' ).val();
                $( '#mediamap-import-msg' ).text( cfg.i18n.importing );
                $( '#mediamap-import-results' ).html( '' );

                $.post( cfg.ajaxurl, {
                    action  : 'mediamap_import',
                    nonce   : cfg.nonce,
                    content : e.target.result,
                    filename: file.name,
                    status  : importStatus
                }, function ( resp ) {
                    if ( ! resp.success ) {
                        $( '#mediamap-import-msg' ).text( resp.data.message || cfg.i18n.importFailed );
                        return;
                    }
                    var d = resp.data;
                    $( '#mediamap-import-msg' ).text( '' );
                    $( '#mediamap-import-results' ).html(
                        '<div class="notice notice-success inline"><p>' +
                        d.imported + ' ' + cfg.i18n.imported + ', ' +
                        d.skipped  + ' ' + cfg.i18n.skipped  + ', ' +
                        d.errors   + ' ' + cfg.i18n.errors   +
                        '</p></div>'
                    );
                } ).fail( function () {
                    $( '#mediamap-import-msg' ).text( cfg.i18n.requestFailed );
                } );
            };
            reader.readAsText( file );
        } );
    }

} )( jQuery, MediaMapAdmin );
