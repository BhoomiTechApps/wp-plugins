/* global L, MediaMapConfig, jQuery */
( function ( $, cfg ) {
    'use strict';

    /* ===================================================================
       Utility
    =================================================================== */
    const s   = cfg.settings;
    const i18n = cfg.i18n;

    function svgPin( color, glyphSvg, glyphColor ) {
        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 42" width="32" height="42">
  <path d="M16 0C7.163 0 0 7.163 0 16c0 10 10 20 16 26 6-6 16-16 16-26C32 7.163 24.837 0 16 0z"
        fill="${color}" stroke="rgba(0,0,0,.25)" stroke-width="1.5"/>
  <g transform="translate(8,6)" fill="${glyphColor}">${glyphSvg}</g>
</svg>`;
    }

    function pendingSvg() {
        // White circle marker with a red cross (X) — unapproved submissions
        return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">
  <circle cx="16" cy="16" r="14" fill="#FFFFFF" stroke="rgba(0,0,0,.3)" stroke-width="1.5"/>
  <path d="M9 9 L23 23 M23 9 L9 23" stroke="#EF4444" stroke-width="3" stroke-linecap="round"/>
</svg>`;
    }

    // SVG icon paths (16×16 viewBox, rendered inside an 8,6 translate on the 32×42 pin)
    // video: video camera  | image: still camera  | audio: microphone  | text: pen/nib
    const GLYPHS = {
        video: {
            // Video camera icon
            path: '<path d="M1 3h8a1 1 0 0 1 1 1v8a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1zm10 2.5 4-2v8l-4-2V5.5z"/>',
            color: '#ffffff',
        },
        image: {
            // Still camera icon
            path: '<path d="M6 1 4.5 3H1a1 1 0 0 0-1 1v9a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V4a1 1 0 0 0-1-1h-3.5L10 1H6zm2 3a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0 1.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5z"/>',
            color: '#000000',
        },
        audio: {
            // Microphone icon
            path: '<path d="M8 1a3 3 0 0 1 3 3v5a3 3 0 0 1-6 0V4a3 3 0 0 1 3-3zm-5 8a5 5 0 0 0 10 0h-1.5a3.5 3.5 0 0 1-7 0H3zm5 5v2H7v-2h1z"/>',
            color: '#ffffff',
        },
        text: {
            // Pen/nib icon
            path: '<path d="M12.854.146a.5.5 0 0 0-.707 0L10.5 1.793 14.207 5.5l1.647-1.646a.5.5 0 0 0 0-.708L12.854.146zm.646 6.061L9.793 2.5 3.293 9H3.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.207l6.5-6.5zm-7.468 7.468A.5.5 0 0 1 6 13.5V13h-.5a.5.5 0 0 1-.5-.5V12h-.5a.5.5 0 0 1-.5-.5v-.5h-.5a.5.5 0 0 1-.5-.5V10h-.5a.5.5 0 0 1-.175-.032l-.179.178a.5.5 0 0 0-.11.168l-2 5a.5.5 0 0 0 .65.65l5-2a.5.5 0 0 0 .168-.11l.178-.178z"/>',
            color: '#000000',
        },
    };

    function makeIcon( type, status, overrideUrl ) {
        if ( overrideUrl ) {
            return L.icon( {
                iconUrl: overrideUrl,
                iconSize: [ 32, 42 ],
                iconAnchor: [ 16, 42 ],
                popupAnchor: [ 0, -42 ],
            } );
        }

        if ( status === 'pending' ) {
            return L.divIcon( {
                html: pendingSvg(),
                className: 'mediamap-div-icon mediamap-icon-' + type + ' mediamap-icon-pending',
                iconSize: [ 32, 32 ],
                iconAnchor: [ 16, 16 ],
                popupAnchor: [ 0, -20 ],
            } );
        }

        const color = s[ 'marker_' + type ] || '#888888';
        const glyph = GLYPHS[ type ] || GLYPHS.text;
        const svgStr = svgPin( color, glyph.path, glyph.color );

        // Use a standard Leaflet Icon as the base so the image-based fallback
        // (the default blue marker) is automatically used on devices where
        // CSS-rendered divIcons fail to paint. We overlay the SVG via a data-URI
        // so it behaves exactly like a normal <img> marker.
        const svgDataUri = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent( svgStr );
        return L.icon( {
            iconUrl:     svgDataUri,
            iconSize:    [ 32, 42 ],
            iconAnchor:  [ 16, 42 ],
            popupAnchor: [ 0, -42 ],
            className:   'mediamap-svg-icon mediamap-icon-' + type,
        } );
    }

    /* ===================================================================
       Thumbnail helpers
    =================================================================== */
    function getThumbnail( type, url ) {
        if ( ! url ) return '';
        const u = url.toLowerCase();

        // YouTube
        let yt = url.match( /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([A-Za-z0-9_-]{11})/ );
        if ( yt ) return `https://img.youtube.com/vi/${yt[1]}/mqdefault.jpg`;

        // Vimeo
        // thumbnail requires API call, return generic
        if ( u.includes('vimeo.com') ) return '';

        // Images direct
        const imgExts = /\.(jpg|jpeg|png|gif|webp|svg|avif|bmp)(\?|$)/i;
        if ( imgExts.test( url ) ) return url;

        return '';
    }

    function getEmbedUrl( type, url ) {
        // YouTube
        let yt = url.match( /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/))([A-Za-z0-9_-]{11})/ );
        if ( yt ) return `https://www.youtube.com/embed/${yt[1]}?autoplay=1`;

        // Vimeo
        let vm = url.match( /vimeo\.com\/(\d+)/ );
        if ( vm ) return `https://player.vimeo.com/video/${vm[1]}?autoplay=1`;

        // Dailymotion
        let dm = url.match( /dailymotion\.com\/video\/([a-zA-Z0-9]+)/ );
        if ( dm ) return `https://www.dailymotion.com/embed/video/${dm[1]}?autoplay=1`;

        // Spotify
        let sp = url.match( /open\.spotify\.com\/(track|episode|playlist|album)\/([A-Za-z0-9]+)/ );
        if ( sp ) return `https://open.spotify.com/embed/${sp[1]}/${sp[2]}`;

        // SoundCloud
        if ( url.includes('soundcloud.com') )
            return `https://w.soundcloud.com/player/?url=${encodeURIComponent(url)}&auto_play=true&color=1abc9c`;

        // Bandcamp
        // Not easily embeddable generically, return as iframe src
        return null;
    }

    /* ===================================================================
       Info Panel
    =================================================================== */
    function renderPanel( $panel, marker ) {
        // Issue 4: Unapproved submissions must not be viewable
        if ( marker.status === 'pending' ) {
            $panel.find( '.mediamap-panel-inner' ).html( `
                <div class="mediamap-panel-pending-notice">
                    <span class="mediamap-pending-icon">⏳</span>
                    <div>
                        <strong>${ i18n.pendingTitle || 'Submission Awaiting Approval' }</strong>
                        <p>${ i18n.pendingMessage || 'This submission is awaiting admin approval and cannot be viewed yet.' }</p>
                    </div>
                </div>
            ` );
            $panel.addClass( 'mediamap-panel-open' );
            return;
        }

        const thumb = getThumbnail( marker.type, marker.url );
        const embedUrl = marker.url ? getEmbedUrl( marker.type, marker.url ) : null;

        let thumbHtml = '';
        if ( marker.url ) {
            if ( thumb ) {
                thumbHtml = `<div class="mediamap-thumb" data-type="${marker.type}" data-url="${marker.url}" data-embed="${embedUrl || ''}">
                    <img src="${thumb}" alt="" />
                    ${ marker.type === 'video' ? '<div class="mediamap-play-overlay">▶</div>' : '' }
                    ${ marker.type === 'audio' ? '<div class="mediamap-audio-icon">♪</div>' : '' }
                </div>`;
            } else if ( marker.type === 'video' ) {
                thumbHtml = `<div class="mediamap-thumb mediamap-thumb-novid" data-type="${marker.type}" data-url="${marker.url}" data-embed="${embedUrl || ''}">
                    <div class="mediamap-play-overlay mediamap-play-big">▶</div>
                    <span>${ escHtml( new URL( marker.url ).hostname ) }</span>
                </div>`;
            } else if ( marker.type === 'audio' ) {
                thumbHtml = `<div class="mediamap-thumb mediamap-thumb-audio" data-type="${marker.type}" data-url="${marker.url}" data-embed="${embedUrl || ''}">
                    <div class="mediamap-audio-icon">♪</div>
                    <span>${ escHtml( new URL( marker.url ).hostname ) }</span>
                </div>`;
            } else if ( marker.type === 'image' ) {
                thumbHtml = `<div class="mediamap-thumb mediamap-thumb-img" data-type="image" data-url="${marker.url}" data-embed="">
                    <div class="mediamap-img-placeholder">🖼</div>
                    <span>${ escHtml( new URL( marker.url ).hostname ) }</span>
                </div>`;
            }
        }

        const statusBadge = marker.status === 'pending'
            ? `<span class="mediamap-panel-badge pending">⏳ Awaiting approval</span>` : '';

        $panel.find( '.mediamap-panel-inner' ).html( `
            <div class="mediamap-panel-content">
                ${ thumbHtml ? `<div class="mediamap-panel-media">${ thumbHtml }</div>` : '' }
                <div class="mediamap-panel-text">
                    ${ statusBadge }
                    ${ marker.place ? `<div class="mediamap-panel-place">📍 ${ escHtml(marker.place) }</div>` : '' }
                    ${ marker.desc ? `<p class="mediamap-panel-desc">${ escHtml(marker.desc) }</p>` : '' }
                    ${ marker.url && marker.type !== 'audio' && marker.type !== 'video' ? `<a class="mediamap-panel-link" href="${ marker.url }" target="_blank" rel="noopener">Open link ↗</a>` : '' }
                </div>
            </div>
        ` );

        // Bind click on thumbnail
        $panel.find( '.mediamap-thumb' ).on( 'click', function () {
            const type    = $( this ).data( 'type' );
            const url     = $( this ).data( 'url' );
            const embedSrc= $( this ).data( 'embed' );
            if ( type === 'image' ) openLightboxImage( url );
            else if ( type === 'video' ) openLightboxVideo( embedSrc || url );
            else if ( type === 'audio' ) openAudioPlayer( embedSrc || url );
        } );

        $panel.addClass( 'mediamap-panel-open' );
    }

    /* ===================================================================
       Lightbox
    =================================================================== */
    function getLightbox() {
        let $lb = $( '#mediamap-lightbox' );
        if ( ! $lb.length ) {
            $lb = $( `<div id="mediamap-lightbox" class="mediamap-lightbox" style="display:none;" role="dialog" aria-modal="true">
                <div class="mediamap-lb-backdrop"></div>
                <div class="mediamap-lb-inner">
                    <button class="mediamap-lb-close" aria-label="Close">&times;</button>
                    <div class="mediamap-lb-body"></div>
                </div>
            </div>` );
            $( 'body' ).append( $lb );
            $lb.on( 'click', '.mediamap-lb-backdrop, .mediamap-lb-close', function () {
                $lb.find( '.mediamap-lb-body' ).empty();
                $lb.fadeOut( 200 );
            } );
        }
        return $lb;
    }

    function openLightboxImage( url ) {
        const $lb = getLightbox();
        $lb.find( '.mediamap-lb-body' ).html( `<img src="${ url }" alt="" style="max-width:90vw;max-height:85vh;display:block;margin:auto;border-radius:4px;">` );
        $lb.fadeIn( 200 );
    }

    function openLightboxVideo( embedSrc ) {
        const $lb = getLightbox();
        $lb.find( '.mediamap-lb-body' ).html(
            `<div class="mediamap-lb-video"><iframe src="${ embedSrc }" frameborder="0" allowfullscreen allow="autoplay; encrypted-media"></iframe></div>`
        );
        $lb.fadeIn( 200 );
    }

    function openAudioPlayer( embedSrc ) {
        const $lb = getLightbox();
        if ( embedSrc && ( embedSrc.includes('w.soundcloud.com') || embedSrc.includes('spotify.com/embed') ) ) {
            $lb.find( '.mediamap-lb-body' ).html(
                `<div class="mediamap-lb-audio"><iframe src="${ embedSrc }" frameborder="0" allow="autoplay"></iframe></div>`
            );
        } else {
            $lb.find( '.mediamap-lb-body' ).html(
                `<div class="mediamap-lb-audio">
                    <audio controls autoplay style="width:100%;min-width:320px;">
                        <source src="${ embedSrc }">
                        Your browser does not support audio playback.
                    </audio>
                </div>`
            );
        }
        $lb.fadeIn( 200 );
    }

    /* ===================================================================
       XSS helper
    =================================================================== */
    function escHtml( str ) {
        return $( '<span>' ).text( str ).html();
    }

    /* ===================================================================
       Nominatim Search
    =================================================================== */
    let searchDebounce;
    function nominatimSearch( query, callback ) {
        clearTimeout( searchDebounce );
        searchDebounce = setTimeout( function () {
            $.getJSON( 'https://nominatim.openstreetmap.org/search', {
                q: query, format: 'json', limit: 7, addressdetails: 1,
            }, callback );
        }, 350 );
    }

    /* ===================================================================
       Map initialisation
    =================================================================== */
    function initMap( $wrap ) {
        const mapId  = $wrap.data( 'map-id' );
        const $canvas = $( '#' + mapId );
        const $panel  = $( '#' + mapId + '-panel' );

        if ( ! $canvas.length ) return;

        const map = L.map( mapId, {
            minZoom:     s.min_zoom,
            maxZoom:     s.max_zoom,
            zoomControl: true,
        } );

        // Basemap
        L.tileLayer( s.basemap_url, {
            attribution: s.basemap_attribution,
            maxZoom: s.max_zoom,
        } ).addTo( map );

        // Fullscreen
        if ( s.fullscreen ) {
            if ( typeof L.control.fullscreen === 'function' ) {
                L.control.fullscreen( { position: 'topleft', title: { 'false': 'Enter fullscreen', 'true': 'Exit fullscreen' } } ).addTo( map );
            } else if ( typeof L.Control.Fullscreen !== 'undefined' ) {
                new L.Control.Fullscreen( { position: 'topleft' } ).addTo( map );
            }
        }

        // Initial view
        map.setView( [ s.default_lat || 20, s.default_lng || 0 ], s.default_zoom || 3 );

        // Marker layer (clustered or plain)
        const markerLayer = s.cluster_markers && L.markerClusterGroup
            ? L.markerClusterGroup( { chunkedLoading: true } )
            : L.layerGroup();
        markerLayer.addTo( map );

        let markersData = [];

        // Load markers
        function loadMarkers() {
            $.post( cfg.ajaxurl, {
                action: 'mediamap_get_markers',
                nonce:  cfg.nonce_public,
            }, function ( resp ) {
                if ( ! resp.success ) return;
                markerLayer.clearLayers();
                markersData = resp.data;

                resp.data.forEach( function ( m ) {
                    const iconOverride = s[ 'icon_' + ( m.status === 'pending' ? 'pending' : m.type ) ] || '';
                    const icon = makeIcon( m.type, m.status, iconOverride );
                    const marker = L.marker( [ m.lat, m.lng ], { icon: icon, title: m.place || '' } );
                    marker.on( 'click', function () {
                        renderPanel( $panel, m );
                        if ( ! $panel.is( ':visible' ) ) {
                            $panel.slideDown( 250 );
                        }
                    } );
                    markerLayer.addLayer( marker );
                } );

                // Zoom to bounds
                if ( s.zoom_bound && resp.data.length > 0 ) {
                    const approved = resp.data.filter( x => x.status === 'approved' );
                    if ( approved.length > 0 ) {
                        const bounds = L.latLngBounds( approved.map( x => [ x.lat, x.lng ] ) );
                        map.fitBounds( bounds.pad( 0.1 ) );
                    }
                }
            } );
        }

        loadMarkers();

        /* ------------------------------------------------------------------
           Submission text search (above the map)
        ------------------------------------------------------------------ */
        const $subSearch = $( '#' + mapId + '-sub-search' );
        if ( $subSearch.length ) {
            const $subInput   = $subSearch.find( '.mediamap-sub-search-input' );
            const $subResults = $subSearch.find( '.mediamap-sub-search-results' );
            const $subClear   = $subSearch.find( '.mediamap-sub-search-clear' );

            let subSearchDebounce;

            function runSubSearch( q ) {
                q = q.toLowerCase().trim();
                $subResults.empty();

                if ( q.length < 2 ) {
                    $subResults.hide();
                    $subInput.attr( 'aria-expanded', 'false' );
                    return;
                }

                // Filter approved markers only
                const matches = markersData.filter( function( m ) {
                    if ( m.status !== 'approved' ) return false;
                    const haystack = [
                        m.desc  || '',
                        m.place || '',
                        m.type  || '',
                    ].join( ' ' ).toLowerCase();
                    return haystack.indexOf( q ) !== -1;
                } );

                if ( ! matches.length ) {
                    $subResults.html( '<li class="mediamap-ssr-none">No matching submissions found.</li>' ).show();
                    $subInput.attr( 'aria-expanded', 'true' );
                    return;
                }

                matches.slice( 0, 8 ).forEach( function( m ) {
                    const desc  = m.desc  ? m.desc.substring( 0, 90 )  + ( m.desc.length  > 90  ? '…' : '' ) : '';
                    const place = m.place ? m.place.substring( 0, 60 ) + ( m.place.length > 60  ? '…' : '' ) : '';
                    const $li = $( '<li>', { class: 'mediamap-ssr-item', role: 'option', tabindex: '0' } );
                    $li.html(
                        `<span class="mediamap-ssr-badge mediamap-ssr-badge-${ escHtml(m.type) }">${ escHtml( m.type ) }</span>` +
                        ( place ? `<span class="mediamap-ssr-place">📍 ${ escHtml(place) }</span>` : '' ) +
                        ( desc  ? `<span class="mediamap-ssr-desc">${ escHtml(desc) }</span>` : '' )
                    );

                    function selectMatch() {
                        $subInput.val( place || desc );
                        $subResults.hide().empty();
                        $subInput.attr( 'aria-expanded', 'false' );
                        $subClear.show();

                        // Fly to the marker and zoom to level 17
                        map.flyTo( [ m.lat, m.lng ], 17, { animate: true, duration: 1.2 } );

                        // Open the info panel after fly animation settles
                        setTimeout( function() {
                            renderPanel( $panel, m );
                            if ( ! $panel.is( ':visible' ) ) $panel.slideDown( 250 );
                        }, 400 );
                    }

                    $li.on( 'click', selectMatch );
                    $li.on( 'keydown', function( e ) {
                        if ( e.key === 'Enter' || e.key === ' ' ) { e.preventDefault(); selectMatch(); }
                        if ( e.key === 'ArrowDown' ) { e.preventDefault(); $li.next().focus(); }
                        if ( e.key === 'ArrowUp'   ) { e.preventDefault(); $li.prev().length ? $li.prev().focus() : $subInput.focus(); }
                        if ( e.key === 'Escape'    ) { $subResults.hide(); $subInput.focus(); }
                    } );

                    $subResults.append( $li );
                } );

                $subResults.show();
                $subInput.attr( 'aria-expanded', 'true' );
            }

            $subInput.on( 'input', function() {
                const q = $( this ).val();
                $subClear.toggle( q.length > 0 );
                clearTimeout( subSearchDebounce );
                subSearchDebounce = setTimeout( function() { runSubSearch( q ); }, 220 );
            } );

            $subInput.on( 'keydown', function( e ) {
                if ( e.key === 'ArrowDown' ) {
                    e.preventDefault();
                    $subResults.find( '.mediamap-ssr-item' ).first().focus();
                }
                if ( e.key === 'Escape' ) {
                    $subResults.hide();
                    $subInput.attr( 'aria-expanded', 'false' );
                }
            } );

            $subClear.on( 'click', function() {
                $subInput.val( '' ).focus();
                $subClear.hide();
                $subResults.hide().empty();
                $subInput.attr( 'aria-expanded', 'false' );
            } );

            // Close dropdown when clicking outside
            $( document ).on( 'click.subSearch', function( e ) {
                if ( ! $subSearch[0].contains( e.target ) ) {
                    $subResults.hide();
                    $subInput.attr( 'aria-expanded', 'false' );
                }
            } );
        }

        // Geolocation button
        const locCtrl = L.control( { position: 'bottomright' } );
        locCtrl.onAdd = function () {
            const btn = L.DomUtil.create( 'button', 'mediamap-locate-btn' );
            btn.innerHTML = '⊙';
            btn.title = 'Your location';
            btn.onclick = function () {
                map.locate( { setView: true, maxZoom: 14 } );
            };
            return btn;
        };
        locCtrl.addTo( map );

        /* ------------------------------------------------------------------
           Nominatim Map Search Control (always visible, top-right)
        ------------------------------------------------------------------ */
        const searchCtrl = L.control( { position: 'topright' } );
        searchCtrl.onAdd = function () {
            const container = L.DomUtil.create( 'div', 'mediamap-search-ctrl' );
            container.innerHTML = `
                <div class="mediamap-search-box">
                    <input type="text" class="mediamap-map-search-input" placeholder="Search places…" autocomplete="off" />
                    <button class="mediamap-map-search-btn" title="Search"><svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.099zm-5.242 1.156a5.5 5.5 0 1 1 0-11 5.5 5.5 0 0 1 0 11z"/></svg></button>
                    <ul class="mediamap-map-search-results" style="display:none;"></ul>
                </div>`;

            // Prevent map drag/click while interacting with the control
            L.DomEvent.disableClickPropagation( container );
            L.DomEvent.disableScrollPropagation( container );

            const input   = container.querySelector( '.mediamap-map-search-input' );
            const btn     = container.querySelector( '.mediamap-map-search-btn' );
            const results = container.querySelector( '.mediamap-map-search-results' );

            let searchPin = null;

            function doSearch() {
                const q = input.value.trim();
                if ( q.length < 2 ) { results.style.display = 'none'; return; }
                results.innerHTML = `<li class="mediamap-msr-loading">Searching…</li>`;
                results.style.display = 'block';

                nominatimSearch( q, function ( data ) {
                    results.innerHTML = '';
                    if ( ! data || ! data.length ) {
                        results.innerHTML = `<li class="mediamap-msr-none">No results found.</li>`;
                        return;
                    }
                    data.forEach( function ( place ) {
                        const li = document.createElement( 'li' );
                        li.className = 'mediamap-msr-item';
                        li.textContent = place.display_name;
                        li.addEventListener( 'click', function () {
                            const lat = parseFloat( place.lat );
                            const lng = parseFloat( place.lon );
                            map.setView( [ lat, lng ], 14 );

                            // Drop a temporary search result marker
                            if ( searchPin ) map.removeLayer( searchPin );
                            searchPin = L.marker( [ lat, lng ], {
                                icon: L.divIcon( {
                                    html: `<div class="mediamap-search-pin">📍</div>`,
                                    className: '',
                                    iconSize: [ 28, 28 ],
                                    iconAnchor: [ 14, 28 ],
                                } ),
                            } ).addTo( map );
                            searchPin.bindPopup( `<strong>${ place.display_name }</strong>` ).openPopup();

                            // Auto-dismiss after 8 seconds
                            setTimeout( function () {
                                if ( searchPin ) { map.removeLayer( searchPin ); searchPin = null; }
                            }, 8000 );

                            input.value = place.display_name;
                            results.style.display = 'none';
                        } );
                        results.appendChild( li );
                    } );
                } );
            }

            btn.addEventListener( 'click', doSearch );
            input.addEventListener( 'keydown', function ( e ) {
                if ( e.key === 'Enter' ) doSearch();
            } );
            input.addEventListener( 'input', function () {
                if ( input.value.trim().length >= 2 ) doSearch();
                else results.style.display = 'none';
            } );

            // Close results when clicking elsewhere
            document.addEventListener( 'click', function ( e ) {
                if ( ! container.contains( e.target ) ) results.style.display = 'none';
            } );

            return container;
        };
        searchCtrl.addTo( map );

        /* ------------------------------------------------------------------
           Submission pin drop
        ------------------------------------------------------------------ */
        if ( ! cfg.logged_in ) return;

        const $submitWrap = $( '#' + mapId + '-submit' );
        let tempPin = null;

        map.on( 'click', function ( e ) {
            if ( ! $submitWrap.find( '.mediamap-form-container' ).is( ':visible' ) ) return;
            placeTempPin( e.latlng );
        } );

        function placeTempPin( latlng ) {
            if ( tempPin ) map.removeLayer( tempPin );
            tempPin = L.marker( latlng, {
                icon: L.divIcon( {
                    html: '<div class="mediamap-drop-pin">📍</div>',
                    className: '', iconSize: [ 24, 24 ], iconAnchor: [ 12, 24 ],
                } ),
                draggable: true,
            } ).addTo( map );

            tempPin.on( 'dragend', function ( ev ) {
                updatePinInputs( ev.target.getLatLng() );
            } );
            updatePinInputs( latlng );
        }

        function updatePinInputs( latlng ) {
            const lat = latlng.lat.toFixed( 6 );
            const lng = latlng.lng.toFixed( 6 );
            $submitWrap.find( '.mediamap-lat-input' ).val( lat );
            $submitWrap.find( '.mediamap-lng-input' ).val( lng );
            $submitWrap.find( '.mediamap-coords-display' ).val( `${ lat }, ${ lng }` );
        }

        // Toggle form
        $submitWrap.on( 'click', '.mediamap-toggle-form', function () {
            $submitWrap.find( '.mediamap-form-container' ).slideToggle( 200 );
        } );

        $submitWrap.on( 'click', '.mediamap-cancel-btn', function () {
            $submitWrap.find( '.mediamap-form-container' ).slideUp( 200 );
            if ( tempPin ) { map.removeLayer( tempPin ); tempPin = null; }
        } );

        /* Nominatim place search */
        $submitWrap.on( 'input', '.mediamap-place-search', function () {
            const q = $( this ).val().trim();
            const $res = $submitWrap.find( '.mediamap-place-results' );
            if ( q.length < 3 ) { $res.empty().hide(); return; }
            $res.html( `<div class="mediamap-pr-loading">${ i18n.searching }</div>` ).show();

            nominatimSearch( q, function ( data ) {
                if ( ! data || ! data.length ) {
                    $res.html( `<div class="mediamap-pr-none">${ i18n.noResults }</div>` );
                    return;
                }
                let html = '<ul class="mediamap-pr-list">';
                data.forEach( function ( place ) {
                    html += `<li class="mediamap-pr-item" data-lat="${ place.lat }" data-lng="${ place.lon }" data-name="${ escHtml(place.display_name) }">${ escHtml( place.display_name ) }</li>`;
                } );
                html += '</ul>';
                $res.html( html );
            } );
        } );

        $submitWrap.on( 'click', '.mediamap-pr-item', function () {
            const lat  = parseFloat( $( this ).data( 'lat' ) );
            const lng  = parseFloat( $( this ).data( 'lng' ) );
            const name = $( this ).data( 'name' );
            map.flyTo( [ lat, lng ], 18, { animate: true, duration: 1.0 } );
            placeTempPin( L.latLng( lat, lng ) );
            $submitWrap.find( '.mediamap-place-name-input' ).val( name );
            $submitWrap.find( '.mediamap-place-search' ).val( name );
            $submitWrap.find( '.mediamap-place-results' ).empty().hide();
        } );

        // URL type detection feedback
        $submitWrap.on( 'input', '.mediamap-url-input', function () {
            const url = $( this ).val().trim();
            const $fb = $submitWrap.find( '.mediamap-url-feedback' );
            if ( ! url ) { $fb.empty(); return; }
            // Simple client-side peek (mirrors server logic)
            let type = detectTypeClient( url );
            if ( type ) {
                $fb.html( `<span class="mediamap-url-ok">✔ Detected as <strong>${ type }</strong></span>` );
            } else {
                $fb.html( `<span class="mediamap-url-warn">⚠ Unknown platform — will default to image if URL is valid.</span>` );
            }
        } );

        function detectTypeClient( url ) {
            const u = url.toLowerCase();
            const videoHosts = [ 'youtube.com', 'youtu.be', 'vimeo.com', 'dailymotion.com', 'twitch.tv', 'tiktok.com', 'streamable.com', 'loom.com', 'rumble.com', 'ted.com', 'bilibili.com' ];
            const audioHosts = [ 'spotify.com', 'soundcloud.com', 'anchor.fm', 'podcasts.apple.com', 'bandcamp.com', 'mixcloud.com', 'audiomack.com', 'audius.co' ];
            const imageHosts = [ 'imgur.com', 'flickr.com', 'unsplash.com', 'pexels.com', 'pixabay.com', '500px.com', 'deviantart.com', 'artstation.com', 'imgbb.com', 'ibb.co', 'postimages.org', 'cloudinary.com', 'giphy.com' ];
            if ( videoHosts.some( h => u.includes(h) ) ) return 'video';
            if ( audioHosts.some( h => u.includes(h) ) ) return 'audio';
            if ( imageHosts.some( h => u.includes(h) ) ) return 'image';
            const ext = u.split('?')[0].split('.').pop();
            if ( [ 'jpg','jpeg','png','gif','webp','avif','svg' ].includes(ext) ) return 'image';
            if ( [ 'mp4','webm','mov','avi','mkv' ].includes(ext) ) return 'video';
            if ( [ 'mp3','wav','ogg','flac','aac','m4a' ].includes(ext) ) return 'audio';
            return null;
        }

        /* Submit */
        $submitWrap.on( 'click', '.mediamap-submit-btn', function () {
            const $btn  = $( this );
            const $fb   = $submitWrap.find( '.mediamap-form-feedback' );
            const lat   = $submitWrap.find( '.mediamap-lat-input' ).val();
            const lng   = $submitWrap.find( '.mediamap-lng-input' ).val();
            const url   = $submitWrap.find( '.mediamap-url-input' ).val().trim();
            const desc  = $submitWrap.find( '.mediamap-desc-input' ).val().trim();
            const place = $submitWrap.find( '.mediamap-place-name-input' ).val().trim()
                       || $submitWrap.find( '.mediamap-place-search' ).val().trim();

            if ( ! lat || ! lng ) {
                $fb.html( `<span class="mediamap-fb-error">${ i18n.noLocation }</span>` ); return;
            }
            if ( ! url && ! desc ) {
                $fb.html( `<span class="mediamap-fb-error">${ i18n.noContent }</span>` ); return;
            }

            $btn.prop( 'disabled', true ).text( i18n.submitting );
            $fb.html( '' );

            $.post( cfg.ajaxurl, {
                action:      'mediamap_submit',
                nonce:       cfg.nonce_submit,
                lat:         lat,
                lng:         lng,
                place_name:  place,
                media_url:   url,
                description: desc,
            }, function ( resp ) {
                $btn.prop( 'disabled', false ).text( 'Submit for Approval' );
                if ( resp.success ) {
                    $fb.html( `<span class="mediamap-fb-ok">✔ ${ resp.data.message }</span>` );
                    // Reset form
                    $submitWrap.find( 'input[type=text], input[type=url], textarea' ).val( '' );
                    $submitWrap.find( '.mediamap-lat-input, .mediamap-lng-input, .mediamap-place-name-input' ).val( '' );
                    $submitWrap.find( '.mediamap-url-feedback, .mediamap-place-results' ).empty();
                    if ( tempPin ) { map.removeLayer( tempPin ); tempPin = null; }
                    loadMarkers();
                } else {
                    $fb.html( `<span class="mediamap-fb-error">✖ ${ resp.data.message }</span>` );
                }
            } ).fail( function ( jqXHR ) {
                $btn.prop( 'disabled', false ).text( 'Submit for Approval' );
                let msg = 'Network error. Please try again.';
                if ( jqXHR.status === 429 ) {
                    // Rate limit — try to parse the server message
                    try {
                        const resp = JSON.parse( jqXHR.responseText );
                        msg = ( resp.data && resp.data.message ) ? resp.data.message : 'Submission limit reached. Please wait before trying again.';
                    } catch (e) {
                        msg = 'Submission limit reached. Please wait before trying again.';
                    }
                } else if ( jqXHR.status === 403 ) {
                    msg = 'You must be logged in to submit.';
                } else if ( jqXHR.status === 0 ) {
                    msg = 'Could not reach the server. Check your internet connection and try again.';
                } else if ( jqXHR.status >= 500 ) {
                    msg = 'Server error (' + jqXHR.status + '). Please try again later.';
                }
                $fb.html( `<span class="mediamap-fb-error">✖ ${ msg }</span>` );
            } );
        } );

        /* My submissions panel */
        const $mySubs = $( '#' + mapId + '-my' );

        $mySubs.on( 'click', '.mediamap-toggle-my-subs', function () {
            $mySubs.find( '.mediamap-my-subs-list' ).slideToggle( 200 );
        } );

        $mySubs.on( 'click', '.mediamap-del-own', function () {
            if ( ! confirm( i18n.confirmDelete ) ) return;
            const id = $( this ).data( 'id' );
            $.post( cfg.ajaxurl, { action: 'mediamap_delete_own', nonce: cfg.nonce_user, id: id }, function ( r ) {
                if ( r.success ) { $mySubs.find( `tr[data-sub-id="${ id }"]` ).fadeOut( 200, function () { $( this ).remove(); } ); loadMarkers(); }
            } );
        } );
    }

    /* ===================================================================
       Boot
    =================================================================== */
    $( document ).ready( function () {
        $( '.mediamap-wrap' ).each( function () {
            initMap( $( this ) );
        } );
    } );

} )( jQuery, MediaMapConfig );
