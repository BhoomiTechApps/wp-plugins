/**
 * ProjectLens Project Editor — Frontend JS
 *
 * Handles:
 *  • Project selector → AJAX load of project data
 *  • Full segment editor (all 6 segment types) with add / delete / reorder
 *  • Settings tab population and collection
 *  • AJAX save
 *  • Inline media library modal (user's own uploads only, paginated, search,
 *    upload tab using the WP REST media endpoint)
 *
 * Dependencies: jQuery, jQuery UI Sortable (both enqueued by PHP).
 * Global: PLE  (localised by wp_localize_script in class-ple-editor.php)
 */
(function ($) {
    'use strict';

    /* ── State ──────────────────────────────────────────────────────────── */
    var currentProjectId = 0;

    /* ── Helpers ────────────────────────────────────────────────────────── */
    function notice(msg, type) {
        var $n = $('#ple-ajax-notice');
        $n.removeClass('is-success is-error')
          .addClass(type === 'error' ? 'is-error' : 'is-success')
          .text(msg)
          .show();
        clearTimeout($n.data('timer'));
        $n.data('timer', setTimeout(function () { $n.fadeOut(); }, 5000));
    }

    function spinner(id, show) {
        show ? $('#' + id).show() : $('#' + id).hide();
    }

    function uid() {
        return 'seg_' + Math.random().toString(36).substr(2, 9);
    }

    /* ── Project selector ───────────────────────────────────────────────── */
    $(document).on('change', '#ple-project-select', function () {
        var pid = parseInt($(this).val(), 10);
        if (!pid) {
            $('#ple-editor-area').hide();
            currentProjectId = 0;
            return;
        }
        loadProject(pid);
    });

    function loadProject(pid) {
        currentProjectId = pid;
        spinner('ple-load-spinner', true);
        $('#ple-editor-area').hide();

        $.post(PLE.ajaxUrl, {
            action:  'ple_get_project_data',
            nonce:   PLE.nonce,
            post_id: pid
        }, function (res) {
            spinner('ple-load-spinner', false);
            if (!res.success) {
                notice(res.data.message || PLE.i18n.saveError, 'error');
                return;
            }
            populateEditor(res.data);
            $('#ple-editor-area').show();
            // Reset to Segments tab
            switchTab('segments');
        }).fail(function () {
            spinner('ple-load-spinner', false);
            notice(PLE.i18n.saveError, 'error');
        });
    }

    /* ── Populate editor from server data ───────────────────────────────── */
    function populateEditor(data) {
        // Title
        $('#ple-post-title').val(data.post_title || '');

        // Segments
        var $list = $('#ple-segments-list').empty();
        var segments = data.segments || [];
        segments.forEach(function (seg, idx) {
            $list.append(buildSegmentRow(seg, idx));
        });
        initSortable($list);

        // Settings
        populateSettings(data.settings || {});
    }

    /* ── Tabs ───────────────────────────────────────────────────────────── */
    $(document).on('click', '.ple-tab', function () {
        switchTab($(this).data('tab'));
    });

    function switchTab(tab) {
        $('.ple-tab').removeClass('ple-tab--active').attr('aria-selected', 'false');
        $('.ple-tab[data-tab="' + tab + '"]').addClass('ple-tab--active').attr('aria-selected', 'true');
        $('.ple-tab-panel').hide();
        $('#ple-tab-' + tab).show();
    }

    /* ════════════════════════════════════════════════════════════════════════
       SEGMENT BUILDER
    ════════════════════════════════════════════════════════════════════════ */

    function buildSegmentRow(seg, idx) {
        var type      = seg.type       || 'descriptive';
        var title     = seg.title      || '';
        var enabled   = seg.enabled    !== false;
        var collapsed = !!seg.collapsed;
        var id        = seg.id         || uid();
        var label     = (PLE.segmentTypes && PLE.segmentTypes[type]) ? PLE.segmentTypes[type] : type;

        var $row = $('<div class="ple-segment-row" />')
            .attr('data-index', idx)
            .attr('data-type',  type)
            .toggleClass('ple-collapsed', collapsed);

        // Header
        var $hdr = $('<div class="ple-segment-header" />');
        $hdr.append('<span class="ple-drag-handle" title="Drag to reorder">⠿</span>');
        $hdr.append('<span class="ple-segment-type-badge">' + escHtml(label) + '</span>');
        $hdr.append(
            $('<input type="text" class="ple-segment-title-input ple-input" />')
                .attr('name', 'pl_segments[' + idx + '][title]')
                .attr('placeholder', 'Segment Title')
                .val(title)
        );
        $hdr.append(
            $('<label class="ple-visible-toggle" />')
                .append(
                    $('<input type="checkbox" />')
                        .attr('name', 'pl_segments[' + idx + '][enabled]')
                        .val('1')
                        .prop('checked', enabled)
                )
                .append(' Visible')
        );
        $hdr.append('<button type="button" class="ple-segment-collapse-btn ple-btn--icon" title="Collapse">▾</button>');
        if (PLE.isAdmin) {
            $hdr.append('<button type="button" class="ple-segment-delete-btn ple-btn--icon" title="Remove segment">🗑</button>');
        }

        // Hidden fields
        $hdr.append($('<input type="hidden" />').attr('name', 'pl_segments[' + idx + '][id]').val(id));
        $hdr.append($('<input type="hidden" />').attr('name', 'pl_segments[' + idx + '][type]').val(type));
        $hdr.append(
            $('<input type="hidden" class="ple-collapsed-input" />')
                .attr('name', 'pl_segments[' + idx + '][collapsed]')
                .val(collapsed ? '1' : '0')
        );

        $row.append($hdr);

        // Body
        var $body = $('<div class="ple-segment-body" />');
        $body.append(buildSegmentBody(seg, idx));
        if (collapsed) $body.hide();
        $row.append($body);

        return $row;
    }

    function buildSegmentBody(seg, idx) {
        var type = seg.type || 'descriptive';
        var n    = 'pl_segments[' + idx + ']';

        switch (type) {

            case 'descriptive':
                var $d = $('<div />');
                $d.append(fieldRow('Sub-title',
                    $('<input type="text" class="ple-input ple-input--wide" />')
                        .attr('name', n + '[subtitle]').val(seg.subtitle || '')));
                $d.append(fieldRow('Summary Content',
                    $('<textarea class="ple-textarea ple-textarea--wide" rows="5" />')
                        .attr('name', n + '[content]').val(seg.content || '')));
                $d.append(fieldRow('Detail Content',
                    $('<textarea class="ple-textarea ple-textarea--wide" rows="7" />')
                        .attr('name', n + '[detail_content]').val(seg.detail_content || '')));
                return $d;

            case 'media':
                var $m = $('<div />');
                var $slideList = $('<div class="ple-slides-list ple-sub-list" />')
                    .attr('data-segment-index', idx)
                    .attr('data-subkey', 'slides');
                var slides = seg.slides || [];
                slides.forEach(function (slide, si) {
                    $slideList.append(buildSlideRow(slide, idx, si));
                });
                initSubSortable($slideList);
                $m.append($slideList);
                $m.append(
                    $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-add-slide" />')
                        .attr('data-segment', idx).text(PLE.i18n.addSlide)
                );
                return $m;

            case 'metadata':
                var $mf = $('<div />');
                var $fieldList = $('<div class="ple-meta-fields-list ple-sub-list" />')
                    .attr('data-segment-index', idx)
                    .attr('data-subkey', 'fields');
                var fields = seg.fields || [];
                fields.forEach(function (f, fi) {
                    $fieldList.append(buildMetaFieldRow(f, idx, fi));
                });
                initSubSortable($fieldList);
                $mf.append($fieldList);
                $mf.append(
                    $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-add-meta-field" />')
                        .attr('data-segment', idx).text(PLE.i18n.addField)
                );
                return $mf;

            case 'team':
                var $tm = $('<div />');
                var $memberList = $('<div class="ple-team-list ple-sub-list" />')
                    .attr('data-segment-index', idx)
                    .attr('data-subkey', 'members');
                var members = seg.members || [];
                members.forEach(function (m, mi) {
                    $memberList.append(buildMemberRow(m, idx, mi));
                });
                initSubSortable($memberList);
                $tm.append($memberList);
                $tm.append(
                    $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-add-member" />')
                        .attr('data-segment', idx).text(PLE.i18n.addMember)
                );
                return $tm;

            case 'timeline':
                var $tl = $('<div />');
                var $msList = $('<div class="ple-milestone-list ple-sub-list" />')
                    .attr('data-segment-index', idx)
                    .attr('data-subkey', 'milestones');
                var milestones = seg.milestones || [];
                milestones.forEach(function (ms, mi) {
                    $msList.append(buildMilestoneRow(ms, idx, mi));
                });
                initSubSortable($msList);
                $tl.append($msList);
                $tl.append(
                    $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-add-milestone" />')
                        .attr('data-segment', idx).text(PLE.i18n.addMilestone)
                );
                return $tl;

            case 'documents':
                var $doc = $('<div />');
                var $fileList = $('<div class="ple-files-list ple-sub-list" />')
                    .attr('data-segment-index', idx)
                    .attr('data-subkey', 'files');
                var files = seg.files || [];
                files.forEach(function (f, fi) {
                    $fileList.append(buildFileRow(f, idx, fi));
                });
                initSubSortable($fileList);
                $doc.append($fileList);
                $doc.append(
                    $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-add-file" />')
                        .attr('data-segment', idx).text(PLE.i18n.addFile)
                );
                return $doc;

            default:
                return $('<p />').text('Unknown segment type: ' + type);
        }
    }

    /* ── Sub-row builders ───────────────────────────────────────────────── */

    function buildSlideRow(slide, segIdx, slideIdx) {
        var n = 'pl_segments[' + segIdx + '][slides][' + slideIdx + ']';
        var mediaId   = slide.media_id  || 0;
        var mediaType = slide.media_type || 'image';
        var preview   = slide._preview_url || '';

        var $row = $('<div class="ple-sub-row ple-slide-row" />');
        $row.append('<span class="ple-drag-handle">⠿</span>');
        var $fields = $('<div class="ple-sub-fields" />');

        // Media picker
        var $mRow = $('<div class="ple-media-row" />');
        $mRow.append($('<input type="hidden" class="ple-media-id" />').attr('name', n + '[media_id]').val(mediaId));
        var $img = $('<img class="ple-media-preview" />').toggle(!!preview && mediaType === 'image');
        if (preview && mediaType === 'image') $img.attr('src', preview);
        $mRow.append($img);
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-pick-media" />')
                .attr('data-media-type', 'image')
                .text('Select Image / Video')
        );
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--icon ple-btn-remove-media" />')
                .text('✕').toggle(!!mediaId)
        );
        $fields.append($mRow);

        // Media type select
        $fields.append(fieldRow('Media Type',
            $('<select class="ple-select ple-media-type-select" />')
                .attr('name', n + '[media_type]')
                .append(opt('image', 'Image', mediaType))
                .append(opt('video', 'Embedded Video', mediaType))
                .append(opt('video_url', 'External Video URL', mediaType))
        ));

        // Video URL (shown only when type = video_url)
        var $videoUrlRow = fieldRow('Video URL (YouTube / Vimeo)',
            $('<input type="url" class="ple-input ple-input--wide ple-video-url" />')
                .attr('name', n + '[video_url]').val(slide.video_url || '')
        );
        if (mediaType !== 'video_url') $videoUrlRow.hide();
        $fields.append($videoUrlRow);

        $fields.append(fieldRow('Caption',
            $('<input type="text" class="ple-input ple-input--wide" />')
                .attr('name', n + '[caption]').val(slide.caption || '')));
        $fields.append(fieldRow('Description',
            $('<textarea class="ple-textarea ple-textarea--wide" rows="2" />')
                .attr('name', n + '[description]').val(slide.description || '')));

        // Geo
        var $geoWrap = $('<div class="ple-geo-fields" />');
        $geoWrap.append($('<label />').text('Geo-location'));
        var $geoRow = $('<div class="ple-geo-row" />');
        $geoRow.append($('<input type="text" class="ple-input" placeholder="Latitude" />')
            .attr('name', n + '[geo_lat]').val(slide.geo_lat || ''));
        $geoRow.append($('<input type="text" class="ple-input" placeholder="Longitude" />')
            .attr('name', n + '[geo_lng]').val(slide.geo_lng || ''));
        $geoWrap.append($geoRow);
        $geoWrap.append($('<input type="text" class="ple-input ple-input--wide" placeholder="Location label" />')
            .attr('name', n + '[geo_label]').val(slide.geo_label || ''));
        $fields.append($geoWrap);

        $row.append($fields);
        $row.append(
            $('<button type="button" class="ple-btn--icon ple-btn-delete-sub" />')
                .attr('title', 'Remove slide').text('🗑')
        );
        return $row;
    }

    function buildMetaFieldRow(f, segIdx, fieldIdx) {
        var n = 'pl_segments[' + segIdx + '][fields][' + fieldIdx + ']';
        var $row = $('<div class="ple-sub-row ple-meta-field-row" />');
        $row.append('<span class="ple-drag-handle">⠿</span>');
        $row.append(
            $('<input type="text" class="ple-input" placeholder="Field Label" style="flex:1" />')
                .attr('name', n + '[label]').val(f.label || '')
        );
        $row.append(
            $('<input type="text" class="ple-input" placeholder="Field Value" style="flex:2" />')
                .attr('name', n + '[value]').val(f.value || '')
        );
        $row.append(
            $('<button type="button" class="ple-btn--icon ple-btn-delete-sub" />')
                .attr('title', 'Remove field').text('🗑')
        );
        return $row;
    }

    function buildMemberRow(m, segIdx, memberIdx) {
        var n       = 'pl_segments[' + segIdx + '][members][' + memberIdx + ']';
        var preview = m._preview_url || '';
        var $row    = $('<div class="ple-sub-row ple-member-row" />');
        $row.append('<span class="ple-drag-handle">⠿</span>');
        var $fields = $('<div class="ple-sub-fields" />');

        var $mRow = $('<div class="ple-media-row" />');
        $mRow.append($('<input type="hidden" class="ple-media-id" />').attr('name', n + '[avatar_id]').val(m.avatar_id || 0));
        var $img = $('<img class="ple-media-preview" style="border-radius:50%;" />').toggle(!!preview);
        if (preview) $img.attr('src', preview);
        $mRow.append($img);
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-pick-media" />')
                .attr('data-media-type', 'image').text('Select Photo')
        );
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--icon ple-btn-remove-media" />')
                .text('✕').toggle(!!(m.avatar_id))
        );
        $fields.append($mRow);

        $fields.append(
            $('<input type="text" class="ple-input ple-input--wide" placeholder="Full Name" />')
                .attr('name', n + '[name]').val(m.name || '')
        );
        $('<br />').appendTo($fields);
        $fields.append(
            $('<input type="text" class="ple-input ple-input--wide" placeholder="Role / Title" />')
                .attr('name', n + '[role]').val(m.role || '')
        );
        $('<br />').appendTo($fields);
        $fields.append(
            $('<input type="email" class="ple-input ple-input--wide" placeholder="Email" />')
                .attr('name', n + '[email]').val(m.email || '')
        );
        $('<br />').appendTo($fields);
        $fields.append(
            $('<textarea class="ple-textarea ple-textarea--wide" rows="2" placeholder="Short bio…" />')
                .attr('name', n + '[bio]').val(m.bio || '')
        );

        $row.append($fields);
        $row.append(
            $('<button type="button" class="ple-btn--icon ple-btn-delete-sub" />').text('🗑')
        );
        return $row;
    }

    function buildMilestoneRow(ms, segIdx, msIdx) {
        var n    = 'pl_segments[' + segIdx + '][milestones][' + msIdx + ']';
        var stat = ms.status || 'planned';
        var $row = $('<div class="ple-sub-row ple-milestone-row" />');
        $row.append('<span class="ple-drag-handle">⠿</span>');
        var $fields = $('<div class="ple-sub-fields" />');

        $fields.append(
            $('<input type="text" class="ple-input ple-input--wide" placeholder="Milestone Title" />')
                .attr('name', n + '[title]').val(ms.title || '')
        );
        var $meta = $('<div class="ple-milestone-meta" />');
        $meta.append($('<input type="date" class="ple-input" />')
            .attr('name', n + '[date]').val(ms.date || ''));
        $meta.append(
            $('<select class="ple-select" />')
                .attr('name', n + '[status]')
                .append(opt('planned',   'Planned',   stat))
                .append(opt('active',    'Active',    stat))
                .append(opt('completed', 'Completed', stat))
                .append(opt('delayed',   'Delayed',   stat))
        );
        $fields.append($meta);
        $fields.append(
            $('<textarea class="ple-textarea ple-textarea--wide" rows="2" placeholder="Description…" />')
                .attr('name', n + '[description]').val(ms.description || '')
        );

        $row.append($fields);
        $row.append(
            $('<button type="button" class="ple-btn--icon ple-btn-delete-sub" />').text('🗑')
        );
        return $row;
    }

    function buildFileRow(f, segIdx, fileIdx) {
        var n      = 'pl_segments[' + segIdx + '][files][' + fileIdx + ']';
        var fileId = f.file_id || 0;
        var $row   = $('<div class="ple-sub-row ple-file-row" />');
        $row.append('<span class="ple-drag-handle">⠿</span>');
        var $fields = $('<div class="ple-sub-fields" />');

        var $mRow = $('<div class="ple-media-row" />');
        $mRow.append($('<input type="hidden" class="ple-media-id" />').attr('name', n + '[file_id]').val(fileId));
        $mRow.append(
            $('<span class="ple-file-name" />').text(f._file_name || (fileId ? '#' + fileId : ''))
        );
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--secondary ple-btn-pick-media" />')
                .attr('data-media-type', 'application').text('Select File')
        );
        $mRow.append(
            $('<button type="button" class="ple-btn ple-btn--icon ple-btn-remove-file" />')
                .text('✕').toggle(!!fileId)
        );
        $fields.append($mRow);

        $fields.append(
            $('<input type="text" class="ple-input ple-input--wide" placeholder="Display Name (optional)" />')
                .attr('name', n + '[label]').val(f.label || '')
        );
        $('<br />').appendTo($fields);
        $fields.append(
            $('<textarea class="ple-textarea ple-textarea--wide" rows="2" placeholder="Short description…" />')
                .attr('name', n + '[description]').val(f.description || '')
        );

        $row.append($fields);
        $row.append(
            $('<button type="button" class="ple-btn--icon ple-btn-delete-sub" />').text('🗑')
        );
        return $row;
    }

    /* ── Segment-level controls ─────────────────────────────────────────── */

    // Add segment
    $(document).on('click', '#ple-btn-add-segment', function () {
        if (!PLE.isAdmin) return;
        var type  = $('#ple-new-segment-type').val();
        var $list = $('#ple-segments-list');
        var idx   = $list.children('.ple-segment-row').length;
        var seg   = { type: type, id: uid(), title: '', enabled: true, collapsed: false };
        $list.append(buildSegmentRow(seg, idx));
        reindexSegments();
        // Init sortable for any sub-list in the new row
        $list.find('.ple-sub-list').each(function () {
            if (!$(this).hasClass('ui-sortable')) initSubSortable($(this));
        });
    });

    // Collapse / expand
    $(document).on('click', '.ple-segment-collapse-btn', function () {
        var $row = $(this).closest('.ple-segment-row');
        var collapsed = $row.hasClass('ple-collapsed');
        $row.toggleClass('ple-collapsed', !collapsed);
        $row.find('.ple-segment-body').toggle(collapsed);
        $row.find('.ple-collapsed-input').val(collapsed ? '0' : '1');
    });

    // Delete segment
    $(document).on('click', '.ple-segment-delete-btn', function () {
        if (!PLE.isAdmin) return;
        if (!window.confirm(PLE.i18n.confirmDelete)) return;
        $(this).closest('.ple-segment-row').remove();
        reindexSegments();
    });

    // Media type toggle (video URL row)
    $(document).on('change', '.ple-media-type-select', function () {
        var $row = $(this).closest('.ple-sub-row');
        $row.find('.ple-video-url').closest('p, .ple-form-row, div').toggle($(this).val() === 'video_url');
    });

    /* ── Sub-item add buttons ───────────────────────────────────────────── */

    $(document).on('click', '.ple-btn-add-slide', function () {
        var segIdx   = parseInt($(this).data('segment'), 10);
        var $list    = $(this).closest('.ple-segment-body').find('.ple-slides-list');
        var slideIdx = $list.children('.ple-sub-row').length;
        $list.append(buildSlideRow({}, segIdx, slideIdx));
    });

    $(document).on('click', '.ple-btn-add-meta-field', function () {
        var segIdx   = parseInt($(this).data('segment'), 10);
        var $list    = $(this).closest('.ple-segment-body').find('.ple-meta-fields-list');
        var fieldIdx = $list.children('.ple-sub-row').length;
        $list.append(buildMetaFieldRow({}, segIdx, fieldIdx));
    });

    $(document).on('click', '.ple-btn-add-member', function () {
        var segIdx    = parseInt($(this).data('segment'), 10);
        var $list     = $(this).closest('.ple-segment-body').find('.ple-team-list');
        var memberIdx = $list.children('.ple-sub-row').length;
        $list.append(buildMemberRow({}, segIdx, memberIdx));
    });

    $(document).on('click', '.ple-btn-add-milestone', function () {
        var segIdx = parseInt($(this).data('segment'), 10);
        var $list  = $(this).closest('.ple-segment-body').find('.ple-milestone-list');
        var msIdx  = $list.children('.ple-sub-row').length;
        $list.append(buildMilestoneRow({}, segIdx, msIdx));
    });

    $(document).on('click', '.ple-btn-add-file', function () {
        var segIdx  = parseInt($(this).data('segment'), 10);
        var $list   = $(this).closest('.ple-segment-body').find('.ple-files-list');
        var fileIdx = $list.children('.ple-sub-row').length;
        $list.append(buildFileRow({}, segIdx, fileIdx));
    });

    // Delete sub-item
    $(document).on('click', '.ple-btn-delete-sub', function () {
        if (!window.confirm(PLE.i18n.confirmDeleteSub)) return;
        var $row   = $(this).closest('.ple-sub-row');
        var $list  = $row.closest('.ple-sub-list');
        var subKey = $list.data('subkey');
        $row.remove();
        if (subKey) reindexSubItems($list, subKey);
    });

    /* ── Media "remove" buttons ─────────────────────────────────────────── */
    $(document).on('click', '.ple-btn-remove-media', function () {
        var $row = $(this).closest('.ple-media-row');
        $row.find('.ple-media-id').val('');
        $row.find('.ple-media-preview').hide().attr('src', '');
        $(this).hide();
    });

    $(document).on('click', '.ple-btn-remove-file', function () {
        var $row = $(this).closest('.ple-media-row');
        $row.find('.ple-media-id').val('');
        $row.find('.ple-file-name').text('');
        $(this).hide();
    });

    /* ── Sortable setup ─────────────────────────────────────────────────── */
    function initSortable($list) {
        $list.sortable({
            handle:      '.ple-drag-handle',
            placeholder: 'ple-segment-row ui-sortable-placeholder',
            tolerance:   'pointer',
            update: function () { reindexSegments(); }
        });
    }

    function initSubSortable($list) {
        $list.sortable({
            handle:      '.ple-drag-handle',
            placeholder: 'ple-sub-row ui-sortable-placeholder',
            tolerance:   'pointer',
            update: function () {
                var subKey = $list.data('subkey');
                if (subKey) reindexSubItems($list, subKey);
            }
        });
    }

    /* ── Re-index helpers ───────────────────────────────────────────────── */
    function reindexSegments() {
        $('#ple-segments-list .ple-segment-row').each(function (newIdx) {
            var $row = $(this);
            $row.attr('data-index', newIdx);
            $row.find('[name]').each(function () {
                var old = $(this).attr('name');
                var nw  = old.replace(/^pl_segments\[\d+\]/, 'pl_segments[' + newIdx + ']');
                if (nw !== old) $(this).attr('name', nw);
            });
            $row.find('[data-segment]').attr('data-segment', newIdx);
            $row.find('[data-segment-index]').attr('data-segment-index', newIdx);
        });
    }

    function reindexSubItems($list, subKey) {
        var segIdx = $list.closest('.ple-segment-row').attr('data-index');
        $list.children('.ple-sub-row').each(function (newSubIdx) {
            $(this).find('[name]').each(function () {
                var old = $(this).attr('name');
                var nw  = old.replace(
                    new RegExp('\\[' + subKey + '\\]\\[\\d+\\]'),
                    '[' + subKey + '][' + newSubIdx + ']'
                );
                if (nw !== old) $(this).attr('name', nw);
            });
        });
    }

    /* ════════════════════════════════════════════════════════════════════════
       SETTINGS TAB
    ════════════════════════════════════════════════════════════════════════ */

    function populateSettings(s) {
        // Use name-attribute-based selection to match the PHP-rendered fields
        $('#ple-tab-settings [name]').each(function () {
            var name = $(this).attr('name');
            var m    = name.match(/^pl_settings\[([^\]]+)\]$/);
            if (!m) return;
            var key = m[1];
            if (!(key in s)) return;
            var val = s[key];
            if ($(this).is(':checkbox')) {
                $(this).prop('checked', !!val);
            } else {
                $(this).val(val);
            }
        });
    }

    function collectSettings() {
        var settings = {};
        $('#ple-tab-settings [name]').each(function () {
            var name = $(this).attr('name');
            var m    = name.match(/^pl_settings\[([^\]]+)\]$/);
            if (!m) return;
            var key = m[1];
            if ($(this).is(':checkbox')) {
                settings[key] = $(this).is(':checked') ? '1' : '0';
            } else {
                settings[key] = $(this).val();
            }
        });
        return settings;
    }

    /* ════════════════════════════════════════════════════════════════════════
       COLLECT SEGMENTS FOR SAVE
    ════════════════════════════════════════════════════════════════════════ */

    function collectSegments() {
        var segments = [];
        $('#ple-segments-list .ple-segment-row').each(function () {
            var seg = {};
            $(this).find('[name]').each(function () {
                var name = $(this).attr('name');
                // Strip the leading 'pl_segments[N]' and parse the rest
                var match = name.match(/^pl_segments\[\d+\](.*)$/);
                if (!match) return;
                var rest = match[1]; // e.g. [type], [slides][0][caption]
                var val  = $(this).is(':checkbox') ? ($(this).is(':checked') ? '1' : '0') : $(this).val();
                setNestedKey(seg, rest, val);
            });
            segments.push(seg);
        });
        return segments;
    }

    /**
     * Convert a bracketed key path like [slides][0][caption] into a nested object.
     * Simple iterative implementation sufficient for our data shapes.
     */
    function setNestedKey(obj, path, value) {
        var parts = [];
        var re    = /\[([^\]]*)\]/g;
        var m;
        while ((m = re.exec(path)) !== null) {
            parts.push(m[1]);
        }
        if (!parts.length) return;
        var cur = obj;
        for (var i = 0; i < parts.length - 1; i++) {
            var k    = parts[i];
            var next = parts[i + 1];
            var isNextIdx = next !== '' && !isNaN(parseInt(next, 10));
            if (!(k in cur)) {
                cur[k] = isNextIdx ? [] : {};
            }
            cur = cur[k];
        }
        var lastKey = parts[parts.length - 1];
        if (Array.isArray(cur)) {
            cur.push(value);
        } else {
            cur[lastKey] = value;
        }
    }

    /* ════════════════════════════════════════════════════════════════════════
       SAVE
    ════════════════════════════════════════════════════════════════════════ */

    $(document).on('click', '#ple-btn-save', function () {
        if (!currentProjectId) {
            notice(PLE.i18n.selectProject, 'error');
            return;
        }

        var $btn = $(this).prop('disabled', true).text(PLE.i18n.saving);
        spinner('ple-save-spinner', true);

        var segments = collectSegments();
        var settings = collectSettings();

        $.post(PLE.ajaxUrl, {
            action:      'ple_save_project',
            nonce:       PLE.nonce,
            post_id:     currentProjectId,
            post_title:  $('#ple-post-title').val(),
            pl_segments: segments,
            pl_settings: settings
        }, function (res) {
            spinner('ple-save-spinner', false);
            $btn.prop('disabled', false).text('Save Changes');
            if (res.success) {
                notice(res.data.message || PLE.i18n.saved, 'success');
                // Update title in the selector dropdown
                if (res.data.post_title) {
                    $('#ple-project-select option[value="' + currentProjectId + '"]')
                        .text(res.data.post_title);
                    $('#ple-post-title').val(res.data.post_title);
                }
            } else {
                notice((res.data && res.data.message) || PLE.i18n.saveError, 'error');
            }
        }).fail(function () {
            spinner('ple-save-spinner', false);
            $btn.prop('disabled', false).text('Save Changes');
            notice(PLE.i18n.saveError, 'error');
        });
    });

    /* ════════════════════════════════════════════════════════════════════════
       INLINE MEDIA LIBRARY MODAL
    ════════════════════════════════════════════════════════════════════════ */

    var mediaModal = {
        $el:           null,
        callback:      null,   // fn(id, url, thumb, type, filename)
        mediaType:     'image',// 'image' | 'application' | '' (all)
        page:          1,
        search:        '',
        hasMore:       false,
        loading:       false,

        open: function (mediaType, callback) {
            this.callback  = callback;
            this.mediaType = mediaType || 'image';
            this.page      = 1;
            this.search    = '';
            this.hasMore   = false;
            this._build();
            this.load();
        },

        _build: function () {
            if (this.$el) { this.$el.remove(); }
            var self = this;

            var $overlay = $('<div class="ple-media-modal-overlay" />');
            var $modal   = $('<div class="ple-media-modal" role="dialog" aria-modal="true" />');

            // Header
            var $hdr = $('<div class="ple-media-modal__header" />');
            $hdr.append($('<h3 class="ple-media-modal__title" />').text(PLE.i18n.selectMedia));
            var $close = $('<button type="button" class="ple-media-modal__close" aria-label="Close">✕</button>');
            $close.on('click', function () { self.close(); });
            $hdr.append($close);
            $modal.append($hdr);

            // Tabs (Library / Upload)
            var $tabs = $('<div class="ple-media-tabs" />');
            var $tabLib = $('<button type="button" class="ple-media-tab ple-media-tab--active" data-mtab="library">My Library</button>');
            var $tabUp  = $('<button type="button" class="ple-media-tab" data-mtab="upload">Upload</button>');
            $tabs.append($tabLib).append($tabUp);
            $modal.append($tabs);

            $tabs.on('click', 'button', function () {
                $tabs.find('button').removeClass('ple-media-tab--active');
                $(this).addClass('ple-media-tab--active');
                var tab = $(this).data('mtab');
                $modal.find('.ple-media-panel').hide();
                $modal.find('.ple-media-panel[data-panel="' + tab + '"]').css('display', 'flex');
            });

            // ── Library panel ──
            var $libPanel = $('<div class="ple-media-panel" data-panel="library" style="display:flex;flex-direction:column;flex:1;min-height:0;" />');

            // Toolbar
            var $toolbar = $('<div class="ple-media-modal__toolbar" />');
            var $search  = $('<input type="search" class="ple-input ple-media-search" placeholder="Search…" />');
            $search.on('input', debounce(function () {
                self.search = $(this).val();
                self.page   = 1;
                self.$grid.empty();
                self.load();
            }, 400));
            $toolbar.append($search);

            // Filter by type
            var $filter = $('<select class="ple-select" />');
            $filter.append('<option value="">All types</option>');
            $filter.append('<option value="image">Images</option>');
            $filter.append('<option value="application">Documents</option>');
            $filter.append('<option value="video">Video</option>');
            if (this.mediaType && this.mediaType !== 'image') {
                $filter.val(this.mediaType);
            }
            $filter.on('change', function () {
                self.mediaType = $(this).val();
                self.page      = 1;
                self.$grid.empty();
                self.load();
            });
            $toolbar.append($filter);
            $libPanel.append($toolbar);

            // Grid body
            var $body = $('<div class="ple-media-modal__body" />');
            this.$grid = $('<div class="ple-media-grid" />');
            this.$loadMore = $('<div class="ple-media-load-more" style="display:none" />');
            var $lmBtn = $('<button type="button" class="ple-btn ple-btn--secondary">Load more</button>');
            $lmBtn.on('click', function () { self.page++; self.load(); });
            this.$loadMore.append($lmBtn);
            this.$status = $('<p class="ple-media-status" style="text-align:center;color:#888;" />');

            $body.append(this.$grid).append(this.$loadMore).append(this.$status);
            $libPanel.append($body);

            // Footer
            var $footer = $('<div class="ple-media-modal__footer" />');
            this.$useBtn = $('<button type="button" class="ple-btn ple-btn--primary" disabled>')
                .text(PLE.i18n.useMedia);
            var $cancelBtn = $('<button type="button" class="ple-btn ple-btn--secondary">Cancel</button>');
            $cancelBtn.on('click', function () { self.close(); });
            this.$useBtn.on('click', function () { self._confirm(); });
            $footer.append($cancelBtn).append(self.$useBtn);
            $libPanel.append($footer);

            // ── Upload panel ──
            var $upPanel = $('<div class="ple-media-panel" data-panel="upload" style="display:none;flex-direction:column;flex:1;min-height:0;overflow-y:auto;" />');
            var $upBody  = $('<div style="padding:.85em" />');
            var $zone    = $('<div class="ple-upload-zone"><p>Click to browse, or drag & drop files here.</p></div>');
            var $fileInput = $('<input type="file" id="ple-upload-input" accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx" multiple style="position:absolute;width:1px;height:1px;opacity:0;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;" />');

            $zone.on('click', function () {
                $fileInput[0].click();
            });
            $zone.on('dragover', function (e) { e.preventDefault(); $(this).addClass('is-dragover'); });
            $zone.on('dragleave drop', function (e) {
                e.preventDefault();
                $(this).removeClass('is-dragover');
                if (e.type === 'drop') {
                    var files = e.originalEvent.dataTransfer.files;
                    if (files.length) self._upload(files);
                }
            });
            $fileInput.on('change', function () {
                if (this.files.length) self._upload(this.files);
            });

            this.$upProgress = $('<div class="ple-upload-progress" style="display:none" />')
                .append($('<progress value="0" max="100" />'))
                .append($('<p class="ple-upload-status" />'));

            $upBody.append($zone).append(self.$upProgress);
            $upPanel.append($upBody);

            $modal.append($libPanel).append($upPanel);
            $overlay.append($modal);
            $('body').append($overlay).append($fileInput);
            this.$el = $overlay;
            this.selectedItem = null;

            // Close on overlay click
            $overlay.on('click', function (e) {
                if ($(e.target).is($overlay)) self.close();
            });

            // ESC to close
            $(document).on('keydown.ple-media', function (e) {
                if (e.key === 'Escape') self.close();
            });
        },

        load: function () {
            if (this.loading) return;
            this.loading = true;
            this.$status.text(PLE.i18n.loading);

            var self = this;
            $.post(PLE.ajaxUrl, {
                action: 'ple_get_user_media',
                nonce:  PLE.nonce,
                paged:  self.page,
                search: self.search,
                type:   self.mediaType
            }, function (res) {
                self.loading = false;
                self.$status.text('');
                if (!res.success) {
                    self.$status.text(PLE.i18n.noMedia);
                    return;
                }
                var items = res.data.items || [];
                self.hasMore = !!res.data.has_more;
                self.$loadMore.toggle(self.hasMore);

                if (!items.length && self.page === 1) {
                    self.$status.text(PLE.i18n.noMedia);
                    return;
                }

                items.forEach(function (item) {
                    self.$grid.append(self._buildItem(item));
                });
            }).fail(function () {
                self.loading = false;
                self.$status.text(PLE.i18n.saveError);
            });
        },

        _buildItem: function (item) {
            var self = this;
            var $item = $('<div class="ple-media-item" tabindex="0" />')
                .attr('data-id',       item.id)
                .attr('data-url',      item.url)
                .attr('data-thumb',    item.thumb || item.url)
                .attr('data-type',     item.type)
                .attr('data-filename', item.filename || '')
                .attr('title',         item.title || item.filename || '');

            if (item.type === 'image') {
                $item.append($('<img loading="lazy" />').attr('src', item.thumb || item.url).attr('alt', item.title || ''));
            } else {
                $item.append('<div class="ple-media-item__file-icon">📄</div>');
            }
            $item.append('<div class="ple-media-item__check">✓</div>');

            // Delete button — visible on hover; calls AJAX to permanently remove the file
            var $del = $('<button type="button" class="ple-media-item__delete" title="Delete file">🗑</button>');
            $del.on('click', function (e) {
                e.stopPropagation();
                if (!window.confirm('Permanently delete this file? This cannot be undone.')) return;
                $del.prop('disabled', true).text('…');
                $.post(PLE.ajaxUrl, {
                    action:        'ple_delete_media',
                    nonce:         PLE.nonce,
                    attachment_id: item.id
                }, function (res) {
                    if (res.success) {
                        $item.remove();
                        // Deselect if this was the selected item
                        if (self.selectedItem && self.selectedItem.id === item.id) {
                            self.selectedItem = null;
                            self.$useBtn.prop('disabled', true);
                        }
                    } else {
                        $del.prop('disabled', false).text('🗑');
                        alert(res.data && res.data.message ? res.data.message : 'Could not delete file.');
                    }
                }).fail(function () {
                    $del.prop('disabled', false).text('🗑');
                    alert('Delete request failed.');
                });
            });
            $item.append($del);

            $item.on('click keydown', function (e) {
                if (e.type === 'keydown' && e.key !== 'Enter') return;
                self.$grid.find('.ple-media-item').removeClass('is-selected');
                $item.addClass('is-selected');
                self.selectedItem = {
                    id:       parseInt($item.data('id'),  10),
                    url:      $item.data('url'),
                    thumb:    $item.data('thumb'),
                    type:     $item.data('type'),
                    filename: $item.data('filename')
                };
                self.$useBtn.prop('disabled', false);
            });

            return $item;
        },

        _confirm: function () {
            if (!this.selectedItem || !this.callback) { this.close(); return; }
            this.callback(this.selectedItem);
            this.close();
        },

        close: function () {
            if (this.$el) { this.$el.remove(); this.$el = null; }
            $('#ple-upload-input').remove();
            $(document).off('keydown.ple-media');
        },

        // Upload via WP REST API  /wp-json/wp/v2/media
        _upload: function (files) {
            var self = this;
            var total = files.length;
            var done  = 0;

            self.$upProgress.show();
            self.$upProgress.find('.ple-upload-status').text('Uploading ' + total + ' file(s)…');

            function uploadOne(file) {
                var formData = new FormData();
                formData.append('file', file, file.name);

                // Sanitise the filename: strip non-ASCII and chars that would
                // break the Content-Disposition header value.
                var safeFilename = file.name.replace(/[^\x20-\x7E]/g, '_').replace(/["\\]/g, '_');

                $.ajax({
                    url:         window.location.origin + '/wp-json/wp/v2/media',
                    method:      'POST',
                    data:        formData,
                    processData: false,
                    contentType: false,
                    beforeSend:  function (xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', PLE.restNonce);
                        // WordPress REST media endpoint REQUIRES Content-Disposition
                        // to determine the filename and MIME type. Without it,
                        // wp_check_filetype_and_ext() has no extension to check
                        // and the server returns a 500 instead of a clean error.
                        xhr.setRequestHeader('Content-Disposition', 'attachment; filename="' + safeFilename + '"');
                    },
                    xhr: function () {
                        var xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener('progress', function (e) {
                            if (e.lengthComputable) {
                                var pct = Math.round((e.loaded / e.total) * 100);
                                self.$upProgress.find('progress').val(pct);
                            }
                        });
                        return xhr;
                    },
                    success: function () {
                        done++;
                        if (done === total) {
                            self.$upProgress.find('.ple-upload-status').text('Upload complete. Switching to library…');
                            setTimeout(function () {
                                self.$upProgress.hide();
                                // Switch back to library tab and reload
                                self.$el.find('[data-mtab="library"]').trigger('click');
                                self.page = 1;
                                self.$grid.empty();
                                self.load();
                            }, 800);
                        }
                    },
                    error: function (xhr) {
                        var msg = (xhr.responseJSON && xhr.responseJSON.message) || 'Upload failed.';
                        self.$upProgress.find('.ple-upload-status').text(msg);
                    }
                });
            }

            for (var i = 0; i < files.length; i++) {
                uploadOne(files[i]);
            }
        }
    };

    /* ── Media picker trigger ───────────────────────────────────────────── */
    $(document).on('click', '.ple-btn-pick-media', function () {
        var $btn       = $(this);
        var $row       = $btn.closest('.ple-media-row');
        var mediaType  = $btn.data('media-type') || 'image';

        mediaModal.open(mediaType, function (item) {
            $row.find('.ple-media-id').val(item.id);

            if (item.type === 'image') {
                $row.find('.ple-media-preview')
                    .attr('src', item.thumb || item.url)
                    .show();
            }
            $row.find('.ple-file-name').text(item.filename || '');
            $row.find('.ple-btn-remove-media, .ple-btn-remove-file').show();
        });
    });

    /* ── Utility functions ──────────────────────────────────────────────── */
    function fieldRow(labelText, $control) {
        var $p = $('<p />');
        $p.append($('<label />').text(labelText));
        $p.append($control);
        return $p;
    }

    function opt(value, text, selected) {
        return $('<option />').val(value).text(text).prop('selected', value === selected);
    }

    function escHtml(str) {
        return $('<div />').text(str).html();
    }

    function debounce(fn, delay) {
        var t;
        return function () {
            var ctx  = this;
            var args = arguments;
            clearTimeout(t);
            t = setTimeout(function () { fn.apply(ctx, args); }, delay);
        };
    }

}(jQuery));
