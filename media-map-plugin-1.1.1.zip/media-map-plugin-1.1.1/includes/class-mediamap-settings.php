<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Settings {

    public static function init() {
        // Settings are managed via the Admin class; this class exposes the getter.
    }

    /**
     * Return all plugin settings as an associative array.
     */
    public static function get_all(): array {
        return [
            'basemap_url'        => get_option( 'mediamap_basemap_url',        'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png' ),
            'basemap_attribution'=> get_option( 'mediamap_basemap_attribution', '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' ),
            'min_zoom'           => (int) get_option( 'mediamap_min_zoom',      2 ),
            'max_zoom'           => (int) get_option( 'mediamap_max_zoom',      19 ),
            'zoom_bound'         => (bool) get_option( 'mediamap_zoom_bound',   true ),
            'fullscreen'         => (bool) get_option( 'mediamap_fullscreen',   true ),
            'default_height'     => (int) get_option( 'mediamap_default_height',500 ),
            'cluster_markers'    => (bool) get_option( 'mediamap_cluster_markers', true ),
            'rate_limit'         => (int) get_option( 'mediamap_rate_limit',    5 ),
            // Marker colours: video=red, image=yellow, audio=violet, text=light-grey, pending=white
            'marker_image'       => get_option( 'mediamap_marker_image',  '#EAB308' ), // yellow
            'marker_video'       => get_option( 'mediamap_marker_video',  '#EF4444' ), // red
            'marker_audio'       => get_option( 'mediamap_marker_audio',  '#8B5CF6' ), // violet
            'marker_text'        => get_option( 'mediamap_marker_text',   '#D1D5DB' ), // light grey
            'marker_pending'     => get_option( 'mediamap_marker_pending','#FFFFFF' ), // white
            'icon_image'         => get_option( 'mediamap_icon_image',    '' ),
            'icon_video'         => get_option( 'mediamap_icon_video',    '' ),
            'icon_audio'         => get_option( 'mediamap_icon_audio',    '' ),
            'icon_text'          => get_option( 'mediamap_icon_text',     '' ),
            'icon_pending'       => get_option( 'mediamap_icon_pending',  '' ),
        ];
    }
}
