<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Shortcode {

    public static function init() {
        add_shortcode( 'mediamap', [ __CLASS__, 'render' ] );
    }

    public static function render( $atts ): string {
        $atts = shortcode_atts( [
            'height' => get_option( 'mediamap_default_height', 500 ),
            'class'  => '',
        ], $atts, 'mediamap' );

        // Enqueue assets
        MediaMap_Frontend::enqueue_assets();

        $height   = (int) $atts['height'];
        $extra    = esc_attr( $atts['class'] );
        $map_id   = 'mediamap-' . wp_unique_id();

        ob_start();
        ?>
        <div class="mediamap-wrap <?php echo $extra; ?>" data-map-id="<?php echo esc_attr( $map_id ); ?>">
            <div id="<?php echo esc_attr( $map_id ); ?>"
                 class="mediamap-canvas"
                 style="height:<?php echo $height; ?>px; width:100%; position:relative; z-index:1;">
            </div>
            <div class="mediamap-info-panel" id="<?php echo esc_attr( $map_id ); ?>-panel">
                <div class="mediamap-panel-inner">
                    <p class="mediamap-panel-hint"><?php esc_html_e( 'Click a marker to see details.', 'media-map' ); ?></p>
                </div>
            </div>
            <?php if ( is_user_logged_in() ) : ?>
            <div class="mediamap-submit-wrap" id="<?php echo esc_attr( $map_id ); ?>-submit">
                <?php self::render_submit_form( $map_id ); ?>
            </div>
            <?php else : ?>
            <p class="mediamap-login-notice">
                <?php printf(
                    wp_kses( __( '<a href="%s">Log in</a> to add content to the map.', 'media-map' ), [ 'a' => [ 'href' => [] ] ] ),
                    esc_url( wp_login_url( get_permalink() ) )
                ); ?>
            </p>
            <?php endif; ?>

            <?php if ( is_user_logged_in() ) : ?>
            <div class="mediamap-my-submissions" id="<?php echo esc_attr( $map_id ); ?>-my">
                <?php self::render_my_submissions(); ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private static function render_submit_form( string $map_id ): void {
        ?>
        <div class="mediamap-form-toggle">
            <button type="button" class="mediamap-btn mediamap-btn-primary mediamap-toggle-form">
                &#43; <?php esc_html_e( 'Add to Map', 'media-map' ); ?>
            </button>
        </div>
        <div class="mediamap-form-container" style="display:none;">
            <h3><?php esc_html_e( 'Add a Location', 'media-map' ); ?></h3>
            <p class="mediamap-form-hint">
                <?php esc_html_e( 'Search for a place or click directly on the map to pin a location, then fill in the details below.', 'media-map' ); ?>
            </p>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Search Place', 'media-map' ); ?></label>
                <input type="text" class="mediamap-place-search" placeholder="<?php esc_attr_e( 'Type a place name…', 'media-map' ); ?>" />
                <div class="mediamap-place-results"></div>
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Selected Coordinates', 'media-map' ); ?></label>
                <input type="text" class="mediamap-coords-display" readonly placeholder="<?php esc_attr_e( 'Click map or search to set', 'media-map' ); ?>" />
                <input type="hidden" class="mediamap-lat-input" />
                <input type="hidden" class="mediamap-lng-input" />
                <input type="hidden" class="mediamap-place-name-input" />
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Media URL', 'media-map' ); ?></label>
                <input type="url" class="mediamap-url-input" placeholder="<?php esc_attr_e( 'https://… (image, video, audio) — leave blank for text only', 'media-map' ); ?>" />
                <small><?php esc_html_e( 'Supports: YouTube, Vimeo, TikTok, SoundCloud, Spotify, Flickr, Imgur, and hundreds more.', 'media-map' ); ?></small>
                <div class="mediamap-url-feedback"></div>
            </div>
            <div class="mediamap-field">
                <label><?php esc_html_e( 'Description', 'media-map' ); ?></label>
                <textarea class="mediamap-desc-input" rows="3" placeholder="<?php esc_attr_e( 'Describe this location…', 'media-map' ); ?>"></textarea>
            </div>
            <div class="mediamap-form-actions">
                <button type="button" class="mediamap-btn mediamap-btn-primary mediamap-submit-btn">
                    <?php esc_html_e( 'Submit for Approval', 'media-map' ); ?>
                </button>
                <button type="button" class="mediamap-btn mediamap-btn-secondary mediamap-cancel-btn">
                    <?php esc_html_e( 'Cancel', 'media-map' ); ?>
                </button>
            </div>
            <div class="mediamap-form-feedback"></div>
        </div>
        <?php
    }

    private static function render_my_submissions(): void {
        $subs = MediaMap_Post_Type::get_user_submissions( get_current_user_id() );
        if ( empty( $subs ) ) return;
        ?>
        <div class="mediamap-my-subs-toggle">
            <button type="button" class="mediamap-btn mediamap-btn-ghost mediamap-toggle-my-subs">
                <?php esc_html_e( 'My Submissions', 'media-map' ); ?>
                <span class="mediamap-badge"><?php echo count( $subs ); ?></span>
            </button>
        </div>
        <div class="mediamap-my-subs-list" style="display:none;">
            <table class="mediamap-my-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Place', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Type', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'media-map' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'media-map' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $subs as $s ) : ?>
                    <tr data-sub-id="<?php echo (int) $s->id; ?>">
                        <td><?php echo esc_html( $s->place_name ?: "{$s->lat}, {$s->lng}" ); ?></td>
                        <td><?php echo esc_html( ucfirst( $s->media_type ) ); ?></td>
                        <td><span class="mediamap-status mediamap-status-<?php echo esc_attr( $s->status ); ?>"><?php echo esc_html( ucfirst( $s->status ) ); ?></span></td>
                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $s->submitted_at ) ) ); ?></td>
                        <td>
                            <?php if ( $s->status === 'pending' ) : ?>
                            <button class="mediamap-btn-link mediamap-edit-own" data-id="<?php echo (int) $s->id; ?>"><?php esc_html_e( 'Edit', 'media-map' ); ?></button>
                            <?php endif; ?>
                            <button class="mediamap-btn-link mediamap-del-own" data-id="<?php echo (int) $s->id; ?>"><?php esc_html_e( 'Delete', 'media-map' ); ?></button>
                            <?php if ( $s->status === 'rejected' && $s->rejection_note ) : ?>
                            <span class="mediamap-rejection-note" title="<?php echo esc_attr( $s->rejection_note ); ?>">&#9432;</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
}
