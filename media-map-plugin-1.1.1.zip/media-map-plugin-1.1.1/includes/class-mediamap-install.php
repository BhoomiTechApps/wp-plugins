<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Install {

    public static function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        // Main submissions table
        $table = $wpdb->prefix . 'mediamap_submissions';
        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id              BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id         BIGINT(20) UNSIGNED NOT NULL,
            lat             DECIMAL(10,7)       NOT NULL,
            lng             DECIMAL(10,7)       NOT NULL,
            place_name      VARCHAR(500)        NOT NULL DEFAULT '',
            media_type      ENUM('image','video','audio','text') NOT NULL,
            media_url       TEXT,
            description     TEXT,
            status          ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
            rejection_note  TEXT,
            url_hash        VARCHAR(64)         NOT NULL DEFAULT '',
            submitted_at    DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            reviewed_at     DATETIME,
            reviewed_by     BIGINT(20) UNSIGNED,
            PRIMARY KEY (id),
            KEY user_id  (user_id),
            KEY status   (status),
            KEY url_hash (url_hash)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        // Rate-limit log table
        $log_table = $wpdb->prefix . 'mediamap_rate_log';
        $sql2 = "CREATE TABLE IF NOT EXISTS {$log_table} (
            id         BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT(20) UNSIGNED NOT NULL,
            submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY submitted_at (submitted_at)
        ) {$charset};";
        dbDelta( $sql2 );

        self::seed_default_options();
        flush_rewrite_rules();
    }

    public static function deactivate() {
        flush_rewrite_rules();
    }

    private static function seed_default_options() {
        $defaults = [
            'mediamap_basemap_url'         => 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            'mediamap_basemap_attribution'  => '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            'mediamap_min_zoom'            => 2,
            'mediamap_max_zoom'            => 19,
            'mediamap_zoom_bound'          => 1,
            'mediamap_fullscreen'          => 1,
            'mediamap_default_height'      => 500,
            'mediamap_cluster_markers'     => 1,
            'mediamap_rate_limit'          => 5,   // submissions per hour per user
            'mediamap_notify_admin'        => 1,
            'mediamap_notify_user'         => 1,
            // Marker colours (CSS colour strings used to tint SVG markers)
            'mediamap_marker_image'        => '#3B82F6',
            'mediamap_marker_video'        => '#EF4444',
            'mediamap_marker_audio'        => '#10B981',
            'mediamap_marker_text'         => '#8B5CF6',
            'mediamap_marker_pending'      => '#F59E0B',
            // Custom SVG/icon overrides (data-URI or URL) – empty = use built-in
            'mediamap_icon_image'          => '',
            'mediamap_icon_video'          => '',
            'mediamap_icon_audio'          => '',
            'mediamap_icon_text'           => '',
            'mediamap_icon_pending'        => '',
        ];
        foreach ( $defaults as $key => $value ) {
            if ( get_option( $key ) === false ) {
                add_option( $key, $value );
            }
        }
    }
}
