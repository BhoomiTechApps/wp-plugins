<?php
defined( 'ABSPATH' ) || exit;

/**
 * Registers nothing as a CPT; the plugin stores submissions in a custom table.
 * This class provides helper DB methods consumed across the plugin.
 */
class MediaMap_Post_Type {

    public static function init() {
        // No CPT needed – all data lives in custom table.
    }

    /* ------------------------------------------------------------------
       DB Helpers
    ------------------------------------------------------------------ */

    public static function get_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'mediamap_submissions';
    }

    public static function get_rate_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'mediamap_rate_log';
    }

    /** Fetch a single submission by ID. */
    public static function get( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::get_table() . " WHERE id = %d", $id
        ) );
    }

    /** Fetch all approved submissions (for map display). */
    public static function get_approved(): array {
        global $wpdb;
        return $wpdb->get_results(
            "SELECT id, lat, lng, place_name, media_type, media_url, description, submitted_at
             FROM " . self::get_table() . "
             WHERE status = 'approved'
             ORDER BY submitted_at DESC"
        );
    }

    /** Fetch pending submissions visible to a user (their own) or all (admin). */
    public static function get_pending( int $user_id = 0 ): array {
        global $wpdb;
        $t = self::get_table();
        if ( $user_id ) {
            return $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$t} WHERE status = 'pending' AND user_id = %d ORDER BY submitted_at DESC", $user_id
            ) );
        }
        return $wpdb->get_results(
            "SELECT s.*, u.user_login FROM {$t} s
             LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id
             WHERE s.status = 'pending'
             ORDER BY s.submitted_at DESC"
        );
    }

    /** Paginated list for admin. */
    public static function admin_list( array $args = [] ): array {
        global $wpdb;
        $t      = self::get_table();
        $status = isset( $args['status'] ) ? $args['status'] : '';
        $search = isset( $args['search'] ) ? '%' . $wpdb->esc_like( $args['search'] ) . '%' : '';
        $limit  = isset( $args['limit']  ) ? (int) $args['limit']  : 20;
        $offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;

        $where = '1=1';
        $params = [];
        if ( $status ) {
            $where   .= ' AND s.status = %s';
            $params[] = $status;
        }
        if ( $search ) {
            $where   .= ' AND (s.description LIKE %s OR s.place_name LIKE %s OR u.user_login LIKE %s)';
            $params[] = $search;
            $params[] = $search;
            $params[] = $search;
        }

        $params[] = $limit;
        $params[] = $offset;

        $sql = "SELECT s.*, u.user_login
                FROM {$t} s
                LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id
                WHERE {$where}
                ORDER BY s.submitted_at DESC
                LIMIT %d OFFSET %d";

        $rows  = $wpdb->get_results( $params ? $wpdb->prepare( $sql, ...$params ) : $sql );
        $count_sql = "SELECT COUNT(*) FROM {$t} s LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id WHERE {$where}";
        $total = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_sql, ...array_slice( $params, 0, -2 ) ) : $count_sql );

        return compact( 'rows', 'total' );
    }

    /** Insert a new submission. Returns inserted ID or WP_Error. */
    public static function insert( array $data ) {
        global $wpdb;
        $result = $wpdb->insert( self::get_table(), [
            'user_id'    => (int)    $data['user_id'],
            'lat'        => (float)  $data['lat'],
            'lng'        => (float)  $data['lng'],
            'place_name' => sanitize_text_field( $data['place_name'] ?? '' ),
            'media_type' => sanitize_key( $data['media_type'] ),
            'media_url'  => esc_url_raw( $data['media_url'] ?? '' ),
            'description'=> sanitize_textarea_field( $data['description'] ?? '' ),
            'url_hash'   => $data['media_url'] ? hash( 'sha256', $data['media_url'] ) : '',
            'status'     => 'pending',
            'submitted_at' => current_time( 'mysql' ),
        ] );
        if ( false === $result ) {
            return new WP_Error( 'db_error', $wpdb->last_error );
        }
        return $wpdb->insert_id;
    }

    /** Update status */
    public static function update_status( int $id, string $status, string $note = '', int $reviewer = 0 ): bool {
        global $wpdb;
        return (bool) $wpdb->update( self::get_table(), [
            'status'         => $status,
            'rejection_note' => $note,
            'reviewed_at'    => current_time( 'mysql' ),
            'reviewed_by'    => $reviewer,
        ], [ 'id' => $id ] );
    }

    /** Delete a submission */
    public static function delete( int $id ): bool {
        global $wpdb;
        return (bool) $wpdb->delete( self::get_table(), [ 'id' => $id ] );
    }

    /** Rate limit check: how many submissions has this user made in the last hour? */
    public static function count_recent( int $user_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::get_rate_table() .
            " WHERE user_id = %d AND submitted_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)",
            $user_id
        ) );
    }

    public static function log_submission( int $user_id ): void {
        global $wpdb;
        $wpdb->insert( self::get_rate_table(), [
            'user_id'      => $user_id,
            'submitted_at' => current_time( 'mysql' ),
        ] );
    }

    /** Check if URL was already submitted */
    public static function url_exists( string $url ): bool {
        global $wpdb;
        $hash = hash( 'sha256', $url );
        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . self::get_table() . " WHERE url_hash = %s", $hash
        ) );
        return (int) $count > 0;
    }

    /** User's own submissions (all statuses) */
    public static function get_user_submissions( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . self::get_table() . " WHERE user_id = %d ORDER BY submitted_at DESC",
            $user_id
        ) );
    }

    /** Update a pending submission (user edit) */
    public static function update_submission( int $id, array $data ): bool {
        global $wpdb;
        $row = self::get( $id );
        if ( ! $row || $row->status !== 'pending' ) return false;
        return (bool) $wpdb->update( self::get_table(), [
            'place_name'  => sanitize_text_field( $data['place_name'] ?? $row->place_name ),
            'media_type'  => sanitize_key( $data['media_type'] ?? $row->media_type ),
            'media_url'   => esc_url_raw( $data['media_url'] ?? $row->media_url ),
            'description' => sanitize_textarea_field( $data['description'] ?? $row->description ),
        ], [ 'id' => $id ] );
    }
}
