<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Notifications {

    public static function init() {
        // Nothing to hook at init time.
    }

    public static function on_new_submission( int $id ): void {
        if ( ! get_option( 'mediamap_notify_admin', 1 ) ) return;

        $row        = MediaMap_Post_Type::get( $id );
        if ( ! $row ) return;
        $admin_email = get_option( 'admin_email' );
        $site        = get_bloginfo( 'name' );
        $user        = get_userdata( (int) $row->user_id );
        $username    = $user ? $user->user_login : 'Unknown';
        $admin_url   = admin_url( 'admin.php?page=mediamap-submissions' );

        $subject = sprintf( '[%s] New Media Map submission awaiting approval', $site );
        $message = sprintf(
            "A new submission has been received on %s.\n\nSubmitted by: %s\nLocation: %s\nMedia type: %s\nDescription: %s\n\nReview it here:\n%s",
            $site, $username, $row->place_name ?: "{$row->lat}, {$row->lng}",
            strtoupper( $row->media_type ), $row->description, $admin_url
        );

        wp_mail( $admin_email, $subject, $message );
    }

    public static function on_approved( int $id ): void {
        if ( ! get_option( 'mediamap_notify_user', 1 ) ) return;

        $row  = MediaMap_Post_Type::get( $id );
        if ( ! $row ) return;
        $user = get_userdata( (int) $row->user_id );
        if ( ! $user ) return;

        $site    = get_bloginfo( 'name' );
        $subject = sprintf( '[%s] Your Media Map submission has been approved', $site );
        $message = sprintf(
            "Hi %s,\n\nYour submission on %s has been approved and is now visible on the map.\n\nLocation: %s\nMedia type: %s\nDescription: %s\n\nThank you for contributing!",
            $user->display_name, $site,
            $row->place_name ?: "{$row->lat}, {$row->lng}",
            strtoupper( $row->media_type ), $row->description
        );

        wp_mail( $user->user_email, $subject, $message );
    }

    public static function on_rejected( int $id, string $note ): void {
        if ( ! get_option( 'mediamap_notify_user', 1 ) ) return;

        $row  = MediaMap_Post_Type::get( $id );
        if ( ! $row ) return;
        $user = get_userdata( (int) $row->user_id );
        if ( ! $user ) return;

        $site    = get_bloginfo( 'name' );
        $subject = sprintf( '[%s] Your Media Map submission was not approved', $site );
        $message = sprintf(
            "Hi %s,\n\nUnfortunately your submission on %s was not approved.",
            $user->display_name, $site
        );
        if ( $note ) {
            $message .= "\n\nReason: {$note}";
        }
        $message .= "\n\nIf you have questions, please contact the site administrator.";

        wp_mail( $user->user_email, $subject, $message );
    }
}
