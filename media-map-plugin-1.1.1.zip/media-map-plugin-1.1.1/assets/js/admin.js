/* global MediaMapAdmin, jQuery */
( function ( $, cfg ) {
    'use strict';

    let rejectTargetId = null;

    $( document ).on( 'click', '.mediamap-approve-btn', function () {
        if ( ! confirm( cfg.i18n.confirmApprove ) ) return;
        const id  = $( this ).data( 'id' );
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_approve', nonce: cfg.nonce, id: id }, function ( r ) {
            if ( r.success ) {
                $row.find( '.mediamap-status-badge' ).text( 'Approved' ).removeClass( 'mediamap-status-pending mediamap-status-rejected' ).addClass( 'mediamap-status-approved' );
                $row.find( '.mediamap-approve-btn' ).remove();
                $row.find( '.mediamap-reject-btn' ).text( 'Revoke' );
            } else {
                alert( 'Error: ' + ( r.data && r.data.message ? r.data.message : 'Unknown error' ) );
            }
        } );
    } );

    $( document ).on( 'click', '.mediamap-reject-btn', function () {
        rejectTargetId = $( this ).data( 'id' );
        $( '#mediamap-reject-note' ).val( '' );
        $( '#mediamap-reject-modal' ).dialog( {
            title:  cfg.i18n.confirmReject,
            modal:  true,
            width:  480,
            buttons: {},
        } );
        $( '#mediamap-reject-modal' ).show();
    } );

    $( document ).on( 'click', '#mediamap-reject-confirm', function () {
        const id   = rejectTargetId;
        const note = $( '#mediamap-reject-note' ).val();
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_reject', nonce: cfg.nonce, id: id, note: note }, function ( r ) {
            $( '#mediamap-reject-modal' ).hide();
            if ( r.success ) {
                $row.find( '.mediamap-status-badge' ).text( 'Rejected' ).removeClass( 'mediamap-status-pending mediamap-status-approved' ).addClass( 'mediamap-status-rejected' );
                $row.find( '.mediamap-approve-btn, .mediamap-reject-btn' ).remove();
                const $td = $row.find( '.mediamap-row-actions' );
                $td.prepend( '<button class="button button-primary button-small mediamap-approve-btn" data-id="' + id + '">Re-approve</button> ' );
                $td.prepend( '<button class="button button-link-delete button-small mediamap-delete-btn" data-id="' + id + '">Delete</button> ' );
            }
        } );
    } );

    $( document ).on( 'click', '#mediamap-reject-cancel', function () {
        $( '#mediamap-reject-modal' ).hide();
    } );

    $( document ).on( 'click', '.mediamap-delete-btn', function () {
        if ( ! confirm( cfg.i18n.confirmDelete ) ) return;
        const id  = $( this ).data( 'id' );
        const $row = $( '#mediamap-row-' + id );
        $.post( cfg.ajaxurl, { action: 'mediamap_admin_delete', nonce: cfg.nonce, id: id }, function ( r ) {
            if ( r.success ) $row.fadeOut( 200, function () { $( this ).remove(); } );
        } );
    } );

    // Colour preview on marker settings page
    $( 'input[type=color]' ).on( 'input change', function () {
        const $row = $( this ).closest( 'tr' );
        $row.find( '.mediamap-marker-preview' ).css( 'background', $( this ).val() );
    } ).trigger( 'input' );

} )( jQuery, MediaMapAdmin );
