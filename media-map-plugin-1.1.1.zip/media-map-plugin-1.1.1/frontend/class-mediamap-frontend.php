<?php
defined( 'ABSPATH' ) || exit;

class MediaMap_Frontend {

    private static bool $enqueued = false;

    public static function init() {
        // Assets are enqueued on demand by the shortcode renderer.
    }

    public static function enqueue_assets(): void {
        if ( self::$enqueued ) return;
        self::$enqueued = true;

        $settings = MediaMap_Settings::get_all();

        // ---- Leaflet core ----
        wp_enqueue_style(
            'leaflet',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
            [], '1.9.4'
        );
        wp_enqueue_script(
            'leaflet',
            'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
            [], '1.9.4', true
        );

        // ---- Marker Cluster ----
        if ( $settings['cluster_markers'] ) {
            wp_enqueue_style(
                'leaflet-cluster-css',
                'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.css',
                [ 'leaflet' ], '1.5.3'
            );
            wp_enqueue_style(
                'leaflet-cluster-default',
                'https://unpkg.com/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css',
                [ 'leaflet-cluster-css' ], '1.5.3'
            );
            wp_enqueue_script(
                'leaflet-cluster',
                'https://unpkg.com/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js',
                [ 'leaflet' ], '1.5.3', true
            );
        }

        // ---- Leaflet Fullscreen ----
        if ( $settings['fullscreen'] ) {
            wp_enqueue_style(
                'leaflet-fullscreen-css',
                'https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.css',
                [ 'leaflet' ], '2.4.0'
            );
            wp_enqueue_script(
                'leaflet-fullscreen',
                'https://unpkg.com/leaflet.fullscreen@2.4.0/Control.FullScreen.js',
                [ 'leaflet' ], '2.4.0', true
            );
        }

        // ---- Nominatim geocoder (custom lightweight) ----
        // Built into our own JS; no extra dep needed.

        // ---- Plugin CSS ----
        wp_enqueue_style(
            'mediamap-frontend',
            MEDIAMAP_PLUGIN_URL . 'assets/css/frontend.css',
            [ 'leaflet' ], MEDIAMAP_VERSION
        );

        // ---- Plugin JS ----
        wp_enqueue_script(
            'mediamap-frontend',
            MEDIAMAP_PLUGIN_URL . 'assets/js/frontend.js',
            [ 'leaflet', 'jquery' ], MEDIAMAP_VERSION, true
        );

        // ---- Localize config ----
        wp_localize_script( 'mediamap-frontend', 'MediaMapConfig', [
            'ajaxurl'      => admin_url( 'admin-ajax.php' ),
            'nonce_submit' => wp_create_nonce( 'mediamap_submit' ),
            'nonce_public' => wp_create_nonce( 'mediamap_public' ),
            'nonce_user'   => wp_create_nonce( 'mediamap_user' ),
            'logged_in'    => is_user_logged_in(),
            'settings'     => $settings,
            'i18n'         => [
                'clickToPin'    => __( 'Click on the map to place your pin.', 'media-map' ),
                'pinPlaced'     => __( 'Pin placed at', 'media-map' ),
                'submitting'    => __( 'Submitting…', 'media-map' ),
                'detectingType' => __( 'Detecting media type…', 'media-map' ),
                'pendingMarker' => __( 'Your submission (pending approval)', 'media-map' ),
                'confirmDelete' => __( 'Delete this submission?', 'media-map' ),
                'noLocation'    => __( 'Please select a location on the map first.', 'media-map' ),
                'noContent'     => __( 'Please provide a URL or description.', 'media-map' ),
                'searching'     => __( 'Searching…', 'media-map' ),
                'noResults'     => __( 'No places found.', 'media-map' ),
                'pendingTitle'  => __( 'Submission Awaiting Approval', 'media-map' ),
                'pendingMessage'=> __( 'This submission is awaiting admin approval and cannot be viewed yet.', 'media-map' ),
            ],
        ] );
    }
}
