<?php
/**
 * REST API endpoints for LexiPic.
 *
 * Namespace: lexipic/v1
 *
 * Routes:
 *   GET    /sets                   — list all sets
 *   POST   /sets                   — create a set
 *   GET    /sets/(?P<id>\d+)       — get one set (metadata only)
 *   DELETE /sets/(?P<id>\d+)       — delete a set + its entries/files
 *
 *   GET    /sets/(?P<set_id>\d+)/entries         — list entries (no blobs)
 *   POST   /sets/(?P<set_id>\d+)/entries         — create an entry
 *   DELETE /entries/(?P<id>\d+)                  — delete one entry
 *
 *   GET    /entries/(?P<id>\d+)/image            — serve the image blob
 *   GET    /sets/(?P<id>\d+)/export              — download JSON export
 *   POST   /import                               — import a JSON file
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lexipic_REST_API {

	private static $ns = 'lexipic/v1';

	public static function register_routes() {
		// ── Sets ──────────────────────────────────────────────────────────────
		register_rest_route( self::$ns, '/sets', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_sets' ),
				'permission_callback' => array( __CLASS__, 'can_read' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_set' ),
				'permission_callback' => array( __CLASS__, 'can_write' ),
				'args'                => array(
					'name'     => array( 'required' => true, 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ),
					'language' => array( 'required' => false, 'type' => 'string', 'default' => 'bpm', 'sanitize_callback' => 'sanitize_key' ),
				),
			),
		) );

		register_rest_route( self::$ns, '/sets/(?P<id>\d+)', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_set' ),
				'permission_callback' => array( __CLASS__, 'can_read' ),
			),
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( __CLASS__, 'delete_set' ),
				'permission_callback' => array( __CLASS__, 'can_write' ),
			),
		) );

		// ── Entries ───────────────────────────────────────────────────────────
		register_rest_route( self::$ns, '/sets/(?P<set_id>\d+)/entries', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'get_entries' ),
				'permission_callback' => array( __CLASS__, 'can_read' ),
			),
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( __CLASS__, 'create_entry' ),
				'permission_callback' => array( __CLASS__, 'can_write' ),
			),
		) );

		register_rest_route( self::$ns, '/entries/(?P<id>\d+)', array(
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( __CLASS__, 'delete_entry' ),
				'permission_callback' => array( __CLASS__, 'can_write' ),
			),
		) );

		// ── Image serve ───────────────────────────────────────────────────────
		register_rest_route( self::$ns, '/entries/(?P<id>\d+)/image', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'serve_image' ),
			'permission_callback' => array( __CLASS__, 'can_read' ),
		) );

		// ── Export ────────────────────────────────────────────────────────────
		register_rest_route( self::$ns, '/sets/(?P<id>\d+)/export', array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => array( __CLASS__, 'export_set' ),
			'permission_callback' => array( __CLASS__, 'can_write' ),
		) );

		// ── Import ────────────────────────────────────────────────────────────
		register_rest_route( self::$ns, '/import', array(
			'methods'             => WP_REST_Server::CREATABLE,
			'callback'            => array( __CLASS__, 'import_json' ),
			'permission_callback' => array( __CLASS__, 'can_write' ),
		) );
	}

	// ── Permission callbacks ──────────────────────────────────────────────────

	public static function can_read( $request ) {
		// Public sets can be viewed by logged-in users or if the plugin is set to public.
		$options = get_option( 'lexipic_settings', array() );
		if ( ! empty( $options['public_view'] ) ) {
			return true;
		}
		return is_user_logged_in();
	}

	public static function can_write( $request ) {
		return is_user_logged_in();
	}

	// ── Sets ──────────────────────────────────────────────────────────────────

	public static function get_sets( $request ) {
		// The set list backs the Archive selector, which every reader (per
		// can_read — logged-in users, or anyone if "public_view" is on)
		// should see in full, regardless of who created each set.
		// "Owner or admin" restrictions for write actions (delete, etc.)
		// are enforced separately in their own callbacks.
		$sets = Lexipic_DB::get_sets();

		// Attach entry counts.
		foreach ( $sets as &$set ) {
			$set->entry_count = Lexipic_DB::count_entries( (int) $set->id );
		}

		return rest_ensure_response( $sets );
	}

	public static function get_set( $request ) {
		$set = Lexipic_DB::get_set( (int) $request['id'] );
		if ( ! $set ) {
			return new WP_Error( 'not_found', 'Set not found.', array( 'status' => 404 ) );
		}
		return rest_ensure_response( $set );
	}

	public static function create_set( $request ) {
		$name     = $request->get_param( 'name' );
		$language = $request->get_param( 'language' );
		$user_id  = get_current_user_id();

		$set_id = Lexipic_DB::create_set( $name, $language, $user_id );
		if ( is_wp_error( $set_id ) ) {
			return $set_id;
		}

		$set = Lexipic_DB::get_set( $set_id );
		return rest_ensure_response( $set );
	}

	public static function delete_set( $request ) {
		$set_id = (int) $request['id'];
		$set    = Lexipic_DB::get_set( $set_id );
		if ( ! $set ) {
			return new WP_Error( 'not_found', 'Set not found.', array( 'status' => 404 ) );
		}

		// Only owner or admin can delete.
		if ( ! current_user_can( 'manage_options' ) && (int) $set->created_by !== get_current_user_id() ) {
			return new WP_Error( 'forbidden', 'You cannot delete this set.', array( 'status' => 403 ) );
		}

		Lexipic_DB::delete_set( $set_id );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	// ── Entries ───────────────────────────────────────────────────────────────

	public static function get_entries( $request ) {
		$set_id  = (int) $request['set_id'];
		$entries = Lexipic_DB::get_entries( $set_id );

		// Attach image URL (served through REST) and audio URL for each entry.
		$rest_base = rest_url( 'lexipic/v1/' );
		foreach ( $entries as &$entry ) {
			$entry->image_url = $entry->image_mime
				? $rest_base . 'entries/' . $entry->id . '/image'
				: '';
			$entry->audio_url = $entry->audio_path
				? LEXIPIC_UPLOAD_URL . '/' . basename( $entry->audio_path )
				: '';
		}

		return rest_ensure_response( $entries );
	}

	/**
	 * Create a new entry.
	 *
	 * Expects JSON body (or multipart):
	 *   word_script   string  — native script word
	 *   word_roman    string  — Roman transliteration
	 *   description   string  — optional notes
	 *   image         string  — base64 data-URI
	 *   audio         string  — base64 data-URI
	 */
	public static function create_entry( $request ) {
		$set_id = (int) $request['set_id'];
		$set    = Lexipic_DB::get_set( $set_id );
		if ( ! $set ) {
			return new WP_Error( 'not_found', 'Set not found.', array( 'status' => 404 ) );
		}

		// Decode image → binary blob.
		$image_data = null;
		$image_mime = 'image/jpeg';
		$image_uri  = $request->get_param( 'image' );
		if ( $image_uri ) {
			$decoded = Lexipic_File_Handler::decode_image( $image_uri );
			if ( ! is_wp_error( $decoded ) ) {
				$image_data = $decoded['binary'];
				$image_mime = $decoded['mime'];
			}
		}

		// Insert entry to get an ID for the audio filename.
		$entry_id = Lexipic_DB::create_entry( array(
			'set_id'      => $set_id,
			'word_script' => sanitize_text_field( $request->get_param( 'word_script' ) ?? '' ),
			'word_roman'  => sanitize_text_field( $request->get_param( 'word_roman' ) ?? '' ),
			'description' => sanitize_textarea_field( $request->get_param( 'description' ) ?? '' ),
			'image_data'  => $image_data,
			'image_mime'  => $image_mime,
			'audio_path'  => null,
			'audio_mime'  => 'audio/webm',
		) );

		if ( is_wp_error( $entry_id ) ) {
			return $entry_id;
		}

		// Save audio file.
		$audio_uri = $request->get_param( 'audio' );
		if ( $audio_uri ) {
			$audio = Lexipic_File_Handler::save_audio( $audio_uri, $entry_id );
			if ( ! is_wp_error( $audio ) ) {
				Lexipic_DB::update_audio( $entry_id, $audio['path'], $audio['mime'] );
				Lexipic_Audio_Converter::schedule_conversion( $entry_id, $audio['path'] );
			}
		}

		// Return the full entry with URLs.
		$entry             = Lexipic_DB::get_entry( $entry_id );
		$entry->image_url  = $entry->image_mime
			? rest_url( 'lexipic/v1/entries/' . $entry_id . '/image' )
			: '';
		$entry->audio_url  = $entry->audio_path
			? LEXIPIC_UPLOAD_URL . '/' . basename( $entry->audio_path )
			: '';
		// Don't return the raw blob over the wire.
		unset( $entry->image_data );

		return rest_ensure_response( $entry );
	}

	public static function delete_entry( $request ) {
		$entry_id = (int) $request['id'];
		$entry    = Lexipic_DB::get_entry( $entry_id );
		if ( ! $entry ) {
			return new WP_Error( 'not_found', 'Entry not found.', array( 'status' => 404 ) );
		}
		Lexipic_DB::delete_entry( $entry_id );
		return rest_ensure_response( array( 'deleted' => true ) );
	}

	// ── Image serve ───────────────────────────────────────────────────────────

	public static function serve_image( $request ) {
		$entry = Lexipic_DB::get_entry( (int) $request['id'] );
		if ( ! $entry || ! $entry->image_data ) {
			return new WP_Error( 'not_found', 'Image not found.', array( 'status' => 404 ) );
		}

		// Stream the image binary with correct headers.
		header( 'Content-Type: ' . $entry->image_mime );
		header( 'Content-Length: ' . strlen( $entry->image_data ) );
		header( 'Cache-Control: public, max-age=86400' );
		echo $entry->image_data; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	// ── Export ────────────────────────────────────────────────────────────────

	public static function export_set( $request ) {
		$set_id = (int) $request['id'];
		$set    = Lexipic_DB::get_set( $set_id );
		if ( ! $set ) {
			return new WP_Error( 'not_found', 'Set not found.', array( 'status' => 404 ) );
		}

		$export = Lexipic_File_Handler::build_export( $set_id );
		$json   = wp_json_encode( $export, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );

		$filename = sanitize_file_name( $set->slug ) . '_lexipic_' . date( 'Ymd' ) . '.json';

		// Gzip the payload when the client advertises support, for a
		// significant transfer-size reduction on large exports.
		$accept_encoding = isset( $_SERVER['HTTP_ACCEPT_ENCODING'] ) ? $_SERVER['HTTP_ACCEPT_ENCODING'] : '';
		$can_gzip        = function_exists( 'gzencode' ) && false !== stripos( $accept_encoding, 'gzip' );

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		if ( $can_gzip ) {
			$gzipped = gzencode( $json, 9 );
			if ( false !== $gzipped ) {
				header( 'Content-Encoding: gzip' );
				header( 'Vary: Accept-Encoding' );
				header( 'Content-Length: ' . strlen( $gzipped ) );
				echo $gzipped; // phpcs:ignore WordPress.Security.EscapeOutput
				exit;
			}
		}

		header( 'Content-Length: ' . strlen( $json ) );
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput
		exit;
	}

	// ── Import ────────────────────────────────────────────────────────────────

	public static function import_json( $request ) {
		$body = $request->get_json_params();

		if ( empty( $body ) ) {
			return new WP_Error( 'empty_body', 'No JSON data received.', array( 'status' => 400 ) );
		}

		$result = Lexipic_File_Handler::import_json( $body, get_current_user_id() );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return rest_ensure_response( $result );
	}
}
