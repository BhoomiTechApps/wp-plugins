/**
 * LexiPic — Frontend App Script
 *
 * Communicates with the WP REST API (lexipic/v1/).
 * Replaces the original IndexedDB-based script.js from the PWA.
 *
 * Config injected by PHP via wp_localize_script as window.lexipicConfig:
 *   restUrl       — base REST URL ending in /
 *   nonce         — WP REST nonce
 *   speechLocale  — BCP-47 locale for SpeechRecognition
 *   language      — 'as' | 'bn' | 'bpm'
 *   pluginUrl     — plugin URL for asset paths
 *   ffmpegEnabled — '1' or '0'
 *   imeMaps       — { forward: {...}, reverse: {...} } IME maps
 *   imeHooks      — array of CompLing AI snippet hook definitions
 *   imeSettings   — engine settings (virama, zwj, section_order, etc.)
 */

/* global lexipicConfig, CPLAI_ENGINE */
( function () {
	'use strict';

	// ── Config ───────────────────────────────────────────────────────────────
	const cfg        = window.lexipicConfig || {};
	const REST_URL   = cfg.restUrl     || '';
	const NONCE      = cfg.nonce       || '';
	const SR_LOCALE  = cfg.speechLocale || 'bn-IN';
	const IME_LANG   = cfg.language    || 'bpm';
	const PLUGIN_URL = cfg.pluginUrl   || '';
	const IME_MAPS     = cfg.imeMaps     || { forward: {}, reverse: {} };
	const IME_HOOKS    = Array.isArray( cfg.imeHooks ) ? cfg.imeHooks : [];
	const IME_SETTINGS = cfg.imeSettings || {};
	// Whether the current visitor is logged in (entry deletion requires this
	// on the backend — see Lexipic_REST_API::can_write).
	const CAN_WRITE    = cfg.canWrite === '1';

	// Max dimensions for captured images before encoding (perf cap).
	const MAX_IMAGE_DIM = 400;

	// ── State ─────────────────────────────────────────────────────────────────
	let currentSetId   = null;
	let mediaRecorder  = null;
	let audioChunks    = [];
	let finalAudioBlob = null;

	// ── DOM refs ──────────────────────────────────────────────────────────────
	const $  = ( sel, ctx = document ) => ctx.querySelector( sel );
	const $$ = ( sel, ctx = document ) => Array.from( ctx.querySelectorAll( sel ) );

	const app              = $( '#lexipic-app' );
	if ( ! app ) return; // Shortcode not on this page.

	const tabButtons       = $$( '.lp-tab-btn', app );
	const tabPanels        = $$( '.lp-tab-panel', app );
	const setSelect        = $( '#lp-set-select' );
	const setNameInput     = $( '#lp-set-name' );
	const setLangSelect    = $( '#lp-set-language' );
	const createSetBtn     = $( '#lp-create-set-btn' );
	const exportBtn        = $( '#lp-export-btn' );
	const importInput      = $( '#lp-import-input' );
	const deleteSetBtn     = $( '#lp-delete-set-btn' );
	const captureAction    = $( '#lp-capture-action' );
	const imageInput       = $( '#lp-image-input' );
	const previewContainer = $( '#lp-preview-container' );
	const scriptInput      = $( '#lp-script-input' );
	const romanInput       = $( '#lp-roman-input' );
	const descInput        = $( '#lp-description-input' );
	const entryStatus      = $( '#lp-entry-status' );
	const saveEntryBtn     = $( '#lp-save-entry-btn' );
	const slider           = $( '#lp-archive-slider' );
	const prevBtn          = $( '#lp-prev-btn' );
	const nextBtn          = $( '#lp-next-btn' );

	// ── REST helpers ──────────────────────────────────────────────────────────
	async function apiFetch( path, options = {} ) {
		const defaults = {
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce':   NONCE,
			},
		};
		const merged = Object.assign( {}, defaults, options );
		if ( merged.body && typeof merged.body === 'object' ) {
			merged.body = JSON.stringify( merged.body );
		}
		const res = await fetch( REST_URL + path, merged );
		if ( ! res.ok ) {
			const err = await res.json().catch( () => ( { message: res.statusText } ) );
			throw new Error( err.message || 'Request failed' );
		}
		// Export endpoint returns a Blob (triggers download), not JSON.
		if ( options._isExport ) return res;
		return res.json();
	}

	// ── Tabs ──────────────────────────────────────────────────────────────────
	if ( tabButtons.length ) {
		tabButtons.forEach( ( btn ) => {
			btn.addEventListener( 'click', () => switchTab( btn.dataset.tab ) );
		} );
	}

	function switchTab( tabKey ) {
		tabButtons.forEach( ( btn ) => {
			const isActive = btn.dataset.tab === tabKey;
			btn.classList.toggle( 'active', isActive );
			btn.setAttribute( 'aria-selected', isActive ? 'true' : 'false' );
		} );
		tabPanels.forEach( ( panel ) => {
			const isActive = panel.dataset.tab === tabKey;
			panel.classList.toggle( 'active', isActive );
			panel.hidden = ! isActive;
		} );
	}

	// ── Sets ──────────────────────────────────────────────────────────────────
	async function loadSets() {
		if ( ! setSelect ) return;
		try {
			const sets = await apiFetch( 'sets' );
			const prev = setSelect.value;
			setSelect.innerHTML = '<option value="">— Select a set —</option>';
			sets.forEach( s => {
				const opt = document.createElement( 'option' );
				opt.value       = s.id;
				opt.textContent = s.name + ' (' + s.entry_count + ')';
				setSelect.appendChild( opt );
			} );
			if ( prev ) setSelect.value = prev;
		} catch ( err ) {
			console.error( 'LexiPic: could not load sets', err );
		}
	}

	// Pre-load a set by slug (from shortcode [lexipic set="slug"]).
	const preloadSlug = app.dataset.setSlug;

	async function init() {
		await loadSets();
		if ( preloadSlug ) {
			const opt = $$( 'option', setSelect ).find( o => o.dataset.slug === preloadSlug );
			if ( opt ) {
				setSelect.value = opt.value;
				await switchSet( parseInt( opt.value, 10 ) );
			}
		}
	}

	if ( setSelect ) {
		setSelect.addEventListener( 'change', async () => {
			const id = parseInt( setSelect.value, 10 );
			if ( id ) {
				await switchSet( id );
			} else {
				currentSetId = null;
				renderCards( [] );
				updateSetButtons();
			}
		} );
	}

	async function switchSet( id ) {
		currentSetId = id;
		updateSetButtons();
		const entries = await apiFetch( 'sets/' + id + '/entries' );
		renderCards( entries );
	}

	function updateSetButtons() {
		const has = !! currentSetId;
		if ( exportBtn )    exportBtn.disabled    = ! has;
		if ( deleteSetBtn ) deleteSetBtn.disabled = ! has;
	}

	if ( createSetBtn ) {
		createSetBtn.addEventListener( 'click', async () => {
			const name = setNameInput ? setNameInput.value.trim() : '';
			const lang = setLangSelect ? setLangSelect.value : IME_LANG;
			if ( ! name ) { alert( 'Please enter a set name.' ); return; }
			try {
				const set = await apiFetch( 'sets', { method: 'POST', body: { name, language: lang } } );
				await loadSets();
				setSelect.value = set.id;
				await switchSet( set.id );
				if ( setNameInput ) setNameInput.value = '';
			} catch ( err ) {
				alert( 'Error creating set: ' + err.message );
			}
		} );
	}

	// Delete set.
	if ( deleteSetBtn ) {
		deleteSetBtn.addEventListener( 'click', async () => {
			if ( ! currentSetId ) return;
			if ( ! confirm( 'Delete this entire set and all its entries? This cannot be undone.' ) ) return;
			try {
				await apiFetch( 'sets/' + currentSetId, { method: 'DELETE' } );
				currentSetId = null;
				await loadSets();
				renderCards( [] );
				updateSetButtons();
			} catch ( err ) {
				alert( 'Error deleting set: ' + err.message );
			}
		} );
	}

	// ── Export / Import ───────────────────────────────────────────────────────
	if ( exportBtn ) {
		exportBtn.addEventListener( 'click', async () => {
			if ( ! currentSetId ) return;
			try {
				const url  = REST_URL + 'sets/' + currentSetId + '/export';
				const res  = await fetch( url, { headers: { 'X-WP-Nonce': NONCE } } );
				if ( ! res.ok ) throw new Error( 'Export failed' );
				const blob = await res.blob();
				const disp = res.headers.get( 'Content-Disposition' ) || '';
				const name = ( disp.match( /filename="([^"]+)"/ ) || [] )[ 1 ] || 'lexipic_export.json';
				const a    = document.createElement( 'a' );
				a.href     = URL.createObjectURL( blob );
				a.download = name;
				a.click();
				URL.revokeObjectURL( a.href );
			} catch ( err ) {
				alert( 'Export error: ' + err.message );
			}
		} );
	}

	if ( importInput ) {
		importInput.addEventListener( 'change', async () => {
			const file = importInput.files[ 0 ];
			if ( ! file ) return;
			try {
				const text = await file.text();
				const data = JSON.parse( text );
				const result = await apiFetch( 'import', { method: 'POST', body: data } );
				alert( result.imported + ' entries imported successfully!' );
				await loadSets();
				setSelect.value = result.set_id;
				await switchSet( result.set_id );
			} catch ( err ) {
				alert( 'Import error: ' + err.message );
			}
			importInput.value = '';
		} );
	}

	// ── Image capture ─────────────────────────────────────────────────────────
	if ( imageInput ) {
		imageInput.addEventListener( 'change', () => {
			const file = imageInput.files[ 0 ];
			if ( ! file ) return;
			const reader = new FileReader();
			reader.onload = () => {
				const img    = new Image();
				img.onload   = () => {
					// Scale down so neither dimension exceeds MAX_IMAGE_DIM,
					// preserving aspect ratio. Never scales up.
					const scale = Math.min(
						1,
						MAX_IMAGE_DIM / img.width,
						MAX_IMAGE_DIM / img.height
					);
					const targetW = Math.max( 1, Math.round( img.width  * scale ) );
					const targetH = Math.max( 1, Math.round( img.height * scale ) );

					const canvas = document.createElement( 'canvas' );
					canvas.width  = targetW;
					canvas.height = targetH;
					canvas.getContext( '2d' ).drawImage( img, 0, 0, targetW, targetH );
					const dataUrl = canvas.toDataURL( 'image/jpeg', 0.7 );
					if ( previewContainer ) {
						previewContainer.innerHTML = '<img src="' + dataUrl + '" alt="Preview">';
						previewContainer.classList.add( 'visible' );
					}
				};
				img.src = reader.result;
			};
			reader.readAsDataURL( file );
		} );
	}

	// ── Speech recognition + audio recording ─────────────────────────────────
	const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

	if ( captureAction && SpeechRecognition ) {
		const recognition      = new SpeechRecognition();
		recognition.lang       = SR_LOCALE;
		recognition.continuous = false;
		recognition.interimResults = false;

		captureAction.addEventListener( 'click', async () => {
			try {
				const stream = await navigator.mediaDevices.getUserMedia( { audio: true } );
				mediaRecorder = new MediaRecorder( stream, { mimeType: 'audio/webm' } );
				audioChunks   = [];
				mediaRecorder.ondataavailable = ( e ) => {
					if ( e.data.size > 0 ) audioChunks.push( e.data );
				};
				mediaRecorder.onstop = () => {
					finalAudioBlob = new Blob( audioChunks, { type: 'audio/webm' } );
				};
				mediaRecorder.start();
				recognition.start();
				captureAction.innerHTML = '<i class="fa-solid fa-circle-dot lp-rec-pulse"></i> Listening…';
				captureAction.classList.add( 'lp-active-rec' );
			} catch ( err ) {
				console.error( err );
				alert( 'Microphone access denied. Ensure you are on HTTPS.' );
			}
		} );

		recognition.onresult = ( event ) => {
			const transcript = event.results[ 0 ][ 0 ].transcript;
			if ( scriptInput ) {
				scriptInput.value = transcript.toLowerCase().replace( /\.$/, '' ).trim();
				// Trigger IME reverse transliteration.
				scriptInput.dispatchEvent( new Event( 'input' ) );
			}
			if ( mediaRecorder && mediaRecorder.state !== 'inactive' ) {
				mediaRecorder.stop();
			}
			captureAction.innerHTML = '<i class="fa-solid fa-microphone"></i> Speak';
			captureAction.classList.remove( 'lp-active-rec' );
		};

		recognition.onerror = () => {
			if ( mediaRecorder && mediaRecorder.state !== 'inactive' ) mediaRecorder.stop();
			captureAction.innerHTML = '<i class="fa-solid fa-microphone"></i> Speak';
			captureAction.classList.remove( 'lp-active-rec' );
		};
	} else if ( captureAction ) {
		// Browser does not support SpeechRecognition.
		captureAction.disabled = true;
		captureAction.title    = 'Speech recognition not supported in this browser.';
	}

	// ── IME — transliteration ─────────────────────────────────────────────────
	/**
	 * Partition the CompLing AI snippet hook definitions into the
	 * pre/loop/post buckets bpmTransliterate() expects, filtered by
	 * direction and active flag, and compiled into callable functions.
	 *
	 * @param {string} direction 'forward' | 'reverse'
	 * @return {{pre: Function[], loop: Function[], post: Function[]}}
	 */
	function getHooksForDirection( direction ) {
		const buckets = { pre: [], loop: [], post: [] };
		IME_HOOKS.forEach( ( hook ) => {
			if ( ! hook || hook.is_active === 0 || hook.is_active === false ) return;
			if ( hook.direction !== direction ) return;
			if ( ! hook.js_body || ! buckets[ hook.hook_stage ] ) return;
			try {
				// js_body is a full named function declaration; evaluate it to
				// obtain a reference, then invoke that reference.
				const fn = new Function( hook.js_body + '\nreturn ' + functionNameFromBody( hook.js_body ) + ';' )();
				if ( typeof fn === 'function' ) {
					buckets[ hook.hook_stage ].push( fn );
				}
			} catch ( e ) {
				console.error( 'LexiPic: failed to compile IME hook', hook.snippet_key, e );
			}
		} );
		// Respect declared sort order within each stage.
		Object.keys( buckets ).forEach( ( stage ) => {
			buckets[ stage ].sort( ( a, b ) => {
				const ha = IME_HOOKS.find( h => functionNameFromBody( h.js_body || '' ) === a.name ) || {};
				const hb = IME_HOOKS.find( h => functionNameFromBody( h.js_body || '' ) === b.name ) || {};
				return ( ha.sort_order || 0 ) - ( hb.sort_order || 0 );
			} );
		} );
		return buckets;
	}

	/**
	 * Extract the declared function name from a `function name(...) {...}` body.
	 */
	function functionNameFromBody( body ) {
		const m = /function\s+([A-Za-z0-9_$]+)\s*\(/.exec( body );
		return m ? m[ 1 ] : '';
	}

	// Compile hook buckets once — IME_HOOKS doesn't change at runtime.
	const FORWARD_HOOKS = getHooksForDirection( 'forward' );
	const REVERSE_HOOKS = getHooksForDirection( 'reverse' );

	/**
	 * Run the CompLing AI IME engine in the given direction.
	 * Falls back to returning the input unchanged if the engine
	 * or its maps are unavailable.
	 *
	 * @param {string} text
	 * @param {string} direction 'forward' | 'reverse'
	 * @return {string}
	 */
	function runTranslit( text, direction ) {
		if ( ! text ) return '';
		if ( ! window.CPLAI_ENGINE || typeof CPLAI_ENGINE.bpmTransliterate !== 'function' ) {
			return text;
		}
		if ( ! IME_MAPS || ! IME_MAPS.forward || ! IME_MAPS.reverse ) {
			return text;
		}
		const hooks = direction === 'forward' ? FORWARD_HOOKS : REVERSE_HOOKS;
		try {
			const result = CPLAI_ENGINE.bpmTransliterate(
				text,
				direction,
				IME_MAPS,
				hooks.pre,
				hooks.loop,
				hooks.post,
				{},
				IME_SETTINGS
			);
			return ( result && typeof result.output === 'string' ) ? result.output : text;
		} catch ( e ) {
			console.error( 'LexiPic: IME transliteration error', e );
			return text;
		}
	}

	/**
	 * Script (heritage) text → Roman transliteration.
	 */
	function reverseTranslit( text ) {
		return runTranslit( text, 'reverse' );
	}

	/**
	 * Roman text → Script (heritage) transliteration.
	 */
	function forwardTranslit( text ) {
		return runTranslit( text, 'forward' );
	}

	if ( scriptInput ) {
		scriptInput.addEventListener( 'input', () => {
			if ( romanInput ) romanInput.value = reverseTranslit( scriptInput.value );
		} );
	}

	if ( romanInput ) {
		romanInput.addEventListener( 'input', ( e ) => {
			const pos       = romanInput.selectionStart;
			const converted = forwardTranslit( romanInput.value );
			if ( converted !== romanInput.value ) {
				romanInput.value = converted;
				romanInput.setSelectionRange( pos, pos );
			}
			if ( scriptInput ) scriptInput.value = converted;
		} );
	}

	// ── Save entry ────────────────────────────────────────────────────────────
	if ( saveEntryBtn ) {
		saveEntryBtn.addEventListener( 'click', async () => {
			if ( ! currentSetId ) {
				setStatus( 'Please select or create a set first.', 'error' );
				return;
			}
			const img = $( 'img', previewContainer );
			if ( ! img || ! finalAudioBlob || ! scriptInput.value.trim() ) {
				setStatus( 'Please fill in all fields (image, audio, and word).', 'error' );
				return;
			}

			saveEntryBtn.disabled = true;
			setStatus( 'Saving…', '' );

			try {
				// Convert audio blob to base64.
				const audioB64 = await blobToDataUri( finalAudioBlob );

				const payload = {
					word_script:  scriptInput.value.trim(),
					word_roman:   romanInput   ? romanInput.value.trim()  : '',
					description:  descInput    ? descInput.value.trim()   : '',
					image:        img.src,     // already a data-URI from canvas
					audio:        audioB64,
				};

				await apiFetch( 'sets/' + currentSetId + '/entries', {
					method: 'POST',
					body:   payload,
				} );

				// Reset form.
				scriptInput.value = '';
				if ( romanInput )       romanInput.value       = '';
				if ( descInput )        descInput.value        = '';
				if ( imageInput )       imageInput.value       = '';
				if ( previewContainer ) {
					previewContainer.innerHTML = '';
					previewContainer.classList.remove( 'visible' );
				}
				finalAudioBlob = null;
				setStatus( 'Entry added!', 'success' );

				// Refresh archive.
				const entries = await apiFetch( 'sets/' + currentSetId + '/entries' );
				renderCards( entries );
			} catch ( err ) {
				setStatus( 'Error: ' + err.message, 'error' );
			} finally {
				saveEntryBtn.disabled = false;
			}
		} );
	}

	function setStatus( msg, type ) {
		if ( ! entryStatus ) return;
		entryStatus.textContent  = msg;
		entryStatus.className    = 'lp-status' + ( type ? ' lp-status-' + type : '' );
	}

	function blobToDataUri( blob ) {
		return new Promise( ( resolve, reject ) => {
			const reader  = new FileReader();
			reader.onload = () => resolve( reader.result );
			reader.onerror = reject;
			reader.readAsDataURL( blob );
		} );
	}

	// ── Render archive cards ──────────────────────────────────────────────────
	function renderCards( entries ) {
		if ( ! slider ) return;

		if ( ! entries || entries.length === 0 ) {
			slider.innerHTML = '';
			updateNavButtons();
			return;
		}

		slider.innerHTML = entries.map( ( e ) => {
			const label = e.word_script || e.word_roman || '';
			const sub   = ( e.word_script && e.word_roman ) ? '<small>' + escHtml( e.word_roman ) + '</small>' : '';
			const desc  = e.description ? '<p class="lp-card-desc">' + escHtml( e.description ) + '</p>' : '';
			const imgSrc = e.image_url || '';
			const deleteBtn = CAN_WRITE
				? `<button class="lp-delete-btn" data-id="${ e.id }"
						aria-label="Delete ${ escHtml( label ) }">
						<i class="fa-solid fa-trash-can" aria-hidden="true"></i>
					</button>`
				: '';

			return `
			<div class="lp-card" role="listitem" data-entry-id="${ e.id }">
				<img src="${ escHtml( imgSrc ) }" alt="${ escHtml( label ) }" loading="lazy">
				<div class="lp-script-display">
					${ escHtml( label ) }
					${ sub }
				</div>
				${ desc }
				<div class="lp-card-actions">
					<button class="lp-play-btn" data-audio="${ escHtml( e.audio_url || '' ) }"
						aria-label="Play audio for ${ escHtml( label ) }">
						<i class="fa-solid fa-volume-high" aria-hidden="true"></i>
					</button>
					${ deleteBtn }
				</div>
			</div>`;
		} ).join( '' );

		// Attach play / delete handlers.
		$$( '.lp-play-btn', slider ).forEach( btn => {
			btn.addEventListener( 'click', () => {
				const url = btn.dataset.audio;
				if ( url ) new Audio( url ).play().catch( () => {} );
			} );
		} );

		$$( '.lp-delete-btn', slider ).forEach( btn => {
			btn.addEventListener( 'click', async () => {
				const id = parseInt( btn.dataset.id, 10 );
				if ( ! confirm( 'Delete this entry?' ) ) return;
				try {
					await apiFetch( 'entries/' + id, { method: 'DELETE' } );
					const entries = await apiFetch( 'sets/' + currentSetId + '/entries' );
					renderCards( entries );
					// Refresh set count in selector.
					await loadSets();
					setSelect.value = currentSetId;
				} catch ( err ) {
					alert( 'Delete error: ' + err.message );
				}
			} );
		} );

		updateNavButtons();
	}

	// ── Slider nav ────────────────────────────────────────────────────────────
	function cardWidth() {
		const card = slider ? $( '.lp-card', slider ) : null;
		if ( ! card ) return 0;
		const gap = parseInt( window.getComputedStyle( slider ).gap ) || 0;
		return card.offsetWidth + gap;
	}

	if ( nextBtn ) nextBtn.addEventListener( 'click', () => slider.scrollBy( { left: cardWidth(), behavior: 'smooth' } ) );
	if ( prevBtn ) prevBtn.addEventListener( 'click', () => slider.scrollBy( { left: -cardWidth(), behavior: 'smooth' } ) );
	if ( slider )  slider.addEventListener( 'scroll', updateNavButtons );

	function updateNavButtons() {
		if ( ! slider ) return;
		const atStart = slider.scrollLeft <= 5;
		const atEnd   = slider.scrollLeft >= slider.scrollWidth - slider.clientWidth - 5;
		if ( prevBtn ) prevBtn.style.display = atStart ? 'none' : 'flex';
		if ( nextBtn ) nextBtn.style.display = atEnd   ? 'none' : 'flex';
	}

	// ── Utility ───────────────────────────────────────────────────────────────
	function escHtml( str ) {
		return String( str )
			.replace( /&/g,  '&amp;'  )
			.replace( /</g,  '&lt;'   )
			.replace( />/g,  '&gt;'   )
			.replace( /"/g,  '&quot;' )
			.replace( /'/g,  '&#039;' );
	}

	// ── Boot ──────────────────────────────────────────────────────────────────
	init();

} )();
