<?php
/**
 * LexiPic — Admin Settings Page.
 *
 * Registers the top-level admin menu and the settings form.
 * Settings stored in WP option: lexipic_settings (array).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Register menu ─────────────────────────────────────────────────────────────
add_action( 'admin_menu', 'lexipic_admin_menu' );
function lexipic_admin_menu() {
	add_menu_page(
		__( 'LexiPic', 'lexipic' ),
		__( 'LexiPic', 'lexipic' ),
		'read',                     // Any logged-in user can access.
		'lexipic',
		'lexipic_settings_page',
		'dashicons-microphone',
		30
	);

	add_submenu_page(
		'lexipic',
		__( 'Settings', 'lexipic' ),
		__( 'Settings', 'lexipic' ),
		'manage_options',
		'lexipic',
		'lexipic_settings_page'
	);
}

// ── Register settings ─────────────────────────────────────────────────────────
add_action( 'admin_init', 'lexipic_register_settings' );
function lexipic_register_settings() {
	register_setting(
		'lexipic_settings_group',
		'lexipic_settings',
		array(
			'sanitize_callback' => 'lexipic_sanitize_settings',
			'default'           => array(
				'language'    => 'bpm',
				'public_view' => 0,
			),
		)
	);

	add_settings_section(
		'lexipic_general',
		__( 'General Settings', 'lexipic' ),
		null,
		'lexipic'
	);

	add_settings_field(
		'lexipic_language',
		__( 'Default Language', 'lexipic' ),
		'lexipic_field_language',
		'lexipic',
		'lexipic_general'
	);

	add_settings_field(
		'lexipic_public_view',
		__( 'Public Archive', 'lexipic' ),
		'lexipic_field_public_view',
		'lexipic',
		'lexipic_general'
	);
}

function lexipic_sanitize_settings( $input ) {
	$clean = array();
	$allowed_langs = array( 'as', 'bn', 'bpm' );
	$clean['language']    = in_array( $input['language'] ?? 'bpm', $allowed_langs, true ) ? $input['language'] : 'bpm';
	$clean['public_view'] = ! empty( $input['public_view'] ) ? 1 : 0;
	return $clean;
}

function lexipic_field_language() {
	$options  = get_option( 'lexipic_settings', array() );
	$current  = $options['language'] ?? 'bpm';
	$langs    = array(
		'bpm' => __( 'Bishnupriya Manipuri (ইমার ঠার)', 'lexipic' ),
		'as'  => __( 'Assamese (অসমীয়া)', 'lexipic' ),
		'bn'  => __( 'Bengali (বাংলা)', 'lexipic' ),
	);
	echo '<select name="lexipic_settings[language]">';
	foreach ( $langs as $code => $label ) {
		printf(
			'<option value="%s"%s>%s</option>',
			esc_attr( $code ),
			selected( $current, $code, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Sets the speech recognition locale and IME behaviour for all users.', 'lexipic' ) . '</p>';
}

function lexipic_field_public_view() {
	$options = get_option( 'lexipic_settings', array() );
	$checked = ! empty( $options['public_view'] );
	echo '<label>';
	echo '<input type="checkbox" name="lexipic_settings[public_view]" value="1"' . checked( $checked, true, false ) . '>';
	echo ' ' . esc_html__( 'Allow non-logged-in visitors to view the archive (read-only)', 'lexipic' );
	echo '</label>';
}

// ── Page render ───────────────────────────────────────────────────────────────
function lexipic_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Access denied.', 'lexipic' ) );
	}

	// FFmpeg status badge.
	$ffmpeg_ok = Lexipic_Audio_Converter::is_available();
	$badge_cls = $ffmpeg_ok ? 'notice-success' : 'notice-warning';
	$badge_msg = $ffmpeg_ok
		? __( '✔ FFmpeg detected — audio will be automatically converted to MP3.', 'lexipic' )
		: __( '⚠ FFmpeg not detected — audio will be stored as .webm (may not play on Safari/iOS).', 'lexipic' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'LexiPic Settings', 'lexipic' ); ?></h1>

		<div class="notice <?php echo esc_attr( $badge_cls ); ?> inline" style="padding:8px 12px;">
			<p><?php echo esc_html( $badge_msg ); ?></p>
		</div>

		<form method="post" action="options.php" style="margin-top:20px;">
			<?php
			settings_fields( 'lexipic_settings_group' );
			do_settings_sections( 'lexipic' );
			submit_button();
			?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Plugin Status', 'lexipic' ); ?></h2>
		<table class="widefat striped" style="max-width:600px;">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Upload Directory', 'lexipic' ); ?></td>
					<td>
						<?php
						if ( file_exists( LEXIPIC_UPLOAD_DIR ) && is_writable( LEXIPIC_UPLOAD_DIR ) ) {
							echo '<span style="color:green;">✔ ' . esc_html( LEXIPIC_UPLOAD_DIR ) . '</span>';
						} else {
							echo '<span style="color:red;">✘ ' . esc_html( LEXIPIC_UPLOAD_DIR ) . ' — not writable</span>';
						}
						?>
					</td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'FFmpeg', 'lexipic' ); ?></td>
					<td>
						<?php echo $ffmpeg_ok
							? '<span style="color:green;">✔ Available</span>'
							: '<span style="color:#856404;">⚠ Not available (webm fallback active)</span>';
						?>
					</td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'REST API Base', 'lexipic' ); ?></td>
					<td><code><?php echo esc_html( rest_url( 'lexipic/v1/' ) ); ?></code></td>
				</tr>
			</tbody>
		</table>
	</div>
	<?php
}
