<?php
/**
 * LexiPic — Front-end app template.
 * Included by lexipic_render_shortcode() via ob_start().
 * $atts['set'] may pre-load a specific set slug.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
$is_logged_in = is_user_logged_in();
?>
<div id="lexipic-app" class="lexipic-wrap" data-set-slug="<?php echo esc_attr( $atts['set'] ?? '' ); ?>">

	<!-- ── TOP ACCORDION (controls) ──────────────────────────────────────── -->
	<div class="lp-top-accordion">
		<div class="lp-accordion-header" id="lp-accordion-toggle" tabindex="0" role="button" aria-expanded="false">
			<h1 class="lp-title">LexiPic</h1>
			<i class="fa-solid fa-chevron-down" aria-hidden="true"></i>
		</div>
		<div class="lp-accordion-body" id="lp-accordion-body">

			<?php if ( $is_logged_in ) : ?>
			<!-- Set selector / creator -->
			<div class="lp-set-bar">
				<select id="lp-set-select" aria-label="<?php esc_attr_e( 'Select a word set', 'lexipic' ); ?>">
					<option value=""><?php esc_html_e( '— Select a set —', 'lexipic' ); ?></option>
				</select>
				<button id="lp-new-set-btn" class="lp-util-btn" type="button">
					<i class="fa-solid fa-folder-plus" aria-hidden="true"></i>
					<?php esc_html_e( 'New Set', 'lexipic' ); ?>
				</button>
			</div>

			<!-- New set modal (inline) -->
			<div id="lp-new-set-panel" class="lp-panel" hidden>
				<input type="text" id="lp-set-name" placeholder="<?php esc_attr_e( 'Set name e.g. Domestic Animals', 'lexipic' ); ?>">
				<select id="lp-set-language" aria-label="<?php esc_attr_e( 'Language', 'lexipic' ); ?>">
					<option value="bpm"><?php esc_html_e( 'Bishnupriya Manipuri', 'lexipic' ); ?></option>
					<option value="as"><?php esc_html_e( 'Assamese', 'lexipic' ); ?></option>
					<option value="bn"><?php esc_html_e( 'Bengali', 'lexipic' ); ?></option>
				</select>
				<button id="lp-create-set-btn" class="lp-save-btn" type="button">
					<?php esc_html_e( 'Create Set', 'lexipic' ); ?>
				</button>
			</div>

			<!-- Data controls -->
			<div class="lp-data-controls">
				<button id="lp-export-btn" class="lp-util-btn" type="button" disabled>
					<i class="fa-solid fa-file-arrow-down" aria-hidden="true"></i>
					<?php esc_html_e( 'Save to Disk', 'lexipic' ); ?>
				</button>
				<label class="lp-util-btn">
					<i class="fa-solid fa-file-arrow-up" aria-hidden="true"></i>
					<?php esc_html_e( 'Load from Disk', 'lexipic' ); ?>
					<input type="file" id="lp-import-input" accept=".json" hidden>
				</label>
				<button id="lp-delete-set-btn" class="lp-util-btn lp-danger" type="button" disabled>
					<i class="fa-solid fa-trash" aria-hidden="true"></i>
					<?php esc_html_e( 'Delete Set', 'lexipic' ); ?>
				</button>
			</div>

			<!-- Add entry form -->
			<div class="lp-new-entry">
				<h4><?php esc_html_e( 'Add New Entry', 'lexipic' ); ?></h4>
				<hr>
				<section class="lp-creator-card">
					<div class="lp-control-group">
						<input type="file" id="lp-image-input" accept="image/*"
							aria-label="<?php esc_attr_e( 'Upload image', 'lexipic' ); ?>">
						<button id="lp-capture-action" class="lp-primary-btn" type="button">
							<i class="fa-solid fa-microphone" aria-hidden="true"></i>
							<?php esc_html_e( 'Speak', 'lexipic' ); ?>
						</button>
					</div>
					<div id="lp-preview-container"></div>
					<div class="lp-control-group">
						<input type="text" id="lp-script-input"
							placeholder="<?php esc_attr_e( 'Heritage word (script)', 'lexipic' ); ?>"
							dir="auto" autocomplete="off">
						<input type="text" id="lp-roman-input"
							placeholder="<?php esc_attr_e( 'Roman transliteration', 'lexipic' ); ?>"
							autocomplete="off">
					</div>
					<input type="text" id="lp-description-input"
						placeholder="<?php esc_attr_e( 'Description (optional)', 'lexipic' ); ?>">
					<p id="lp-entry-status" class="lp-status" aria-live="polite"></p>
					<button id="lp-save-entry-btn" class="lp-save-btn" type="button">
						<?php esc_html_e( 'Add to Archive', 'lexipic' ); ?>
					</button>
				</section>
			</div>
			<?php else : ?>
			<p class="lp-login-notice">
				<?php
				printf(
					/* translators: login URL */
					wp_kses(
						__( '<a href="%s">Log in</a> to create or manage word sets.', 'lexipic' ),
						array( 'a' => array( 'href' => array() ) )
					),
					esc_url( wp_login_url( get_permalink() ) )
				);
				?>
			</p>
			<?php endif; ?>

		</div><!-- /lp-accordion-body -->
	</div><!-- /lp-top-accordion -->

	<!-- ── ARCHIVE SLIDER ────────────────────────────────────────────────── -->
	<div class="lp-app-container">
		<div class="lp-slider-wrapper">
			<button id="lp-prev-btn" class="lp-nav-btn lp-prev" type="button" aria-label="<?php esc_attr_e( 'Previous', 'lexipic' ); ?>">&#10094;</button>
			<div id="lp-archive-slider" class="lp-slider-container" role="list" aria-label="<?php esc_attr_e( 'Word archive', 'lexipic' ); ?>">
				<!-- Cards injected by JS -->
			</div>
			<button id="lp-next-btn" class="lp-nav-btn lp-next" type="button" aria-label="<?php esc_attr_e( 'Next', 'lexipic' ); ?>">&#10095;</button>
		</div>
	</div>

</div><!-- /#lexipic-app -->
