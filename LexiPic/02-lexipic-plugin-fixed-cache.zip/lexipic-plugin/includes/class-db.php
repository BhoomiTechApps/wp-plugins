<?php
/**
 * Database layer for LexiPic.
 *
 * Tables:
 *   wp_lexipic_sets     – word set metadata
 *   wp_lexipic_entries  – individual word entries (image stored as MEDIUMBLOB)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lexipic_DB {

	// ── Table names ───────────────────────────────────────────────────────────

	public static function sets_table() {
		global $wpdb;
		return $wpdb->prefix . 'lexipic_sets';
	}

	public static function entries_table() {
		global $wpdb;
		return $wpdb->prefix . 'lexipic_entries';
	}

	// ── Schema ────────────────────────────────────────────────────────────────

	public static function create_tables() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$sql_sets = "CREATE TABLE IF NOT EXISTS " . self::sets_table() . " (
			id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			name        VARCHAR(255)        NOT NULL,
			slug        VARCHAR(255)        NOT NULL,
			language    VARCHAR(10)         NOT NULL DEFAULT 'bpm',
			created_by  BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug)
		) $charset_collate;";

		$sql_entries = "CREATE TABLE IF NOT EXISTS " . self::entries_table() . " (
			id               BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			set_id           BIGINT(20) UNSIGNED NOT NULL,
			word_script      VARCHAR(500)        NOT NULL DEFAULT '',
			word_roman       VARCHAR(500)        NOT NULL DEFAULT '',
			description      TEXT                         DEFAULT NULL,
			image_data       MEDIUMBLOB                   DEFAULT NULL,
			image_mime       VARCHAR(50)                  DEFAULT NULL,
			audio_path       VARCHAR(500)                 DEFAULT NULL,
			audio_mime       VARCHAR(50)                  DEFAULT NULL,
			created_at       DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY set_id (set_id)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql_sets );
		dbDelta( $sql_entries );
	}

	// ── Sets ──────────────────────────────────────────────────────────────────

	/**
	 * Create a new set. Returns new set ID or WP_Error.
	 */
	public static function create_set( $name, $language = 'bpm', $user_id = 0 ) {
		global $wpdb;
		$slug = self::unique_slug( sanitize_title( $name ) );

		$result = $wpdb->insert(
			self::sets_table(),
			array(
				'name'       => sanitize_text_field( $name ),
				'slug'       => $slug,
				'language'   => sanitize_key( $language ),
				'created_by' => absint( $user_id ),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%d', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error( 'db_error', $wpdb->last_error );
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Get all sets, newest first.
	 */
	public static function get_sets( $user_id = 0 ) {
		global $wpdb;
		if ( $user_id ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM " . self::sets_table() . " WHERE created_by = %d ORDER BY created_at DESC",
					$user_id
				)
			);
		}
		return $wpdb->get_results(
			"SELECT * FROM " . self::sets_table() . " ORDER BY created_at DESC"
		);
	}

	/**
	 * Get a single set by ID.
	 */
	public static function get_set( $set_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM " . self::sets_table() . " WHERE id = %d",
				$set_id
			)
		);
	}

	/**
	 * Delete a set and all its entries.
	 */
	public static function delete_set( $set_id ) {
		global $wpdb;
		// First delete all audio files for entries in this set.
		$entries = self::get_entries( $set_id );
		foreach ( $entries as $entry ) {
			if ( $entry->audio_path && file_exists( $entry->audio_path ) ) {
				@unlink( $entry->audio_path );
			}
		}
		$wpdb->delete( self::entries_table(), array( 'set_id' => $set_id ), array( '%d' ) );
		$wpdb->delete( self::sets_table(),   array( 'id'     => $set_id ), array( '%d' ) );
	}

	// ── Entries ───────────────────────────────────────────────────────────────

	/**
	 * Save a new entry. $data keys:
	 *   set_id, word_script, word_roman, description,
	 *   image_data (binary), image_mime, audio_path, audio_mime
	 *
	 * Returns new entry ID or WP_Error.
	 */
	public static function create_entry( $data ) {
		global $wpdb;

		$result = $wpdb->insert(
			self::entries_table(),
			array(
				'set_id'      => absint( $data['set_id'] ),
				'word_script' => sanitize_text_field( $data['word_script'] ?? '' ),
				'word_roman'  => sanitize_text_field( $data['word_roman']  ?? '' ),
				'description' => sanitize_textarea_field( $data['description'] ?? '' ),
				'image_data'  => $data['image_data'] ?? null,
				'image_mime'  => sanitize_mime_type( $data['image_mime'] ?? 'image/jpeg' ),
				'audio_path'  => $data['audio_path'] ?? null,
				'audio_mime'  => sanitize_mime_type( $data['audio_mime'] ?? 'audio/webm' ),
				'created_at'  => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			return new WP_Error( 'db_error', $wpdb->last_error );
		}
		return (int) $wpdb->insert_id;
	}

	/**
	 * Get all entries for a set (without image_data blob to keep queries fast).
	 */
	public static function get_entries( $set_id ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, set_id, word_script, word_roman, description,
				        image_mime, audio_path, audio_mime, created_at
				 FROM " . self::entries_table() . "
				 WHERE set_id = %d
				 ORDER BY created_at ASC",
				$set_id
			)
		);
	}

	/**
	 * Get a single entry WITH its image blob (used for serving the image).
	 */
	public static function get_entry( $entry_id ) {
		global $wpdb;
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM " . self::entries_table() . " WHERE id = %d",
				$entry_id
			)
		);
	}

	/**
	 * Delete a single entry and its audio file.
	 */
	public static function delete_entry( $entry_id ) {
		global $wpdb;
		$entry = self::get_entry( $entry_id );
		if ( $entry && $entry->audio_path && file_exists( $entry->audio_path ) ) {
			@unlink( $entry->audio_path );
		}
		$wpdb->delete( self::entries_table(), array( 'id' => $entry_id ), array( '%d' ) );
	}

	/**
	 * Update audio path and mime on an existing entry (used after FFmpeg conversion).
	 */
	public static function update_audio( $entry_id, $audio_path, $audio_mime ) {
		global $wpdb;
		$wpdb->update(
			self::entries_table(),
			array(
				'audio_path' => $audio_path,
				'audio_mime' => $audio_mime,
			),
			array( 'id' => $entry_id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Count entries for a set.
	 */
	public static function count_entries( $set_id ) {
		global $wpdb;
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM " . self::entries_table() . " WHERE set_id = %d",
				$set_id
			)
		);
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private static function unique_slug( $base ) {
		global $wpdb;
		$slug    = $base;
		$counter = 1;
		while ( $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM " . self::sets_table() . " WHERE slug = %s", $slug
		) ) ) {
			$slug = $base . '-' . $counter++;
		}
		return $slug;
	}
}
