<?php
/**
 * Audio Converter for LexiPic.
 *
 * Attempts to convert .webm audio to .mp3 via FFmpeg as a WP background action.
 * Silently skips if FFmpeg is not available on the server.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lexipic_Audio_Converter {

	const CRON_HOOK = 'lexipic_convert_audio';

	// ── FFmpeg detection ──────────────────────────────────────────────────────

	/**
	 * Check if FFmpeg is available on the server.
	 * Result is cached in a transient for 1 hour.
	 */
	public static function is_available() {
		$cached = get_transient( 'lexipic_ffmpeg_available' );
		if ( $cached !== false ) {
			return (bool) $cached;
		}

		$available = false;
		if ( function_exists( 'exec' ) ) {
			$output = array();
			$return = 0;
			@exec( 'ffmpeg -version 2>&1', $output, $return );
			$available = ( $return === 0 && ! empty( $output ) );
		}

		set_transient( 'lexipic_ffmpeg_available', $available ? '1' : '0', HOUR_IN_SECONDS );
		return $available;
	}

	// ── Schedule & Run ────────────────────────────────────────────────────────

	/**
	 * Schedule a single background conversion event for an entry.
	 *
	 * @param int    $entry_id
	 * @param string $webm_path  Absolute path to the .webm file.
	 */
	public static function schedule_conversion( $entry_id, $webm_path ) {
		if ( ! self::is_available() ) {
			return;
		}
		if ( pathinfo( $webm_path, PATHINFO_EXTENSION ) === 'mp3' ) {
			return; // Already mp3, nothing to do.
		}
		wp_schedule_single_event(
			time() + 5, // 5 seconds from now.
			self::CRON_HOOK,
			array( $entry_id, $webm_path )
		);
	}

	/**
	 * Perform the actual FFmpeg conversion. Hooked to the cron event.
	 *
	 * @param int    $entry_id
	 * @param string $webm_path
	 */
	public static function convert( $entry_id, $webm_path ) {
		if ( ! self::is_available() ) {
			return;
		}
		if ( ! file_exists( $webm_path ) ) {
			return;
		}

		$mp3_path = preg_replace( '/\.\w+$/', '.mp3', $webm_path );

		$cmd    = sprintf(
			'ffmpeg -i %s -vn -ar 44100 -ac 1 -b:a 64k %s 2>&1',
			escapeshellarg( $webm_path ),
			escapeshellarg( $mp3_path )
		);
		$output = array();
		$return = 0;
		@exec( $cmd, $output, $return );

		if ( $return === 0 && file_exists( $mp3_path ) ) {
			// Update DB with new path.
			Lexipic_DB::update_audio( $entry_id, $mp3_path, 'audio/mpeg' );
			// Delete the original webm to save space.
			@unlink( $webm_path );
		}
		// If conversion fails, the original .webm stays and is used for playback.
	}

	// ── Hook registration ─────────────────────────────────────────────────────

	public static function register_hooks() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'convert' ), 10, 2 );
	}
}

Lexipic_Audio_Converter::register_hooks();
