<?php
/**
 * File Handler for LexiPic.
 *
 * Handles:
 *  - Decoding base64 image data → binary for DB storage.
 *  - Saving audio blobs to wp-content/uploads/lexipic/.
 *  - Packaging entries into the export JSON format.
 *  - Importing entries from a JSON backup.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Lexipic_File_Handler {

	// ── Image ─────────────────────────────────────────────────────────────────

	/**
	 * Strip the data-URI header and return raw binary + MIME type.
	 *
	 * @param  string $data_uri  e.g. "data:image/jpeg;base64,/9j/4AAQ…"
	 * @return array|WP_Error    { 'binary' => string, 'mime' => string }
	 */
	public static function decode_image( $data_uri ) {
		if ( strpos( $data_uri, 'data:' ) !== 0 ) {
			return new WP_Error( 'invalid_image', 'Not a data URI.' );
		}

		// data:<mime>;base64,<data>
		$parts = explode( ',', $data_uri, 2 );
		if ( count( $parts ) !== 2 ) {
			return new WP_Error( 'invalid_image', 'Malformed data URI.' );
		}

		$header = $parts[0]; // "data:image/jpeg;base64"
		$b64    = $parts[1];

		preg_match( '/data:([^;]+)/', $header, $m );
		$mime   = isset( $m[1] ) ? $m[1] : 'image/jpeg';
		$binary = base64_decode( $b64 );

		if ( $binary === false ) {
			return new WP_Error( 'invalid_image', 'Base64 decode failed.' );
		}

		return array( 'binary' => $binary, 'mime' => $mime );
	}

	// ── Audio ─────────────────────────────────────────────────────────────────

	/**
	 * Save audio from a base64 data-URI to the uploads/lexipic/ directory.
	 *
	 * @param  string $data_uri   Base64 audio data URI.
	 * @param  int    $entry_id   Used to generate a unique filename.
	 * @return array|WP_Error     { 'path' => abs path, 'url' => public URL, 'mime' => string }
	 */
	public static function save_audio( $data_uri, $entry_id ) {
		if ( strpos( $data_uri, 'data:' ) !== 0 ) {
			return new WP_Error( 'invalid_audio', 'Not a data URI.' );
		}

		$parts = explode( ',', $data_uri, 2 );
		if ( count( $parts ) !== 2 ) {
			return new WP_Error( 'invalid_audio', 'Malformed data URI.' );
		}

		$header = $parts[0];
		$b64    = $parts[1];

		preg_match( '/data:([^;]+)/', $header, $m );
		$mime = isset( $m[1] ) ? $m[1] : 'audio/webm';
		$ext  = ( $mime === 'audio/mp4' || $mime === 'audio/mpeg' ) ? 'mp4' : 'webm';

		$binary = base64_decode( $b64 );
		if ( $binary === false ) {
			return new WP_Error( 'invalid_audio', 'Base64 decode failed.' );
		}

		// Ensure upload directory exists.
		if ( ! file_exists( LEXIPIC_UPLOAD_DIR ) ) {
			wp_mkdir_p( LEXIPIC_UPLOAD_DIR );
		}

		$filename = 'audio_' . $entry_id . '_' . time() . '.' . $ext;
		$filepath = LEXIPIC_UPLOAD_DIR . '/' . $filename;
		$fileurl  = LEXIPIC_UPLOAD_URL . '/' . $filename;

		$bytes = file_put_contents( $filepath, $binary );
		if ( $bytes === false ) {
			return new WP_Error( 'write_error', 'Could not write audio file.' );
		}

		return array(
			'path' => $filepath,
			'url'  => $fileurl,
			'mime' => $mime,
		);
	}

	/**
	 * Return a base64 data-URI from a saved audio file path.
	 */
	public static function audio_to_data_uri( $path, $mime ) {
		if ( ! file_exists( $path ) ) {
			return '';
		}
		return 'data:' . $mime . ';base64,' . base64_encode( file_get_contents( $path ) );
	}

	/**
	 * Return a base64 data-URI from stored image binary + mime.
	 */
	public static function image_to_data_uri( $binary, $mime ) {
		return 'data:' . $mime . ';base64,' . base64_encode( $binary );
	}

	// ── Export JSON ───────────────────────────────────────────────────────────

	/**
	 * Build the portable JSON export array for a set.
	 * Each entry has base64 image + base64 audio so the file is self-contained.
	 *
	 * @param  int    $set_id
	 * @return array  Associative array ready for json_encode.
	 */
	public static function build_export( $set_id ) {
		$set     = Lexipic_DB::get_set( $set_id );
		$entries = Lexipic_DB::get_entries( $set_id );

		$export = array(
			'lexipic_version' => LEXIPIC_VERSION,
			'set'             => array(
				'name'     => $set->name,
				'slug'     => $set->slug,
				'language' => $set->language,
			),
			'entries'         => array(),
		);

		foreach ( $entries as $e ) {
			// Fetch full row (with image blob) for export.
			$full = Lexipic_DB::get_entry( $e->id );

			$image_uri = $full->image_data
				? self::image_to_data_uri( $full->image_data, $full->image_mime )
				: '';

			$audio_uri = ( $full->audio_path && file_exists( $full->audio_path ) )
				? self::audio_to_data_uri( $full->audio_path, $full->audio_mime )
				: '';

			$export['entries'][] = array(
				'id'             => $full->id,
				'word_script'    => $full->word_script,
				'word_roman'     => $full->word_roman,
				'description'    => $full->description,
				'image'          => $image_uri,
				'audio'          => $audio_uri,
				'image_mime'     => $full->image_mime,
				'audio_mime'     => $full->audio_mime,
			);
		}

		return $export;
	}

	// ── Import JSON ───────────────────────────────────────────────────────────

	/**
	 * Import a JSON export array into the database.
	 * Creates a new set; entries are inserted fresh (IDs not preserved).
	 *
	 * @param  array       $data       Decoded JSON as PHP array.
	 * @param  int         $user_id    WP user ID of the importer.
	 * @return array|WP_Error          { 'set_id', 'imported' count }
	 */
	public static function import_json( $data, $user_id = 0 ) {
		// Support both old PWA format (flat array) and new plugin format (with 'set' key).
		if ( isset( $data['set'] ) ) {
			$set_name = sanitize_text_field( $data['set']['name'] );
			$language = sanitize_key( $data['set']['language'] ?? 'bpm' );
			$entries  = $data['entries'] ?? array();
		} else {
			// Legacy PWA flat-array format.
			$set_name = 'Imported Set ' . date( 'Y-m-d H:i' );
			$language = 'bpm';
			$entries  = $data;
		}

		$set_id = Lexipic_DB::create_set( $set_name, $language, $user_id );
		if ( is_wp_error( $set_id ) ) {
			return $set_id;
		}

		$imported = 0;
		foreach ( $entries as $e ) {
			// Map old PWA keys → new keys.
			$word_script = $e['word_script']    ?? ( $e['heritage']         ?? '' );
			$word_roman  = $e['word_roman']      ?? ( $e['transliteration'] ?? '' );
			$description = $e['description']    ?? '';
			$image_uri   = $e['image']          ?? '';
			$audio_uri   = $e['audio']          ?? '';

			// Decode image to binary for DB.
			$image_data  = null;
			$image_mime  = 'image/jpeg';
			if ( $image_uri ) {
				$img = self::decode_image( $image_uri );
				if ( ! is_wp_error( $img ) ) {
					$image_data = $img['binary'];
					$image_mime = $img['mime'];
				}
			}

			// Insert entry first to get an ID for the audio filename.
			$entry_id = Lexipic_DB::create_entry( array(
				'set_id'      => $set_id,
				'word_script' => $word_script,
				'word_roman'  => $word_roman,
				'description' => $description,
				'image_data'  => $image_data,
				'image_mime'  => $image_mime,
				'audio_path'  => null,
				'audio_mime'  => 'audio/webm',
			) );

			if ( is_wp_error( $entry_id ) ) {
				continue;
			}

			// Save audio file.
			if ( $audio_uri ) {
				$audio = self::save_audio( $audio_uri, $entry_id );
				if ( ! is_wp_error( $audio ) ) {
					Lexipic_DB::update_audio( $entry_id, $audio['path'], $audio['mime'] );
					// Schedule background mp3 conversion.
					Lexipic_Audio_Converter::schedule_conversion( $entry_id, $audio['path'] );
				}
			}

			$imported++;
		}

		return array( 'set_id' => $set_id, 'imported' => $imported );
	}
}
