<?php
/**
 * LexiPic — Front-end app template.
 * Included by lexipic_render_shortcode() via ob_start().
 * $atts['set'] may pre-load a specific set slug.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$options          = get_option( 'lexipic_settings', array() );
$is_logged_in     = is_user_logged_in();
$is_admin         = current_user_can( 'manage_options' );
$current_user_id  = get_current_user_id();
$is_public_view   = ! empty( $options['public_view'] );
$can_view_archive = $is_logged_in || $is_public_view;

// ── Tab access control (lexipic_settings['tab_access']) ─────────────────────
$tab_access    = $options['tab_access'] ?? array();
$add_entry_ids = array_map( 'absint', (array) ( $tab_access['add_entry'] ?? array() ) );
$sets_ids      = array_map( 'absint', (array) ( $tab_access['sets'] ?? array() ) );

$can_add_entry   = $is_logged_in && ( $is_admin || in_array( $current_user_id, $add_entry_ids, true ) );
$can_manage_sets = $is_logged_in && ( $is_admin || in_array( $current_user_id, $sets_ids, true ) );

// Build the list of visible tabs in display order.
$tabs = array(
	'archive' => array(
		'label' => __( 'Archive', 'lexipic' ),
		'icon'  => 'fa-images',
	),
);
if ( $can_add_entry ) {
	$tabs['add-entry'] = array(
		'label' => __( 'Add Entry', 'lexipic' ),
		'icon'  => 'fa-circle-plus',
	);
}
if ( $can_manage_sets ) {
	$tabs['sets'] = array(
		'label' => __( 'Sets', 'lexipic' ),
		'icon'  => 'fa-folder-open',
	);
}
$show_tab_nav = count( $tabs ) > 1;
?>
<div id="lexipic-app" class="lexipic-wrap" data-set-slug="<?php echo esc_attr( $atts['set'] ?? '' ); ?>">

	<!-- ── HEADER + PERSISTENT SET SELECTOR ─────────────────────────────── -->
	<div class="lp-app-header">
		<h1 class="lp-title">LexiPic</h1>

		<?php if ( $can_view_archive ) : ?>
		<div class="lp-set-bar">
			<i class="fa-solid fa-folder-tree lp-set-bar-icon" aria-hidden="true"></i>
			<select id="lp-set-select" aria-label="<?php esc_attr_e( 'Select a word set', 'lexipic' ); ?>">
				<option value=""><?php esc_html_e( '— Select a set —', 'lexipic' ); ?></option>
			</select>
		</div>
		<?php endif; ?>
	</div>

	<!-- ── TABS ─────────────────────────────────────────────────────────── -->
	<?php if ( $show_tab_nav ) : ?>
	<div class="lp-tabs" role="tablist" aria-label="<?php esc_attr_e( 'LexiPic sections', 'lexipic' ); ?>">
		<?php
		$first = true;
		foreach ( $tabs as $tab_key => $tab ) :
			?>
			<button type="button"
				class="lp-tab-btn<?php echo $first ? ' active' : ''; ?>"
				role="tab"
				data-tab="<?php echo esc_attr( $tab_key ); ?>"
				aria-selected="<?php echo $first ? 'true' : 'false'; ?>">
				<i class="fa-solid <?php echo esc_attr( $tab['icon'] ); ?>" aria-hidden="true"></i>
				<span><?php echo esc_html( $tab['label'] ); ?></span>
			</button>
			<?php
			$first = false;
		endforeach;
		?>
	</div>
	<?php endif; ?>

	<!-- ── TAB PANELS ───────────────────────────────────────────────────── -->
	<div class="lp-tab-panels">

		<!-- Archive: browse / view entries ──────────────────────────────── -->
		<div class="lp-tab-panel active" data-tab="archive" role="tabpanel">
			<?php if ( ! $can_view_archive ) : ?>
				<p class="lp-login-notice">
					<?php
					printf(
						/* translators: login URL */
						wp_kses(
							__( '<a href="%s">Log in</a> to view the heritage language archive.', 'lexipic' ),
							array( 'a' => array( 'href' => array() ) )
						),
						esc_url( wp_login_url( get_permalink() ) )
					);
					?>
				</p>
			<?php else : ?>
				<div class="lp-app-container">
					<div class="lp-slider-wrapper">
						<button id="lp-prev-btn" class="lp-nav-btn lp-prev" type="button" aria-label="<?php esc_attr_e( 'Previous', 'lexipic' ); ?>">&#10094;</button>
						<div id="lp-archive-slider" class="lp-slider-container" role="list" aria-label="<?php esc_attr_e( 'Word archive', 'lexipic' ); ?>">
							<!-- Cards injected by JS -->
						</div>
						<button id="lp-next-btn" class="lp-nav-btn lp-next" type="button" aria-label="<?php esc_attr_e( 'Next', 'lexipic' ); ?>">&#10095;</button>
					</div>
				</div>
			<?php endif; ?>
		</div>

		<!-- Add Entry: capture form ───────────────────────────────────────── -->
		<?php if ( $can_add_entry ) : ?>
		<div class="lp-tab-panel" data-tab="add-entry" role="tabpanel" hidden>
			<section class="lp-creator-card">
				<div class="lp-control-group">
					<input type="file" id="lp-image-input" accept="image/*"
						aria-label="<?php esc_attr_e( 'Upload image', 'lexipic' ); ?>">
					<button id="lp-capture-action" class="lp-primary-btn" type="button">
						<i class="fa-solid fa-microphone" aria-hidden="true"></i>
						<?php esc_html_e( 'Speak', 'lexipic' ); ?>
					</button>
				</div>
				<div id="lp-preview-container"></div>
				<div class="lp-control-group">
					<input type="text" id="lp-script-input"
						placeholder="<?php esc_attr_e( 'Heritage word (script)', 'lexipic' ); ?>"
						dir="auto" autocomplete="off">
					<input type="text" id="lp-roman-input"
						placeholder="<?php esc_attr_e( 'Roman transliteration', 'lexipic' ); ?>"
						autocomplete="off">
				</div>
				<input type="text" id="lp-description-input"
					placeholder="<?php esc_attr_e( 'Description (optional)', 'lexipic' ); ?>">
				<p id="lp-entry-status" class="lp-status" aria-live="polite"></p>
				<button id="lp-save-entry-btn" class="lp-save-btn" type="button">
					<?php esc_html_e( 'Add to Archive', 'lexipic' ); ?>
				</button>
			</section>
		</div>
		<?php endif; ?>

		<!-- Sets: create / manage sets ────────────────────────────────────── -->
		<?php if ( $can_manage_sets ) : ?>
		<div class="lp-tab-panel" data-tab="sets" role="tabpanel" hidden>

			<!-- Create set form — always visible, no toggle. -->
			<div class="lp-panel lp-create-set-panel">
				<h4 class="lp-panel-heading"><?php esc_html_e( 'Create a New Set', 'lexipic' ); ?></h4>
				<input type="text" id="lp-set-name" placeholder="<?php esc_attr_e( 'Set name e.g. Domestic Animals', 'lexipic' ); ?>">
				<select id="lp-set-language" aria-label="<?php esc_attr_e( 'Language', 'lexipic' ); ?>">
					<option value="bpm"><?php esc_html_e( 'Bishnupriya Manipuri', 'lexipic' ); ?></option>
					<option value="as"><?php esc_html_e( 'Assamese', 'lexipic' ); ?></option>
					<option value="bn"><?php esc_html_e( 'Bengali', 'lexipic' ); ?></option>
				</select>
				<button id="lp-create-set-btn" class="lp-save-btn" type="button">
					<i class="fa-solid fa-folder-plus" aria-hidden="true"></i>
					<?php esc_html_e( 'Create Set', 'lexipic' ); ?>
				</button>
			</div>

			<!-- Manage currently-selected set. -->
			<div class="lp-panel lp-manage-set-panel">
				<h4 class="lp-panel-heading"><?php esc_html_e( 'Manage Selected Set', 'lexipic' ); ?></h4>
				<p class="lp-panel-hint"><?php esc_html_e( 'Use the set selector at the top of the page to choose which set these actions apply to.', 'lexipic' ); ?></p>
				<div class="lp-data-controls">
					<button id="lp-export-btn" class="lp-util-btn" type="button" disabled>
						<i class="fa-solid fa-file-arrow-down" aria-hidden="true"></i>
						<?php esc_html_e( 'Save to Disk', 'lexipic' ); ?>
					</button>
					<label class="lp-util-btn">
						<i class="fa-solid fa-file-arrow-up" aria-hidden="true"></i>
						<?php esc_html_e( 'Load from Disk', 'lexipic' ); ?>
						<input type="file" id="lp-import-input" accept=".json" hidden>
					</label>
					<button id="lp-delete-set-btn" class="lp-util-btn lp-danger" type="button" disabled>
						<i class="fa-solid fa-trash" aria-hidden="true"></i>
						<?php esc_html_e( 'Delete Set', 'lexipic' ); ?>
					</button>
				</div>
			</div>
		</div>
		<?php endif; ?>

	</div><!-- /lp-tab-panels -->

</div><!-- /#lexipic-app -->
