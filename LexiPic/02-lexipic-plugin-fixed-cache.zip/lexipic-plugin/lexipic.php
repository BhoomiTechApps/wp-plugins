<?php
/**
 * Plugin Name:       LexiPic — Heritage Language Archive
 * Plugin URI:        https://bhoomitech.org/lexipic
 * Description:       Record, archive, and share heritage language word sets with photo, audio, native script, and Roman transliteration.
 * Version:           1.0.0
 * Author:            BhoomiTech Heritage and Development Foundation
 * Author URI:        https://bhoomitech.org
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       lexipic
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Constants ─────────────────────────────────────────────────────────────────
define( 'LEXIPIC_VERSION',     '1.0.0' );
define( 'LEXIPIC_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'LEXIPIC_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'LEXIPIC_UPLOAD_DIR',  WP_CONTENT_DIR . '/uploads/lexipic' );
define( 'LEXIPIC_UPLOAD_URL',  WP_CONTENT_URL  . '/uploads/lexipic' );

// ── Includes ──────────────────────────────────────────────────────────────────
require_once LEXIPIC_PLUGIN_DIR . 'includes/class-db.php';
require_once LEXIPIC_PLUGIN_DIR . 'includes/class-file-handler.php';
require_once LEXIPIC_PLUGIN_DIR . 'includes/class-audio-converter.php';
require_once LEXIPIC_PLUGIN_DIR . 'includes/class-rest-api.php';
require_once LEXIPIC_PLUGIN_DIR . 'admin/settings-page.php';
require_once LEXIPIC_PLUGIN_DIR . 'admin/import-export.php';

// ── Activation / Deactivation ─────────────────────────────────────────────────
register_activation_hook( __FILE__, 'lexipic_activate' );
function lexipic_activate() {
	Lexipic_DB::create_tables();
	lexipic_create_upload_dir();
	flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'lexipic_deactivate' );
function lexipic_deactivate() {
	flush_rewrite_rules();
}

function lexipic_create_upload_dir() {
	if ( ! file_exists( LEXIPIC_UPLOAD_DIR ) ) {
		wp_mkdir_p( LEXIPIC_UPLOAD_DIR );
		// Protect the directory from direct listing.
		file_put_contents( LEXIPIC_UPLOAD_DIR . '/.htaccess', "Options -Indexes\n" );
	}
}

// ── Init ──────────────────────────────────────────────────────────────────────
add_action( 'init', 'lexipic_init' );
function lexipic_init() {
	load_plugin_textdomain( 'lexipic', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}

// ── REST API ──────────────────────────────────────────────────────────────────
add_action( 'rest_api_init', array( 'Lexipic_REST_API', 'register_routes' ) );

// ── Shortcode ─────────────────────────────────────────────────────────────────
add_shortcode( 'lexipic', 'lexipic_render_shortcode' );
function lexipic_render_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'set' => '', // optional: pre-load a specific set slug
	), $atts, 'lexipic' );

	lexipic_enqueue_assets();
	ob_start();
	include LEXIPIC_PLUGIN_DIR . 'public/partials/app.php';
	return ob_get_clean();
}

// ── IME data helper ───────────────────────────────────────────────────────────
/**
 * Read and decode one of the CompLing AI IME engine's JSON data files.
 *
 * @param  string $filename  File name within public/js/ime/.
 * @return mixed|null        Decoded JSON (array) or null on failure.
 */
function lexipic_read_ime_json( $filename ) {
	$path = LEXIPIC_PLUGIN_DIR . 'public/js/ime/' . $filename;
	if ( ! file_exists( $path ) ) {
		return null;
	}
	$contents = file_get_contents( $path );
	if ( false === $contents ) {
		return null;
	}
	$data = json_decode( $contents, true );
	return ( json_last_error() === JSON_ERROR_NONE ) ? $data : null;
}

// ── Asset Enqueue ──────────────────────────────────────────────────────────────
function lexipic_enqueue_assets() {
	$options  = get_option( 'lexipic_settings', array() );
	$language = isset( $options['language'] ) ? $options['language'] : 'bpm';

	// Speech recognition locale map.
	$lang_locales = array(
		'as'  => 'as-IN',
		'bn'  => 'bn-IN',
		'bpm' => 'bn-IN', // No dedicated BCP-47 code for Bishnupriya Manipuri.
	);
	$speech_locale = isset( $lang_locales[ $language ] ) ? $lang_locales[ $language ] : 'bn-IN';

	// Styles.
	wp_enqueue_style(
		'lexipic-style',
		LEXIPIC_PLUGIN_URL . 'public/css/style.css',
		array(),
		LEXIPIC_VERSION
	);
	wp_enqueue_style(
		'font-awesome',
		'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
		array(),
		'6.5.1'
	);

	// IME engine (no defer — must be available before app.js).
	wp_enqueue_script(
		'lexipic-ime-engine',
		LEXIPIC_PLUGIN_URL . 'public/js/ime/engine.js',
		array(),
		LEXIPIC_VERSION,
		true
	);

	// Main app script.
	wp_enqueue_script(
		'lexipic-app',
		LEXIPIC_PLUGIN_URL . 'public/js/lexipic-app.js',
		array( 'lexipic-ime-engine' ),
		LEXIPIC_VERSION,
		true
	);

	// Pass PHP config to JS.
	wp_localize_script( 'lexipic-app', 'lexipicConfig', array(
		'restUrl'       => esc_url_raw( rest_url( 'lexipic/v1/' ) ),
		'nonce'         => wp_create_nonce( 'wp_rest' ),
		'speechLocale'  => $speech_locale,
		'language'      => $language,
		'pluginUrl'     => LEXIPIC_PLUGIN_URL,
		'ffmpegEnabled' => Lexipic_Audio_Converter::is_available() ? '1' : '0',
		// CompLing AI IME engine data — used to wire CPLAI_ENGINE.bpmTransliterate()
		// for both forward (roman → script) and reverse (script → roman) directions.
		'imeMaps'       => array(
			'forward' => lexipic_read_ime_json( 'forwardMap.json' ),
			'reverse' => lexipic_read_ime_json( 'reverseMap.json' ),
		),
		'imeHooks'      => lexipic_read_ime_json( 'defaults.json' ),
		'imeSettings'   => lexipic_read_ime_json( 'js-engine-settings.default.json' ),
	) );
}
