<?php
/**
 * LexiPic — Uninstall script.
 *
 * Runs when the plugin is deleted from the WordPress admin.
 * Removes custom DB tables, options, and uploaded files.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// ── Drop custom tables ────────────────────────────────────────────────────────
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}lexipic_entries" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}lexipic_sets" );

// ── Remove plugin options ─────────────────────────────────────────────────────
delete_option( 'lexipic_settings' );
delete_transient( 'lexipic_ffmpeg_available' );

// ── Remove uploaded files ─────────────────────────────────────────────────────
$upload_dir = WP_CONTENT_DIR . '/uploads/lexipic';
if ( is_dir( $upload_dir ) ) {
	lexipic_rrmdir( $upload_dir );
}

// ── Scheduled events ─────────────────────────────────────────────────────────
wp_clear_scheduled_hook( 'lexipic_convert_audio' );

/**
 * Recursively delete a directory.
 */
function lexipic_rrmdir( $dir ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}
	$items = scandir( $dir );
	foreach ( $items as $item ) {
		if ( $item === '.' || $item === '..' ) {
			continue;
		}
		$path = $dir . '/' . $item;
		if ( is_dir( $path ) ) {
			lexipic_rrmdir( $path );
		} else {
			@unlink( $path );
		}
	}
	@rmdir( $dir );
}
