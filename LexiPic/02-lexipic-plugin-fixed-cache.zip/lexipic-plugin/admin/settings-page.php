<?php
/**
 * LexiPic — Admin Settings Page.
 *
 * Registers the top-level admin menu and the settings form.
 * Settings stored in WP option: lexipic_settings (array).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ── Register menu ─────────────────────────────────────────────────────────────
add_action( 'admin_menu', 'lexipic_admin_menu' );
function lexipic_admin_menu() {
	add_menu_page(
		__( 'LexiPic', 'lexipic' ),
		__( 'LexiPic', 'lexipic' ),
		'read',                     // Any logged-in user can access.
		'lexipic',
		'lexipic_settings_page',
		'dashicons-microphone',
		30
	);

	add_submenu_page(
		'lexipic',
		__( 'Settings', 'lexipic' ),
		__( 'Settings', 'lexipic' ),
		'manage_options',
		'lexipic',
		'lexipic_settings_page'
	);
}

// ── Register settings ─────────────────────────────────────────────────────────
add_action( 'admin_init', 'lexipic_register_settings' );
function lexipic_register_settings() {
	register_setting(
		'lexipic_settings_group',
		'lexipic_settings',
		array(
			'sanitize_callback' => 'lexipic_sanitize_settings',
			'default'           => array(
				'language'    => 'bpm',
				'public_view' => 0,
				'tab_access'  => array(
					'add_entry' => array(),
					'sets'      => array(),
				),
			),
		)
	);

	add_settings_section(
		'lexipic_general',
		__( 'General Settings', 'lexipic' ),
		null,
		'lexipic'
	);

	add_settings_field(
		'lexipic_language',
		__( 'Default Language', 'lexipic' ),
		'lexipic_field_language',
		'lexipic',
		'lexipic_general'
	);

	add_settings_field(
		'lexipic_public_view',
		__( 'Public Archive', 'lexipic' ),
		'lexipic_field_public_view',
		'lexipic',
		'lexipic_general'
	);

	add_settings_field(
		'lexipic_tab_access',
		__( 'Tab Access Control', 'lexipic' ),
		'lexipic_field_tab_access',
		'lexipic',
		'lexipic_general'
	);
}

function lexipic_sanitize_settings( $input ) {
	$clean = array();
	$allowed_langs = array( 'as', 'bn', 'bpm' );
	$clean['language']    = in_array( $input['language'] ?? 'bpm', $allowed_langs, true ) ? $input['language'] : 'bpm';
	$clean['public_view'] = ! empty( $input['public_view'] ) ? 1 : 0;

	// Tab access control — comma-separated WordPress usernames per tab,
	// resolved to numeric user IDs for storage/use elsewhere in the plugin.
	$clean['tab_access'] = array();
	$invalid_logins      = array();
	foreach ( array( 'add_entry', 'sets' ) as $tab_key ) {
		$raw = $input['tab_access'][ $tab_key ] ?? '';
		if ( is_array( $raw ) ) {
			$raw = implode( ',', $raw );
		}

		$ids = array();
		foreach ( explode( ',', (string) $raw ) as $token ) {
			$token = trim( $token );
			if ( '' === $token ) {
				continue;
			}

			$user = get_user_by( 'login', $token );
			if ( ! $user && ctype_digit( $token ) ) {
				// Fall back to numeric IDs (e.g. values saved by an older version).
				$user = get_user_by( 'id', (int) $token );
			}

			if ( $user ) {
				$ids[] = (int) $user->ID;
			} else {
				$invalid_logins[] = $token;
			}
		}

		$clean['tab_access'][ $tab_key ] = array_values( array_unique( $ids ) );
	}

	if ( $invalid_logins ) {
		add_settings_error(
			'lexipic_messages',
			'lexipic_unknown_user',
			sprintf(
				/* translators: %s: comma-separated list of usernames that could not be matched. */
				__( 'LexiPic: could not find a user named “%s” — check the spelling and that the username (not display name) was used. This entry was not saved.', 'lexipic' ),
				implode( '”, “', array_unique( $invalid_logins ) )
			),
			'error'
		);
	}

	return $clean;
}

function lexipic_field_language() {
	$options  = get_option( 'lexipic_settings', array() );
	$current  = $options['language'] ?? 'bpm';
	$langs    = array(
		'bpm' => __( 'Bishnupriya Manipuri (ইমার ঠার)', 'lexipic' ),
		'as'  => __( 'Assamese (অসমীয়া)', 'lexipic' ),
		'bn'  => __( 'Bengali (বাংলা)', 'lexipic' ),
	);
	echo '<select name="lexipic_settings[language]">';
	foreach ( $langs as $code => $label ) {
		printf(
			'<option value="%s"%s>%s</option>',
			esc_attr( $code ),
			selected( $current, $code, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Sets the speech recognition locale and IME behaviour for all users.', 'lexipic' ) . '</p>';
}

function lexipic_field_public_view() {
	$options = get_option( 'lexipic_settings', array() );
	$checked = ! empty( $options['public_view'] );
	echo '<label>';
	echo '<input type="checkbox" name="lexipic_settings[public_view]" value="1"' . checked( $checked, true, false ) . '>';
	echo ' ' . esc_html__( 'Allow non-logged-in visitors to view the archive (read-only)', 'lexipic' );
	echo '</label>';
}

function lexipic_field_tab_access() {
	$options    = get_option( 'lexipic_settings', array() );
	$tab_access = $options['tab_access'] ?? array();

	$add_entry_names = lexipic_ids_to_logins( $tab_access['add_entry'] ?? array() );
	$sets_names      = lexipic_ids_to_logins( $tab_access['sets'] ?? array() );
	?>
	<fieldset>
		<div style="margin-bottom:14px;">
			<label for="lexipic_tab_access_add_entry"><strong><?php esc_html_e( '“Add Entry” tab', 'lexipic' ); ?></strong></label><br>
			<input type="text" id="lexipic_tab_access_add_entry" name="lexipic_settings[tab_access][add_entry]"
				value="<?php echo esc_attr( $add_entry_names ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. jdoe, msmith', 'lexipic' ); ?>">
			<p class="description"><?php esc_html_e( 'Comma-separated WordPress usernames (login names, not display names) allowed to see and use the “Add Entry” tab.', 'lexipic' ); ?></p>
		</div>
		<div style="margin-bottom:14px;">
			<label for="lexipic_tab_access_sets"><strong><?php esc_html_e( '“Sets” tab', 'lexipic' ); ?></strong></label><br>
			<input type="text" id="lexipic_tab_access_sets" name="lexipic_settings[tab_access][sets]"
				value="<?php echo esc_attr( $sets_names ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. jdoe', 'lexipic' ); ?>">
			<p class="description"><?php esc_html_e( 'Comma-separated WordPress usernames (login names, not display names) allowed to see and use the “Sets” tab (create/manage/export/delete sets).', 'lexipic' ); ?></p>
		</div>
		<p class="description">
			<?php esc_html_e( 'Administrators always have access to every tab. All other logged-in users not listed above — and all logged-out visitors — only see the “Archive” tab.', 'lexipic' ); ?>
		</p>
	</fieldset>
	<?php
}

/**
 * Convert an array of WordPress user IDs to a comma-separated string of
 * their usernames (login names), for display in the settings form.
 *
 * Any ID that no longer corresponds to a user is dropped silently — it will
 * simply disappear from the field the next time settings are saved.
 *
 * @param  int[] $ids  WordPress user IDs.
 * @return string      Comma-separated usernames, e.g. "jdoe, msmith".
 */
function lexipic_ids_to_logins( $ids ) {
	$logins = array();
	foreach ( (array) $ids as $id ) {
		$user = get_userdata( (int) $id );
		if ( $user ) {
			$logins[] = $user->user_login;
		}
	}
	return implode( ', ', $logins );
}

// ── Page render ───────────────────────────────────────────────────────────────
function lexipic_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Access denied.', 'lexipic' ) );
	}

	// FFmpeg status badge.
	$ffmpeg_ok = Lexipic_Audio_Converter::is_available();
	$badge_cls = $ffmpeg_ok ? 'notice-success' : 'notice-warning';
	$badge_msg = $ffmpeg_ok
		? __( '✔ FFmpeg detected — audio will be automatically converted to MP3.', 'lexipic' )
		: __( '⚠ FFmpeg not detected — audio will be stored as .webm (may not play on Safari/iOS).', 'lexipic' );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'LexiPic Settings', 'lexipic' ); ?></h1>

		<?php
		// options.php redirects back here with ?settings-updated=true on
		// successful save, but nothing renders a confirmation unless we
		// explicitly register and print it.
		if ( isset( $_GET['settings-updated'] ) ) {
			add_settings_error(
				'lexipic_messages',
				'lexipic_message',
				__( 'Settings saved.', 'lexipic' ),
				'success'
			);
		}
		settings_errors( 'lexipic_messages' );
		?>

		<div class="notice <?php echo esc_attr( $badge_cls ); ?> inline" style="padding:8px 12px;">
			<p><?php echo esc_html( $badge_msg ); ?></p>
		</div>

		<form method="post" action="options.php" style="margin-top:20px;">
			<?php
			settings_fields( 'lexipic_settings_group' );
			do_settings_sections( 'lexipic' );
			submit_button();
			?>
		</form>

		<hr>
		<h2><?php esc_html_e( 'Plugin Status', 'lexipic' ); ?></h2>
		<table class="widefat striped" style="max-width:600px;">
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Upload Directory', 'lexipic' ); ?></td>
					<td>
						<?php
						if ( file_exists( LEXIPIC_UPLOAD_DIR ) && is_writable( LEXIPIC_UPLOAD_DIR ) ) {
							echo '<span style="color:green;">✔ ' . esc_html( LEXIPIC_UPLOAD_DIR ) . '</span>';
						} else {
							echo '<span style="color:red;">✘ ' . esc_html( LEXIPIC_UPLOAD_DIR ) . ' — not writable</span>';
						}
						?>
					</td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'FFmpeg', 'lexipic' ); ?></td>
					<td>
						<?php echo $ffmpeg_ok
							? '<span style="color:green;">✔ Available</span>'
							: '<span style="color:#856404;">⚠ Not available (webm fallback active)</span>';
						?>
					</td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'REST API Base', 'lexipic' ); ?></td>
					<td><code><?php echo esc_html( rest_url( 'lexipic/v1/' ) ); ?></code></td>
				</tr>
			</tbody>
		</table>
	</div>
	<?php
}
