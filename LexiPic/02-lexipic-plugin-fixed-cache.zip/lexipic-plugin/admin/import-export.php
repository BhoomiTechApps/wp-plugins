<?php
/**
 * LexiPic — Admin Import / Export page.
 *
 * Registers a sub-menu page for JSON import and export of word sets.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', 'lexipic_import_export_menu' );
function lexipic_import_export_menu() {
	add_submenu_page(
		'lexipic',
		__( 'Import / Export', 'lexipic' ),
		__( 'Import / Export', 'lexipic' ),
		'read',
		'lexipic-import-export',
		'lexipic_import_export_page'
	);
}

// ── Handle import POST ────────────────────────────────────────────────────────
add_action( 'admin_post_lexipic_import', 'lexipic_handle_import' );
function lexipic_handle_import() {
	if ( ! is_user_logged_in() ) {
		wp_die( esc_html__( 'You must be logged in.', 'lexipic' ) );
	}
	check_admin_referer( 'lexipic_import_nonce' );

	if ( empty( $_FILES['lexipic_json_file']['tmp_name'] ) ) {
		wp_redirect( add_query_arg( array( 'page' => 'lexipic-import-export', 'lp_error' => 'no_file' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	$file = $_FILES['lexipic_json_file'];
	if ( $file['type'] !== 'application/json' && pathinfo( $file['name'], PATHINFO_EXTENSION ) !== 'json' ) {
		wp_redirect( add_query_arg( array( 'page' => 'lexipic-import-export', 'lp_error' => 'wrong_type' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	$raw = file_get_contents( $file['tmp_name'] );
	if ( ! $raw ) {
		wp_redirect( add_query_arg( array( 'page' => 'lexipic-import-export', 'lp_error' => 'empty_file' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	$data = json_decode( $raw, true );
	if ( json_last_error() !== JSON_ERROR_NONE ) {
		wp_redirect( add_query_arg( array( 'page' => 'lexipic-import-export', 'lp_error' => 'invalid_json' ), admin_url( 'admin.php' ) ) );
		exit;
	}

	$result = Lexipic_File_Handler::import_json( $data, get_current_user_id() );
	if ( is_wp_error( $result ) ) {
		wp_redirect( add_query_arg( array( 'page' => 'lexipic-import-export', 'lp_error' => urlencode( $result->get_error_message() ) ), admin_url( 'admin.php' ) ) );
		exit;
	}

	wp_redirect( add_query_arg( array(
		'page'        => 'lexipic-import-export',
		'lp_imported' => $result['imported'],
		'lp_set_id'   => $result['set_id'],
	), admin_url( 'admin.php' ) ) );
	exit;
}

// ── Page render ───────────────────────────────────────────────────────────────
function lexipic_import_export_page() {
	if ( ! is_user_logged_in() ) {
		wp_die( esc_html__( 'You must be logged in.', 'lexipic' ) );
	}

	// Flash messages.
	if ( isset( $_GET['lp_imported'] ) ) {
		$count  = (int) $_GET['lp_imported'];
		$set_id = (int) $_GET['lp_set_id'];
		echo '<div class="notice notice-success is-dismissible"><p>'
			. sprintf(
				/* translators: 1: number of entries, 2: set ID */
				esc_html__( 'Import complete. %1$d entries added (Set ID: %2$d).', 'lexipic' ),
				$count,
				$set_id
			)
			. '</p></div>';
	}
	if ( isset( $_GET['lp_error'] ) ) {
		$msgs = array(
			'no_file'      => __( 'No file was uploaded.', 'lexipic' ),
			'wrong_type'   => __( 'File must be a .json file.', 'lexipic' ),
			'empty_file'   => __( 'Uploaded file was empty.', 'lexipic' ),
			'invalid_json' => __( 'File does not contain valid JSON.', 'lexipic' ),
		);
		$err = sanitize_text_field( $_GET['lp_error'] );
		$msg = $msgs[ $err ] ?? $err;
		echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( $msg ) . '</p></div>';
	}

	// Get all sets for the export table.
	$sets = current_user_can( 'manage_options' )
		? Lexipic_DB::get_sets()
		: Lexipic_DB::get_sets( get_current_user_id() );

	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'LexiPic — Import / Export', 'lexipic' ); ?></h1>

		<div style="display:grid;grid-template-columns:1fr 1fr;gap:30px;margin-top:20px;">

			<!-- ── IMPORT ─────────────────────────────────────────────── -->
			<div class="postbox" style="padding:15px;">
				<h2 class="hndle"><?php esc_html_e( '⬆ Import a JSON Set', 'lexipic' ); ?></h2>
				<div class="inside">
					<p><?php esc_html_e( 'Upload a .json file exported from LexiPic (or from the original PWA). A new set will be created automatically.', 'lexipic' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="lexipic_import">
						<?php wp_nonce_field( 'lexipic_import_nonce' ); ?>
						<p>
							<input type="file" name="lexipic_json_file" accept=".json" required style="display:block;margin-bottom:10px;">
							<?php submit_button( __( 'Import', 'lexipic' ), 'primary', 'submit', false ); ?>
						</p>
					</form>
				</div>
			</div>

			<!-- ── EXPORT ────────────────────────────────────────────── -->
			<div class="postbox" style="padding:15px;">
				<h2 class="hndle"><?php esc_html_e( '⬇ Export a Set as JSON', 'lexipic' ); ?></h2>
				<div class="inside">
					<p><?php esc_html_e( 'Download a self-contained JSON file (images + audio embedded as base64) for sharing or backup.', 'lexipic' ); ?></p>
					<?php if ( empty( $sets ) ) : ?>
						<p><em><?php esc_html_e( 'No sets found. Create one first using the shortcode on your page.', 'lexipic' ); ?></em></p>
					<?php else : ?>
						<table class="widefat striped" style="margin-top:10px;">
							<thead>
								<tr>
									<th><?php esc_html_e( 'Set Name', 'lexipic' ); ?></th>
									<th><?php esc_html_e( 'Language', 'lexipic' ); ?></th>
									<th><?php esc_html_e( 'Entries', 'lexipic' ); ?></th>
									<th><?php esc_html_e( 'Created', 'lexipic' ); ?></th>
									<th></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $sets as $set ) :
									$export_url = add_query_arg(
										array( '_wpnonce' => wp_create_nonce( 'wp_rest' ) ),
										rest_url( 'lexipic/v1/sets/' . $set->id . '/export' )
									);
									$count = Lexipic_DB::count_entries( (int) $set->id );
								?>
								<tr>
									<td><?php echo esc_html( $set->name ); ?></td>
									<td><?php echo esc_html( strtoupper( $set->language ) ); ?></td>
									<td><?php echo esc_html( $count ); ?></td>
									<td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $set->created_at ) ) ); ?></td>
									<td>
										<a href="<?php echo esc_url( $export_url ); ?>" class="button button-small">
											<?php esc_html_e( 'Download JSON', 'lexipic' ); ?>
										</a>
									</td>
								</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</div>
			</div>

		</div><!-- /grid -->
	</div>
	<?php
}
