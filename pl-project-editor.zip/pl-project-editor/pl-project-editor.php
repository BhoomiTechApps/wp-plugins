<?php
/**
 * Plugin Name:       ProjectLens Project Editor
 * Plugin URI:        https://github.com/BhoomiTech/projectlens
 * Description:       Adds a [pl_project_editor] shortcode that renders a full
 *                    project-editing interface on any frontend page for users
 *                    with the pl_edit_projects capability. No create / delete.
 *                    Media library is scoped to each user's own uploads only.
 *                    Requires the ProjectLens plugin (projectlens).
 * Version:           1.0.0
 * Author:            BhoomiTech Heritage and Development Foundation
 * License:           GPL-2.0+
 * Text Domain:       pl-project-editor
 * Requires Plugins:  projectlens
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PLE_VERSION',    '1.0.0' );
define( 'PLE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'PLE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Bail early with an admin notice if ProjectLens is not active.
 *
 * @return bool
 */
function ple_check_dependency() {
	if ( ! defined( 'PL_VERSION' ) ) {
		add_action( 'admin_notices', function () {
			echo '<div class="notice notice-error"><p>';
			echo '<strong>ProjectLens Project Editor</strong> requires the <strong>ProjectLens</strong> plugin to be installed and activated.';
			echo '</p></div>';
		} );
		return false;
	}
	return true;
}

/**
 * Load the editor class and initialise it.
 */
function ple_init() {
	if ( ! ple_check_dependency() ) return;

	require_once PLE_PLUGIN_DIR . 'includes/class-ple-editor.php';
	PLE_Editor::init();
}
add_action( 'plugins_loaded', 'ple_init', 25 ); // after ProjectLens (10) and any access-control extension (20)
