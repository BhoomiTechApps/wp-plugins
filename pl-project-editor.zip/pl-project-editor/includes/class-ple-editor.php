<?php
/**
 * ProjectLens Project Editor — Core Class
 *
 * Provides the [pl_project_editor] shortcode and all AJAX endpoints
 * needed by the frontend editing interface.
 *
 * Shortcode usage:
 *   [pl_project_editor]
 *
 * What it does:
 *  • Lists every pl_project the current user can edit (pl_edit_projects cap).
 *  • Renders a full segment + settings editor that mirrors the WP admin UI.
 *  • Saves via AJAX (wp_ajax_ple_save_project).
 *  • Exposes a media-library AJAX endpoint (wp_ajax_ple_get_user_media) that
 *    returns only attachments uploaded by the currently logged-in user.
 *  • Does NOT allow creating or deleting projects.
 *  • Does NOT expose styling controls.
 *
 * Security model:
 *  • All AJAX handlers verify a nonce (ple_nonce / action ple_nonce).
 *  • Saving re-checks current_user_can('pl_edit_projects') AND that the post
 *    belongs to post-type pl_project before touching any data.
 *  • Media queries are strictly filtered to the current user's own uploads.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class PLE_Editor {

	// -----------------------------------------------------------------------
	// Bootstrap
	// -----------------------------------------------------------------------

	public static function init() {
		add_shortcode( 'pl_project_editor', [ __CLASS__, 'render_shortcode' ] );

		// Enqueue assets only where the shortcode is present
		add_action( 'wp_enqueue_scripts', [ __CLASS__, 'maybe_enqueue_assets' ] );

		// AJAX handlers (logged-in users only)
		add_action( 'wp_ajax_ple_save_project',    [ __CLASS__, 'ajax_save_project'    ] );
		add_action( 'wp_ajax_ple_get_user_media',  [ __CLASS__, 'ajax_get_user_media'  ] );
		add_action( 'wp_ajax_ple_get_project_data', [ __CLASS__, 'ajax_get_project_data' ] );

		/*
		 * Website A fix — REST API media upload (403 for non-admin users):
		 *
		 * WordPress's /wp-json/wp/v2/media endpoint requires the `upload_files`
		 * capability. Users who only hold the custom `pl_edit_projects` cap
		 * are rejected with a 403. We grant `upload_files` temporarily at the
		 * REST layer, scoped only to users who already have `pl_edit_projects`
		 * so no privilege is given to anyone who shouldn't have it.
		 */
		add_filter( 'user_has_cap', [ __CLASS__, 'grant_rest_upload_cap' ], 10, 3 );

		/*
		 * Website B fix — WP-Optimize / script minifier compatibility:
		 *
		 * WP-Optimize concatenates scripts into a single bundle. When
		 * ple-editor.js is merged with WordPress core media scripts the click
		 * handler on the upload zone ends up in the same closure scope as core
		 * handlers, which causes jQuery .trigger('click') to re-fire the zone
		 * handler infinitely. Excluding ple-editor.js from minification
		 * prevents the merge. The JS-side fix (using $fileInput[0].click())
		 * also guards against this, but excluding the handle is the belt-and-
		 * braces defence so no minifier can cause a regression.
		 */
		add_filter( 'wpo_minify_exclude_handles', [ __CLASS__, 'exclude_from_wpo_minify' ] );
	}

	/**
	 * Grant `upload_files` to any user who holds `pl_edit_projects` so that
	 * the WP REST API media endpoint accepts their upload requests.
	 *
	 * @param  bool[]   $allcaps  All capabilities currently granted to the user.
	 * @param  string[] $caps     Required capabilities being checked.
	 * @param  array    $args     Additional context (capability, user ID, …).
	 * @return bool[]
	 */
	public static function grant_rest_upload_cap( $allcaps, $caps, $args ) {
		if (
			in_array( 'upload_files', $caps, true ) &&
			! empty( $allcaps['pl_edit_projects'] )
		) {
			$allcaps['upload_files'] = true;
		}
		return $allcaps;
	}

	/**
	 * Tell WP-Optimize's script minifier to leave ple-editor.js alone.
	 * Merging it with core media scripts causes an infinite click-trigger
	 * loop (stack overflow) in jQuery.
	 *
	 * @param  string[] $handles  Script handles already excluded.
	 * @return string[]
	 */
	public static function exclude_from_wpo_minify( $handles ) {
		$handles[] = 'ple-editor';
		return $handles;
	}

	// -----------------------------------------------------------------------
	// Asset enqueueing
	// -----------------------------------------------------------------------

	public static function maybe_enqueue_assets() {
		global $post;
		if (
			! is_a( $post, 'WP_Post' ) ||
			! has_shortcode( $post->post_content, 'pl_project_editor' )
		) {
			return;
		}

		if ( ! is_user_logged_in() || ! current_user_can( 'pl_edit_projects' ) ) {
			return;
		}

		// jQuery UI sortable for segment reordering
		wp_enqueue_script( 'jquery-ui-sortable' );

		// WordPress media uploader (wp.media)
		wp_enqueue_media();

		// Use filemtime as the cache-busting version so any update to the
		// JS or CSS file immediately invalidates browser and proxy caches,
		// even when PLE_VERSION itself has not changed.
		$js_ver  = filemtime( PLE_PLUGIN_DIR . 'public/js/ple-editor.js'  ) ?: PLE_VERSION;
		$css_ver = filemtime( PLE_PLUGIN_DIR . 'public/css/ple-editor.css' ) ?: PLE_VERSION;

		wp_enqueue_style(
			'ple-editor',
			PLE_PLUGIN_URL . 'public/css/ple-editor.css',
			[],
			$css_ver
		);

		wp_enqueue_script(
			'ple-editor',
			PLE_PLUGIN_URL . 'public/js/ple-editor.js',
			[ 'jquery', 'jquery-ui-sortable' ],
			$js_ver,
			true
		);

		wp_localize_script( 'ple-editor', 'PLE', [
			'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
			'nonce'         => wp_create_nonce( 'ple_nonce' ),
			'restNonce'     => wp_create_nonce( 'wp_rest' ),
			'currentUserId' => get_current_user_id(),
			'segmentTypes'  => PL_Segment::get_type_labels(),
			'i18n'          => [
				'selectProject'   => __( 'Select a project to edit',                    'pl-project-editor' ),
				'loading'         => __( 'Loading…',                                    'pl-project-editor' ),
				'saving'          => __( 'Saving…',                                     'pl-project-editor' ),
				'saved'           => __( 'Project saved successfully.',                 'pl-project-editor' ),
				'saveError'       => __( 'Save failed. Please try again.',              'pl-project-editor' ),
				'confirmDelete'   => __( 'Remove this segment?',                        'pl-project-editor' ),
				'confirmDeleteSub'=> __( 'Remove this item?',                           'pl-project-editor' ),
				'selectMedia'     => __( 'Select Image / File',                         'pl-project-editor' ),
				'useMedia'        => __( 'Use this media',                              'pl-project-editor' ),
				'noMedia'         => __( 'No media found in your library.',             'pl-project-editor' ),
				'addSlide'        => __( '+ Add Slide',                                 'pl-project-editor' ),
				'addField'        => __( '+ Add Field',                                 'pl-project-editor' ),
				'addMember'       => __( '+ Add Member',                                'pl-project-editor' ),
				'addMilestone'    => __( '+ Add Milestone',                             'pl-project-editor' ),
				'addFile'         => __( '+ Add File',                                  'pl-project-editor' ),
				'addSegment'      => __( '+ Add Segment',                               'pl-project-editor' ),
				'noProjects'      => __( 'No projects are available for you to edit.',  'pl-project-editor' ),
			],
		] );
	}

	// -----------------------------------------------------------------------
	// Shortcode
	// -----------------------------------------------------------------------

	/**
	 * [pl_project_editor] callback.
	 *
	 * @param array  $atts
	 * @param string $content
	 * @return string HTML
	 */
	public static function render_shortcode( $atts, $content = '' ) {
		if ( ! is_user_logged_in() ) {
			return '<div class="ple-notice ple-notice--warning">' .
				esc_html__( 'You must be logged in to edit projects.', 'pl-project-editor' ) .
				'</div>';
		}

		if ( ! current_user_can( 'pl_edit_projects' ) ) {
			return '<div class="ple-notice ple-notice--error">' .
				esc_html__( 'You do not have permission to edit projects.', 'pl-project-editor' ) .
				'</div>';
		}

		$projects = self::get_editable_projects();

		ob_start();
		self::render_editor_shell( $projects );
		return ob_get_clean();
	}

	// -----------------------------------------------------------------------
	// Helpers: fetch editable projects
	// -----------------------------------------------------------------------

	/**
	 * Return all published pl_project posts the current user may edit.
	 *
	 * @return WP_Post[]
	 */
	private static function get_editable_projects() {
		return get_posts( [
			'post_type'      => 'pl_project',
			'post_status'    => [ 'publish', 'draft', 'private' ],
			'posts_per_page' => -1,
			'orderby'        => 'title',
			'order'          => 'ASC',
		] );
	}

	// -----------------------------------------------------------------------
	// HTML shell (project selector + editor area)
	// -----------------------------------------------------------------------

	private static function render_editor_shell( $projects ) {
		?>
		<div class="ple-wrap" id="ple-wrap">

			<!-- ── Inline AJAX notice ── -->
			<div class="ple-ajax-notice" id="ple-ajax-notice" style="display:none" role="alert" aria-live="polite"></div>

			<!-- ── Project selector ── -->
			<div class="ple-selector-bar">
				<label for="ple-project-select" class="ple-selector-label">
					<?php esc_html_e( 'Project:', 'pl-project-editor' ); ?>
				</label>
				<select id="ple-project-select" class="ple-select">
					<option value=""><?php esc_html_e( '— Choose a project —', 'pl-project-editor' ); ?></option>
					<?php foreach ( $projects as $project ) : ?>
						<option value="<?php echo absint( $project->ID ); ?>">
							<?php echo esc_html( $project->post_title ?: __( '(no title)', 'pl-project-editor' ) ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<span class="ple-spinner" id="ple-load-spinner" style="display:none"></span>
			</div>

			<?php if ( empty( $projects ) ) : ?>
				<p class="ple-notice ple-notice--warning">
					<?php esc_html_e( 'No projects are available for you to edit.', 'pl-project-editor' ); ?>
				</p>
			<?php endif; ?>

			<!-- ── Editor area (populated by JS after project selection) ── -->
			<div id="ple-editor-area" style="display:none">

				<!-- Project title -->
				<div class="ple-section ple-section--title">
					<label class="ple-field-label" for="ple-post-title">
						<?php esc_html_e( 'Project Title', 'pl-project-editor' ); ?>
					</label>
					<input type="text" id="ple-post-title" class="ple-input ple-input--wide"
					       placeholder="<?php esc_attr_e( 'Project Title', 'pl-project-editor' ); ?>" />
				</div>

				<!-- Tabs -->
				<nav class="ple-tabs" role="tablist">
					<button type="button" class="ple-tab ple-tab--active" data-tab="segments" role="tab"
					        aria-selected="true">
						<?php esc_html_e( 'Segments', 'pl-project-editor' ); ?>
					</button>
					<button type="button" class="ple-tab" data-tab="settings" role="tab"
					        aria-selected="false">
						<?php esc_html_e( 'Settings', 'pl-project-editor' ); ?>
					</button>
				</nav>

				<!-- Tab: Segments -->
				<div class="ple-tab-panel" id="ple-tab-segments" role="tabpanel">
					<div id="ple-segments-list" class="ple-segments-list">
						<!-- Populated by JS -->
					</div>

					<div class="ple-add-segment-bar">
						<label class="ple-field-label"><?php esc_html_e( 'Add Segment:', 'pl-project-editor' ); ?></label>
						<select id="ple-new-segment-type" class="ple-select">
							<?php foreach ( PL_Segment::get_type_labels() as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<button type="button" id="ple-btn-add-segment" class="ple-btn ple-btn--secondary">
							<?php esc_html_e( '+ Add Segment', 'pl-project-editor' ); ?>
						</button>
					</div>
				</div>

				<!-- Tab: Settings -->
				<div class="ple-tab-panel" id="ple-tab-settings" role="tabpanel" style="display:none">
					<?php self::render_settings_fields(); ?>
				</div>

				<!-- Save bar -->
				<div class="ple-save-bar">
					<button type="button" id="ple-btn-save" class="ple-btn ple-btn--primary">
						<?php esc_html_e( 'Save Changes', 'pl-project-editor' ); ?>
					</button>
					<span class="ple-spinner" id="ple-save-spinner" style="display:none"></span>
				</div>

			</div><!-- /#ple-editor-area -->

		</div><!-- /.ple-wrap -->
		<?php
	}

	// -----------------------------------------------------------------------
	// Settings fields HTML (mirrors admin meta-box, minus styling)
	// -----------------------------------------------------------------------

	private static function render_settings_fields() {
		$statuses = [
			'concept'   => __( 'Concept',         'pl-project-editor' ),
			'planning'  => __( 'Planning',         'pl-project-editor' ),
			'active'    => __( 'Active / Ongoing', 'pl-project-editor' ),
			'completed' => __( 'Completed',        'pl-project-editor' ),
			'certified' => __( 'Certified',        'pl-project-editor' ),
			'suspended' => __( 'Suspended',        'pl-project-editor' ),
			'cancelled' => __( 'Cancelled',        'pl-project-editor' ),
		];
		$currencies = [ 'USD','EUR','GBP','INR','AUD','CAD','JPY','CNY','CHF','SEK','NOK','DKK' ];
		?>
		<div class="ple-settings-grid">

			<!-- Project Identity -->
			<div class="ple-settings-section">
				<h4 class="ple-settings-section__title"><?php esc_html_e( 'Project Identity', 'pl-project-editor' ); ?></h4>
				<div class="ple-form-table">

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Project Code / ID', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[project_code]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Project Status', 'pl-project-editor' ); ?></label>
						<select name="pl_settings[project_status]" class="ple-select">
							<?php foreach ( $statuses as $val => $label ) : ?>
								<option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Short Description', 'pl-project-editor' ); ?></label>
						<textarea name="pl_settings[short_description]" rows="3" class="ple-textarea ple-textarea--wide"></textarea>
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Project Location', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[location]" class="ple-input"
						       placeholder="<?php esc_attr_e( 'e.g. Assam, India', 'pl-project-editor' ); ?>" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Country / Region', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[country]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Website / URL', 'pl-project-editor' ); ?></label>
						<input type="url" name="pl_settings[website]" class="ple-input" />
					</div>

				</div>
			</div>

			<!-- Dates & Duration -->
			<div class="ple-settings-section">
				<h4 class="ple-settings-section__title"><?php esc_html_e( 'Dates & Duration', 'pl-project-editor' ); ?></h4>
				<div class="ple-form-table">

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Start Date', 'pl-project-editor' ); ?></label>
						<input type="date" name="pl_settings[start_date]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'End Date (Planned)', 'pl-project-editor' ); ?></label>
						<input type="date" name="pl_settings[end_date]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Actual Completion Date', 'pl-project-editor' ); ?></label>
						<input type="date" name="pl_settings[completion_date]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Reporting Period', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[reporting_period]" class="ple-input"
						       placeholder="<?php esc_attr_e( 'e.g. Q3 2024 / Annual', 'pl-project-editor' ); ?>" />
					</div>

				</div>
			</div>

			<!-- Funding & Budget -->
			<div class="ple-settings-section">
				<h4 class="ple-settings-section__title"><?php esc_html_e( 'Funding & Budget', 'pl-project-editor' ); ?></h4>
				<div class="ple-form-table">

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Funding Agency / Donor', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[funder_name]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Implementing Agency', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[implementing_agency]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Executing Agency', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[executing_agency]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Grant / Agreement No.', 'pl-project-editor' ); ?></label>
						<input type="text" name="pl_settings[grant_number]" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Currency', 'pl-project-editor' ); ?></label>
						<select name="pl_settings[budget_currency]" class="ple-select">
							<?php foreach ( $currencies as $c ) : ?>
								<option value="<?php echo esc_attr( $c ); ?>"><?php echo esc_html( $c ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Total Budget', 'pl-project-editor' ); ?></label>
						<input type="number" name="pl_settings[budget_total]" step="0.01" min="0" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Grant Amount', 'pl-project-editor' ); ?></label>
						<input type="number" name="pl_settings[grant_amount]" step="0.01" min="0" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Co-financing', 'pl-project-editor' ); ?></label>
						<input type="number" name="pl_settings[cofinancing]" step="0.01" min="0" class="ple-input" />
					</div>

					<div class="ple-form-row">
						<label class="ple-form-label"><?php esc_html_e( 'Disbursement to Date', 'pl-project-editor' ); ?></label>
						<input type="number" name="pl_settings[disbursement]" step="0.01" min="0" class="ple-input" />
					</div>

				</div>
			</div>

		</div><!-- /.ple-settings-grid -->
		<?php
	}

	// -----------------------------------------------------------------------
	// AJAX: load project data
	// -----------------------------------------------------------------------

	/**
	 * Returns all meta for a given project as JSON.
	 * Used by JS to populate the editor after a project is selected.
	 */
	public static function ajax_get_project_data() {
		check_ajax_referer( 'ple_nonce', 'nonce' );

		if ( ! current_user_can( 'pl_edit_projects' ) ) {
			wp_send_json_error( [ 'message' => __( 'Access denied.', 'pl-project-editor' ) ], 403 );
		}

		$post_id = absint( wp_unslash( $_POST['post_id'] ?? 0 ) );
		$post    = get_post( $post_id );

		if ( ! $post || $post->post_type !== 'pl_project' ) {
			wp_send_json_error( [ 'message' => __( 'Invalid project.', 'pl-project-editor' ) ] );
		}

		$segments = get_post_meta( $post_id, '_pl_segments', true ) ?: [];
		$settings = get_post_meta( $post_id, '_pl_project_settings', true ) ?: [];

		// Enrich media segments with preview URLs so JS can display thumbnails
		foreach ( $segments as &$segment ) {
			$type = $segment['type'] ?? '';
			if ( $type === 'media' && ! empty( $segment['slides'] ) ) {
				foreach ( $segment['slides'] as &$slide ) {
					$mid = absint( $slide['media_id'] ?? 0 );
					$slide['_preview_url'] = $mid ? wp_get_attachment_image_url( $mid, 'thumbnail' ) : '';
				}
				unset( $slide );
			}
			if ( $type === 'team' && ! empty( $segment['members'] ) ) {
				foreach ( $segment['members'] as &$member ) {
					$mid = absint( $member['avatar_id'] ?? 0 );
					$member['_preview_url'] = $mid ? wp_get_attachment_image_url( $mid, 'thumbnail' ) : '';
				}
				unset( $member );
			}
			if ( $type === 'documents' && ! empty( $segment['files'] ) ) {
				foreach ( $segment['files'] as &$file ) {
					$fid = absint( $file['file_id'] ?? 0 );
					$file['_file_name'] = $fid ? get_the_title( $fid ) : '';
				}
				unset( $file );
			}
		}
		unset( $segment );

		wp_send_json_success( [
			'post_title' => $post->post_title,
			'segments'   => $segments,
			'settings'   => $settings,
		] );
	}

	// -----------------------------------------------------------------------
	// AJAX: save project
	// -----------------------------------------------------------------------

	/**
	 * Receives the serialised form, sanitises, and persists to post meta.
	 * Also updates the post title via wp_update_post().
	 */
	public static function ajax_save_project() {
		check_ajax_referer( 'ple_nonce', 'nonce' );

		if ( ! current_user_can( 'pl_edit_projects' ) ) {
			wp_send_json_error( [ 'message' => __( 'Access denied.', 'pl-project-editor' ) ], 403 );
		}

		$post_id = absint( wp_unslash( $_POST['post_id'] ?? 0 ) );
		$post    = get_post( $post_id );

		if ( ! $post || $post->post_type !== 'pl_project' ) {
			wp_send_json_error( [ 'message' => __( 'Invalid project.', 'pl-project-editor' ) ] );
		}

		// ── Title ────────────────────────────────────────────────────────
		$new_title = sanitize_text_field( wp_unslash( $_POST['post_title'] ?? '' ) );
		if ( $new_title !== '' && $new_title !== $post->post_title ) {
			wp_update_post( [
				'ID'         => $post_id,
				'post_title' => $new_title,
			] );
		}

		// ── Segments ─────────────────────────────────────────────────────
		$raw_segments = wp_unslash( $_POST['pl_segments'] ?? [] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( is_array( $raw_segments ) ) {
			$segments = self::sanitize_segments( $raw_segments );
			update_post_meta( $post_id, '_pl_segments', $segments );
		}

		// ── Settings ─────────────────────────────────────────────────────
		$raw_settings = wp_unslash( $_POST['pl_settings'] ?? [] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( is_array( $raw_settings ) ) {
			$settings = self::sanitize_settings( $raw_settings );
			update_post_meta( $post_id, '_pl_project_settings', $settings );
		}

		wp_send_json_success( [
			'message'    => __( 'Project saved successfully.', 'pl-project-editor' ),
			'post_title' => get_the_title( $post_id ),
		] );
	}

	// -----------------------------------------------------------------------
	// AJAX: user media library
	// -----------------------------------------------------------------------

	/**
	 * Returns paginated media items uploaded by the current user only.
	 *
	 * POST params:
	 *   paged      int    Page number (default 1).
	 *   search     string Optional search term.
	 *   type       string 'image' | 'application' | '' (all).
	 *
	 * Response shape:
	 *   items[]    { id, url, thumb, filename, type }
	 *   has_more   bool
	 */
	public static function ajax_get_user_media() {
		check_ajax_referer( 'ple_nonce', 'nonce' );

		if ( ! current_user_can( 'pl_edit_projects' ) ) {
			wp_send_json_error( [ 'message' => __( 'Access denied.', 'pl-project-editor' ) ], 403 );
		}

		$per_page  = 24;
		$paged     = max( 1, absint( wp_unslash( $_POST['paged'] ?? 1 ) ) );
		$search    = sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) );
		$mime_type = sanitize_key( wp_unslash( $_POST['type'] ?? '' ) );

		$query_args = [
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'author'         => get_current_user_id(), // strict: only this user's uploads
			'posts_per_page' => $per_page + 1,         // fetch one extra to know if there's a next page
			'paged'          => $paged,
			'orderby'        => 'date',
			'order'          => 'DESC',
		];

		if ( $search !== '' ) {
			$query_args['s'] = $search;
		}

		// Map shorthand to MIME prefix
		$mime_map = [
			'image'       => 'image',
			'application' => 'application',
			'video'       => 'video',
		];
		if ( isset( $mime_map[ $mime_type ] ) ) {
			$query_args['post_mime_type'] = $mime_map[ $mime_type ];
		}

		$query       = new WP_Query( $query_args );
		$attachments = $query->posts;
		$has_more    = count( $attachments ) > $per_page;
		if ( $has_more ) {
			array_pop( $attachments );
		}

		$items = [];
		foreach ( $attachments as $att ) {
			$thumb = wp_get_attachment_image_url( $att->ID, 'thumbnail' );
			$full  = wp_get_attachment_url( $att->ID );
			$mime  = $att->post_mime_type;
			$items[] = [
				'id'       => $att->ID,
				'url'      => $full,
				'thumb'    => $thumb ?: $full,
				'filename' => basename( get_attached_file( $att->ID ) ),
				'title'    => $att->post_title,
				'type'     => strstr( $mime, '/', true ), // 'image', 'video', 'application' …
				'mime'     => $mime,
			];
		}

		wp_send_json_success( [
			'items'    => $items,
			'has_more' => $has_more,
			'paged'    => $paged,
		] );
	}

	// -----------------------------------------------------------------------
	// Sanitisation (mirrors PL_Meta_Boxes private methods, kept here so the
	// editor plugin is self-contained and doesn't depend on admin classes)
	// -----------------------------------------------------------------------

	private static function sanitize_segments( $raw ) {
		$out = [];
		if ( ! is_array( $raw ) ) return $out;

		foreach ( $raw as $seg ) {
			if ( ! is_array( $seg ) ) continue;
			$type  = sanitize_key( $seg['type'] ?? 'descriptive' );
			$clean = [
				'id'        => sanitize_text_field( $seg['id'] ?? uniqid( 'seg_' ) ),
				'type'      => $type,
				'title'     => sanitize_text_field( $seg['title'] ?? '' ),
				'enabled'   => ! empty( $seg['enabled'] ),
				'collapsed' => ! empty( $seg['collapsed'] ),
			];

			switch ( $type ) {
				case 'descriptive':
					$clean['subtitle']       = sanitize_text_field( $seg['subtitle'] ?? '' );
					$clean['content']        = wp_kses_post( $seg['content'] ?? '' );
					$clean['detail_content'] = wp_kses_post( $seg['detail_content'] ?? '' );
					break;

				case 'media':
					$slides = [];
					foreach ( (array) ( $seg['slides'] ?? [] ) as $slide ) {
						$slides[] = [
							'media_id'    => absint( $slide['media_id']   ?? 0 ),
							'media_type'  => sanitize_key( $slide['media_type'] ?? 'image' ),
							'video_url'   => esc_url_raw( $slide['video_url']  ?? '' ),
							'caption'     => sanitize_text_field( $slide['caption']     ?? '' ),
							'description' => sanitize_textarea_field( $slide['description'] ?? '' ),
							'geo_lat'     => sanitize_text_field( $slide['geo_lat']  ?? '' ),
							'geo_lng'     => sanitize_text_field( $slide['geo_lng']  ?? '' ),
							'geo_label'   => sanitize_text_field( $slide['geo_label'] ?? '' ),
						];
					}
					$clean['slides'] = $slides;
					break;

				case 'metadata':
					$fields = [];
					foreach ( (array) ( $seg['fields'] ?? [] ) as $f ) {
						$fields[] = [
							'label' => sanitize_text_field( $f['label'] ?? '' ),
							'value' => sanitize_text_field( $f['value'] ?? '' ),
						];
					}
					$clean['fields'] = $fields;
					break;

				case 'team':
					$members = [];
					foreach ( (array) ( $seg['members'] ?? [] ) as $m ) {
						$members[] = [
							'avatar_id' => absint( $m['avatar_id'] ?? 0 ),
							'name'      => sanitize_text_field( $m['name']  ?? '' ),
							'role'      => sanitize_text_field( $m['role']  ?? '' ),
							'email'     => sanitize_email( $m['email'] ?? '' ),
							'bio'       => sanitize_textarea_field( $m['bio'] ?? '' ),
						];
					}
					$clean['members'] = $members;
					break;

				case 'timeline':
					$milestones = [];
					$valid_statuses = [ 'planned', 'active', 'completed', 'delayed' ];
					foreach ( (array) ( $seg['milestones'] ?? [] ) as $ms ) {
						$milestones[] = [
							'title'       => sanitize_text_field( $ms['title']       ?? '' ),
							'date'        => sanitize_text_field( $ms['date']        ?? '' ),
							'status'      => in_array( $ms['status'] ?? '', $valid_statuses, true )
							                    ? $ms['status'] : 'planned',
							'description' => sanitize_textarea_field( $ms['description'] ?? '' ),
						];
					}
					$clean['milestones'] = $milestones;
					break;

				case 'documents':
					$files = [];
					foreach ( (array) ( $seg['files'] ?? [] ) as $f ) {
						$files[] = [
							'file_id'     => absint( $f['file_id']     ?? 0 ),
							'label'       => sanitize_text_field( $f['label']       ?? '' ),
							'description' => sanitize_textarea_field( $f['description'] ?? '' ),
						];
					}
					$clean['files'] = $files;
					break;
			}

			$out[] = $clean;
		}
		return $out;
	}

	private static function sanitize_settings( $raw ) {
		$text_fields   = [
			'project_code', 'short_description', 'location', 'country',
			'reporting_period', 'funder_name', 'implementing_agency',
			'executing_agency', 'grant_number', 'budget_currency',
			'project_status', 'default_detail',
		];
		$date_fields   = [ 'start_date', 'end_date', 'completion_date' ];
		$number_fields = [ 'budget_total', 'grant_amount', 'cofinancing', 'disbursement', 'word_limit' ];
		$bool_fields   = [ 'show_header' ];
		$url_fields    = [ 'website' ];

		$out = [];
		foreach ( $text_fields   as $f ) $out[ $f ] = sanitize_text_field( $raw[ $f ] ?? '' );
		foreach ( $date_fields    as $f ) $out[ $f ] = sanitize_text_field( $raw[ $f ] ?? '' );
		foreach ( $number_fields  as $f ) $out[ $f ] = floatval( $raw[ $f ] ?? 0 );
		foreach ( $bool_fields    as $f ) $out[ $f ] = ! empty( $raw[ $f ] ) ? 1 : 0;
		foreach ( $url_fields     as $f ) $out[ $f ] = esc_url_raw( $raw[ $f ] ?? '' );
		return $out;
	}
}
