=== ProjectLens ===
Contributors:       BhoomiTech Heritage and Development Foundation
Tags:               project management, portfolio, custom post type, segments, funding
Version:            2.1.0
Requires at least:  6.0
Tested up to:       7.0
Requires PHP:       8.0
Stable tag:         2.1.0
License:            GPL-2.0-or-later
License URI:        https://www.gnu.org/licenses/gpl-2.0.html

A full-featured development project showcase plugin with flexible segments, funding metadata, and an interactive 70/30 split layout.
