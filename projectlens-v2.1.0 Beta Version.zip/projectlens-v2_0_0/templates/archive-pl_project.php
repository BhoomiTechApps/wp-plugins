<?php
/**
 * ProjectLens — Archive template for pl_project
 * Bypasses the active theme entirely, mirrors the single template approach.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$global          = get_option( 'pl_global', [] );
$per_page        = max( 1, (int) ( $global['per_page']          ?? 12 ) );
$show_cat_filter = (bool) ( $global['show_cat_filter']          ?? 1  );
$show_sts_filter = (bool) ( $global['show_status_filter']       ?? 0  );
$accent          = $global['default_accent']                    ?? '#2563eb';
$radius          = (int) ( $global['default_border_radius']     ?? 8  );
$font_size       = (int) ( $global['default_font_size']         ?? 15 );

// ── Active filters from query string ──────────────────────────────────────
$active_cat = sanitize_key( wp_unslash( $_GET['pl_cat']    ?? '' ) );
$active_sts = sanitize_key( wp_unslash( $_GET['pl_status'] ?? '' ) );
$paged      = max( 1, get_query_var( 'paged', 1 ) );

// ── Build query ───────────────────────────────────────────────────────────
$tax_query = [ 'relation' => 'AND' ];
if ( $active_cat ) {
    $tax_query[] = [
        'taxonomy' => 'pl_category',
        'field'    => 'slug',
        'terms'    => $active_cat,
    ];
}
if ( $active_sts ) {
    $tax_query[] = [
        'taxonomy' => 'pl_status',
        'field'    => 'slug',
        'terms'    => $active_sts,
    ];
}

$args = [
    'post_type'      => 'pl_project',
    'post_status'    => 'publish',
    'posts_per_page' => $per_page,
    'paged'          => $paged,
    'orderby'        => 'date',
    'order'          => 'DESC',
];
if ( count( $tax_query ) > 1 ) {
    $args['tax_query'] = $tax_query;
}

$query      = new WP_Query( $args );
$site_name  = get_bloginfo( 'name' );
$categories = $show_cat_filter ? get_terms( [ 'taxonomy' => 'pl_category', 'hide_empty' => true ] ) : [];
$statuses   = $show_sts_filter ? get_terms( [ 'taxonomy' => 'pl_status',   'hide_empty' => true ] ) : [];

// ── Filter URL helper ─────────────────────────────────────────────────────
function pl_archive_filter_url( $cat_slug, $sts_slug ) {
    $base = get_post_type_archive_link( 'pl_project' );
    $args = [];
    if ( $cat_slug ) $args['pl_cat']    = $cat_slug;
    if ( $sts_slug ) $args['pl_status'] = $sts_slug;
    return $args ? add_query_arg( $args, $base ) : $base;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php esc_html_e( 'All Projects', 'projectlens' ); ?> — <?php echo esc_html( $site_name ); ?></title>
<style>
:root {
    --pl-accent:   <?php echo esc_attr( $accent ); ?>;
    --pl-heading:  #111827;
    --pl-body:     #374151;
    --pl-bg:       #f3f4f6;
    --pl-panel-bg: #ffffff;
    --pl-border:   #e5e7eb;
    --pl-radius:   <?php echo $radius; ?>px;
    --pl-font-size:<?php echo $font_size; ?>px;
    --pl-h-size:   20px;
    --pl-font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}
</style>
<?php wp_head(); ?>
</head>
<body class="pl-project-page pl-archive-page">

<!-- Top bar (mirrors single template) -->
<div class="pl-topbar">
    <?php PL_Nav_Menu::render( 'archive' ); ?>
    <span class="pl-site-name"><?php echo esc_html( $site_name ); ?></span>
</div>

<!-- Archive header -->
<div class="pl-archive-header">
    <h1 class="pl-archive-header__title">
        <?php esc_html_e( 'All Projects', 'projectlens' ); ?>
        <?php if ( $query->found_posts ) : ?>
            <span class="pl-archive-count"><?php echo (int) $query->found_posts; ?></span>
        <?php endif; ?>
    </h1>

    <?php if ( $categories || $statuses ) : ?>
    <div class="pl-filter-bar">

        <?php if ( $categories ) : ?>
        <div class="pl-filter-group">
            <a href="<?php echo esc_url( pl_archive_filter_url( '', $active_sts ) ); ?>"
               class="pl-filter-pill <?php echo ! $active_cat ? 'pl-filter-pill--active' : ''; ?>">
                <?php esc_html_e( 'All', 'projectlens' ); ?>
            </a>
            <?php foreach ( $categories as $cat ) : ?>
            <a href="<?php echo esc_url( pl_archive_filter_url( $cat->slug, $active_sts ) ); ?>"
               class="pl-filter-pill <?php echo $active_cat === $cat->slug ? 'pl-filter-pill--active' : ''; ?>">
                <?php echo esc_html( $cat->name ); ?>
                <span class="pl-filter-count"><?php echo (int) $cat->count; ?></span>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if ( $statuses ) : ?>
        <div class="pl-filter-group pl-filter-group--status">
            <?php foreach ( $statuses as $sts ) : ?>
            <a href="<?php echo esc_url( pl_archive_filter_url( $active_cat, $active_sts === $sts->slug ? '' : $sts->slug ) ); ?>"
               class="pl-filter-pill pl-filter-pill--status pl-status--<?php echo esc_attr( $sts->slug ); ?> <?php echo $active_sts === $sts->slug ? 'pl-filter-pill--active' : ''; ?>">
                <?php echo esc_html( $sts->name ); ?>
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

    </div>
    <?php endif; ?>
</div>

<!-- Project grid -->
<main class="pl-archive-main">

    <?php if ( $query->have_posts() ) : ?>
    <div class="pl-project-grid">
        <?php while ( $query->have_posts() ) : $query->the_post();
            $pid      = get_the_ID();
            $settings = get_post_meta( $pid, '_pl_project_settings', true ) ?: [];
            $styling  = get_post_meta( $pid, '_pl_styling',          true ) ?: [];
            $card_accent  = $styling['accent_color']  ?: $accent;
            $card_radius  = $styling['border_radius'] ?: $radius;
            $thumb        = get_the_post_thumbnail_url( $pid, 'medium' );
            $status_val   = $settings['project_status'] ?? '';
            $short_desc   = $settings['short_description'] ?? '';
            $location     = $settings['location'] ?? '';
            $funder       = $settings['funder_name'] ?? '';
            $start        = $settings['start_date'] ?? '';
            $end          = $settings['end_date'] ?? '';
            $permalink    = get_permalink( $pid );
            // Category terms for this post
            $post_cats = get_the_terms( $pid, 'pl_category' );
        ?>
        <article class="pl-card" style="--pl-card-accent:<?php echo esc_attr( $card_accent ); ?>;--pl-card-radius:<?php echo (int) $card_radius; ?>px;">

            <!-- Thumbnail -->
            <a href="<?php echo esc_url( $permalink ); ?>" class="pl-card__thumb-wrap" tabindex="-1" aria-hidden="true">
                <?php if ( $thumb ) : ?>
                    <img src="<?php echo esc_url( $thumb ); ?>"
                         alt="<?php echo esc_attr( get_the_title() ); ?>"
                         class="pl-card__thumb" loading="lazy">
                <?php else : ?>
                    <div class="pl-card__thumb pl-card__thumb--placeholder"></div>
                <?php endif; ?>
                <?php if ( $status_val ) : ?>
                    <span class="pl-card__status-badge pl-status--<?php echo esc_attr( $status_val ); ?>">
                        <?php echo esc_html( ucfirst( $status_val ) ); ?>
                    </span>
                <?php endif; ?>
            </a>

            <!-- Body -->
            <div class="pl-card__body">

                <!-- Categories -->
                <?php if ( $post_cats && ! is_wp_error( $post_cats ) ) : ?>
                <div class="pl-card__cats">
                    <?php foreach ( $post_cats as $pcat ) : ?>
                    <a href="<?php echo esc_url( pl_archive_filter_url( $pcat->slug, $active_sts ) ); ?>"
                       class="pl-card__cat-tag">
                        <?php echo esc_html( $pcat->name ); ?>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <h2 class="pl-card__title">
                    <a href="<?php echo esc_url( $permalink ); ?>"><?php the_title(); ?></a>
                </h2>

                <?php if ( $short_desc ) : ?>
                <p class="pl-card__desc"><?php echo esc_html( wp_strip_all_tags( $short_desc ) ); ?></p>
                <?php endif; ?>

                <!-- Meta row -->
                <div class="pl-card__meta">
                    <?php if ( $location ) : ?>
                    <span class="pl-card__meta-item">📍 <?php echo esc_html( $location ); ?></span>
                    <?php endif; ?>
                    <?php if ( $funder ) : ?>
                    <span class="pl-card__meta-item">🏛 <?php echo esc_html( $funder ); ?></span>
                    <?php endif; ?>
                    <?php if ( $start || $end ) : ?>
                    <span class="pl-card__meta-item">
                        📅 <?php echo esc_html( $start ); ?><?php if ( $start && $end ) echo ' – '; ?><?php echo esc_html( $end ); ?>
                    </span>
                    <?php endif; ?>
                </div>

                <a href="<?php echo esc_url( $permalink ); ?>" class="pl-card__cta">
                    <?php esc_html_e( 'View Project', 'projectlens' ); ?> →
                </a>

            </div><!-- /.pl-card__body -->
        </article>
        <?php endwhile; wp_reset_postdata(); ?>
    </div><!-- /.pl-project-grid -->

    <!-- Pagination -->
    <?php if ( $query->max_num_pages > 1 ) :
        $base_url = get_post_type_archive_link( 'pl_project' );
        $filter_args = [];
        if ( $active_cat ) $filter_args['pl_cat']    = $active_cat;
        if ( $active_sts ) $filter_args['pl_status'] = $active_sts;
    ?>
    <nav class="pl-pagination" aria-label="<?php esc_attr_e( 'Projects pagination', 'projectlens' ); ?>">
        <?php for ( $p = 1; $p <= $query->max_num_pages; $p++ ) :
            $page_url = $p === 1
                ? ( $filter_args ? add_query_arg( $filter_args, $base_url ) : $base_url )
                : add_query_arg( array_merge( $filter_args, [ 'paged' => $p ] ), $base_url );
        ?>
        <a href="<?php echo esc_url( $page_url ); ?>"
           class="pl-pagination__btn <?php echo $p === $paged ? 'pl-pagination__btn--active' : ''; ?>">
            <?php echo (int) $p; ?>
        </a>
        <?php endfor; ?>
    </nav>
    <?php endif; ?>

    <?php else : ?>
    <div class="pl-archive-empty">
        <p><?php esc_html_e( 'No projects found.', 'projectlens' ); ?></p>
        <?php if ( $active_cat || $active_sts ) : ?>
        <a href="<?php echo esc_url( get_post_type_archive_link( 'pl_project' ) ); ?>" class="pl-archive-reset">
            <?php esc_html_e( '← Clear filters', 'projectlens' ); ?>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>

</main>

<?php wp_footer(); ?>
</body>
</html>
