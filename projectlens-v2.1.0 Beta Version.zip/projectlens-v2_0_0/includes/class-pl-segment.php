<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Segment {

    // -------------------------------------------------------------------------
    // Segment type registry
    // -------------------------------------------------------------------------

    public static function get_type_labels() {
        return [
            'descriptive' => __( 'Descriptive',           'projectlens' ),
            'media'       => __( 'Media Slider',           'projectlens' ),
            'metadata'    => __( 'Project Metadata',       'projectlens' ),
            'team'        => __( 'Team & Stakeholders',    'projectlens' ),
            'timeline'    => __( 'Timeline & Milestones',  'projectlens' ),
            'documents'   => __( 'Documents & Downloads',  'projectlens' ),
        ];
    }

    public static function get_default_segment( $type ) {
        $base = [
            'id'      => uniqid( 'seg_' ),
            'type'    => $type,
            'title'   => '',
            'enabled' => true,
        ];
        switch ( $type ) {
            case 'descriptive':
                return array_merge( $base, [ 'subtitle' => '', 'content' => '', 'detail_content' => '' ] );
            case 'media':
                return array_merge( $base, [ 'slides' => [] ] );
            case 'metadata':
                return array_merge( $base, [ 'fields' => [] ] );
            case 'team':
                return array_merge( $base, [ 'members' => [] ] );
            case 'timeline':
                return array_merge( $base, [ 'milestones' => [] ] );
            case 'documents':
                return array_merge( $base, [ 'files' => [] ] );
        }
        return $base;
    }

    // -------------------------------------------------------------------------
    // Admin: render segment editor row
    // -------------------------------------------------------------------------

    public static function render_admin_segment( $segment, $index ) {
        $type   = $segment['type']  ?? 'descriptive';
        $title  = $segment['title'] ?? '';
        $id     = $segment['id']    ?? uniqid( 'seg_' );
        $enabled = isset( $segment['enabled'] ) ? (bool) $segment['enabled'] : true;
        $collapsed = ! empty( $segment['collapsed'] );
        $labels = self::get_type_labels();
        $type_label = $labels[ $type ] ?? ucfirst( $type );
        ?>
        <div class="pl-segment-row<?php echo $collapsed ? ' pl-collapsed' : ''; ?>" data-index="<?php echo esc_attr( $index ); ?>" data-type="<?php echo esc_attr( $type ); ?>">
            <div class="pl-segment-header">
                <span class="pl-drag-handle dashicons dashicons-menu" title="Drag to reorder"></span>
                <span class="pl-segment-type-badge"><?php echo esc_html( $type_label ); ?></span>
                <input type="text"
                       name="pl_segments[<?php echo absint( $index ); ?>][title]"
                       value="<?php echo esc_attr( $title ); ?>"
                       placeholder="<?php esc_attr_e( 'Segment Title', 'projectlens' ); ?>"
                       class="pl-segment-title-input" />
                <label class="pl-toggle-label">
                    <input type="checkbox"
                           name="pl_segments[<?php echo absint( $index ); ?>][enabled]"
                           value="1"
                           <?php checked( $enabled ); ?> />
                    <?php esc_html_e( 'Visible', 'projectlens' ); ?>
                </label>
                <button type="button" class="pl-btn-collapse button-link">
                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                </button>
                <button type="button" class="pl-btn-delete button-link">
                    <span class="dashicons dashicons-trash"></span>
                </button>
                <input type="hidden" name="pl_segments[<?php echo absint( $index ); ?>][id]"   value="<?php echo esc_attr( $id ); ?>" />
                <input type="hidden" name="pl_segments[<?php echo absint( $index ); ?>][type]" value="<?php echo esc_attr( $type ); ?>" />
                <input type="hidden" name="pl_segments[<?php echo absint( $index ); ?>][collapsed]" value="<?php echo $collapsed ? '1' : '0'; ?>" class="pl-collapsed-input" />
            </div>

            <div class="pl-segment-body">
                <?php self::render_admin_segment_fields( $segment, $index ); ?>
            </div>
        </div>
        <?php
    }

    private static function render_admin_segment_fields( $segment, $index ) {
        $type = $segment['type'] ?? 'descriptive';
        $n    = "pl_segments[$index]";

        switch ( $type ) {

            // -----------------------------------------------------------------
            case 'descriptive':
                ?>
                <p>
                    <label><?php esc_html_e( 'Sub-title', 'projectlens' ); ?></label>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[subtitle]"
                           value="<?php echo esc_attr( $segment['subtitle'] ?? '' ); ?>" class="widefat" />
                </p>
                <p>
                    <label><?php esc_html_e( 'Summary Content (shown truncated in left panel)', 'projectlens' ); ?></label>
                    <?php
                    wp_editor(
                        wp_kses_post( $segment['content'] ?? '' ),
                        'pl_seg_' . ( $segment['id'] ?? $index ) . '_content',
                        [
                            'textarea_name' => "{$n}[content]",
                            'textarea_rows' => 6,
                            'media_buttons' => false,
                            'teeny'         => false,
                            'tinymce'       => [
                                'toolbar1' => 'formatselect,bold,italic,underline,|,alignleft,aligncenter,alignright,alignjustify,|,bullist,numlist,|,link,unlink,|,undo,redo',
                                'toolbar2' => '',
                            ],
                        ]
                    );
                    ?>
                </p>
                <p>
                    <label><?php esc_html_e( 'Detail Content (shown in right panel on "Show Detail")', 'projectlens' ); ?></label>
                    <?php
                    wp_editor(
                        wp_kses_post( $segment['detail_content'] ?? '' ),
                        'pl_seg_' . ( $segment['id'] ?? $index ) . '_detail',
                        [
                            'textarea_name' => "{$n}[detail_content]",
                            'textarea_rows' => 8,
                            'media_buttons' => true,
                            'teeny'         => false,
                            'tinymce'       => [
                                'toolbar1' => 'bold,italic,underline,|,alignleft,aligncenter,alignright,alignjustify,|,forecolor,|,bullist,numlist,|,link,unlink,|,undo,redo',
                                'toolbar2' => 'strikethrough,blockquote,hr,|,pastetext,removeformat,|,charmap,|,outdent,indent,|,wp_help',
                                'plugins'  => 'charmap,colorpicker,hr,lists,paste,tabfocus,textcolor,wordpress,wpautoresize,wpeditimage,wpgallery,wplink,wptextpattern',
                            ],
                        ]
                    );
                    ?>
                </p>
                <?php
                break;

            // -----------------------------------------------------------------
            case 'media':
                $slides = $segment['slides'] ?? [];
                ?>
                <div class="pl-slides-list" data-segment-index="<?php echo absint( $index ); ?>">
                    <?php foreach ( $slides as $si => $slide ) :
                        self::render_admin_slide( $slide, $index, $si );
                    endforeach; ?>
                </div>
                <button type="button" class="pl-btn-add-slide button" data-segment="<?php echo absint( $index ); ?>">
                    + <?php esc_html_e( 'Add Slide', 'projectlens' ); ?>
                </button>
                <?php
                break;

            // -----------------------------------------------------------------
            case 'metadata':
                $fields = $segment['fields'] ?? [];
                ?>
                <div class="pl-meta-fields-list" data-segment-index="<?php echo absint( $index ); ?>">
                    <?php foreach ( $fields as $fi => $field ) :
                        self::render_admin_meta_field( $field, $index, $fi );
                    endforeach; ?>
                </div>
                <button type="button" class="pl-btn-add-meta-field button" data-segment="<?php echo absint( $index ); ?>">
                    + <?php esc_html_e( 'Add Field', 'projectlens' ); ?>
                </button>
                <?php
                break;

            // -----------------------------------------------------------------
            case 'team':
                $members = $segment['members'] ?? [];
                ?>
                <div class="pl-team-list" data-segment-index="<?php echo absint( $index ); ?>">
                    <?php foreach ( $members as $mi => $member ) :
                        self::render_admin_team_member( $member, $index, $mi );
                    endforeach; ?>
                </div>
                <button type="button" class="pl-btn-add-member button" data-segment="<?php echo absint( $index ); ?>">
                    + <?php esc_html_e( 'Add Member', 'projectlens' ); ?>
                </button>
                <?php
                break;

            // -----------------------------------------------------------------
            case 'timeline':
                $milestones = $segment['milestones'] ?? [];
                ?>
                <div class="pl-milestone-list" data-segment-index="<?php echo absint( $index ); ?>">
                    <?php foreach ( $milestones as $mi => $ms ) :
                        self::render_admin_milestone( $ms, $index, $mi );
                    endforeach; ?>
                </div>
                <button type="button" class="pl-btn-add-milestone button" data-segment="<?php echo absint( $index ); ?>">
                    + <?php esc_html_e( 'Add Milestone', 'projectlens' ); ?>
                </button>
                <?php
                break;

            // -----------------------------------------------------------------
            case 'documents':
                $files = $segment['files'] ?? [];
                ?>
                <div class="pl-files-list" data-segment-index="<?php echo absint( $index ); ?>">
                    <?php foreach ( $files as $fi => $file ) :
                        self::render_admin_file( $file, $index, $fi );
                    endforeach; ?>
                </div>
                <button type="button" class="pl-btn-add-file button" data-segment="<?php echo absint( $index ); ?>">
                    + <?php esc_html_e( 'Add File', 'projectlens' ); ?>
                </button>
                <?php
                break;
        }
    }

    // -------------------------------------------------------------------------
    // Admin sub-item renderers
    // -------------------------------------------------------------------------

    public static function render_admin_slide( $slide, $seg_index, $slide_index ) {
        $n = "pl_segments[$seg_index][slides][$slide_index]";
        ?>
        <div class="pl-slide-row pl-sub-row">
            <span class="pl-drag-handle dashicons dashicons-menu"></span>
            <div class="pl-sub-fields">
                <div class="pl-media-row">
                    <input type="hidden" name="<?php echo esc_attr( $n ); ?>[media_id]"
                           value="<?php echo esc_attr( $slide['media_id'] ?? '' ); ?>"
                           class="pl-media-id" />
                    <img src="<?php echo esc_url( $slide['media_id'] ? wp_get_attachment_image_url( $slide['media_id'], 'thumbnail' ) : '' ); ?>"
                         class="pl-media-preview" style="max-width:80px;<?php echo empty( $slide['media_id'] ) ? 'display:none;' : ''; ?>" />
                    <button type="button" class="pl-btn-select-media button button-small">
                        <?php esc_html_e( 'Select Image/Video', 'projectlens' ); ?>
                    </button>
                    <button type="button" class="pl-btn-remove-media button-link" style="<?php echo empty( $slide['media_id'] ) ? 'display:none;' : ''; ?>">
                        <?php esc_html_e( 'Remove', 'projectlens' ); ?>
                    </button>
                </div>
                <p>
                    <label><?php esc_html_e( 'Media Type', 'projectlens' ); ?></label>
                    <select name="<?php echo esc_attr( $n ); ?>[media_type]">
                        <option value="image" <?php selected( $slide['media_type'] ?? 'image', 'image' ); ?>><?php esc_html_e( 'Image', 'projectlens' ); ?></option>
                        <option value="video" <?php selected( $slide['media_type'] ?? '', 'video' ); ?>><?php esc_html_e( 'Video', 'projectlens' ); ?></option>
                        <option value="video_url" <?php selected( $slide['media_type'] ?? '', 'video_url' ); ?>><?php esc_html_e( 'External Video URL', 'projectlens' ); ?></option>
                    </select>
                </p>
                <p class="pl-video-url-row" style="<?php echo ( ($slide['media_type'] ?? '') === 'video_url' ) ? '' : 'display:none;'; ?>">
                    <label><?php esc_html_e( 'Video URL (YouTube / Vimeo)', 'projectlens' ); ?></label>
                    <input type="url" name="<?php echo esc_attr( $n ); ?>[video_url]"
                           value="<?php echo esc_url( $slide['video_url'] ?? '' ); ?>" class="widefat" />
                </p>
                <p>
                    <label><?php esc_html_e( 'Caption', 'projectlens' ); ?></label>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[caption]"
                           value="<?php echo esc_attr( $slide['caption'] ?? '' ); ?>" class="widefat" />
                </p>
                <p>
                    <label><?php esc_html_e( 'Description', 'projectlens' ); ?></label>
                    <textarea name="<?php echo esc_attr( $n ); ?>[description]" rows="2" class="widefat"><?php echo esc_textarea( $slide['description'] ?? '' ); ?></textarea>
                </p>
                <div class="pl-geo-fields">
                    <label><?php esc_html_e( 'Geo-location', 'projectlens' ); ?></label>
                    <div class="pl-geo-row">
                        <input type="text" name="<?php echo esc_attr( $n ); ?>[geo_lat]"
                               value="<?php echo esc_attr( $slide['geo_lat'] ?? '' ); ?>"
                               placeholder="Latitude" style="width:45%;" />
                        <input type="text" name="<?php echo esc_attr( $n ); ?>[geo_lng]"
                               value="<?php echo esc_attr( $slide['geo_lng'] ?? '' ); ?>"
                               placeholder="Longitude" style="width:45%;" />
                    </div>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[geo_label]"
                           value="<?php echo esc_attr( $slide['geo_label'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Location label (e.g. Site Alpha, Dhemaji District)', 'projectlens' ); ?>"
                           class="widefat" />
                </div>
            </div>
            <button type="button" class="pl-btn-delete-sub button-link">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
        <?php
    }

    public static function render_admin_meta_field( $field, $seg_index, $field_index ) {
        $n = "pl_segments[$seg_index][fields][$field_index]";
        ?>
        <div class="pl-meta-field-row pl-sub-row">
            <span class="pl-drag-handle dashicons dashicons-menu"></span>
            <input type="text" name="<?php echo esc_attr( $n ); ?>[label]"
                   value="<?php echo esc_attr( $field['label'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Field Label', 'projectlens' ); ?>"
                   style="width:30%;" />
            <input type="text" name="<?php echo esc_attr( $n ); ?>[value]"
                   value="<?php echo esc_attr( $field['value'] ?? '' ); ?>"
                   placeholder="<?php esc_attr_e( 'Field Value', 'projectlens' ); ?>"
                   style="width:55%;" />
            <button type="button" class="pl-btn-delete-sub button-link">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
        <?php
    }

    public static function render_admin_team_member( $member, $seg_index, $m_index ) {
        $n = "pl_segments[$seg_index][members][$m_index]";
        ?>
        <div class="pl-member-row pl-sub-row">
            <span class="pl-drag-handle dashicons dashicons-menu"></span>
            <div class="pl-sub-fields">
                <div class="pl-media-row">
                    <input type="hidden" name="<?php echo esc_attr( $n ); ?>[avatar_id]"
                           value="<?php echo esc_attr( $member['avatar_id'] ?? '' ); ?>"
                           class="pl-media-id" />
                    <img src="<?php echo esc_url( !empty($member['avatar_id']) ? wp_get_attachment_image_url( $member['avatar_id'], 'thumbnail' ) : '' ); ?>"
                         class="pl-media-preview" style="max-width:60px;border-radius:50%;<?php echo empty($member['avatar_id']) ? 'display:none;' : ''; ?>" />
                    <button type="button" class="pl-btn-select-media button button-small">
                        <?php esc_html_e( 'Select Photo', 'projectlens' ); ?>
                    </button>
                    <button type="button" class="pl-btn-remove-media button-link" style="<?php echo empty($member['avatar_id']) ? 'display:none;' : ''; ?>">
                        <?php esc_html_e( 'Remove Photo', 'projectlens' ); ?>
                    </button>
                </div>
                <p>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[name]"
                           value="<?php echo esc_attr( $member['name'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Full Name', 'projectlens' ); ?>" class="widefat" />
                </p>
                <p>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[role]"
                           value="<?php echo esc_attr( $member['role'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Role / Title', 'projectlens' ); ?>" class="widefat" />
                </p>
                <p>
                    <input type="email" name="<?php echo esc_attr( $n ); ?>[email]"
                           value="<?php echo esc_attr( $member['email'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Email', 'projectlens' ); ?>" class="widefat" />
                </p>
                <p>
                    <textarea name="<?php echo esc_attr( $n ); ?>[bio]" rows="2" class="widefat"
                              placeholder="<?php esc_attr_e( 'Short bio…', 'projectlens' ); ?>"><?php echo esc_textarea( $member['bio'] ?? '' ); ?></textarea>
                </p>
            </div>
            <button type="button" class="pl-btn-delete-sub button-link">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
        <?php
    }

    public static function render_admin_milestone( $ms, $seg_index, $m_index ) {
        $n = "pl_segments[$seg_index][milestones][$m_index]";
        $statuses = [ 'planned' => 'Planned', 'active' => 'Active', 'completed' => 'Completed', 'delayed' => 'Delayed' ];
        ?>
        <div class="pl-milestone-row pl-sub-row">
            <span class="pl-drag-handle dashicons dashicons-menu"></span>
            <div class="pl-sub-fields">
                <p>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[title]"
                           value="<?php echo esc_attr( $ms['title'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Milestone Title', 'projectlens' ); ?>" class="widefat" />
                </p>
                <div style="display:flex;gap:10px;">
                    <input type="date" name="<?php echo esc_attr( $n ); ?>[date]"
                           value="<?php echo esc_attr( $ms['date'] ?? '' ); ?>" />
                    <select name="<?php echo esc_attr( $n ); ?>[status]">
                        <?php foreach ( $statuses as $val => $label ) : ?>
                            <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $ms['status'] ?? 'planned', $val ); ?>>
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <p>
                    <textarea name="<?php echo esc_attr( $n ); ?>[description]" rows="2" class="widefat"
                              placeholder="<?php esc_attr_e( 'Description…', 'projectlens' ); ?>"><?php echo esc_textarea( $ms['description'] ?? '' ); ?></textarea>
                </p>
            </div>
            <button type="button" class="pl-btn-delete-sub button-link">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
        <?php
    }

    public static function render_admin_file( $file, $seg_index, $f_index ) {
        $n = "pl_segments[$seg_index][files][$f_index]";
        ?>
        <div class="pl-file-row pl-sub-row">
            <span class="pl-drag-handle dashicons dashicons-menu"></span>
            <div class="pl-sub-fields">
                <div class="pl-media-row">
                    <input type="hidden" name="<?php echo esc_attr( $n ); ?>[file_id]"
                           value="<?php echo esc_attr( $file['file_id'] ?? '' ); ?>"
                           class="pl-media-id" />
                    <span class="pl-file-name"><?php
                        if ( !empty($file['file_id']) ) {
                            echo esc_html( get_the_title( $file['file_id'] ) );
                        }
                    ?></span>
                    <button type="button" class="pl-btn-select-file button button-small" data-library="application">
                        <?php esc_html_e( 'Select File', 'projectlens' ); ?>
                    </button>
                    <button type="button" class="pl-btn-remove-file button-link" style="<?php echo empty($file['file_id']) ? 'display:none;' : ''; ?>">
                        <?php esc_html_e( 'Remove File', 'projectlens' ); ?>
                    </button>
                </div>
                <p>
                    <input type="text" name="<?php echo esc_attr( $n ); ?>[label]"
                           value="<?php echo esc_attr( $file['label'] ?? '' ); ?>"
                           placeholder="<?php esc_attr_e( 'Display Name (optional)', 'projectlens' ); ?>" class="widefat" />
                </p>
                <p>
                    <textarea name="<?php echo esc_attr( $n ); ?>[description]" rows="2" class="widefat"
                              placeholder="<?php esc_attr_e( 'Short description…', 'projectlens' ); ?>"><?php echo esc_textarea( $file['description'] ?? '' ); ?></textarea>
                </p>
                <p style="display:flex;gap:20px;margin-top:4px;">
                    <label>
                        <input type="hidden" name="<?php echo esc_attr( $n ); ?>[allow_download]" value="0" />
                        <input type="checkbox" name="<?php echo esc_attr( $n ); ?>[allow_download]" value="1"
                               <?php checked( $file['allow_download'] ?? 1 ); ?> />
                        <?php esc_html_e( 'Enable Download Button', 'projectlens' ); ?>
                    </label>
                    <label>
                        <input type="hidden" name="<?php echo esc_attr( $n ); ?>[allow_viewer]" value="0" />
                        <input type="checkbox" name="<?php echo esc_attr( $n ); ?>[allow_viewer]" value="1"
                               <?php checked( $file['allow_viewer'] ?? 1 ); ?> />
                        <?php esc_html_e( 'Enable Document Viewer', 'projectlens' ); ?>
                    </label>
                </p>
            </div>
            <button type="button" class="pl-btn-delete-sub button-link">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Frontend renderers — Summary panel (left, 70%)
    // -------------------------------------------------------------------------

    public static function render_summary_segment( $segment, $word_limit = 60 ) {
        if ( empty( $segment['enabled'] ) ) return;
        $type  = $segment['type'] ?? 'descriptive';
        $title = $segment['title'] ?? '';
        $id    = $segment['id']   ?? '';
        ?>
        <div class="pl-seg pl-seg--<?php echo esc_attr( $type ); ?>" data-seg-id="<?php echo esc_attr( $id ); ?>" data-seg-type="<?php echo esc_attr( $type ); ?>">
            <?php if ( $title ) : ?>
            <h3 class="pl-seg__title"><?php echo esc_html( $title ); ?></h3>
            <?php endif; ?>
            <?php
            switch ( $type ) {
                case 'descriptive': self::render_summary_descriptive( $segment, $word_limit ); break;
                case 'media':       self::render_summary_media( $segment );       break;
                case 'metadata':    self::render_summary_metadata( $segment );    break;
                case 'team':        self::render_summary_team( $segment );        break;
                case 'timeline':    self::render_summary_timeline( $segment );    break;
                case 'documents':   self::render_summary_documents( $segment );   break;
            }
            ?>
        </div>
        <?php
    }

    private static function render_summary_descriptive( $segment, $word_limit ) {
        $subtitle = $segment['subtitle'] ?? '';
        $content  = $segment['content']  ?? '';
        $words    = wp_strip_all_tags( $content );
        $truncated = wp_trim_words( $words, $word_limit, '…' );
        ?>
        <?php if ( $subtitle ) : ?>
        <p class="pl-seg__subtitle"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>
        <div class="pl-seg__summary-text"><?php echo esc_html( $truncated ); ?></div>
        <button type="button" class="pl-btn-show-detail"
                data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                data-seg-type="descriptive">
            <?php esc_html_e( 'Show Detail', 'projectlens' ); ?>
            <span class="pl-arrow">→</span>
        </button>
        <?php
    }

    private static function render_summary_media( $segment ) {
        $slides = $segment['slides'] ?? [];
        if ( empty( $slides ) ) return;
        ?>
        <div class="pl-slider" data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>">
            <div class="pl-slider__track">
                <?php foreach ( $slides as $si => $slide ) :
                    $media_type = $slide['media_type'] ?? 'image';
                    $media_id   = $slide['media_id']   ?? '';
                    $video_url  = $slide['video_url']  ?? '';
                    $caption    = $slide['caption']    ?? '';
                    $thumb_url  = '';
                    if ( $media_id ) {
                        $thumb_url = wp_get_attachment_image_url( $media_id, 'medium' );
                    }
                    // For video_url slides without a media_id, fetch the video's own thumbnail
                    $is_video = ( $media_type === 'video' || $media_type === 'video_url' );
                    if ( ! $thumb_url && $media_type === 'video_url' && $video_url ) {
                        $thumb_url = self::get_video_thumbnail_url( $video_url );
                    }
                    $show_thumb = $thumb_url || $is_video;
                    ?>
                    <div class="pl-slide" data-slide-index="<?php echo absint( $si ); ?>">
                        <?php if ( $show_thumb ) : ?>
                        <div class="pl-slide__thumb"
                             data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                             data-slide-index="<?php echo absint( $si ); ?>"
                             data-seg-type="media"
                             style="cursor:pointer;">
                            <?php if ( $is_video ) : ?>
                            <span class="pl-play-icon">▶</span>
                            <?php endif; ?>
                            <?php if ( $thumb_url ) : ?>
                            <img src="<?php echo esc_url( $thumb_url ); ?>"
                                 alt="<?php echo esc_attr( $caption ); ?>" />
                            <?php elseif ( $is_video ) : ?>
                            <div class="pl-video-placeholder" style="background:var(--pl-border);border-radius:var(--pl-radius);width:120px;height:80px;display:flex;align-items:center;justify-content:center;font-size:28px;">🎬</div>
                            <?php endif; ?>
                            <?php if ( $caption ) : ?>
                            <p class="pl-slide__caption"><?php echo esc_html( $caption ); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Extract a thumbnail URL from a YouTube or Vimeo URL.
     * Returns empty string if not recognised.
     */
    private static function get_video_thumbnail_url( $video_url ) {
        if ( empty( $video_url ) ) return '';

        // YouTube – standard, short, embed variants
        if ( preg_match(
            '/(?:youtube\.com\/(?:watch\?v=|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/',
            $video_url, $m
        ) ) {
            return 'https://img.youtube.com/vi/' . $m[1] . '/hqdefault.jpg';
        }

        // Vimeo – use their oEmbed thumbnail endpoint (cached via transient)
        if ( preg_match( '/vimeo\.com\/(?:video\/)?(\d+)/', $video_url, $m ) ) {
            $transient_key = 'pl_vimeo_thumb_' . $m[1];
            $cached = get_transient( $transient_key );
            if ( $cached ) return $cached;

            $response = wp_remote_get(
                'https://vimeo.com/api/oembed.json?url=' . rawurlencode( $video_url ),
                [ 'timeout' => 5 ]
            );
            if ( ! is_wp_error( $response ) ) {
                $body = json_decode( wp_remote_retrieve_body( $response ), true );
                if ( ! empty( $body['thumbnail_url'] ) ) {
                    set_transient( $transient_key, $body['thumbnail_url'], DAY_IN_SECONDS );
                    return $body['thumbnail_url'];
                }
            }
        }

        return '';
    }

    private static function render_summary_metadata( $segment ) {
        $fields = $segment['fields'] ?? [];
        if ( empty( $fields ) ) return;
        ?>
        <dl class="pl-meta-table">
            <?php foreach ( array_slice( $fields, 0, 5 ) as $field ) : ?>
            <div class="pl-meta-table__row">
                <dt><?php echo esc_html( $field['label'] ?? '' ); ?></dt>
                <dd><?php echo esc_html( $field['value'] ?? '' ); ?></dd>
            </div>
            <?php endforeach; ?>
        </dl>
        <?php if ( count($fields) > 5 ) : ?>
        <button type="button" class="pl-btn-show-detail"
                data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                data-seg-type="metadata">
            <?php
            /* translators: %d: number of additional metadata fields */
            printf( esc_html__( 'Show all %d fields', 'projectlens' ), absint( count( $fields ) ) ); ?> →
        </button>
        <?php endif; ?>
        <?php
    }

    private static function render_summary_team( $segment ) {
        $members = $segment['members'] ?? [];
        ?>
        <div class="pl-team-avatars">
            <?php foreach ( $members as $mi => $member ) :
                $avatar_id = $member['avatar_id'] ?? '';
                $name      = $member['name']      ?? '';
                $role      = $member['role']      ?? '';
                ?>
                <div class="pl-team-avatars__item"
                     data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                     data-seg-type="team"
                     data-member-index="<?php echo (int) $mi; ?>"
                     style="cursor:pointer;"
                     title="<?php echo esc_attr( $name ); ?>">
                    <?php if ( $avatar_id ) : ?>
                    <?php echo wp_get_attachment_image( $avatar_id, 'thumbnail', false, ['class' => 'pl-avatar'] ); ?>
                    <?php else : ?>
                    <div class="pl-avatar pl-avatar--placeholder"><?php echo esc_html( mb_substr($name, 0, 1) ); ?></div>
                    <?php endif; ?>
                    <p class="pl-team-name"><?php echo esc_html( $name ); ?></p>
                    <p class="pl-team-role"><?php echo esc_html( $role ); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
        <?php
    }

    private static function render_summary_timeline( $segment ) {
        $milestones = $segment['milestones'] ?? [];
        ?>
        <div class="pl-timeline-compact">
            <?php foreach ( $milestones as $ms ) :
                $status = $ms['status'] ?? 'planned';
                ?>
                <div class="pl-timeline-compact__item pl-ms-status--<?php echo esc_attr( $status ); ?>">
                    <span class="pl-timeline-compact__dot"></span>
                    <span class="pl-timeline-compact__title"><?php echo esc_html( $ms['title'] ?? '' ); ?></span>
                    <span class="pl-timeline-compact__date"><?php echo esc_html( $ms['date'] ?? '' ); ?></span>
                    <span class="pl-timeline-compact__status"><?php echo esc_html( ucfirst($status) ); ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <button type="button" class="pl-btn-show-detail"
                data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                data-seg-type="timeline">
            <?php esc_html_e( 'Show Detail', 'projectlens' ); ?> →
        </button>
        <?php
    }

    private static function render_summary_documents( $segment ) {
        $files = $segment['files'] ?? [];
        $count = count( $files );
        $icons = [ 'pdf' => '📄', 'doc' => '📝', 'docx' => '📝', 'xls' => '📊', 'xlsx' => '📊', 'ppt' => '📊', 'pptx' => '📊', 'zip' => '📦', 'txt' => '📃', 'default' => '📎' ];
        ?>
        <div class="pl-docs-summary">
            <span class="pl-docs-count"><?php
                /* translators: %d: number of documents */
                printf( esc_html( _n( '%d Document', '%d Documents', $count, 'projectlens' ) ), absint( $count ) );
            ?></span>
            <div class="pl-docs-list-summary">
                <?php foreach ( $files as $fi => $file ) :
                    $file_id   = $file['file_id'] ?? '';
                    $file_url  = $file_id ? wp_get_attachment_url( $file_id ) : '';
                    $ext       = $file_id ? strtolower( pathinfo( get_attached_file($file_id), PATHINFO_EXTENSION ) ) : '';
                    $icon      = $icons[$ext] ?? $icons['default'];
                    $label     = $file['label'] ?? ( $file_id ? get_the_title($file_id) : '' );
                    if ( ! $file_url ) continue;
                    ?>
                    <div class="pl-doc-summary-item"
                         data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                         data-file-index="<?php echo (int) $fi; ?>"
                         style="cursor:pointer;display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--pl-border);">
                        <span style="font-size:18px;"><?php echo esc_html( $icon ); ?></span>
                        <span><?php echo esc_html( $label ?: basename($file_url) ); ?></span>
                        <?php if ( $ext ) : ?><span class="pl-file-ext" style="margin-left:auto;"><?php echo esc_html( strtoupper($ext) ); ?></span><?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <button type="button" class="pl-btn-show-detail"
                data-seg-id="<?php echo esc_attr( $segment['id'] ?? '' ); ?>"
                data-seg-type="documents"
                style="margin-top:8px;">
            <?php esc_html_e( 'Show All Documents', 'projectlens' ); ?> →
        </button>
        <?php
    }

    // -------------------------------------------------------------------------
    // Frontend renderers — Detail panel (right, 30%)
    // Returns full detail HTML as string for inline JS injection
    // -------------------------------------------------------------------------

    public static function render_detail_panel_html( $segment ) {
        ob_start();
        $type = $segment['type'] ?? '';
        switch ( $type ) {
            case 'descriptive': self::render_detail_descriptive( $segment ); break;
            case 'media':       self::render_detail_media( $segment );       break;
            case 'metadata':    self::render_detail_metadata( $segment );    break;
            case 'team':        self::render_detail_team( $segment );        break;
            case 'timeline':    self::render_detail_timeline( $segment );    break;
            case 'documents':   self::render_detail_documents( $segment );   break;
        }
        return ob_get_clean();
    }

    private static function render_detail_descriptive( $s ) {
        ?>
        <div class="pl-detail pl-detail--descriptive">
            <?php if ( $s['title'] ) : ?><h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ); ?></h2><?php endif; ?>
            <?php if ( $s['subtitle'] ?? '' ) : ?><p class="pl-detail__subtitle"><?php echo esc_html( $s['subtitle'] ); ?></p><?php endif; ?>
            <div class="pl-detail__body"><?php echo wp_kses_post( $s['detail_content'] ?? $s['content'] ?? '' ); ?></div>
        </div>
        <?php
    }

    private static function render_detail_media( $s ) {
        // This is called per-slide via JS; we embed all slide data as JSON
        $slides = $s['slides'] ?? [];
        ?>
        <div class="pl-detail pl-detail--media">
            <h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ?? '' ); ?></h2>
            <div class="pl-detail-media__viewer">
                <?php foreach ( $slides as $si => $slide ) :
                    $media_id   = $slide['media_id']   ?? '';
                    $media_type = $slide['media_type'] ?? 'image';
                    $video_url  = $slide['video_url']  ?? '';
                    $caption    = $slide['caption']    ?? '';
                    $desc       = $slide['description']?? '';
                    $geo_lat    = $slide['geo_lat']    ?? '';
                    $geo_lng    = $slide['geo_lng']    ?? '';
                    $geo_label  = $slide['geo_label']  ?? '';
                    $full_url   = $media_id ? wp_get_attachment_image_url( $media_id, 'large' ) : '';
                    ?>
                    <div class="pl-detail-slide" data-slide-index="<?php echo absint( $si ); ?>" style="<?php echo $si > 0 ? 'display:none;' : ''; ?>">
                        <div class="pl-detail-slide__media">
                            <?php if ( $media_type === 'image' && $full_url ) : ?>
                                <img src="<?php echo esc_url( $full_url ); ?>" alt="<?php echo esc_attr($caption); ?>" />
                            <?php elseif ( $media_type === 'video' && $media_id ) :
                                echo wp_kses_post( wp_video_shortcode( [ 'src' => wp_get_attachment_url( $media_id ) ] ) );
                            elseif ( $media_type === 'video_url' && $video_url ) : ?>
                                <div class="pl-embed-wrap"><?php echo wp_kses_post( wp_oembed_get( $video_url ) ); ?></div>
                            <?php endif; ?>
                        </div>
                        <?php if ( $caption ) : ?><p class="pl-detail-slide__caption"><strong><?php echo esc_html($caption); ?></strong></p><?php endif; ?>
                        <?php if ( $desc ) : ?><p class="pl-detail-slide__desc"><?php echo esc_html($desc); ?></p><?php endif; ?>
                        <?php if ( $geo_lat && $geo_lng ) : ?>
                        <div class="pl-geo">
                            <div class="pl-geo__map" id="pl-map-<?php echo absint( $si ); ?>"
                                 data-lat="<?php echo esc_attr($geo_lat); ?>"
                                 data-lng="<?php echo esc_attr($geo_lng); ?>"
                                 data-label="<?php echo esc_attr($geo_label); ?>"
                                 style="height:180px;border-radius:6px;margin-top:10px;"></div>
                            <p class="pl-geo__coords">
                                📍 <?php echo $geo_label ? esc_html($geo_label) . ' — ' : ''; ?>
                                <?php
                                /* translators: 1: latitude coordinate, 2: longitude coordinate */
                                printf( esc_html__( '%1$s, %2$s', 'projectlens' ), esc_html( $geo_lat ), esc_html( $geo_lng ) ); ?>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private static function render_detail_metadata( $s ) {
        $fields = $s['fields'] ?? [];
        ?>
        <div class="pl-detail pl-detail--metadata">
            <h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ?? __('Project Metadata', 'projectlens') ); ?></h2>
            <dl class="pl-meta-table pl-meta-table--full">
                <?php foreach ( $fields as $field ) : ?>
                <div class="pl-meta-table__row">
                    <dt><?php echo esc_html( $field['label'] ?? '' ); ?></dt>
                    <dd><?php echo esc_html( $field['value'] ?? '' ); ?></dd>
                </div>
                <?php endforeach; ?>
            </dl>
        </div>
        <?php
    }

    private static function render_detail_team( $s ) {
        $members = $s['members'] ?? [];
        ?>
        <div class="pl-detail pl-detail--team">
            <h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ?? __('Team & Stakeholders', 'projectlens') ); ?></h2>
            <div class="pl-team-detail">
                <?php foreach ( $members as $m ) : ?>
                <div class="pl-team-detail__card">
                    <?php if ( $m['avatar_id'] ?? '' ) :
                        echo wp_get_attachment_image( $m['avatar_id'], [80,80], false, ['class'=>'pl-avatar pl-avatar--lg'] );
                    else : ?>
                        <div class="pl-avatar pl-avatar--lg pl-avatar--placeholder"><?php echo esc_html( mb_substr($m['name'] ?? '?', 0, 1) ); ?></div>
                    <?php endif; ?>
                    <div class="pl-team-detail__info">
                        <strong><?php echo esc_html( $m['name'] ?? '' ); ?></strong>
                        <span class="pl-team-role"><?php echo esc_html( $m['role'] ?? '' ); ?></span>
                        <?php if ( $m['email'] ?? '' ) : ?><a href="mailto:<?php echo esc_attr($m['email']); ?>"><?php echo esc_html($m['email']); ?></a><?php endif; ?>
                        <?php if ( $m['bio'] ?? '' ) : ?><p><?php echo esc_html( $m['bio'] ); ?></p><?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private static function render_detail_timeline( $s ) {
        $milestones = $s['milestones'] ?? [];
        ?>
        <div class="pl-detail pl-detail--timeline">
            <h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ?? __('Timeline & Milestones', 'projectlens') ); ?></h2>
            <div class="pl-timeline-full">
                <?php foreach ( $milestones as $ms ) :
                    $status = $ms['status'] ?? 'planned';
                    ?>
                    <div class="pl-timeline-full__item pl-ms-status--<?php echo esc_attr($status); ?>">
                        <div class="pl-timeline-full__line">
                            <span class="pl-timeline-full__dot"></span>
                        </div>
                        <div class="pl-timeline-full__content">
                            <strong><?php echo esc_html( $ms['title'] ?? '' ); ?></strong>
                            <div class="pl-timeline-full__meta">
                                <span class="pl-ms-date"><?php echo esc_html( $ms['date'] ?? '' ); ?></span>
                                <span class="pl-ms-badge pl-ms-badge--<?php echo esc_attr($status); ?>"><?php echo esc_html( ucfirst($status) ); ?></span>
                            </div>
                            <?php if ( $ms['description'] ?? '' ) : ?>
                            <p><?php echo esc_html( $ms['description'] ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }

    private static function render_detail_documents( $s ) {
        $files = $s['files'] ?? [];
        ?>
        <div class="pl-detail pl-detail--documents">
            <h2 class="pl-detail__title"><?php echo esc_html( $s['title'] ?? __('Documents & Downloads', 'projectlens') ); ?></h2>
            <ul class="pl-file-list">
                <?php foreach ( $files as $file ) :
                    $file_id  = $file['file_id'] ?? '';
                    $label    = $file['label']   ?? ( $file_id ? get_the_title($file_id) : '' );
                    $desc     = $file['description'] ?? '';
                    $url      = $file_id ? wp_get_attachment_url($file_id) : '';
                    $ext      = $file_id ? strtoupper( pathinfo( get_attached_file($file_id), PATHINFO_EXTENSION ) ) : '';
                    if ( ! $url ) continue;
                    ?>
                    <li class="pl-file-list__item">
                        <div class="pl-file-list__icon">📎</div>
                        <div class="pl-file-list__info">
                            <strong><?php echo esc_html( $label ); ?></strong>
                            <?php if ( $desc ) : ?><p><?php echo esc_html($desc); ?></p><?php endif; ?>
                            <?php if ( $ext ) : ?><span class="pl-file-ext"><?php echo esc_html($ext); ?></span><?php endif; ?>
                        </div>
                        <a href="<?php echo esc_url($url); ?>" class="pl-btn-download" download>
                            ↓ <?php esc_html_e('Download', 'projectlens'); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php
    }
}
