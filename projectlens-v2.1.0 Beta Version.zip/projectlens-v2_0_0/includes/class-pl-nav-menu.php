<?php
/**
 * ProjectLens — Custom Navigation Menu
 *
 * Allows a WordPress nav menu to be displayed:
 *   • Single project page  — sticky horizontal strip directly below the header (no gap).
 *   • Archive page         — full-width strip at the very top of the page content area.
 *
 * Menu assignments are configured in ProjectLens → Global Settings.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Nav_Menu {

    /** Option key inside pl_global[] for single-page menu location. */
    const KEY_SINGLE  = 'nav_menu_single';

    /** Option key inside pl_global[] for archive-page menu location. */
    const KEY_ARCHIVE = 'nav_menu_archive';

    public static function init() {
        add_action( 'after_setup_theme', [ __CLASS__, 'register_locations' ] );
    }

    // ── Register nav-menu locations so WP's Menus screen can assign menus ──

    public static function register_locations() {
        register_nav_menus( [
            'pl_single_nav'  => __( 'ProjectLens — Single Project Page', 'projectlens' ),
            'pl_archive_nav' => __( 'ProjectLens — Archive / Projects List Page', 'projectlens' ),
        ] );
    }

    // ── Helpers ─────────────────────────────────────────────────────────────

    /**
     * Return the menu ID saved for a given key, or 0 if none assigned.
     *
     * @param string $key  KEY_SINGLE or KEY_ARCHIVE
     * @return int
     */
    public static function get_menu_id( $key ) {
        $opts = get_option( 'pl_global', [] );
        return absint( $opts[ $key ] ?? 0 );
    }

    /**
     * Render the nav strip HTML for a given slot.
     * Outputs nothing when no menu is assigned or the menu is empty.
     *
     * @param string $context  'single' | 'archive'
     */
    public static function render( $context ) {
        $key      = ( $context === 'single' ) ? self::KEY_SINGLE : self::KEY_ARCHIVE;
        $menu_id  = self::get_menu_id( $key );

        if ( ! $menu_id ) {
            return; // nothing configured
        }

        // Verify the menu actually exists
        $menu_obj = wp_get_nav_menu_object( $menu_id );
        if ( ! $menu_obj ) {
            return;
        }

        $css_class = ( $context === 'single' )
            ? 'pl-nav-strip pl-nav-strip--single'
            : 'pl-nav-strip pl-nav-strip--archive';

        echo '<nav class="' . esc_attr( $css_class ) . '" aria-label="' . esc_attr( $menu_obj->name ) . '">';

        wp_nav_menu( [
            'menu'            => $menu_id,
            'menu_class'      => 'pl-nav-strip__list',
            'container'       => false,        // we supply our own <nav>
            'fallback_cb'     => false,        // don't fall back to pages list
            'depth'           => 2,            // support one level of dropdowns
            'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
        ] );

        echo '</nav>';
    }

    // ── Settings UI (called from PL_Settings) ────────────────────────────

    /**
     * Output the "Navigation Menus" table rows inside the settings form.
     * Expects to be called inside an existing <table class="form-table">.
     *
     * @param array $opts  Current pl_global options array.
     */
    public static function render_settings_rows( $opts ) {
        // Collect all registered menus for the <select> elements
        $all_menus = wp_get_nav_menus();

        $fields = [
            self::KEY_SINGLE  => [
                'label' => __( 'Single Project Page Menu', 'projectlens' ),
                'desc'  => __( 'Appears as a sticky horizontal strip directly below the project header.', 'projectlens' ),
            ],
            self::KEY_ARCHIVE => [
                'label' => __( 'Archive (Projects List) Page Menu', 'projectlens' ),
                'desc'  => __( 'Appears full-width at the very top of the projects archive page.', 'projectlens' ),
            ],
        ];

        foreach ( $fields as $key => $info ) :
            $saved = absint( $opts[ $key ] ?? 0 );
            ?>
            <tr>
                <th scope="row"><?php echo esc_html( $info['label'] ); ?></th>
                <td>
                    <select name="pl_global[<?php echo esc_attr( $key ); ?>]">
                        <option value="0"><?php esc_html_e( '— None (hidden) —', 'projectlens' ); ?></option>
                        <?php if ( $all_menus ) : ?>
                            <?php foreach ( $all_menus as $menu ) : ?>
                                <option value="<?php echo esc_attr( $menu->term_id ); ?>"
                                    <?php selected( $saved, $menu->term_id ); ?>>
                                    <?php echo esc_html( $menu->name ); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <p class="description"><?php echo esc_html( $info['desc'] ); ?></p>
                    <?php if ( ! $all_menus ) : ?>
                        <p class="description" style="color:#b32d2e;">
                            <?php
                            printf(
                                /* translators: %s: URL to the Menus admin screen */
                                wp_kses(
                                    __( 'No menus found. <a href="%s">Create a menu first</a>, then return here to assign it.', 'projectlens' ),
                                    [ 'a' => [ 'href' => [] ] ]
                                ),
                                esc_url( admin_url( 'nav-menus.php' ) )
                            );
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
            <?php
        endforeach;
    }

    /**
     * Sanitize the nav-menu fields from the settings form submission.
     * Called from PL_Settings::sanitize_global().
     *
     * @param array $raw   Raw $_POST values for pl_global[].
     * @param array $clean Already-sanitized values (other fields).
     * @return array       $clean with nav-menu keys merged in.
     */
    public static function sanitize( $raw, $clean ) {
        $clean[ self::KEY_SINGLE  ] = absint( $raw[ self::KEY_SINGLE  ] ?? 0 );
        $clean[ self::KEY_ARCHIVE ] = absint( $raw[ self::KEY_ARCHIVE ] ?? 0 );
        return $clean;
    }
}
