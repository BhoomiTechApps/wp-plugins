<?php
/**
 * Plugin Name:       ProjectLens
 * Plugin URI:        https://bhoomitechfoundation.org/apps/projectlens
 * Description:       A full-featured development project showcase plugin with flexible segments, funding metadata, and an interactive 70/30 split layout.
 * Version:           2.1.0
 * Author:            BhoomiTech Heritage and Development Foundation
 * License:           GPL-2.0+
 * Requires at least:  6.0
 * Tested up to:       7.0
 * Requires PHP:       8.0
 * Text Domain:       projectlens
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PL_VERSION',     '2.1.0' );
define( 'PL_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'PL_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'PL_PLUGIN_FILE', __FILE__ );

require_once PL_PLUGIN_DIR . 'includes/class-pl-post-type.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-segment.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-meta-boxes.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-settings.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-demo-data.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-access.php';
require_once PL_PLUGIN_DIR . 'includes/class-pl-nav-menu.php';

/**
 * Bootstrap all plugin components.
 */
function pl_init() {
    PL_Post_Type::init();
    PL_Meta_Boxes::init();
    PL_Settings::init();
    PL_Demo_Data::init();
    PL_Access::init();
    PL_Nav_Menu::init();
}
add_action( 'plugins_loaded', 'pl_init' );

/**
 * Enqueue frontend assets.
 */
function pl_enqueue_public_assets() {
    if ( ! is_singular( 'pl_project' ) && ! is_post_type_archive( 'pl_project' ) ) return;

    wp_enqueue_style(
        'projectlens-public',
        PL_PLUGIN_URL . 'public/css/projectlens.css',
        [],
        PL_VERSION
    );

    // Leaflet (OpenStreetMap) for geo-location maps — bundled locally
    wp_enqueue_style( 'leaflet',
        PL_PLUGIN_URL . 'public/vendor/leaflet/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'leaflet',
        PL_PLUGIN_URL . 'public/vendor/leaflet/leaflet.js', [], '1.9.4', true );

    // Conditionally load Google Fonts based on the per-project font choice
    $google_fonts_map = [
        'inter'  => 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap',
        'roboto' => 'https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap',
    ];
    $post_id    = get_the_ID();
    $styling    = get_post_meta( $post_id, '_pl_styling', true ) ?: [];
    $font_key   = $styling['font_family'] ?? 'system';
    if ( isset( $google_fonts_map[ $font_key ] ) ) {
        wp_enqueue_style(
            'pl-google-font-' . sanitize_key( $font_key ),
            $google_fonts_map[ $font_key ],
            [],
            null // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion -- external Google Fonts URL; versioning not applicable
        );
    }

    wp_enqueue_script(
        'projectlens-public',
        PL_PLUGIN_URL . 'public/js/projectlens.js',
        [ 'jquery', 'leaflet' ],
        PL_VERSION,
        true
    );

    wp_localize_script( 'projectlens-public', 'PL', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'pl_nonce' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'pl_enqueue_public_assets' );

/**
 * Enqueue admin assets.
 */
function pl_enqueue_admin_assets( $hook ) {
    global $post;
    if ( ! in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) return;
    if ( ! $post || $post->post_type !== 'pl_project' ) return;

    wp_enqueue_media();

    wp_enqueue_style(
        'projectlens-admin',
        PL_PLUGIN_URL . 'admin/css/admin.css',
        [],
        PL_VERSION
    );

    wp_enqueue_script(
        'projectlens-admin',
        PL_PLUGIN_URL . 'admin/js/admin.js',
        [ 'jquery', 'jquery-ui-sortable', 'wp-color-picker' ],
        PL_VERSION,
        true
    );

    wp_enqueue_style( 'wp-color-picker' );

    wp_localize_script( 'projectlens-admin', 'PL_Admin', [
        'nonce'        => wp_create_nonce( 'pl_admin_nonce' ),
        'segmentTypes' => PL_Segment::get_type_labels(),
        'confirmDelete'=> __( 'Delete this segment? This cannot be undone.', 'projectlens' ),
    ]);
}
add_action( 'admin_enqueue_scripts', 'pl_enqueue_admin_assets' );

/**
 * Force full-page template for pl_project.
 */
function pl_load_project_template( $template ) {
    if ( is_singular( 'pl_project' ) ) {
        $plugin_template = PL_PLUGIN_DIR . 'templates/single-pl_project.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    } elseif ( is_post_type_archive( 'pl_project' ) ) {
        $plugin_template = PL_PLUGIN_DIR . 'templates/archive-pl_project.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    return $template;
}
add_filter( 'template_include', 'pl_load_project_template' );

/**
 * Allow the Query Loop block to render pl_project posts on the frontend.
 *
 * In FSE themes, the block renders via WP_Query on the server rather than
 * the REST API (which the editor uses). On the homepage/front page WordPress
 * can override the block's query with the main query, silently dropping any
 * custom post type. This hook detects when a secondary (block-level) query
 * is explicitly asking for pl_project and ensures it is honoured.
 */
function pl_allow_query_loop_on_frontend( $query ) {
    if ( is_admin() || $query->is_main_query() ) return;
    if ( $query->get( 'post_type' ) === 'pl_project' ) {
        $query->set( 'post_status', 'publish' );
    }
}
add_action( 'pre_get_posts', 'pl_allow_query_loop_on_frontend' );

/**
 * Activation hook — flush rewrite rules.
 */
function pl_activate() {
    PL_Post_Type::register_cpt();
	PL_Access::activate();
    flush_rewrite_rules();
}
register_activation_hook( PL_PLUGIN_FILE, 'pl_activate' );

/**
 * Deactivation hook.
 */
function pl_deactivate() {
	PL_Access::deactivate();
    flush_rewrite_rules();
}
register_deactivation_hook( PL_PLUGIN_FILE, 'pl_deactivate' );
