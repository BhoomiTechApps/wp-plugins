<?php
/**
 * Plugin Name: BhoomiTech LVI
 * Description: Widescreen 16:9 async framework with lightbox forms, PRG session-based clean redirection blocks, robust admin moderation pipelines, media-locked revocation safeguards, authenticated star-rating aggregates, email notifications, and upload progress tracking.
 * Version: 6.0.1
 * Author: BhoomiTech Heritage and Development Foundation
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'LVI_VERSION', '6.0.1' );
define( 'LVI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LVI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// ─── ACTIVATION / DEACTIVATION HOOKS ────────────────────────────────────────

register_activation_hook( __FILE__, 'lvi_activate' );
function lvi_activate() {
    if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'BhoomiTech LVI requires PHP 7.4 or higher.' );
    }
    // Seed default options
    add_option( 'lvi_global_time_budget', 1200 );
    add_option( 'lvi_default_q_duration', 60 );
    add_option( 'lvi_questions_per_page', 4 );
    add_option( 'lvi_youtube_archive_url', '' );
    add_option( 'lvi_notify_on_question', '1' );
    add_option( 'lvi_notify_on_answered', '1' );
    // Flush rewrite rules after CPT registration
    lvi_register_question_cpt();
    flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'lvi_deactivate' );
function lvi_deactivate() {
    // Clean up all plugin transients
    global $wpdb;
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Transient cleanup on deactivation; no caching needed for a one-time cleanup operation.
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_lvi_%' OR option_name LIKE '_transient_timeout_lvi_%'" );
    flush_rewrite_rules();
}

// ─── 1. CORE CPT REGISTRATION ────────────────────────────────────────────────

add_action( 'init', 'lvi_register_question_cpt' );
function lvi_register_question_cpt() {
    $labels = array(
        'name'          => 'Interview Questions',
        'singular_name' => 'Interview Question',
        'menu_name'     => 'BhoomiTech LVI',
        'add_new_item'  => 'Add New Question',
        'edit_item'     => 'Edit Question Properties',
        'all_items'     => 'All Questions',
    );
    $args = array(
        'labels'          => $labels,
        'public'          => false,
        'show_ui'         => true,
        'show_in_menu'    => true,
        'query_var'       => true,
        'capability_type' => 'post',
        'has_archive'     => false,
        'hierarchical'    => false,
        'supports'        => array( 'title' ),
        'show_in_rest'    => true,
        'menu_icon'       => 'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><rect x="1" y="4" width="13" height="12" rx="2" fill="none" stroke="black" stroke-width="1.5"/><polygon points="14,8 19,5 19,15 14,12" fill="black"/><circle cx="7.5" cy="10" r="2" fill="black"/></svg>' ),
    );
    register_post_type( 'interview_question', $args );
}

// ─── 2. ADMIN SETTINGS PAGE ──────────────────────────────────────────────────

add_action( 'admin_menu', 'lvi_add_admin_menu' );
function lvi_add_admin_menu() {
    add_submenu_page(
        'edit.php?post_type=interview_question',
        'Global Settings', 'Global Settings',
        'manage_options', 'lvi-pool-settings', 'lvi_render_pool_settings'
    );
}

function lvi_render_pool_settings() {
    if ( ! current_user_can( 'manage_options' ) ) return;

    if ( isset( $_POST['lvi_save_pool'] ) && check_admin_referer( 'lvi_pool_nonce' ) ) {
        update_option( 'lvi_global_time_budget',  absint( isset( $_POST['lvi_global_budget'] ) ? wp_unslash( $_POST['lvi_global_budget'] ) : 0 ) );
        update_option( 'lvi_default_q_duration',  absint( isset( $_POST['lvi_default_duration'] ) ? wp_unslash( $_POST['lvi_default_duration'] ) : 0 ) );
        update_option( 'lvi_questions_per_page',  max( 1, absint( isset( $_POST['lvi_questions_per_page'] ) ? wp_unslash( $_POST['lvi_questions_per_page'] ) : 1 ) ) );
        update_option( 'lvi_youtube_archive_url', esc_url_raw( wp_unslash( isset( $_POST['lvi_youtube_archive_url'] ) ? $_POST['lvi_youtube_archive_url'] : '' ) ) );
        update_option( 'lvi_notify_on_question',  isset( $_POST['lvi_notify_on_question'] ) ? '1' : '0' );
        update_option( 'lvi_notify_on_answered',  isset( $_POST['lvi_notify_on_answered'] )  ? '1' : '0' );
        // Invalidate allocation cache
        delete_transient( 'lvi_allocated_seconds' );
        echo '<div class="updated"><p>Global settings saved successfully.</p></div>';
    }

    $global_budget        = get_option( 'lvi_global_time_budget', 1200 );
    $default_duration     = get_option( 'lvi_default_q_duration', 60 );
    $questions_per_page   = get_option( 'lvi_questions_per_page', 4 );
    $youtube_url          = get_option( 'lvi_youtube_archive_url', '' );
    $notify_on_question   = get_option( 'lvi_notify_on_question', '1' );
    $notify_on_answered   = get_option( 'lvi_notify_on_answered', '1' );
    $current_allocated    = lvi_get_total_allocated_seconds();
    $remaining_pool       = $global_budget - $current_allocated;
    ?>
    <div class="wrap">
        <h1>Global Settings</h1>
        <div class="notice notice-info inline" style="margin-top:15px; padding:15px;">
            <p style="font-size:14px; margin:0 0 8px 0;"><strong>Active Allocation Metrics:</strong></p>
            <ul style="margin:0; padding-left:20px;">
                <li>Total Pool Storage Capacity: <strong><?php echo absint( $global_budget ); ?> seconds</strong></li>
                <li>Currently Reserved by Open Tasks: <strong style="color:#cca100;"><?php echo absint( $current_allocated ); ?> seconds</strong></li>
                <li>Remaining Space for New Submissions: <strong style="color:#46b450;"><?php echo absint( max( 0, $remaining_pool ) ); ?> seconds</strong></li>
            </ul>
        </div>
        <form method="post" action="" style="margin-top:20px;">
            <?php wp_nonce_field( 'lvi_pool_nonce' ); ?>
            <table class="form-table">
                <tr>
                    <th>Global Pool Limit (Seconds)</th>
                    <td><input type="number" name="lvi_global_budget" value="<?php echo esc_attr( $global_budget ); ?>" class="regular-text" min="1"></td>
                </tr>
                <tr>
                    <th>Default Question Length (Seconds)</th>
                    <td><input type="number" name="lvi_default_duration" value="<?php echo esc_attr( $default_duration ); ?>" class="small-text" min="10"> seconds</td>
                </tr>
                <tr>
                    <th>Questions Per Page (Frontend)</th>
                    <td>
                        <input type="number" name="lvi_questions_per_page" value="<?php echo esc_attr( $questions_per_page ); ?>" min="1" max="100" class="small-text"> questions
                        <p class="description">Number of questions displayed per page on the frontend board. Default: 4.</p>
                    </td>
                </tr>
                <tr>
                    <th>YouTube Archive URL</th>
                    <td>
                        <input type="url" name="lvi_youtube_archive_url" value="<?php echo esc_attr( $youtube_url ); ?>" class="regular-text" placeholder="https://youtube.com/...">
                        <p class="description">Link shown to viewers when a video response has been deleted from the Media Library.</p>
                    </td>
                </tr>
                <tr>
                    <th>Email Notifications</th>
                    <td>
                        <label>
                            <input type="checkbox" name="lvi_notify_on_question" value="1" <?php checked( $notify_on_question, '1' ); ?>>
                            Notify assigned user when a question is submitted/claimed
                        </label><br>
                        <label>
                            <input type="checkbox" name="lvi_notify_on_answered" value="1" <?php checked( $notify_on_answered, '1' ); ?>>
                            Notify question submitter when their question is answered
                        </label>
                    </td>
                </tr>
            </table>
            <input type="submit" name="lvi_save_pool" class="button button-primary" value="Save Global Settings">
        </form>
    </div>
    <?php
}

// Cached version of allocated seconds — invalidated on question save/delete
function lvi_get_total_allocated_seconds() {
    $cached = get_transient( 'lvi_allocated_seconds' );
    if ( $cached !== false ) return (int) $cached;

    $active_questions = get_posts( array(
        'post_type'      => 'interview_question',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'meta_query'     => array(
            array( 'key' => '_lvi_status', 'value' => 'open', 'compare' => '=' ),
        ),
    ) );

    $total = 0;
    foreach ( $active_questions as $q ) {
        $limit  = get_post_meta( $q->ID, '_lvi_time_limit', true );
        $total += ! empty( $limit ) ? absint( $limit ) : absint( get_option( 'lvi_default_q_duration', 60 ) );
    }

    set_transient( 'lvi_allocated_seconds', $total, 60 );
    return $total;
}

// Invalidate the allocation cache whenever an interview_question is saved or deleted
add_action( 'save_post_interview_question', function() { delete_transient( 'lvi_allocated_seconds' ); } );
add_action( 'delete_post', function( $post_id ) {
    if ( get_post_type( $post_id ) === 'interview_question' ) delete_transient( 'lvi_allocated_seconds' );
} );

// ─── 3. ADMIN METABOX ────────────────────────────────────────────────────────

add_action( 'add_meta_boxes', 'lvi_add_assignment_meta_box' );
function lvi_add_assignment_meta_box() {
    add_meta_box(
        'lvi_assignment_meta', 'Question Metadata & Moderation Console',
        'lvi_render_meta_box_callback', 'interview_question', 'normal', 'high'
    );
}

function lvi_render_meta_box_callback( $post ) {
    wp_nonce_field( 'lvi_save_meta_box_data', 'lvi_meta_box_nonce' );

    $current_allocation = get_post_meta( $post->ID, '_lvi_assigned_user', true );
    $current_status     = get_post_meta( $post->ID, '_lvi_status', true );
    $q_time_limit       = get_post_meta( $post->ID, '_lvi_time_limit', true );
    $moderation         = get_post_meta( $post->ID, '_lvi_moderation', true );
    if ( ! $moderation ) { $moderation = ( $post->post_status === 'pending' ) ? 'disallowed' : 'allowed'; }
    $mod_reason         = get_post_meta( $post->ID, '_lvi_disallow_reason', true );
    $attached_video_id  = get_post_meta( $post->ID, '_lvi_attached_video_id', true );
    $rating_sum         = (int) get_post_meta( $post->ID, '_lvi_rating_sum', true );
    $rating_count       = (int) get_post_meta( $post->ID, '_lvi_rating_count', true );
    $avg_rating         = $rating_count > 0 ? round( $rating_sum / $rating_count, 1 ) : 0;
    $guest_name         = get_post_meta( $post->ID, '_lvi_guest_name', true );
    $guest_email        = get_post_meta( $post->ID, '_lvi_guest_email', true );

    if ( ! $current_status )  $current_status = 'open';
    if ( empty( $q_time_limit ) ) $q_time_limit = get_option( 'lvi_default_q_duration', 60 );

    $users = get_users( array( 'fields' => array( 'user_login' ) ) );
    ?>
    <table class="form-table">
        <tr style="background:#f0f6e3;"><th colspan="2"><strong>Moderation & Verification Pipeline</strong></th></tr>
        <tr>
            <th>Moderation Status</th>
            <td>
                <select name="lvi_moderation" style="font-weight:bold;">
                    <option value="allowed" <?php selected( $moderation, 'allowed' ); ?>>✓ Allowed / Visible on Frontend</option>
                    <option value="disallowed" <?php selected( $moderation, 'disallowed' ); ?>>❌ Disallowed / Pending Review</option>
                </select>
            </td>
        </tr>
        <tr>
            <th>Reason for Disallowance</th>
            <td><input type="text" name="lvi_disallow_reason" value="<?php echo esc_attr( $mod_reason ); ?>" class="large-text" placeholder="e.g., Off-topic question..."></td>
        </tr>
        <tr style="background:#f7f9fa;"><th colspan="2"><strong>Assignment Details</strong></th></tr>
        <tr>
            <th>Assigned Registered User</th>
            <td>
                <select name="lvi_assigned_user">
                    <option value="">-- Open Allocation Pool --</option>
                    <?php foreach ( $users as $u ) : ?>
                        <option value="<?php echo esc_attr( $u->user_login ); ?>" <?php selected( $current_allocation, $u->user_login ); ?>><?php echo esc_html( $u->user_login ); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th>Recording Limit (Seconds)</th>
            <td><input type="number" name="lvi_time_limit" value="<?php echo esc_attr( $q_time_limit ); ?>" class="small-text" min="10"> seconds</td>
        </tr>
        <tr>
            <th>Current Status</th>
            <td>
                <select name="lvi_status">
                    <option value="open"   <?php selected( $current_status, 'open' ); ?>>● Open / Unanswered</option>
                    <option value="closed" <?php selected( $current_status, 'closed' ); ?>>🔒 Closed / Answered</option>
                </select>
            </td>
        </tr>
        <tr>
            <th>Community Evaluation</th>
            <td><strong>⭐ <?php echo esc_html( $avg_rating ); ?> / 5.0</strong> (<?php echo absint( $rating_count ); ?> reviews)</td>
        </tr>
        <?php if ( $guest_name || $guest_email ) : ?>
        <tr>
            <th>Submitted By</th>
            <td><?php echo esc_html( $guest_name ); ?> &lt;<?php echo esc_html( $guest_email ); ?>&gt;</td>
        </tr>
        <?php endif; ?>
        <tr>
            <th>Attached Media</th>
            <td>
                <?php if ( $attached_video_id && wp_get_attachment_url( $attached_video_id ) ) : ?>
                    <span style="color:#46b450; font-weight:bold;">✓ Video Linked (ID: <?php echo absint( $attached_video_id ); ?>)</span><br>
                    <a href="<?php echo esc_url( wp_get_attachment_url( $attached_video_id ) ); ?>" target="_blank">Download / Review</a>
                <?php elseif ( $attached_video_id && ! wp_get_attachment_url( $attached_video_id ) ) : ?>
                    <span style="color:#dc2626; font-weight:bold;">⚠ Video Deleted</span><br>
                    <small style="color:#64748b;">Media ID <?php echo absint( $attached_video_id ); ?> was removed from the library.</small>
                <?php else : ?>
                    <span style="color:#cca100;">No video linked yet.</span>
                <?php endif; ?>
            </td>
        </tr>
    </table>
    <?php
}

add_action( 'save_post', 'lvi_save_question_meta_data' );
function lvi_save_question_meta_data( $post_id ) {
    if ( ! isset( $_POST['lvi_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lvi_meta_box_nonce'] ) ), 'lvi_save_meta_box_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    $allowed_meta = array(
        'lvi_assigned_user'  => '_lvi_assigned_user',
        'lvi_time_limit'     => '_lvi_time_limit',
        'lvi_status'         => '_lvi_status',
        'lvi_disallow_reason'=> '_lvi_disallow_reason',
    );
    foreach ( $allowed_meta as $post_key => $meta_key ) {
        if ( isset( $_POST[ $post_key ] ) ) {
            if ( $meta_key === '_lvi_time_limit' ) {
                update_post_meta( $post_id, $meta_key, absint( wp_unslash( $_POST[ $post_key ] ) ) );
            } else {
                update_post_meta( $post_id, $meta_key, sanitize_text_field( wp_unslash( $_POST[ $post_key ] ) ) );
            }
        }
    }

    if ( isset( $_POST['lvi_moderation'] ) ) {
        $mod_choice = sanitize_text_field( wp_unslash( $_POST['lvi_moderation'] ) );
        update_post_meta( $post_id, '_lvi_moderation', $mod_choice );
        remove_action( 'save_post', 'lvi_save_question_meta_data' );
        wp_update_post( array(
            'ID'          => $post_id,
            'post_status' => ( $mod_choice === 'disallowed' ) ? 'pending' : 'publish',
        ) );
        add_action( 'save_post', 'lvi_save_question_meta_data' );
    }

    // Invalidate allocation cache
    delete_transient( 'lvi_allocated_seconds' );
}

// ─── ADMIN BULK MODERATION ACTIONS ───────────────────────────────────────────

add_filter( 'bulk_actions-edit-interview_question', 'lvi_register_bulk_actions' );
function lvi_register_bulk_actions( $bulk_actions ) {
    $bulk_actions['lvi_bulk_allow']    = 'LVI: Allow (Publish)';
    $bulk_actions['lvi_bulk_disallow'] = 'LVI: Disallow (Pending)';
    return $bulk_actions;
}

add_filter( 'handle_bulk_actions-edit-interview_question', 'lvi_handle_bulk_actions', 10, 3 );
function lvi_handle_bulk_actions( $redirect_to, $action, $post_ids ) {
    if ( ! in_array( $action, array( 'lvi_bulk_allow', 'lvi_bulk_disallow' ), true ) ) return $redirect_to;
    if ( ! current_user_can( 'manage_options' ) ) return $redirect_to;

    foreach ( $post_ids as $post_id ) {
        if ( $action === 'lvi_bulk_allow' ) {
            update_post_meta( $post_id, '_lvi_moderation', 'allowed' );
            wp_update_post( array( 'ID' => $post_id, 'post_status' => 'publish' ) );
        } else {
            update_post_meta( $post_id, '_lvi_moderation', 'disallowed' );
            wp_update_post( array( 'ID' => $post_id, 'post_status' => 'pending' ) );
        }
    }

    delete_transient( 'lvi_allocated_seconds' );
    return add_query_arg( 'lvi_bulk_done', count( $post_ids ), $redirect_to );
}

add_action( 'admin_notices', 'lvi_bulk_action_admin_notice' );
function lvi_bulk_action_admin_notice() {
    // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only display of a count passed via redirect URL; no state changes made.
    if ( ! empty( $_REQUEST['lvi_bulk_done'] ) ) {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $count = absint( $_REQUEST['lvi_bulk_done'] );
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sprintf( '%d question(s) updated via bulk moderation.', $count ) ) . '</p></div>';
    }
}

// ─── 4. ADMIN COLUMNS ────────────────────────────────────────────────────────

add_filter( 'manage_interview_question_posts_columns', 'lvi_add_video_status_column' );
function lvi_add_video_status_column( $columns ) {
    $new = array();
    foreach ( $columns as $key => $label ) {
        $new[ $key ] = $label;
        if ( $key === 'title' ) {
            $new['lvi_video_status'] = 'Video Status';
        }
    }
    return $new;
}

add_action( 'manage_interview_question_posts_custom_column', 'lvi_render_video_status_column', 10, 2 );
function lvi_render_video_status_column( $column, $post_id ) {
    if ( $column !== 'lvi_video_status' ) return;

    $status    = get_post_meta( $post_id, '_lvi_status', true );
    $video_id  = get_post_meta( $post_id, '_lvi_attached_video_id', true );
    $video_url = $video_id ? wp_get_attachment_url( $video_id ) : '';

    if ( $status === 'closed' && $video_id && ! $video_url ) {
        echo '<span style="color:#dc2626; font-weight:bold;">⚠ Video Deleted</span>';
    } elseif ( $status === 'closed' && $video_url ) {
        echo '<span style="color:#16a34a; font-weight:bold;">✓ Video Available</span>';
    } elseif ( $status === 'closed' ) {
        echo '<span style="color:#cca100; font-weight:bold;">Answered (No Video)</span>';
    } else {
        echo '<span style="color:#2271b1;">● Open</span>';
    }
}

// ─── 5. ASSET ENQUEUE ────────────────────────────────────────────────────────
// Assets are enqueued directly inside the shortcode function so they load
// regardless of where the shortcode is placed (page builders, widgets, etc.)
// The previous wp_enqueue_scripts + has_shortcode() approach failed because
// has_shortcode() only checks $post->post_content, missing non-standard contexts.

// ─── 6. EMAIL NOTIFICATIONS ───────────────────────────────────────────────────

function lvi_notify_assignee( $post_id, $question_text ) {
    if ( get_option( 'lvi_notify_on_question', '1' ) !== '1' ) return;
    $assigned = get_post_meta( $post_id, '_lvi_assigned_user', true );
    if ( empty( $assigned ) ) return;

    $user = get_user_by( 'login', $assigned );
    if ( ! $user ) return;

    $subject = '[' . get_bloginfo( 'name' ) . '] You have been assigned an interview question';
    $body    = "Hello {$user->display_name},\n\nYou have been assigned a new interview question:\n\n\"{$question_text}\"\n\nPlease log in to record your response.\n\n" . home_url() . "\n\nThank you.";
    wp_mail( $user->user_email, $subject, $body );
}

function lvi_notify_submitter( $post_id ) {
    if ( get_option( 'lvi_notify_on_answered', '1' ) !== '1' ) return;
    $email = get_post_meta( $post_id, '_lvi_guest_email', true );
    $name  = get_post_meta( $post_id, '_lvi_guest_name', true );
    if ( ! is_email( $email ) ) return;

    $question_text = get_the_title( $post_id );
    $subject       = '[' . get_bloginfo( 'name' ) . '] Your question has been answered!';
    $body          = "Hello {$name},\n\nYour submitted question has just been answered:\n\n\"{$question_text}\"\n\nVisit the page to watch the video response:\n\n" . home_url() . "\n\nThank you for your contribution.";
    wp_mail( $email, $subject, $body );
}

// ─── 7. SESSION TOKEN HELPER ──────────────────────────────────────────────────

function lvi_get_user_session_token() {
    if ( is_user_logged_in() ) {
        return 'lvi_user_' . get_current_user_id();
    }
    // Use a cookie-based token for guests to avoid IP/UA fingerprinting
    $cookie_key = 'lvi_guest_token';
    if ( ! isset( $_COOKIE[ $cookie_key ] ) ) {
        $token = wp_generate_password( 20, false );
        setcookie( $cookie_key, $token, time() + 3600, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
        return 'lvi_guest_' . $token;
    }
    return 'lvi_guest_' . sanitize_text_field( wp_unslash( $_COOKIE[ $cookie_key ] ) );
}

// ─── 8. FRONTEND ACCESS RESTRICTION ──────────────────────────────────────────

add_action( 'admin_init', 'lvi_restrict_dashboard_access' );
function lvi_restrict_dashboard_access() {
    if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;
    if ( current_user_can( 'read' ) && ! current_user_can( 'manage_options' ) ) {
        wp_safe_redirect( home_url() );
        exit;
    }
}

// ─── 9. SHORTCODE ─────────────────────────────────────────────────────────────

add_shortcode( 'local_interview', 'lvi_render_interview_playlist_system' );
function lvi_render_interview_playlist_system() {
    // Enqueue assets here so they always load when the shortcode renders,
    // regardless of whether it's in post_content, a widget, or a page builder.
    wp_enqueue_style(
        'lvi-frontend-styles',
        LVI_PLUGIN_URL . 'lvi-styles.css',
        array(),
        LVI_VERSION
    );
    wp_enqueue_script(
        'lvi-playlist-recorder',
        LVI_PLUGIN_URL . 'uploader.js',
        array(),
        LVI_VERSION,
        true
    );

    $current_user     = wp_get_current_user();
    $current_username = is_user_logged_in() ? $current_user->user_login : '';
    $session_key      = lvi_get_user_session_token();

    // ── PRG A: Question submission ──────────────────────────────────────────
    if ( isset( $_POST['lvi_add_front_q'] ) && check_admin_referer( 'lvi_front_q_nonce' ) ) {
        $q_content          = sanitize_textarea_field( wp_unslash( isset( $_POST['lvi_question_text'] ) ? $_POST['lvi_question_text'] : '' ) );
        $alloc_to           = sanitize_text_field( wp_unslash( isset( $_POST['lvi_target_user'] ) ? $_POST['lvi_target_user'] : '' ) );
        $sub_name           = sanitize_text_field( wp_unslash( isset( $_POST['lvi_submitter_name'] ) ? $_POST['lvi_submitter_name'] : '' ) );
        $sub_email          = sanitize_email( wp_unslash( isset( $_POST['lvi_submitter_email'] ) ? $_POST['lvi_submitter_email'] : '' ) );
        $requested_duration = isset( $_POST['lvi_requested_duration'] )
            ? min( 300, max( 60, absint( wp_unslash( $_POST['lvi_requested_duration'] ) ) ) )
            : get_option( 'lvi_default_q_duration', 60 );

        $global_budget  = get_option( 'lvi_global_time_budget', 1200 );
        $current_used   = lvi_get_total_allocated_seconds();
        $baseline_url   = home_url( $GLOBALS['wp']->request ) . '/';

        if ( ! empty( $q_content ) && is_email( $sub_email ) && ! empty( $sub_name ) ) {
            if ( ( $current_used + $requested_duration ) <= $global_budget ) {
                $new_id = wp_insert_post( array(
                    'post_title'  => $q_content,
                    'post_type'   => 'interview_question',
                    'post_status' => 'publish',
                ) );
                if ( $new_id ) {
                    update_post_meta( $new_id, '_lvi_assigned_user', $alloc_to );
                    update_post_meta( $new_id, '_lvi_time_limit',    $requested_duration );
                    update_post_meta( $new_id, '_lvi_status',        'open' );
                    update_post_meta( $new_id, '_lvi_moderation',    'allowed' );
                    update_post_meta( $new_id, '_lvi_guest_name',    $sub_name );
                    update_post_meta( $new_id, '_lvi_guest_email',   $sub_email );
                    delete_transient( 'lvi_allocated_seconds' );
                    // Notify assigned user if set
                    if ( ! empty( $alloc_to ) ) lvi_notify_assignee( $new_id, $q_content );
                    set_transient( 'lvi_status_msg_' . $session_key, 'success', 45 );
                    wp_safe_redirect( $baseline_url );
                    exit;
                }
            } else {
                set_transient( 'lvi_status_msg_' . $session_key, 'overflow', 45 );
                wp_safe_redirect( $baseline_url );
                exit;
            }
        } else {
            set_transient( 'lvi_status_msg_' . $session_key, 'invalid', 45 );
            wp_safe_redirect( $baseline_url );
            exit;
        }
    }

    // ── PRG B: Claim question ───────────────────────────────────────────────
    if ( is_user_logged_in() && isset( $_POST['lvi_claim_question'] ) && check_admin_referer( 'lvi_claim_nonce' ) ) {
        $target_claim_id = isset( $_POST['question_id'] ) ? absint( $_POST['question_id'] ) : 0;
        if (
            get_post_type( $target_claim_id ) === 'interview_question' &&
            get_post_status( $target_claim_id ) === 'publish' &&
            empty( get_post_meta( $target_claim_id, '_lvi_assigned_user', true ) )
        ) {
            update_post_meta( $target_claim_id, '_lvi_assigned_user', $current_username );
            // Notify the claimer's own email
            lvi_notify_assignee( $target_claim_id, get_the_title( $target_claim_id ) );
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        }
    }

    // ── PRG C: Revoke question ──────────────────────────────────────────────
    if ( is_user_logged_in() && isset( $_POST['lvi_revoke_question'] ) && check_admin_referer( 'lvi_revoke_nonce' ) ) {
        $target_revoke_id  = isset( $_POST['question_id'] ) ? absint( $_POST['question_id'] ) : 0;
        $attached_video_id = get_post_meta( $target_revoke_id, '_lvi_attached_video_id', true );
        $current_db_status = get_post_meta( $target_revoke_id, '_lvi_status', true );
        $existing_owner    = get_post_meta( $target_revoke_id, '_lvi_assigned_user', true );
        $has_active_file   = ( $attached_video_id && wp_get_attachment_url( $attached_video_id ) );

        if (
            get_post_type( $target_revoke_id ) === 'interview_question' &&
            ! $has_active_file &&
            $current_db_status !== 'closed' &&
            strcasecmp( $existing_owner, $current_username ) === 0
        ) {
            update_post_meta( $target_revoke_id, '_lvi_assigned_user', '' );
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        } else {
            set_transient( 'lvi_status_msg_' . $session_key, 'revokelocked', 45 );
            wp_safe_redirect( home_url( $GLOBALS['wp']->request ) . '/' );
            exit;
        }
    }

    // Fetch & clear session feedback
    $active_feedback_msg = get_transient( 'lvi_status_msg_' . $session_key );
    if ( $active_feedback_msg ) delete_transient( 'lvi_status_msg_' . $session_key );

    $all_registered_users = get_users( array( 'fields' => array( 'user_login' ) ) );
    $lvi_per_page         = max( 1, (int) get_option( 'lvi_questions_per_page', 4 ) );
    $lvi_paged            = isset( $_GET['lvi_page'] ) ? max( 1, absint( $_GET['lvi_page'] ) ) : 1;
    $lvi_is_logged_in     = is_user_logged_in();
    $youtube_url          = get_option( 'lvi_youtube_archive_url', '' );

    $query_args = array(
        'post_type'      => 'interview_question',
        'posts_per_page' => $lvi_per_page,
        'paged'          => $lvi_paged,
        'post_status'    => 'publish',
        'order'          => 'ASC',
    );
    if ( ! $lvi_is_logged_in ) {
        $query_args['meta_query'] = array(
            array( 'key' => '_lvi_status', 'value' => 'closed', 'compare' => '=' ),
        );
    }

    $questions_query = new WP_Query( $query_args );
    $questions_posts = $questions_query->posts;
    $lvi_total_pages = $questions_query->max_num_pages;

    ob_start();
    ?>
    <div class="lvi-wrapper">

        <?php if ( $active_feedback_msg ) : ?>
            <?php if ( $active_feedback_msg === 'success' ) : ?>
                <div class="lvi-alert lvi-alert-success">✓ Question successfully added to the pipeline.</div>
            <?php elseif ( $active_feedback_msg === 'overflow' ) : ?>
                <div class="lvi-alert lvi-alert-error"><strong>Submission Blocked:</strong> Platform recording capacity limit reached.</div>
            <?php elseif ( $active_feedback_msg === 'invalid' ) : ?>
                <div class="lvi-alert lvi-alert-error"><strong>Error:</strong> Please fill in all required fields.</div>
            <?php elseif ( $active_feedback_msg === 'revokelocked' ) : ?>
                <div class="lvi-alert lvi-alert-error"><strong>Revocation Blocked:</strong> A video response has already been saved for this question.</div>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Add Question Button Bar -->
        <div class="lvi-topbar">
            <div>
                <h4 class="lvi-topbar-title">Have an Inquiry?</h4>
                <p class="lvi-topbar-sub">Submit a question for registered members to record an answer.</p>
            </div>
            <button id="lvi-open-modal-trigger" class="lvi-btn lvi-btn-primary" onclick="document.getElementById('lvi-submission-lightbox').style.display='flex';">➕ Add Question Prompt</button>
        </div>

        <!-- Question Submission Modal -->
        <div id="lvi-submission-lightbox" class="lvi-lightbox-overlay" style="display:none;">
            <div class="lvi-lightbox-box">
                <button class="lvi-lightbox-close" onclick="document.getElementById('lvi-submission-lightbox').style.display='none';">✕</button>
                <h3 class="lvi-modal-title">Submit Interview Request</h3>
                <?php
                $lvi_remaining_secs = max( 0, get_option( 'lvi_global_time_budget', 1200 ) - lvi_get_total_allocated_seconds() );
                ?>
                <div class="lvi-budget-notice">
                    ⏱ <strong><?php echo absint( $lvi_remaining_secs ); ?> seconds</strong> remaining in the global recording budget.
                </div>
                <form method="post" action="">
                    <?php wp_nonce_field( 'lvi_front_q_nonce' ); ?>
                    <div class="lvi-field">
                        <label class="lvi-label">Question Text / Prompt *</label>
                        <textarea name="lvi_question_text" rows="3" class="lvi-textarea" required placeholder="What specific information are you requesting?"></textarea>
                    </div>
                    <div class="lvi-field-grid">
                        <div>
                            <label class="lvi-label">Your Full Name *</label>
                            <input type="text" name="lvi_submitter_name" class="lvi-input" required placeholder="e.g., Jane Doe">
                        </div>
                        <div>
                            <label class="lvi-label">Your Email *</label>
                            <input type="email" name="lvi_submitter_email" class="lvi-input" required placeholder="name@domain.com">
                        </div>
                    </div>
                    <!-- Honeypot anti-spam field -->
                    <div style="display:none;" aria-hidden="true">
                        <input type="text" name="lvi_hp_field" value="" tabindex="-1" autocomplete="off">
                    </div>
                    <div class="lvi-field">
                        <label class="lvi-label">Requested Response Duration (Seconds) *</label>
                        <input type="number" name="lvi_requested_duration" min="60" max="300" value="<?php echo esc_attr( min( 300, max( 60, get_option( 'lvi_default_q_duration', 60 ) ) ) ); ?>" class="lvi-input" required>
                        <p class="lvi-hint">Enter a value between 60 and 300 seconds.</p>
                    </div>
                    <div class="lvi-field">
                        <label class="lvi-label">Allocate Target Responder (Optional)</label>
                        <select name="lvi_target_user" class="lvi-select">
                            <option value="">-- Open Community Claim --</option>
                            <?php foreach ( $all_registered_users as $ru ) : ?>
                                <option value="<?php echo esc_attr( $ru->user_login ); ?>">@<?php echo esc_html( $ru->user_login ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="lvi-modal-actions">
                        <button type="button" class="lvi-btn lvi-btn-ghost" onclick="document.getElementById('lvi-submission-lightbox').style.display='none';">Cancel</button>
                        <input type="submit" name="lvi_add_front_q" value="Publish to Board" class="lvi-btn lvi-btn-primary">
                    </div>
                </form>
            </div>
        </div>

        <?php if ( $lvi_is_logged_in ) : ?>
        <!-- Video Recorder Panel -->
        <div id="lvi-playlist-container"
             data-root="<?php echo esc_url_raw( rest_url() ); ?>"
             data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
             class="lvi-card">

            <div class="lvi-monitor-wrap">
                <video id="lvi-video-monitor" autoplay muted playsinline class="lvi-monitor-video"></video>

                <button id="lvi-toggle-camera" class="lvi-cam-toggle" style="display:none;" title="Switch Camera"
                        onmouseover="this.style.background='rgba(34,113,177,0.9)'"
                        onmouseout="this.style.background='rgba(15,23,42,0.75)'">🔄</button>

                <div id="lvi-rec-timer" class="lvi-rec-badge" style="display:none;">
                    <span class="lvi-rec-dot"></span> LIVE REC
                </div>

                <div id="lvi-overlay-announcer" class="lvi-monitor-overlay">
                    <p id="lvi-announcer-msg" class="lvi-announcer-text">Initializing camera stream…</p>
                </div>
            </div>

            <!-- Upload progress bar -->
            <div id="lvi-upload-progress-wrap" style="display:none;" class="lvi-progress-wrap">
                <div class="lvi-progress-label">Uploading video… <span id="lvi-upload-percent">0%</span></div>
                <div class="lvi-progress-track">
                    <div id="lvi-upload-bar" class="lvi-progress-bar" style="width:0%;"></div>
                </div>
            </div>

            <div class="lvi-recorder-controls">
                <button id="lvi-trigger-rec"  style="display:none;" class="lvi-btn lvi-btn-danger">Record Answer</button>
                <button id="lvi-trigger-stop" style="display:none;" class="lvi-btn lvi-btn-dark">Finish &amp; Save Response</button>
                <div    id="lvi-process-spinner" style="display:none;" class="lvi-spinner-text">Uploading…</div>
            </div>

            <div id="lvi-active-focus-zone" class="lvi-focus-zone">
                <div>
                    <h4 class="lvi-focus-label">Focused Question</h4>
                    <div id="lvi-focused-question-text" class="lvi-focus-text">Select a question from the list below.</div>
                </div>
                <div>
                    <label for="lvi-teleprompter-notes" class="lvi-focus-label">Teleprompter Notes (Optional):</label>
                    <textarea id="lvi-teleprompter-notes" rows="3" class="lvi-textarea" placeholder="Paste reference notes here to read while looking at the camera…"></textarea>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Question Board -->
        <div id="lvi-playlist-global-board"
             data-root="<?php echo esc_url_raw( rest_url() ); ?>"
             data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
             data-perpage="<?php echo esc_attr( $lvi_per_page ); ?>"
             data-loggedin="<?php echo $lvi_is_logged_in ? 'true' : 'false'; ?>"
             data-yturl="<?php echo esc_attr( $youtube_url ); ?>"
             class="lvi-card">

            <h3 class="lvi-board-title">
                <?php echo $lvi_is_logged_in ? 'Timeline Pipeline Queue' : 'Published Video Responses Archive'; ?>
            </h3>

            <div class="lvi-search-wrap">
                <input type="text" id="lvi-live-search" placeholder="🔍 Search questions…" autocomplete="off" class="lvi-search-input">
                <span id="lvi-search-spinner" style="display:none;" class="lvi-search-spinner">⏳</span>
            </div>

            <div id="lvi-question-queue-list" class="lvi-queue-list">
                <?php
                if ( empty( $questions_posts ) ) {
                    echo '<p class="lvi-empty-state">No verified video responses are currently listed.</p>';
                }
                foreach ( $questions_posts as $index => $q_post ) :
                    $assigned_user     = get_post_meta( $q_post->ID, '_lvi_assigned_user', true );
                    $current_status    = get_post_meta( $q_post->ID, '_lvi_status', true );
                    $q_limit           = get_post_meta( $q_post->ID, '_lvi_time_limit', true );
                    $attached_video_id = get_post_meta( $q_post->ID, '_lvi_attached_video_id', true );
                    $rating_sum        = (int) get_post_meta( $q_post->ID, '_lvi_rating_sum', true );
                    $rating_count      = (int) get_post_meta( $q_post->ID, '_lvi_rating_count', true );
                    $avg_rating        = $rating_count > 0 ? round( $rating_sum / $rating_count, 1 ) : 0;
                    if ( empty( $q_limit ) ) $q_limit = get_option( 'lvi_default_q_duration', 60 );

                    $is_done           = ( $current_status === 'closed' );
                    $is_assigned_to_me = ( ! empty( $assigned_user ) && strcasecmp( $assigned_user, $current_username ) === 0 );
                    $is_unallocated    = empty( $assigned_user );
                    $video_url         = ( $is_done && $attached_video_id ) ? wp_get_attachment_url( $attached_video_id ) : '';
                    $has_file          = ! empty( $video_url );
                    $video_deleted     = ( $is_done && $attached_video_id && ! $has_file );

                    if ( $is_done ) {
                        $status_label = '🔒 Answered by @' . esc_html( $assigned_user );
                        $badge_color = '#475569'; $can_record = 'false'; $item_bg = '#f8fafc'; $item_border = '#cbd5e1';
                    } elseif ( $is_unallocated ) {
                        $status_label = '● Open Target';
                        $badge_color = '#2271b1'; $can_record = 'false'; $item_bg = '#fff'; $item_border = '#b4fee4';
                    } elseif ( ! $is_assigned_to_me ) {
                        $status_label = '🔒 Claimed by @' . esc_html( $assigned_user );
                        $badge_color = '#d97706'; $can_record = 'false'; $item_bg = '#fffbeb'; $item_border = '#fef3c7';
                    } else {
                        $status_label = '✓ Assigned to You';
                        $badge_color = '#16a34a'; $can_record = 'true'; $item_bg = '#f0fdf4'; $item_border = '#bbf7d0';
                    }
                ?>
                    <div class="lvi-queue-item"
                         data-postid="<?php echo absint( $q_post->ID ); ?>"
                         data-idx="<?php echo absint( $index ); ?>"
                         data-done="<?php echo $is_done ? 'true' : 'false'; ?>"
                         data-videodeleted="<?php echo $video_deleted ? 'true' : 'false'; ?>"
                         data-allowed="<?php echo esc_attr( $can_record ); ?>"
                         data-limit="<?php echo esc_attr( $q_limit ); ?>"
                         data-unallocated="<?php echo $is_unallocated ? 'true' : 'false'; ?>"
                         data-user="<?php echo esc_attr( $is_unallocated ? 'Nobody' : $assigned_user ); ?>"
                         data-videourl="<?php echo esc_url( $video_url ); ?>"
                         style="background:<?php echo esc_attr( $item_bg ); ?>; border-color:<?php echo esc_attr( $item_border ); ?>;">

                        <div class="lvi-queue-item-header">
                            <span class="lvi-bound-label">BOUND: <?php echo absint( $q_limit ); ?>s</span>
                            <div class="lvi-badge-group">
                                <?php if ( $is_done && $rating_count > 0 ) : ?>
                                    <span class="lvi-rating-badge">⭐ <?php echo esc_html( $avg_rating ); ?></span>
                                <?php endif; ?>
                                <span class="lvi-status-badge" style="color:<?php echo esc_attr( $badge_color ); ?>;"><?php echo esc_html( $status_label ); ?></span>
                            </div>
                        </div>

                        <div class="lvi-q-body-text"><?php echo esc_html( $q_post->post_title ); ?></div>

                        <div class="lvi-queue-item-actions" onclick="event.stopPropagation();">
                            <?php if ( $lvi_is_logged_in && $is_unallocated && ! $is_done ) : ?>
                                <form method="post" action="" style="margin:0;">
                                    <?php wp_nonce_field( 'lvi_claim_nonce' ); ?>
                                    <input type="hidden" name="question_id" value="<?php echo absint( $q_post->ID ); ?>">
                                    <input type="submit" name="lvi_claim_question" value="⚡ Claim Slot" class="lvi-btn lvi-btn-sm lvi-btn-primary">
                                </form>
                            <?php endif; ?>
                            <?php if ( $lvi_is_logged_in && $is_assigned_to_me && ! $is_done && ! $has_file ) : ?>
                                <form method="post" action="" style="margin:0;">
                                    <?php wp_nonce_field( 'lvi_revoke_nonce' ); ?>
                                    <input type="hidden" name="question_id" value="<?php echo absint( $q_post->ID ); ?>">
                                    <input type="submit" name="lvi_revoke_question" value="↩ Revoke Assignment" class="lvi-btn lvi-btn-sm lvi-btn-ghost">
                                </form>
                            <?php endif; ?>
                            <?php if ( $is_done && $has_file ) : ?>
                                <button class="lvi-view-response-trigger lvi-btn lvi-btn-sm lvi-btn-dark"
                                        data-src="<?php echo esc_url( $video_url ); ?>"
                                        data-postid="<?php echo absint( $q_post->ID ); ?>"
                                        onclick="lviLaunchVideoPlaybackModal(this.getAttribute('data-src'), this.getAttribute('data-postid'));">
                                    👁 View Response &amp; Rate
                                </button>
                            <?php endif; ?>
                            <?php if ( $video_deleted ) :
                                $yt = esc_url( get_option( 'lvi_youtube_archive_url', '' ) );
                            ?>
                                <span class="lvi-deleted-badge">
                                    📺 Response unavailable.
                                    <?php if ( $yt ) : ?>
                                        <a href="<?php echo esc_url( $yt ); ?>" target="_blank" rel="noopener" style="color:#b45309; text-decoration:underline;">Check YouTube archive →</a>
                                    <?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <?php if ( $lvi_total_pages > 1 ) : ?>
                <div id="lvi-pagination" class="lvi-pagination">
                    <?php for ( $p = 1; $p <= $lvi_total_pages; $p++ ) :
                        $is_active = ( $p === $lvi_paged );
                        $page_url  = add_query_arg( 'lvi_page', $p );
                    ?>
                        <a href="<?php echo esc_url( $page_url ); ?>"
                           class="lvi-page-btn <?php echo $is_active ? 'lvi-page-btn-active' : ''; ?>"
                           data-page="<?php echo absint( $p ); ?>"><?php echo absint( $p ); ?></a>
                    <?php endfor; ?>
                </div>
            <?php else : ?>
                <div id="lvi-pagination"></div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Video Playback Lightbox -->
    <div id="lvi-playback-lightbox" class="lvi-lightbox-overlay" style="display:none;" onclick="lviCloseVideoPlaybackModal();">
        <div class="lvi-playback-box" onclick="event.stopPropagation();">
            <button class="lvi-lightbox-close lvi-lightbox-close-dark" onclick="lviCloseVideoPlaybackModal();">✕</button>
            <div class="lvi-playback-video-wrap">
                <video id="lvi-playback-node" controls class="lvi-playback-video"></video>
            </div>
            <div id="lvi-rating-panel-area" class="lvi-rating-panel">
                <div>
                    <h5 class="lvi-rating-title">Evaluate this Response</h5>
                    <p class="lvi-rating-sub">Your rating helps surface high-quality answers.</p>
                </div>
                <div class="lvi-rating-controls">
                    <?php if ( $lvi_is_logged_in ) : ?>
                        <div class="lvi-stars-input-row">
                            <span class="lvi-star-node" data-val="5">★</span>
                            <span class="lvi-star-node" data-val="4">★</span>
                            <span class="lvi-star-node" data-val="3">★</span>
                            <span class="lvi-star-node" data-val="2">★</span>
                            <span class="lvi-star-node" data-val="1">★</span>
                        </div>
                        <div id="lvi-rating-status-text" class="lvi-rating-status"></div>
                    <?php else : ?>
                        <span class="lvi-login-prompt">🔒 Log in to rate</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

// ─── 10. REST API ENDPOINTS ────────────────────────────────────────────────────

add_action( 'rest_api_init', 'lvi_register_rest_metadata_fields' );
function lvi_register_rest_metadata_fields() {

    // Expose meta fields via the WP REST API
    register_rest_field( 'interview_question', 'meta', array(
        'get_callback' => function( $post_arr ) {
            $video_id      = get_post_meta( $post_arr['id'], '_lvi_attached_video_id', true );
            $video_url     = ( $video_id ) ? wp_get_attachment_url( $video_id ) : '';
            $video_deleted = ( $video_id && ! $video_url ) ? '1' : '0';
            return array(
                '_lvi_status'            => get_post_meta( $post_arr['id'], '_lvi_status', true ),
                '_lvi_attached_video_id' => $video_id,
                '_lvi_assigned_user'     => get_post_meta( $post_arr['id'], '_lvi_assigned_user', true ),
                '_lvi_time_limit'        => get_post_meta( $post_arr['id'], '_lvi_time_limit', true ) ?: get_option( 'lvi_default_q_duration', 60 ),
                '_lvi_video_deleted'     => $video_deleted,
                '_lvi_video_url'         => $video_url,
            );
        },
        'update_callback' => function( $meta_dict, $post_obj ) {
            if ( ! is_array( $meta_dict ) ) return;
            // Whitelist of allowed meta keys only
            $allowed = array( '_lvi_status', '_lvi_attached_video_id', '_lvi_assigned_user', '_lvi_time_limit' );
            foreach ( $meta_dict as $k => $v ) {
                if ( ! in_array( $k, $allowed, true ) ) continue;
                if ( $k === '_lvi_status' && $v === 'open' ) {
                    if ( get_post_meta( $post_obj->ID, '_lvi_attached_video_id', true ) ) continue;
                }
                update_post_meta( $post_obj->ID, $k, sanitize_text_field( $v ) );
            }
            return true;
        },
    ) );

    // Star rating route
    register_rest_route( 'lvi/v1', '/rate', array(
        'methods'             => 'POST',
        'callback'            => 'lvi_process_rest_star_rating',
        'permission_callback' => function() { return is_user_logged_in(); },
    ) );

    // Frontend meta update route
    register_rest_route( 'lvi/v1', '/submit-response', array(
        'methods'             => 'POST',
        'callback'            => 'lvi_handle_frontend_meta_update',
        'permission_callback' => function() { return is_user_logged_in(); },
    ) );
}

function lvi_process_rest_star_rating( $request ) {
    $params  = $request->get_json_params();
    $post_id = isset( $params['post_id'] ) ? absint( $params['post_id'] ) : 0;
    $rating  = isset( $params['rating'] )  ? absint( $params['rating'] )  : 0;

    if ( ! $post_id || get_post_type( $post_id ) !== 'interview_question' || $rating < 1 || $rating > 5 ) {
        return new WP_Error( 'lvi_invalid_payload', 'Invalid parameters.', array( 'status' => 400 ) );
    }

    // One-vote-per-user enforcement
    $user_id    = get_current_user_id();
    $voted_key  = '_lvi_voter_' . $user_id;
    if ( get_post_meta( $post_id, $voted_key, true ) ) {
        return new WP_Error( 'lvi_already_rated', 'You have already rated this response.', array( 'status' => 409 ) );
    }

    $current_sum   = (int) get_post_meta( $post_id, '_lvi_rating_sum',   true );
    $current_count = (int) get_post_meta( $post_id, '_lvi_rating_count', true );
    update_post_meta( $post_id, '_lvi_rating_sum',   $current_sum   + $rating );
    update_post_meta( $post_id, '_lvi_rating_count', $current_count + 1 );
    update_post_meta( $post_id, $voted_key, '1' ); // Record vote

    return rest_ensure_response( array( 'success' => true ) );
}

function lvi_handle_frontend_meta_update( $request ) {
    $params   = $request->get_json_params();
    $post_id  = isset( $params['post_id'] )  ? absint( $params['post_id'] )  : 0;
    $media_id = isset( $params['media_id'] ) ? absint( $params['media_id'] ) : 0;

    if ( ! $post_id || ! $media_id ) {
        return new WP_Error( 'lvi_missing_data', 'Missing post or media ID.', array( 'status' => 400 ) );
    }
    if ( get_post_type( $post_id ) !== 'interview_question' ) {
        return new WP_Error( 'lvi_invalid_post', 'Invalid post type.', array( 'status' => 400 ) );
    }

    // Verify the media attachment belongs to the current user
    $media_post = get_post( $media_id );
    if ( ! $media_post || $media_post->post_author != get_current_user_id() ) {
        return new WP_Error( 'lvi_media_ownership', 'You do not own this media item.', array( 'status' => 403 ) );
    }

    $current_user   = wp_get_current_user();
    $assigned_owner = get_post_meta( $post_id, '_lvi_assigned_user', true );
    if ( strcasecmp( $assigned_owner, $current_user->user_login ) !== 0 ) {
        return new WP_Error( 'lvi_unauthorized_owner', 'You do not hold assignment rights for this question.', array( 'status' => 403 ) );
    }

    update_post_meta( $post_id, '_lvi_status',            'closed' );
    update_post_meta( $post_id, '_lvi_attached_video_id', $media_id );
    delete_transient( 'lvi_allocated_seconds' );

    // Notify the original question submitter
    lvi_notify_submitter( $post_id );

    return rest_ensure_response( array( 'success' => true ) );
}
