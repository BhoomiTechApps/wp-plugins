/* =============================================================
   BhoomiTech LVI – uploader.js  v6.0.0
   Recorder + Live Search + JS Pagination
   ============================================================= */

// ─── RECORDER MODULE ──────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    const rootBox = document.getElementById('lvi-playlist-container');
    if (!rootBox) return;

    // DOM references
    const monitor         = document.getElementById('lvi-video-monitor');
    const btnRec          = document.getElementById('lvi-trigger-rec');
    const btnStop         = document.getElementById('lvi-trigger-stop');
    const spinner         = document.getElementById('lvi-process-spinner');
    const listWrapper     = document.getElementById('lvi-question-queue-list');
    const activeText      = document.getElementById('lvi-focused-question-text');
    const overlay         = document.getElementById('lvi-overlay-announcer');
    const announcerMsg    = document.getElementById('lvi-announcer-msg');
    const liveIndicator   = document.getElementById('lvi-rec-timer');
    const noteArea        = document.getElementById('lvi-teleprompter-notes');
    const btnToggleCam    = document.getElementById('lvi-toggle-camera');
    const progressWrap    = document.getElementById('lvi-upload-progress-wrap');
    const progressBar     = document.getElementById('lvi-upload-bar');
    const progressPercent = document.getElementById('lvi-upload-percent');

    const restEndpoint = rootBox.getAttribute('data-root');
    const authNonce    = rootBox.getAttribute('data-nonce');
    const queueItems   = document.querySelectorAll('.lvi-queue-item');

    // State
    let activeIndex          = null;
    let activePostId         = null;
    let currentLimitSeconds  = 60;
    let mediaRecorder        = null;
    let recordedChunks       = [];
    let cameraStream         = null;
    let countdownInterval    = null;
    let videoDevices         = [];
    let currentDeviceIndex   = 0;

    // ── Camera init ─────────────────────────────────────────────────────────
    function initCameraStream(constraints = { video: { aspectRatio: 16 / 9 }, audio: true }) {
        if (cameraStream) cameraStream.getTracks().forEach(t => t.stop());

        return navigator.mediaDevices.getUserMedia(constraints)
            .then(stream => {
                cameraStream = stream;
                monitor.srcObject = stream;
                overlay.style.display = 'none';

                const videoTrack    = stream.getVideoTracks()[0];
                const trackSettings = videoTrack ? videoTrack.getSettings() : null;
                monitor.style.transform = (trackSettings && trackSettings.facingMode === 'environment')
                    ? 'scaleX(1)' : 'scaleX(-1)';

                if (videoDevices.length === 0) {
                    navigator.mediaDevices.enumerateDevices().then(devices => {
                        videoDevices = devices.filter(d => d.kind === 'videoinput');
                        if (videoDevices.length > 1) {
                            btnToggleCam.style.display = 'flex';
                            if (trackSettings && trackSettings.deviceId) {
                                const idx = videoDevices.findIndex(d => d.deviceId === trackSettings.deviceId);
                                if (idx !== -1) currentDeviceIndex = idx;
                            }
                        }
                    });
                }
            });
    }

    initCameraStream()
        .then(() => selectFirstAvailableTask())
        .catch(() => {
            announcerMsg.innerHTML = "<strong style='color:#ef4444;'>Webcam Blocked:</strong> Please grant camera access in your browser settings.";
        });

    // ── Camera toggle ────────────────────────────────────────────────────────
    btnToggleCam.addEventListener('click', () => {
        if (videoDevices.length < 2 || (mediaRecorder && mediaRecorder.state === 'recording')) return;
        currentDeviceIndex = (currentDeviceIndex + 1) % videoDevices.length;
        const target = videoDevices[currentDeviceIndex];
        overlay.style.display = 'flex';
        announcerMsg.innerText = 'Switching camera…';
        initCameraStream({
            video: { deviceId: { exact: target.deviceId }, aspectRatio: 16 / 9 },
            audio: true,
        }).catch(() => initCameraStream({ video: true, audio: true }));
    });

    // ── Task selection helpers ────────────────────────────────────────────────
    function selectFirstAvailableTask() {
        const targets  = Array.from(queueItems);
        const priority = targets.find(i => i.getAttribute('data-allowed') === 'true' && i.getAttribute('data-done') === 'false');
        if (priority) {
            activateTaskRow(priority);
        } else if (targets.length > 0) {
            activateTaskRow(targets[0]);
        }
    }

    function activateTaskRow(element) {
        queueItems.forEach(i => i.style.borderColor = '');  // reset; CSS handles default colour
        activeIndex           = parseInt(element.getAttribute('data-idx'));
        activePostId          = element.getAttribute('data-postid');
        currentLimitSeconds   = parseInt(element.getAttribute('data-limit')) || 60;

        const isDone          = element.getAttribute('data-done')         === 'true';
        const isVideoDeleted  = element.getAttribute('data-videodeleted') === 'true';
        const isAllowed       = element.getAttribute('data-allowed')      === 'true';
        const isUnallocated   = element.getAttribute('data-unallocated')  === 'true';
        const assignedUser    = element.getAttribute('data-user');
        const bodyEl          = element.querySelector('.lvi-q-body-text');
        const fullText        = bodyEl ? bodyEl.innerText : '';

        element.style.borderColor = '#2271b1';
        activeText.innerText      = fullText;
        noteArea.value            = '';

        // Remove any leftover preview panel
        removePreviewPanel();

        if (isDone && isVideoDeleted) {
            showOverlay("<span>📺 <strong>Response Unavailable</strong><br><small>The video was removed. Check the YouTube archive.</small></span>");
            btnRec.style.display = 'none';
            btnStop.style.display = 'none';
        } else if (isDone) {
            showOverlay("<span>🔒 <strong>Slot Closed</strong><br><small>This question has already been answered.</small></span>");
            btnRec.style.display = 'none';
            btnStop.style.display = 'none';
        } else if (isUnallocated) {
            showOverlay("<span>⚡ <strong>Unallocated Task</strong><br><small>Click \"Claim Slot\" to record an answer.</small></span>");
            btnRec.style.display = 'none';
            btnStop.style.display = 'none';
        } else if (!isAllowed) {
            showOverlay(`<span>🔒 <strong>Locked</strong><br><small>Recording rights belong to <strong>@${assignedUser}</strong></small></span>`);
            btnRec.style.display = 'none';
            btnStop.style.display = 'none';
        } else {
            overlay.style.display = 'none';
            btnRec.style.display  = 'inline-block';
            btnRec.innerText      = `Record Answer (${currentLimitSeconds}s Max)`;
            btnStop.style.display = 'none';
            spinner.style.display = 'none';
            if (videoDevices.length > 1) btnToggleCam.style.display = 'flex';
        }
    }

    function showOverlay(html) {
        announcerMsg.innerHTML    = html;
        overlay.style.display     = 'flex';
        btnRec.style.display      = 'none';
        btnStop.style.display     = 'none';
        btnToggleCam.style.display = 'none';
    }

    listWrapper.addEventListener('click', e => {
        const itemRow = e.target.closest('.lvi-queue-item');
        if (!itemRow || (mediaRecorder && mediaRecorder.state === 'recording')) return;
        activateTaskRow(itemRow);
    });

    // ── 3-2-1 Pre-record countdown ────────────────────────────────────────────
    function runCountdown(seconds, onComplete) {
        // Inject countdown overlay inside monitor-wrap
        const monitorWrap = document.querySelector('.lvi-monitor-wrap');
        if (!monitorWrap) { onComplete(); return; }

        const cdOverlay = document.createElement('div');
        cdOverlay.className = 'lvi-countdown-overlay';
        cdOverlay.id = 'lvi-countdown-overlay';
        monitorWrap.appendChild(cdOverlay);

        let remaining = seconds;

        function tick() {
            cdOverlay.innerHTML = `<span class="lvi-countdown-number">${remaining}</span>`;
            if (remaining <= 0) {
                cdOverlay.remove();
                onComplete();
                return;
            }
            remaining--;
            setTimeout(tick, 1000);
        }
        tick();
    }

    // ── Record button ─────────────────────────────────────────────────────────
    btnRec.addEventListener('click', () => {
        btnRec.style.display  = 'none';
        btnStop.style.display = 'none';

        runCountdown(3, () => {
            recordedChunks = [];
            let mimeType = 'video/webm;codecs=vp8,opus';
            if (!MediaRecorder.isTypeSupported(mimeType)) mimeType = 'video/mp4';

            try {
                mediaRecorder = new MediaRecorder(cameraStream, { mimeType });
            } catch (e) {
                mediaRecorder = new MediaRecorder(cameraStream);
            }

            mediaRecorder.ondataavailable = e => {
                if (e.data && e.data.size > 0) recordedChunks.push(e.data);
            };

            mediaRecorder.onstop = () => showPreviewBeforeUpload();
            mediaRecorder.start(1000);

            btnStop.style.display       = 'inline-block';
            btnToggleCam.style.display  = 'none';
            liveIndicator.style.display = 'flex';

            let remaining = currentLimitSeconds;
            btnStop.innerText = `Stop Recording (${remaining}s)`;

            countdownInterval = setInterval(() => {
                remaining--;
                if (remaining > 0) {
                    btnStop.innerText = `Stop Recording (${remaining}s)`;
                } else {
                    clearInterval(countdownInterval);
                    if (mediaRecorder.state !== 'inactive') mediaRecorder.stop();
                }
            }, 1000);
        });
    });

    // ── Stop button ───────────────────────────────────────────────────────────
    btnStop.addEventListener('click', () => {
        clearInterval(countdownInterval);
        if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
    });

    // ── Preview panel before upload ───────────────────────────────────────────
    function showPreviewBeforeUpload() {
        liveIndicator.style.display = 'none';
        btnStop.style.display       = 'none';

        const compiledBlob = new Blob(recordedChunks, { type: mediaRecorder.mimeType || 'video/webm' });
        const previewURL   = URL.createObjectURL(compiledBlob);

        // Inject preview panel below recorder controls
        const focusZone = document.getElementById('lvi-active-focus-zone');
        removePreviewPanel();

        const panel = document.createElement('div');
        panel.id        = 'lvi-preview-panel';
        panel.className = 'lvi-preview-panel';
        panel.innerHTML = `
            <p class="lvi-preview-title">✅ Review your recording before submitting:</p>
            <video class="lvi-preview-video" src="${previewURL}" controls></video>
            <div class="lvi-preview-actions">
                <button id="lvi-btn-rerecord" class="lvi-btn lvi-btn-ghost">↩ Re-record</button>
                <button id="lvi-btn-confirm"  class="lvi-btn lvi-btn-primary">Upload &amp; Submit →</button>
            </div>`;

        focusZone.before(panel);

        document.getElementById('lvi-btn-rerecord').addEventListener('click', () => {
            URL.revokeObjectURL(previewURL);
            removePreviewPanel();
            recordedChunks = [];
            btnRec.style.display = 'inline-block';
            btnRec.innerText     = `Record Answer (${currentLimitSeconds}s Max)`;
            if (videoDevices.length > 1) btnToggleCam.style.display = 'flex';
        });

        document.getElementById('lvi-btn-confirm').addEventListener('click', () => {
            URL.revokeObjectURL(previewURL);
            removePreviewPanel();
            processSegmentUpload(compiledBlob);
        });
    }

    function removePreviewPanel() {
        const existing = document.getElementById('lvi-preview-panel');
        if (existing) existing.remove();
    }

    // ── XHR upload with progress bar ──────────────────────────────────────────
    function processSegmentUpload(compiledBlob) {
        spinner.style.display       = 'flex';
        overlay.style.display       = 'flex';
        progressWrap.style.display  = 'block';
        announcerMsg.innerText      = 'Uploading to WordPress Media Library…';

        const formatExt      = (mediaRecorder.mimeType || '').includes('mp4') ? 'mp4' : 'webm';
        const timestamp      = Date.now();
        const payloadTitle   = `lvi-response-stream-Q${activePostId}-${timestamp}`;
        const outputFilename = `${payloadTitle}.${formatExt}`;

        const dataForm = new FormData();
        dataForm.append('file',  compiledBlob, outputFilename);
        dataForm.append('title', payloadTitle);

        const xhr = new XMLHttpRequest();
        xhr.open('POST', `${restEndpoint}wp/v2/media`, true);
        xhr.setRequestHeader('X-WP-Nonce', authNonce);

        xhr.upload.addEventListener('progress', e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 100);
                progressBar.style.width     = pct + '%';
                progressPercent.innerText   = pct + '%';
            }
        });

        xhr.addEventListener('load', () => {
            if (xhr.status < 200 || xhr.status >= 300) {
                let msg = `Upload failed (HTTP ${xhr.status})`;
                try { msg = JSON.parse(xhr.responseText)?.message || msg; } catch (_) {}
                handleUploadError(msg);
                return;
            }

            let mediaObject;
            try { mediaObject = JSON.parse(xhr.responseText); } catch (_) {
                handleUploadError('Could not parse media response.');
                return;
            }

            // Update the question metadata via the custom endpoint
            fetch(`${restEndpoint}lvi/v1/submit-response`, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': authNonce,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ post_id: activePostId, media_id: mediaObject.id }),
            })
            .then(async res => {
                if (!res.ok) {
                    const errData = await res.json();
                    throw new Error(errData?.message || `HTTP ${res.status}`);
                }
                progressBar.style.width    = '100%';
                progressPercent.innerText  = '100%';
                window.location.reload();
            })
            .catch(err => handleUploadError(err.message));
        });

        xhr.addEventListener('error', () => handleUploadError('Network error during upload.'));

        xhr.send(dataForm);
    }

    function handleUploadError(message) {
        spinner.style.display       = 'none';
        overlay.style.display       = 'none';
        progressWrap.style.display  = 'none';
        progressBar.style.width     = '0%';
        progressPercent.innerText   = '0%';
        if (videoDevices.length > 1) btnToggleCam.style.display = 'flex';
        alert(`Upload Error: ${message}`);
        btnRec.style.display = 'inline-block';
        btnRec.innerText     = `Record Answer (${currentLimitSeconds}s Max)`;
    }
});


// ─── LIVE SEARCH + JS PAGINATION ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('lvi-playlist-global-board');
    if (!board) return;

    const searchInput   = document.getElementById('lvi-live-search');
    const queueList     = document.getElementById('lvi-question-queue-list');
    const paginationDiv = document.getElementById('lvi-pagination');
    const searchSpinner = document.getElementById('lvi-search-spinner');
    if (!searchInput || !queueList || !paginationDiv) return;

    const restRoot   = board.getAttribute('data-root');
    const restNonce  = board.getAttribute('data-nonce');
    const perPage    = parseInt(board.getAttribute('data-perpage')) || 4;
    const isLoggedIn = board.getAttribute('data-loggedin') === 'true';
    const ytUrl      = board.getAttribute('data-yturl') || '';

    let currentPage   = 1;
    let currentTerm   = '';
    let debounceTimer = null;
    let totalPages    = 1;
    let isSearchMode  = false;

    // Store PHP-rendered content so we can restore it on search clear
    const phpRenderedList       = queueList.innerHTML;
    const phpRenderedPagination = paginationDiv.innerHTML;

    function fetchAndRender(page, term) {
        searchSpinner.style.display = 'inline';

        const statusFilter = isLoggedIn ? '' : '&meta_key=_lvi_status&meta_value=closed';
        const searchParam  = term.length > 0 ? `&search=${encodeURIComponent(term)}` : '';
        const url = `${restRoot}wp/v2/interview_question?per_page=${perPage}&page=${page}&orderby=date&order=asc${searchParam}&_fields=id,title,meta&status=publish${statusFilter}`;

        fetch(url, { headers: { 'X-WP-Nonce': restNonce } })
            .then(res => {
                totalPages = parseInt(res.headers.get('X-WP-Total-Pages')) || 1;
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return res.json();
            })
            .then(posts => {
                renderList(posts);
                renderPagination(page, totalPages);
                searchSpinner.style.display = 'none';
            })
            .catch(() => {
                searchSpinner.style.display = 'none';
                queueList.innerHTML = '<p class="lvi-empty-state" style="color:#dc2626;">Could not load questions. Please try again.</p>';
                paginationDiv.innerHTML = '';
            });
    }

    function renderList(posts) {
        if (posts.length === 0) {
            queueList.innerHTML = '<p class="lvi-empty-state">No questions match your search.</p>';
            return;
        }

        queueList.innerHTML = posts.map((post, index) => {
            const meta          = post.meta || {};
            const status        = meta._lvi_status || 'open';
            const assignedUser  = meta._lvi_assigned_user || '';
            const qLimit        = meta._lvi_time_limit || 60;
            const isDone        = status === 'closed';
            const isUnallocated = assignedUser === '';
            const videoUrl      = meta._lvi_video_url || '';
            const hasFile       = isDone && videoUrl !== '';
            const videoDeleted  = isDone && !hasFile && meta._lvi_video_deleted === '1';
            const ratingSum     = parseInt(meta._lvi_rating_sum || 0);
            const ratingCount   = parseInt(meta._lvi_rating_count || 0);
            const avgRating     = ratingCount > 0 ? (ratingSum / ratingCount).toFixed(1) : null;

            let statusLabel, badgeColor, canRecord, itemBg, itemBorder;
            if (isDone) {
                statusLabel = `🔒 Answered by @${assignedUser}`;
                badgeColor  = '#475569'; canRecord = 'false';
                itemBg      = '#f8fafc'; itemBorder = '#cbd5e1';
            } else if (isUnallocated) {
                statusLabel = '● Open Target';
                badgeColor  = '#2271b1'; canRecord = 'false';
                itemBg      = '#fff';    itemBorder = '#b4fee4';
            } else {
                statusLabel = `🔒 Claimed by @${assignedUser}`;
                badgeColor  = '#d97706'; canRecord = 'false';
                itemBg      = '#fffbeb'; itemBorder = '#fef3c7';
            }

            const ratingBadge = (isDone && avgRating)
                ? `<span class="lvi-rating-badge">⭐ ${avgRating}</span>`
                : '';

            const ytLink = ytUrl
                ? `<a href="${ytUrl}" target="_blank" rel="noopener" style="color:#b45309; text-decoration:underline;">Check YouTube archive →</a>`
                : '';
            const deletedBadge = videoDeleted
                ? `<span class="lvi-deleted-badge">📺 Response unavailable. ${ytLink}</span>`
                : '';
            const viewButton = hasFile
                ? `<button class="lvi-view-response-trigger lvi-btn lvi-btn-sm lvi-btn-dark"
                        data-src="${videoUrl}"
                        data-postid="${post.id}"
                        onclick="lviLaunchVideoPlaybackModal(this.getAttribute('data-src'), this.getAttribute('data-postid'));">
                        👁 View Response &amp; Rate
                   </button>`
                : '';

            const actionsHtml = (viewButton || deletedBadge)
                ? `<div class="lvi-queue-item-actions" onclick="event.stopPropagation();">${viewButton}${deletedBadge}</div>`
                : '';

            return `<div class="lvi-queue-item"
                data-postid="${post.id}"
                data-idx="${index}"
                data-done="${isDone ? 'true' : 'false'}"
                data-videodeleted="${videoDeleted ? 'true' : 'false'}"
                data-allowed="${canRecord}"
                data-limit="${qLimit}"
                data-unallocated="${isUnallocated ? 'true' : 'false'}"
                data-user="${isUnallocated ? 'Nobody' : assignedUser}"
                data-videourl="${videoUrl}"
                style="background:${itemBg}; border-color:${itemBorder};">
                <div class="lvi-queue-item-header">
                    <span class="lvi-bound-label">BOUND: ${qLimit}s</span>
                    <div class="lvi-badge-group">
                        ${ratingBadge}
                        <span class="lvi-status-badge" style="color:${badgeColor};">${statusLabel}</span>
                    </div>
                </div>
                <div class="lvi-q-body-text">${post.title.rendered}</div>
                ${actionsHtml}
            </div>`;
        }).join('');
    }

    function renderPagination(page, total) {
        if (total <= 1) { paginationDiv.innerHTML = ''; return; }

        paginationDiv.innerHTML = Array.from({ length: total }, (_, i) => i + 1).map(p => {
            const active = p === page;
            return `<button data-page="${p}" class="lvi-page-btn ${active ? 'lvi-page-btn-active' : ''}">${p}</button>`;
        }).join('');

        paginationDiv.querySelectorAll('button[data-page]').forEach(btn => {
            btn.addEventListener('click', () => {
                currentPage = parseInt(btn.getAttribute('data-page'));
                fetchAndRender(currentPage, currentTerm);
            });
        });
    }

    // Live search with 300ms debounce
    searchInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            currentTerm = searchInput.value.trim();

            if (currentTerm === '') {
                // Restore PHP-rendered view in-place (no page reload)
                isSearchMode            = false;
                currentPage             = 1;
                queueList.innerHTML     = phpRenderedList;
                paginationDiv.innerHTML = phpRenderedPagination;
                return;
            }

            isSearchMode = true;
            currentPage  = 1;
            fetchAndRender(currentPage, currentTerm);
        }, 300);
    });
    // PHP renders the first page — no initial fetchAndRender call needed.
});


// ─── VIDEO PLAYBACK LIGHTBOX + STAR RATING ───────────────────────────────────
let lviActivePlaybackPostId = null;

function lviLaunchVideoPlaybackModal(videoUrl, postId) {
    const modal      = document.getElementById('lvi-playback-lightbox');
    const video      = document.getElementById('lvi-playback-node');
    const statusText = document.getElementById('lvi-rating-status-text');

    lviActivePlaybackPostId = postId;
    if (statusText) statusText.innerText = '';
    document.querySelectorAll('.lvi-star-node').forEach(el => el.classList.remove('selected'));

    if (modal && video) {
        video.src = videoUrl;
        modal.style.display = 'flex';
        video.play().catch(() => {});  // Suppress autoplay policy errors
    }
}

function lviCloseVideoPlaybackModal() {
    const modal = document.getElementById('lvi-playback-lightbox');
    const video = document.getElementById('lvi-playback-node');
    if (modal && video) {
        video.pause();
        video.src = '';
        modal.style.display = 'none';
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const globalBoard = document.getElementById('lvi-playlist-global-board');
    if (!globalBoard) return;

    const restRoot  = globalBoard.getAttribute('data-root');
    const restNonce = globalBoard.getAttribute('data-nonce');

    document.querySelectorAll('.lvi-star-node').forEach(star => {
        star.addEventListener('click', function () {
            const scoreValue = parseInt(this.getAttribute('data-val'));
            const statusText = document.getElementById('lvi-rating-status-text');

            document.querySelectorAll('.lvi-star-node').forEach(el => el.classList.remove('selected'));
            this.classList.add('selected');
            if (statusText) statusText.innerText = 'Saving…';

            fetch(`${restRoot}lvi/v1/rate`, {
                method: 'POST',
                headers: {
                    'X-WP-Nonce': restNonce,
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ post_id: lviActivePlaybackPostId, rating: scoreValue }),
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    if (statusText) {
                        statusText.style.color = '#46b450';
                        statusText.innerText   = 'Saved! ⭐';
                    }
                    setTimeout(() => window.location.reload(), 800);
                } else {
                    if (statusText) statusText.innerText = data.message || 'Error';
                    // Re-allow re-clicking if already voted
                    document.querySelectorAll('.lvi-star-node').forEach(el => el.classList.remove('selected'));
                }
            })
            .catch(() => {
                if (statusText) statusText.innerText = 'Connection error';
            });
        });
    });
});
