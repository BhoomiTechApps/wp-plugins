<?php
/**
 * Plugin Name:       TranslitLab
 * Plugin URI:        https://compilingai.com/translitlab
 * Description:       Transliteration Lab — browser-based test module for the CompilingAI transliteration engine. Access is restricted to users with the custom "Transliterator" role; admins control which tabs are visible per user.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            CompilingAI
 * License:           GPL-2.0-or-later
 * Text Domain:       translitlab
 */

defined( 'ABSPATH' ) || exit;

// ── Constants ────────────────────────────────────────────────────────────────
define( 'TRANSLITLAB_VERSION',  '1.0.0' );
define( 'TRANSLITLAB_DIR',      plugin_dir_path( __FILE__ ) );
define( 'TRANSLITLAB_URL',      plugin_dir_url(  __FILE__ ) );
define( 'TRANSLITLAB_ROLE',     'transliterator' );

// ── Bootstrap ────────────────────────────────────────────────────────────────
require_once TRANSLITLAB_DIR . 'includes/class-engine.php';
require_once TRANSLITLAB_DIR . 'includes/class-db.php';
require_once TRANSLITLAB_DIR . 'includes/class-ajax.php';
require_once TRANSLITLAB_DIR . 'includes/class-frontend.php';
require_once TRANSLITLAB_DIR . 'includes/class-admin.php';
require_once TRANSLITLAB_DIR . 'includes/class-role.php';

// ── Activation / Deactivation ────────────────────────────────────────────────
register_activation_hook( __FILE__, [ 'TranslitLab_Role', 'create_role' ] );
register_activation_hook( __FILE__, [ 'TranslitLab_DB',   'install'     ] );
register_deactivation_hook( __FILE__, [ 'TranslitLab_Role', 'remove_role' ] );

// ── Boot ─────────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    TranslitLab_Admin::init();
    TranslitLab_Frontend::init();
    TranslitLab_Ajax::init();
} );
