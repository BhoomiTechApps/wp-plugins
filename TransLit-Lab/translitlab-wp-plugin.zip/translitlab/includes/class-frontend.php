<?php
/**
 * TranslitLab — Frontend
 * Registers the [translitlab] shortcode and serves the lab UI
 * to users who have been granted access.
 */

defined( 'ABSPATH' ) || exit;

class TranslitLab_Frontend {

    public static function init(): void {
        add_shortcode( 'translitlab', [ __CLASS__, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'maybe_enqueue' ] );
    }

    /**
     * Only enqueue assets on pages that contain our shortcode.
     */
    public static function maybe_enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) {
            return;
        }
        if ( ! has_shortcode( $post->post_content, 'translitlab' ) ) {
            return;
        }
        self::enqueue_assets();
    }

    private static function enqueue_assets(): void {
        $v = TRANSLITLAB_VERSION;
        wp_enqueue_style(
            'translitlab-style',
            TRANSLITLAB_URL . 'assets/style.css',
            [],
            $v
        );
        wp_enqueue_script(
            'translitlab-engine',
            TRANSLITLAB_URL . 'assets/engine.js',
            [],
            $v,
            true
        );
        wp_enqueue_script(
            'translitlab-jszip',
            'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js',
            [],
            '3.10.1',
            true
        );
        wp_enqueue_script(
            'translitlab-app',
            TRANSLITLAB_URL . 'assets/app.js',
            [ 'translitlab-engine', 'translitlab-jszip' ],
            $v,
            true
        );

        // Pass WP AJAX config to JS
        $user_id   = get_current_user_id();
        $tab_cfg   = TranslitLab_Role::user_tab_config( $user_id );

        wp_localize_script( 'translitlab-app', 'TranslitLabConfig', [
            'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
            'nonce'      => wp_create_nonce( 'translitlab_nonce' ),
            'enabledTabs'=> $tab_cfg,
        ] );
    }

    /**
     * Shortcode handler: [translitlab]
     */
    public static function render_shortcode( $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="translitlab-notice">'
                . esc_html__( 'Please log in to access the Transliteration Lab.', 'translitlab' )
                . '</p>';
        }

        $user_id = get_current_user_id();

        if ( ! TranslitLab_Role::user_can_access( $user_id ) ) {
            return '<p class="translitlab-notice">'
                . esc_html__( 'You do not have permission to access the Transliteration Lab.', 'translitlab' )
                . '</p>';
        }

        // Enqueue assets if not yet done (e.g., page builder context)
        self::enqueue_assets();

        $enabled_tabs = TranslitLab_Role::user_tab_config( $user_id );

        ob_start();
        self::render_lab( $enabled_tabs );
        return ob_get_clean();
    }

    /**
     * Renders the full lab HTML (adapted from index.html).
     * Tabs not in $enabled_tabs are hidden via CSS class; the JS also
     * respects TranslitLabConfig.enabledTabs to skip event binding.
     */
    private static function render_lab( array $enabled_tabs ): void {
        $all_tabs = [
            'test'     => '⚡ Test',
            'snippets' => '✂️ Snippets',
            'maps'     => '🗺️ Maps',
            'engines'  => '🧩 Engines',
            'debug'    => '🐛 Debug',
        ];
        ?>
<div id="app" class="translitlab-app">
  <header>
    <h1>Translit<span>Lab</span></h1>
    <div style="font-size:12px;color:var(--muted);">CompilingAI Engine Test Module</div>
    <div class="tab-bar">
      <?php
      $first = true;
      foreach ( $all_tabs as $slug => $label ) :
          if ( ! in_array( $slug, $enabled_tabs, true ) ) {
              continue;
          }
          $active = $first ? ' active' : '';
          $first  = false;
      ?>
      <button class="tab-btn<?php echo esc_attr( $active ); ?>" data-tab="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $label ); ?></button>
      <?php endforeach; ?>
    </div>
    <button class="btn btn-sm" id="btn-reset-defaults" title="<?php esc_attr_e( 'Reset all to plugin defaults', 'translitlab' ); ?>" style="margin-left:8px;">↩ <?php esc_html_e( 'Reset Defaults', 'translitlab' ); ?></button>
  </header>

  <main>

    <!-- ═══════════════ TEST PANEL ═══════════════ -->
    <div id="panel-test" class="tab-panel<?php echo in_array( 'test', $enabled_tabs, true ) ? ' active' : ' translitlab-tab-hidden'; ?>">
      <div class="test-left">
        <div class="section-hd">
          <?php esc_html_e( 'Active Snippets', 'translitlab' ); ?>
          <span class="count" id="snip-count">0</span>
        </div>
        <div id="snippet-list"></div>
      </div>
      <div class="test-center">
        <div style="display:flex;align-items:center;gap:10px;flex-shrink:0;">
          <div class="io-label" style="margin:0;"><?php esc_html_e( 'Direction:', 'translitlab' ); ?></div>
          <div class="dir-toggle">
            <button class="dir-btn active" data-dir="forward"><?php esc_html_e( 'Forward (Roman → BPM)', 'translitlab' ); ?></button>
            <button class="dir-btn" data-dir="reverse"><?php esc_html_e( 'Reverse (BPM → Roman)', 'translitlab' ); ?></button>
          </div>
          <button class="run-btn" id="btn-run">▶ <?php esc_html_e( 'Run', 'translitlab' ); ?></button>
        </div>
        <div style="flex-shrink:0;display:flex;flex-direction:column;gap:4px;">
          <div class="io-label"><?php esc_html_e( 'Input', 'translitlab' ); ?></div>
          <textarea class="io-box" id="input-text" rows="3" placeholder="<?php esc_attr_e( 'Type test input here…', 'translitlab' ); ?>" spellcheck="false"></textarea>
        </div>
        <div class="engines-row">
          <div class="engine-card">
            <div class="engine-hd">
              <span class="engine-label js"><?php esc_html_e( 'JS Engine', 'translitlab' ); ?></span>
              <span style="font-size:11px;color:var(--muted);"><?php esc_html_e( 'frontend / browser', 'translitlab' ); ?></span>
              <span class="engine-status" id="js-status">—</span>
            </div>
            <div class="engine-output" id="js-output" dir="auto"></div>
            <div class="engine-log" id="js-log"></div>
          </div>
          <div class="engine-card">
            <div class="engine-hd">
              <span class="engine-label php"><?php esc_html_e( 'PHP Engine', 'translitlab' ); ?></span>
              <span style="font-size:11px;color:var(--muted);"><?php esc_html_e( 'server / WordPress', 'translitlab' ); ?></span>
              <span class="engine-status" id="php-status">—</span>
            </div>
            <div class="engine-output" id="php-output" dir="auto"></div>
            <div class="engine-log" id="php-log"></div>
          </div>
        </div>
      </div>
      <div class="test-right">
        <div class="section-hd">
          <?php esc_html_e( 'Map Viewer', 'translitlab' ); ?>
          <div class="actions">
            <button class="btn btn-sm" id="btn-map-add-entry">+ <?php esc_html_e( 'Add', 'translitlab' ); ?></button>
            <button class="btn btn-sm btn-primary" id="btn-map-save-changes">💾 <?php esc_html_e( 'Save', 'translitlab' ); ?></button>
          </div>
        </div>
        <div id="map-viewer-panel">
          <div class="map-viewer-toolbar">
            <select id="map-view-select">
              <option value="" disabled selected>— <?php esc_html_e( 'Select a Map', 'translitlab' ); ?> —</option>
              <option value="forward"><?php esc_html_e( 'Forward Map', 'translitlab' ); ?></option>
              <option value="reverse"><?php esc_html_e( 'Reverse Map', 'translitlab' ); ?></option>
            </select>
            <input type="search" id="map-search" placeholder="<?php esc_attr_e( 'Filter entries…', 'translitlab' ); ?>">
          </div>
          <div id="map-grid"><div id="map-no-lexicon-msg" class="map-no-lexicon-msg"><?php esc_html_e( 'No Lexicon Map loaded. Select one to load.', 'translitlab' ); ?></div></div>
          <div class="map-viewer-status">
            <span id="map-viewer-count">—</span>
            <span id="map-dirty-badge" class="map-dirty-badge" style="display:none;">● <?php esc_html_e( 'unsaved changes', 'translitlab' ); ?></span>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════════════ SNIPPETS PANEL ═══════════════ -->
    <div id="panel-snippets" class="tab-panel<?php echo in_array( 'snippets', $enabled_tabs, true ) ? '' : ' translitlab-tab-hidden'; ?>">
      <div class="snip-panel-list">
        <div class="section-hd" style="padding:10px 12px;">
          <?php esc_html_e( 'Snippets', 'translitlab' ); ?>
          <span class="count" id="snip-count2">0</span>
          <div class="actions">
            <button class="btn btn-sm" id="btn-import-snippets">📥 <?php esc_html_e( 'Import', 'translitlab' ); ?></button>
            <button class="btn btn-sm" id="btn-export-all-snippets">📤 <?php esc_html_e( 'Export All', 'translitlab' ); ?></button>
            <button class="btn btn-sm" id="btn-add-snippet2">+ <?php esc_html_e( 'New', 'translitlab' ); ?></button>
          </div>
        </div>
        <div id="sel-action-bar">
          <span class="sel-count" id="sel-count-label">0 <?php esc_html_e( 'selected', 'translitlab' ); ?></span>
          <button class="btn btn-sm" id="btn-export-selected">📤 <?php esc_html_e( 'Export Selected', 'translitlab' ); ?></button>
          <span class="sel-clear" id="btn-sel-clear"><?php esc_html_e( 'Clear', 'translitlab' ); ?></span>
        </div>
        <div id="snip-panel-list-body"></div>
      </div>
      <div class="snip-panel-editor">
        <div class="section-hd" style="padding:10px 14px;">
          <?php esc_html_e( 'Snippet Editor', 'translitlab' ); ?>
          <div class="actions">
            <button class="btn btn-sm btn-primary" id="btn-save-snippet-panel">💾 <?php esc_html_e( 'Save Snippet', 'translitlab' ); ?></button>
          </div>
        </div>
        <div class="snip-panel-editor-inner" id="snip-panel-editor-inner">
          <div class="empty-state"><?php esc_html_e( 'Select a snippet from the list to edit, or click + New to create one.', 'translitlab' ); ?></div>
        </div>
      </div>
    </div>

    <!-- ═══════════════ MAPS PANEL ═══════════════ -->
    <div id="panel-maps" class="tab-panel<?php echo in_array( 'maps', $enabled_tabs, true ) ? '' : ' translitlab-tab-hidden'; ?>">
      <div class="map-tab-toolbar">
        <div class="map-tab-left">
          <select id="maps-tab-view-select" class="map-tab-select">
            <option value="forward"><?php esc_html_e( 'Forward Map (Roman → BPM)', 'translitlab' ); ?></option>
            <option value="reverse"><?php esc_html_e( 'Reverse Map (BPM → Roman)', 'translitlab' ); ?></option>
          </select>
          <span id="maps-tab-total" class="map-tab-total">—</span>
        </div>
        <div class="map-tab-right">
          <input type="search" id="maps-tab-search" class="map-tab-search" placeholder="<?php esc_attr_e( 'Search entries…', 'translitlab' ); ?>">
          <button class="btn btn-sm" id="btn-maps-tab-export">📤 <?php esc_html_e( 'Export', 'translitlab' ); ?></button>
        </div>
      </div>
      <div class="maps-tab-columns">
        <div class="maps-tab-left-col">
          <div id="maps-tab-body" class="maps-tab-body"></div>
        </div>
        <div class="maps-tab-right-col">
          <div class="map-json-header"><?php esc_html_e( 'JSON Preview', 'translitlab' ); ?> <span class="map-json-hint">(<?php esc_html_e( 'read-only · updates on save', 'translitlab' ); ?>)</span></div>
          <textarea id="maps-tab-json" class="maps-tab-json" readonly spellcheck="false"></textarea>
        </div>
      </div>
    </div>

    <!-- ═══════════════ ENGINES PANEL ═══════════════ -->
    <div id="panel-engines" class="tab-panel<?php echo in_array( 'engines', $enabled_tabs, true ) ? '' : ' translitlab-tab-hidden'; ?>">
      <div class="engine-settings-row">
        <div class="engine-settings-half">
          <div class="section-hd">🟡 <?php esc_html_e( 'JS Engine Settings', 'translitlab' ); ?> <span style="color:var(--muted);font-size:10px;font-weight:400;text-transform:none;">(js-engine-settings.json)</span></div>
          <div id="engine-settings-js" class="engine-settings-body"></div>
        </div>
        <div class="engine-settings-half">
          <div class="section-hd">🔵 <?php esc_html_e( 'PHP Engine Settings', 'translitlab' ); ?> <span style="color:var(--muted);font-size:10px;font-weight:400;text-transform:none;">(php-engine-settings.json)</span></div>
          <div id="engine-settings-php" class="engine-settings-body"></div>
        </div>
      </div>
      <div class="engine-code-row">
        <div class="engine-code-half">
          <div class="section-hd">🟡 <?php esc_html_e( 'JS Engine', 'translitlab' ); ?> <span style="color:var(--muted);font-size:10px;font-weight:400;text-transform:none;">(engine.js)</span></div>
          <div class="engine-img-wrap" id="engine-img-wrap-js" oncontextmenu="return false;" onselectstart="return false;" oncopy="return false;" oncut="return false;">
            <img src="<?php echo esc_url( TRANSLITLAB_URL . 'assets/engine-js-screenshot.png' ); ?>" alt="<?php esc_attr_e( 'JS Engine source', 'translitlab' ); ?>" id="engine-img-js" class="engine-img" draggable="false">
            <div class="engine-code-watermark-overlay" id="engine-watermark-js"></div>
          </div>
        </div>
        <div class="engine-code-half">
          <div class="section-hd">🔵 <?php esc_html_e( 'PHP Engine', 'translitlab' ); ?> <span style="color:var(--muted);font-size:10px;font-weight:400;text-transform:none;">(engine.php)</span></div>
          <div class="engine-code-wrap" oncontextmenu="return false;" onselectstart="return false;" oncopy="return false;" oncut="return false;">
            <pre class="engine-code-content" id="engine-code-php"></pre>
            <div class="engine-code-watermark-overlay" id="engine-watermark-php"></div>
          </div>
        </div>
      </div>
    </div>

    <!-- ═══════════════ DEBUG PANEL ═══════════════ -->
    <div id="panel-debug" class="tab-panel<?php echo in_array( 'debug', $enabled_tabs, true ) ? '' : ' translitlab-tab-hidden'; ?>">
      <div class="debug-half">
        <div class="section-hd">🟡 <?php esc_html_e( 'JS Engine — Last Run Debug', 'translitlab' ); ?>
          <div class="actions"><button class="btn btn-sm" id="btn-export-debug-js">📄 <?php esc_html_e( 'Export', 'translitlab' ); ?></button></div>
        </div>
        <div class="debug-content" id="debug-js-content">
          <div class="debug-empty"><?php esc_html_e( 'Run a transliteration in the Test tab to see debug output here.', 'translitlab' ); ?></div>
        </div>
      </div>
      <div class="debug-half">
        <div class="section-hd">🔵 <?php esc_html_e( 'PHP Engine — Last Run Debug', 'translitlab' ); ?>
          <div class="actions"><button class="btn btn-sm" id="btn-export-debug-php">📄 <?php esc_html_e( 'Export', 'translitlab' ); ?></button></div>
        </div>
        <div class="debug-content" id="debug-php-content">
          <div class="debug-empty"><?php esc_html_e( 'Run a transliteration in the Test tab to see debug output here.', 'translitlab' ); ?></div>
        </div>
      </div>
    </div>

  </main>
</div>

<div id="toast"></div>

<!-- Map entry edit modal -->
<div id="map-edit-modal-backdrop">
  <div id="map-edit-modal">
    <h3 id="map-edit-modal-title"><?php esc_html_e( 'Edit Map Entry', 'translitlab' ); ?></h3>
    <div class="map-edit-fields">
      <div class="map-edit-field">
        <div class="map-edit-label"><?php esc_html_e( 'FROM (key)', 'translitlab' ); ?></div>
        <input class="map-edit-input" id="map-edit-from" placeholder="Roman key, e.g. ka">
      </div>
      <div class="map-edit-field">
        <div class="map-edit-label"><?php esc_html_e( 'TO (value)', 'translitlab' ); ?></div>
        <input class="map-edit-input" id="map-edit-to" placeholder="BPM character, e.g. ক">
      </div>
      <div class="map-edit-field">
        <div class="map-edit-label"><?php esc_html_e( 'SECTION', 'translitlab' ); ?></div>
        <select class="map-edit-input" id="map-edit-section">
          <option value="consonants">consonants</option>
          <option value="matras">matras</option>
          <option value="independent_vowels">independent_vowels</option>
          <option value="special">special</option>
          <option value="digits">digits</option>
          <option value="punctuation">punctuation</option>
        </select>
      </div>
    </div>
    <div class="map-edit-btns">
      <button class="btn btn-sm btn-danger" id="btn-map-edit-delete" style="margin-right:auto;">🗑 <?php esc_html_e( 'Delete', 'translitlab' ); ?></button>
      <button class="btn btn-sm" id="btn-map-edit-cancel"><?php esc_html_e( 'Cancel', 'translitlab' ); ?></button>
      <button class="btn btn-sm btn-primary" id="btn-map-edit-ok"><?php esc_html_e( 'Apply', 'translitlab' ); ?></button>
    </div>
  </div>
</div>

<!-- Delete confirmation modal -->
<div id="confirm-delete-modal-backdrop">
  <div id="confirm-delete-modal">
    <h3><?php esc_html_e( 'Delete Map Entry?', 'translitlab' ); ?></h3>
    <p id="confirm-delete-text"><?php esc_html_e( 'Are you sure you want to delete this entry?', 'translitlab' ); ?></p>
    <div class="map-edit-btns">
      <button class="btn btn-sm" id="btn-confirm-delete-cancel"><?php esc_html_e( 'Cancel', 'translitlab' ); ?></button>
      <button class="btn btn-sm btn-danger" id="btn-confirm-delete-ok"><?php esc_html_e( 'Delete', 'translitlab' ); ?></button>
    </div>
  </div>
</div>

<!-- Import modal -->
<div id="import-modal-backdrop">
  <div id="import-modal">
    <h2>📥 <?php esc_html_e( 'Import Snippets', 'translitlab' ); ?></h2>
    <div id="import-drop-zone">
      <strong><?php esc_html_e( 'Drop .json file here', 'translitlab' ); ?></strong>
      <?php esc_html_e( 'or click to browse', 'translitlab' ); ?>
    </div>
    <input type="file" id="import-file-input" accept=".json" style="display:none;">
    <div id="import-preview"><?php esc_html_e( 'No file selected.', 'translitlab' ); ?></div>
    <div style="font-size:11px;color:var(--muted);line-height:1.5;">
      <?php esc_html_e( 'Accepts a single snippet object or an array of snippets.', 'translitlab' ); ?><br>
      <?php esc_html_e( 'Existing snippets with matching snippet_key will be updated.', 'translitlab' ); ?>
    </div>
    <div class="import-modal-btns">
      <button class="btn btn-sm" id="btn-import-cancel"><?php esc_html_e( 'Cancel', 'translitlab' ); ?></button>
      <button class="btn btn-sm btn-primary" id="btn-import-confirm" disabled><?php esc_html_e( 'Import', 'translitlab' ); ?></button>
    </div>
  </div>
</div>
        <?php
    }
}
