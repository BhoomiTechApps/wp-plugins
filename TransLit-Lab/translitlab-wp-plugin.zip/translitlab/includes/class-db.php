<?php
/**
 * TranslitLab — Database Layer
 * Uses $wpdb instead of raw PDO so everything lives inside the WP database.
 */

defined( 'ABSPATH' ) || exit;

class TranslitLab_DB {

    // ── Schema install ────────────────────────────────────────────────────────

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();

        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}translit_forward_map (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            section    VARCHAR(100)    NOT NULL DEFAULT 'general',
            map_key    VARCHAR(100)    NOT NULL DEFAULT '',
            map_val    VARCHAR(500)    NOT NULL DEFAULT '',
            sort_order INT             NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY section_order (section, sort_order)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}translit_reverse_map (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            section    VARCHAR(100)    NOT NULL DEFAULT 'general',
            map_key    VARCHAR(100)    NOT NULL DEFAULT '',
            map_val    VARCHAR(500)    NOT NULL DEFAULT '',
            sort_order INT             NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY section_order (section, sort_order)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}translit_snippets (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            snippet_key      VARCHAR(100)    NOT NULL DEFAULT '',
            label            VARCHAR(255)    NOT NULL DEFAULT '',
            direction        VARCHAR(20)     NOT NULL DEFAULT 'forward',
            hook_stage       VARCHAR(20)     NOT NULL DEFAULT 'pre',
            sort_order       INT             NOT NULL DEFAULT 0,
            is_active        TINYINT(1)      NOT NULL DEFAULT 1,
            source           VARCHAR(100)    NOT NULL DEFAULT 'custom',
            logic_description TEXT,
            js_body          LONGTEXT,
            php_body         LONGTEXT,
            PRIMARY KEY (id),
            UNIQUE KEY snippet_key (snippet_key),
            UNIQUE KEY dir_stage_order (direction, hook_stage, sort_order)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}translit_settings (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            engine      VARCHAR(10)     NOT NULL DEFAULT 'js',
            setting_key VARCHAR(100)    NOT NULL DEFAULT '',
            setting_val LONGTEXT,
            PRIMARY KEY (id),
            UNIQUE KEY engine_key (engine, setting_key)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) {
            dbDelta( $q );
        }

        // Seed defaults if tables are empty
        self::maybe_seed();
    }

    // ── Seeding ───────────────────────────────────────────────────────────────

    private static function maybe_seed(): void {
        global $wpdb;
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}translit_snippets" );
        if ( $count > 0 ) {
            return; // Already seeded
        }

        self::import_map( 'forward', TRANSLITLAB_DIR . 'data/forwardMap.json' );
        self::import_map( 'reverse', TRANSLITLAB_DIR . 'data/reverseMap.json' );
        self::import_snippets( TRANSLITLAB_DIR . 'data/defaults.json' );
        self::import_settings( 'js',  TRANSLITLAB_DIR . 'data/js-engine-settings.default.json' );
        self::import_settings( 'php', TRANSLITLAB_DIR . 'data/php-engine-settings.default.json' );
    }

    // ── Map helpers ───────────────────────────────────────────────────────────

    public static function map_table( string $type ): string {
        global $wpdb;
        return $type === 'reverse'
            ? $wpdb->prefix . 'translit_reverse_map'
            : $wpdb->prefix . 'translit_forward_map';
    }

    public static function load_map( string $type ): array {
        global $wpdb;
        $table = self::map_table( $type );
        $rows  = $wpdb->get_results(
            "SELECT id, section, map_key, map_val, sort_order
             FROM $table
             ORDER BY section ASC, sort_order ASC, id ASC",
            ARRAY_A
        );

        $map = [];
        foreach ( $rows as $row ) {
            $sec         = $row['section'] ?: 'general';
            $map[ $sec ][] = [ (int) $row['id'], $row['map_key'], $row['map_val'] ];
        }
        return $map;
    }

    public static function save_map( string $type, array $data ): array {
        global $wpdb;
        $table  = self::map_table( $type );
        $report = [];

        $wpdb->query( "DELETE FROM $table" );

        foreach ( $data as $section => $entries ) {
            if ( $section === '_meta' || ! is_array( $entries ) ) {
                continue;
            }
            $order = 0;
            foreach ( $entries as $pair ) {
                if ( ! is_array( $pair ) || count( $pair ) < 2 ) {
                    continue;
                }
                $wpdb->insert( $table, [
                    'section'    => $section,
                    'map_key'    => (string) $pair[0],
                    'map_val'    => (string) $pair[1],
                    'sort_order' => $order,
                ] );
                $order++;
            }
        }

        return $report;
    }

    public static function reorder_map_section( string $type, string $section, array $ids ): void {
        global $wpdb;
        $table = self::map_table( $type );

        // Step 1 — shift far out of range to avoid UNIQUE collisions
        $wpdb->query(
            $wpdb->prepare( "UPDATE $table SET sort_order = sort_order + 1000000 WHERE section = %s", $section )
        );

        // Step 2 — write new order
        foreach ( $ids as $newOrder => $id ) {
            $wpdb->update(
                $table,
                [ 'sort_order' => $newOrder ],
                [ 'id' => (int) $id, 'section' => $section ]
            );
        }
    }

    // ── Snippets helpers ──────────────────────────────────────────────────────

    public static function load_snippets(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'translit_snippets';
        $rows  = $wpdb->get_results(
            "SELECT snippet_key, label, direction, hook_stage, sort_order,
                    is_active, source, logic_description, js_body, php_body
             FROM $table
             ORDER BY direction ASC, hook_stage ASC, sort_order ASC, id ASC",
            ARRAY_A
        );
        foreach ( $rows as &$r ) {
            $r['sort_order'] = (int) $r['sort_order'];
            $r['is_active']  = (int) $r['is_active'];
        }
        return $rows;
    }

    public static function save_snippets( array $snippets ): array {
        global $wpdb;
        $table  = $wpdb->prefix . 'translit_snippets';
        $report = [];

        $incoming_keys = array_filter( array_column( $snippets, 'snippet_key' ) );

        if ( ! empty( $incoming_keys ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $incoming_keys ), '%s' ) );
            $wpdb->query(
                $wpdb->prepare( "DELETE FROM $table WHERE snippet_key NOT IN ($placeholders)", ...$incoming_keys )
            );
        } else {
            $wpdb->query( "DELETE FROM $table" );
        }

        // Bump sort_order to avoid transient UNIQUE collisions
        $wpdb->query( "UPDATE $table SET sort_order = sort_order + 1000000" );

        foreach ( $snippets as $s ) {
            if ( empty( $s['snippet_key'] ) ) {
                continue;
            }

            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO $table
                        (snippet_key, label, direction, hook_stage, sort_order,
                         is_active, source, logic_description, js_body, php_body)
                     VALUES (%s, %s, %s, %s, %d, %d, %s, %s, %s, %s)
                     ON DUPLICATE KEY UPDATE
                        label             = VALUES(label),
                        direction         = VALUES(direction),
                        hook_stage        = VALUES(hook_stage),
                        sort_order        = VALUES(sort_order),
                        is_active         = VALUES(is_active),
                        source            = VALUES(source),
                        logic_description = VALUES(logic_description),
                        js_body           = VALUES(js_body),
                        php_body          = VALUES(php_body)",
                    $s['snippet_key'],
                    $s['label']             ?? '',
                    $s['direction']         ?? 'forward',
                    $s['hook_stage']        ?? 'pre',
                    (int) ( $s['sort_order'] ?? 0 ),
                    (int) ( $s['is_active']  ?? 1 ),
                    $s['source']            ?? 'custom',
                    $s['logic_description'] ?? '',
                    $s['js_body']           ?? '',
                    $s['php_body']          ?? ''
                )
            );
        }

        return $report;
    }

    // ── Settings helpers ──────────────────────────────────────────────────────

    public static function load_settings( string $engine ): array {
        global $wpdb;
        $table = $wpdb->prefix . 'translit_settings';
        $rows  = $wpdb->get_results(
            $wpdb->prepare( "SELECT setting_key, setting_val FROM $table WHERE engine = %s", $engine ),
            ARRAY_A
        );

        $out = [];
        foreach ( $rows as $row ) {
            $v       = $row['setting_val'];
            $decoded = json_decode( $v, true );
            $out[ $row['setting_key'] ] = ( json_last_error() === JSON_ERROR_NONE ) ? $decoded : $v;
        }
        return $out;
    }

    public static function save_settings( string $engine, array $data ): void {
        global $wpdb;
        $table = $wpdb->prefix . 'translit_settings';

        foreach ( $data as $k => $v ) {
            $val = is_scalar( $v ) ? (string) $v : wp_json_encode( $v );
            $wpdb->query(
                $wpdb->prepare(
                    "INSERT INTO $table (engine, setting_key, setting_val)
                     VALUES (%s, %s, %s)
                     ON DUPLICATE KEY UPDATE setting_val = VALUES(setting_val)",
                    $engine, $k, $val
                )
            );
        }
    }

    // ── Import helpers (used by activation seeder + reset) ────────────────────

    public static function import_map( string $type, string $file ): bool {
        if ( ! file_exists( $file ) ) {
            return false;
        }
        $data = json_decode( file_get_contents( $file ), true );
        if ( ! is_array( $data ) ) {
            return false;
        }
        self::save_map( $type, $data );
        return true;
    }

    public static function import_snippets( string $file ): bool {
        if ( ! file_exists( $file ) ) {
            return false;
        }
        $data = json_decode( file_get_contents( $file ), true );
        if ( ! is_array( $data ) ) {
            return false;
        }
        self::save_snippets( $data );
        return true;
    }

    public static function import_settings( string $engine, string $file ): bool {
        if ( ! file_exists( $file ) ) {
            return false;
        }
        $data = json_decode( file_get_contents( $file ), true );
        if ( ! is_array( $data ) ) {
            return false;
        }
        self::save_settings( $engine, $data );
        return true;
    }

    // ── Reset ─────────────────────────────────────────────────────────────────

    public static function reset_defaults( string $which = 'all' ): void {
        if ( $which === 'forward' || $which === 'all' ) {
            self::import_map( 'forward', TRANSLITLAB_DIR . 'data/forwardMap.json' );
        }
        if ( $which === 'reverse' || $which === 'all' ) {
            self::import_map( 'reverse', TRANSLITLAB_DIR . 'data/reverseMap.json' );
        }
        if ( $which === 'snippets' || $which === 'all' ) {
            self::import_snippets( TRANSLITLAB_DIR . 'data/defaults.json' );
        }
        if ( $which === 'php_settings' || $which === 'all' ) {
            self::import_settings( 'php', TRANSLITLAB_DIR . 'data/php-engine-settings.default.json' );
        }
        if ( $which === 'js_settings' || $which === 'all' ) {
            self::import_settings( 'js', TRANSLITLAB_DIR . 'data/js-engine-settings.default.json' );
        }
    }
}
