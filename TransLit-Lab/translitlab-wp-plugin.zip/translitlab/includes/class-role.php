<?php
/**
 * TranslitLab — Custom Role
 * Registers and removes the "Transliterator" role.
 */

defined( 'ABSPATH' ) || exit;

class TranslitLab_Role {

    /** Called on plugin activation. */
    public static function create_role(): void {
        // Only create if it doesn't already exist
        if ( get_role( TRANSLITLAB_ROLE ) ) {
            return;
        }

        add_role(
            TRANSLITLAB_ROLE,
            __( 'Transliterator', 'translitlab' ),
            [
                'read' => true,  // Basic WP capability so users can log in
            ]
        );
    }

    /** Called on plugin deactivation (not deletion). */
    public static function remove_role(): void {
        // We intentionally leave user accounts intact on deactivation.
        // The role is only hard-removed on uninstall (see uninstall.php).
    }

    /**
     * Returns true if the given user has access to TranslitLab.
     * Admins always pass; Transliterators pass if they have been
     * explicitly granted access in the plugin options.
     */
    public static function user_can_access( int $user_id ): bool {
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return false;
        }

        // Admins/editors always have access
        if ( user_can( $user_id, 'manage_options' ) ) {
            return true;
        }

        // Must hold the Transliterator role
        if ( ! in_array( TRANSLITLAB_ROLE, (array) $user->roles, true ) ) {
            return false;
        }

        // Must be in the approved-users list
        $approved = get_option( 'translitlab_approved_users', [] );
        return in_array( $user_id, array_map( 'intval', (array) $approved ), true );
    }

    /**
     * Returns the tab visibility config for a specific user.
     * Falls back to the global tab config, then to all-enabled.
     */
    public static function user_tab_config( int $user_id ): array {
        $all_tabs = [ 'test', 'snippets', 'maps', 'engines', 'debug' ];

        // Per-user override?
        $per_user = get_user_meta( $user_id, 'translitlab_tabs', true );
        if ( is_array( $per_user ) && ! empty( $per_user ) ) {
            return $per_user;
        }

        // Global default
        $global = get_option( 'translitlab_default_tabs', $all_tabs );
        return is_array( $global ) ? $global : $all_tabs;
    }
}
