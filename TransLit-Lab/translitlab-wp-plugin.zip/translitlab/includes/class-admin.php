<?php
/**
 * TranslitLab — Admin Panel
 *
 * Settings page under Settings > TranslitLab.
 *
 * Features:
 *  1. Assign / revoke the Transliterator role to any registered user.
 *  2. Grant / deny individual approved-user access within that role.
 *  3. Configure which tabs each user can see (per-user override or global default).
 */

defined( 'ABSPATH' ) || exit;

class TranslitLab_Admin {

    private const MENU_SLUG = 'translitlab-settings';

    public static function init(): void {
        add_action( 'admin_menu',    [ __CLASS__, 'add_menu'         ] );
        add_action( 'admin_init',    [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_post_translitlab_save_users', [ __CLASS__, 'handle_save_users' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
    }

    // ── Menu ─────────────────────────────────────────────────────────────────

    public static function add_menu(): void {
        add_options_page(
            __( 'TranslitLab Settings', 'translitlab' ),
            __( 'TranslitLab', 'translitlab' ),
            'manage_options',
            self::MENU_SLUG,
            [ __CLASS__, 'render_page' ]
        );
    }

    // ── Settings API ─────────────────────────────────────────────────────────

    public static function register_settings(): void {
        register_setting( 'translitlab_options', 'translitlab_approved_users' );
        register_setting( 'translitlab_options', 'translitlab_default_tabs' );
    }

    // ── Admin CSS ────────────────────────────────────────────────────────────

    public static function enqueue_admin_assets( string $hook ): void {
        if ( strpos( $hook, self::MENU_SLUG ) === false ) {
            return;
        }
        wp_add_inline_style( 'wp-admin', self::admin_css() );
    }

    private static function admin_css(): string {
        return '
        .tl-card{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:24px;margin-bottom:24px;}
        .tl-card h2{margin-top:0;font-size:1.1rem;border-bottom:1px solid #e2e8f0;padding-bottom:12px;}
        .tl-user-table{width:100%;border-collapse:collapse;}
        .tl-user-table th{background:#f8fafc;font-weight:600;text-align:left;padding:10px 12px;border-bottom:2px solid #e2e8f0;font-size:13px;}
        .tl-user-table td{padding:10px 12px;border-bottom:1px solid #f1f5f9;vertical-align:middle;font-size:13px;}
        .tl-user-table tr:last-child td{border-bottom:none;}
        .tl-user-table tr:hover td{background:#fafbff;}
        .tl-tab-checks label{display:inline-flex;align-items:center;gap:5px;margin-right:12px;font-size:13px;cursor:pointer;}
        .tl-badge{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:600;}
        .tl-badge-role{background:#dbeafe;color:#1d4ed8;}
        .tl-badge-access{background:#dcfce7;color:#15803d;}
        .tl-badge-no{background:#fee2e2;color:#dc2626;}
        .tl-no-users{color:#64748b;font-style:italic;padding:16px 0;}
        .tl-shortcode-box{font-family:monospace;background:#f1f5f9;padding:8px 14px;border-radius:6px;display:inline-block;font-size:14px;border:1px solid #e2e8f0;}
        .tl-search{margin-bottom:12px;width:100%;max-width:360px;padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;}
        ';
    }

    // ── Handle form submission ────────────────────────────────────────────────

    public static function handle_save_users(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Permission denied.', 'translitlab' ) );
        }
        check_admin_referer( 'translitlab_save_users' );

        // ── Global default tabs ───────────────────────────────────────────────
        $all_tabs      = [ 'test', 'snippets', 'maps', 'engines', 'debug' ];
        $default_tabs  = [];
        foreach ( $all_tabs as $tab ) {
            if ( ! empty( $_POST[ 'global_tab_' . $tab ] ) ) {
                $default_tabs[] = $tab;
            }
        }
        update_option( 'translitlab_default_tabs', $default_tabs );

        // ── Per-user role, access & tab overrides ─────────────────────────────
        $approved        = [];
        $all_user_ids    = get_users( [ 'fields' => 'ID' ] );

        foreach ( $all_user_ids as $uid ) {
            $uid = (int) $uid;
            if ( $uid === get_current_user_id() ) {
                continue; // Skip self — admins always have access
            }

            $user = get_userdata( $uid );

            // Assign / remove Transliterator role
            $give_role = ! empty( $_POST[ 'role_' . $uid ] );
            if ( $give_role ) {
                $user->add_role( TRANSLITLAB_ROLE );
            } else {
                $user->remove_role( TRANSLITLAB_ROLE );
            }

            // Approve / revoke access
            $grant_access = $give_role && ! empty( $_POST[ 'access_' . $uid ] );
            if ( $grant_access ) {
                $approved[] = $uid;
            }

            // Per-user tab overrides
            $use_custom = ! empty( $_POST[ 'custom_tabs_' . $uid ] );
            if ( $use_custom ) {
                $user_tabs = [];
                foreach ( $all_tabs as $tab ) {
                    if ( ! empty( $_POST[ 'tab_' . $uid . '_' . $tab ] ) ) {
                        $user_tabs[] = $tab;
                    }
                }
                update_user_meta( $uid, 'translitlab_tabs', $user_tabs );
            } else {
                delete_user_meta( $uid, 'translitlab_tabs' );
            }
        }

        update_option( 'translitlab_approved_users', $approved );

        wp_redirect( add_query_arg( [
            'page'    => self::MENU_SLUG,
            'updated' => '1',
        ], admin_url( 'options-general.php' ) ) );
        exit;
    }

    // ── Render page ───────────────────────────────────────────────────────────

    public static function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $approved     = get_option( 'translitlab_approved_users', [] );
        $approved     = array_map( 'intval', (array) $approved );
        $default_tabs = get_option( 'translitlab_default_tabs', [ 'test', 'snippets', 'maps', 'engines', 'debug' ] );
        $all_tabs     = [
            'test'     => '⚡ Test',
            'snippets' => '✂️ Snippets',
            'maps'     => '🗺️ Maps',
            'engines'  => '🧩 Engines',
            'debug'    => '🐛 Debug',
        ];

        // All non-admin users
        $users = get_users( [
            'role__not_in' => [ 'administrator' ],
            'orderby'      => 'display_name',
        ] );

        ?>
        <div class="wrap">
          <h1>🔣 <?php esc_html_e( 'TranslitLab Settings', 'translitlab' ); ?></h1>

          <?php if ( ! empty( $_GET['updated'] ) ) : ?>
          <div class="notice notice-success is-dismissible">
            <p><?php esc_html_e( 'Settings saved.', 'translitlab' ); ?></p>
          </div>
          <?php endif; ?>

          <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="translitlab_save_users">
            <?php wp_nonce_field( 'translitlab_save_users' ); ?>

            <!-- ── Shortcode Info ───────────────────────────────────────────── -->
            <div class="tl-card">
              <h2><?php esc_html_e( 'Frontend Shortcode', 'translitlab' ); ?></h2>
              <p><?php esc_html_e( 'Place this shortcode on any page to show the lab to authorised users:', 'translitlab' ); ?></p>
              <div class="tl-shortcode-box">[translitlab]</div>
              <p style="color:#64748b;font-size:13px;margin-top:8px;">
                <?php esc_html_e( 'Non-logged-in visitors and users without access will see a polite message instead.', 'translitlab' ); ?>
              </p>
            </div>

            <!-- ── Global Default Tabs ─────────────────────────────────────── -->
            <div class="tl-card">
              <h2><?php esc_html_e( 'Default Tab Visibility', 'translitlab' ); ?></h2>
              <p style="color:#64748b;font-size:13px;margin-bottom:10px;">
                <?php esc_html_e( 'Choose which tabs are shown by default for all Transliterators (you can override per user below).', 'translitlab' ); ?>
              </p>
              <div class="tl-tab-checks">
                <?php foreach ( $all_tabs as $slug => $label ) : ?>
                <label>
                  <input type="checkbox" name="global_tab_<?php echo esc_attr( $slug ); ?>"
                    <?php checked( in_array( $slug, (array) $default_tabs, true ) ); ?>>
                  <?php echo esc_html( $label ); ?>
                </label>
                <?php endforeach; ?>
              </div>
            </div>

            <!-- ── User Access Table ───────────────────────────────────────── -->
            <div class="tl-card">
              <h2><?php esc_html_e( 'User Access & Tab Control', 'translitlab' ); ?></h2>

              <?php if ( empty( $users ) ) : ?>
                <p class="tl-no-users"><?php esc_html_e( 'No non-admin users found. Register users first.', 'translitlab' ); ?></p>
              <?php else : ?>

              <input type="text" id="tl-user-search" class="tl-search"
                placeholder="<?php esc_attr_e( 'Search users…', 'translitlab' ); ?>"
                oninput="tlFilterUsers(this.value)">

              <table class="tl-user-table" id="tl-user-table">
                <thead>
                  <tr>
                    <th><?php esc_html_e( 'User', 'translitlab' ); ?></th>
                    <th><?php esc_html_e( 'Current Roles', 'translitlab' ); ?></th>
                    <th style="text-align:center;"><?php esc_html_e( 'Transliterator Role', 'translitlab' ); ?></th>
                    <th style="text-align:center;"><?php esc_html_e( 'Lab Access', 'translitlab' ); ?></th>
                    <th><?php esc_html_e( 'Tab Visibility', 'translitlab' ); ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ( $users as $user ) :
                    $uid        = (int) $user->ID;
                    $has_role   = in_array( TRANSLITLAB_ROLE, (array) $user->roles, true );
                    $has_access = in_array( $uid, $approved, true );
                    $user_tabs  = get_user_meta( $uid, 'translitlab_tabs', true );
                    $custom     = is_array( $user_tabs ) && ! empty( $user_tabs );
                    $active_tabs = $custom ? $user_tabs : (array) $default_tabs;
                  ?>
                  <tr data-uname="<?php echo esc_attr( strtolower( $user->display_name . ' ' . $user->user_email ) ); ?>">
                    <td>
                      <strong><?php echo esc_html( $user->display_name ); ?></strong><br>
                      <span style="color:#64748b;font-size:12px;"><?php echo esc_html( $user->user_email ); ?></span>
                    </td>
                    <td>
                      <?php foreach ( $user->roles as $role ) :
                        if ( $role === TRANSLITLAB_ROLE ) continue; ?>
                        <span class="tl-badge tl-badge-role"><?php echo esc_html( $role ); ?></span>
                      <?php endforeach; ?>
                    </td>
                    <td style="text-align:center;">
                      <input type="checkbox" name="role_<?php echo $uid; ?>"
                        id="role_<?php echo $uid; ?>"
                        <?php checked( $has_role ); ?>
                        onchange="tlRoleToggle(<?php echo $uid; ?>, this.checked)">
                    </td>
                    <td style="text-align:center;">
                      <input type="checkbox" name="access_<?php echo $uid; ?>"
                        id="access_<?php echo $uid; ?>"
                        <?php checked( $has_access ); ?>
                        <?php disabled( ! $has_role ); ?>>
                    </td>
                    <td>
                      <label style="font-size:12px;margin-bottom:6px;display:block;">
                        <input type="checkbox" name="custom_tabs_<?php echo $uid; ?>"
                          id="custom_tabs_<?php echo $uid; ?>"
                          <?php checked( $custom ); ?>
                          onchange="tlCustomTabsToggle(<?php echo $uid; ?>, this.checked)">
                        <?php esc_html_e( 'Override defaults', 'translitlab' ); ?>
                      </label>
                      <div class="tl-tab-checks" id="tab_row_<?php echo $uid; ?>"
                        style="<?php echo $custom ? '' : 'opacity:.35;pointer-events:none;'; ?>">
                        <?php foreach ( $all_tabs as $slug => $label ) : ?>
                        <label>
                          <input type="checkbox"
                            name="tab_<?php echo $uid; ?>_<?php echo esc_attr( $slug ); ?>"
                            <?php checked( in_array( $slug, $active_tabs, true ) ); ?>>
                          <?php echo esc_html( $label ); ?>
                        </label>
                        <?php endforeach; ?>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>

              <?php endif; ?>
            </div>

            <?php submit_button( __( 'Save All Settings', 'translitlab' ) ); ?>
          </form>
        </div>

        <script>
        function tlRoleToggle(uid, checked) {
            var accessBox = document.getElementById('access_' + uid);
            if (accessBox) accessBox.disabled = !checked;
            if (!checked && accessBox) accessBox.checked = false;
        }
        function tlCustomTabsToggle(uid, checked) {
            var row = document.getElementById('tab_row_' + uid);
            if (row) {
                row.style.opacity = checked ? '1' : '0.35';
                row.style.pointerEvents = checked ? '' : 'none';
            }
        }
        function tlFilterUsers(q) {
            q = q.toLowerCase();
            document.querySelectorAll('#tl-user-table tbody tr').forEach(function(tr) {
                var name = tr.dataset.uname || '';
                tr.style.display = name.includes(q) ? '' : 'none';
            });
        }
        </script>
        <?php
    }
}
