<?php
/**
 * TranslitLab — Uninstall
 * Runs when the plugin is DELETED (not just deactivated).
 * Drops all plugin tables and options.
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// Drop tables
$tables = [
    $wpdb->prefix . 'translit_forward_map',
    $wpdb->prefix . 'translit_reverse_map',
    $wpdb->prefix . 'translit_snippets',
    $wpdb->prefix . 'translit_settings',
];

foreach ( $tables as $table ) {
    $wpdb->query( "DROP TABLE IF EXISTS `$table`" ); // phpcs:ignore WordPress.DB
}

// Remove options
delete_option( 'translitlab_approved_users' );
delete_option( 'translitlab_default_tabs' );

// Remove user meta
$wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'translitlab_tabs' ] );

// Remove the custom role
remove_role( 'transliterator' );
