/**
 * ICB Frontend Extension – admin.js
 *
 * Drives the "Frontend Access Control" settings page.
 * Reads initial state from icbfe_admin_vars (injected inline by ICBFE_Admin::enqueue_assets).
 */
/* global jQuery, icbfe_admin_vars */
(function ($) {
    'use strict';

    const vars    = icbfe_admin_vars || {};
    const strings = vars.strings || {};

    // ── Notice helper ─────────────────────────────────────────────────────────

    function showNotice(type, msg) {
        const $n = $('#icbfe-admin-notice');
        $n.removeClass('icbfe-admin-notice--success icbfe-admin-notice--error')
          .addClass('icbfe-admin-notice--' + type)
          .html(msg)
          .show();
        if (type === 'success') {
            setTimeout(function () { $n.fadeOut(); }, 4000);
        }
    }

    // ── Auto-imply view when edit is checked ──────────────────────────────────
    // Enabling config_edit → auto-enable config_view; same for lexicon.

    const editViewPairs = {
        config_edit:  'config_view',
        lexicon_edit: 'lexicon_view',
    };

    $(document).on('change', '.icbfe-perm-toggle', function () {
        const feature = $(this).data('feature');
        const tier    = $(this).data('tier');
        const checked = $(this).is(':checked');

        if (editViewPairs[feature] && checked) {
            // Enabling edit – force view on too
            const viewFeature = editViewPairs[feature];
            $('[data-tier="' + tier + '"][data-feature="' + viewFeature + '"]').prop('checked', true);
        }

        // Disabling view – force edit off too (reverse pair)
        const reverseMap = {};
        $.each(editViewPairs, function (edit, view) { reverseMap[view] = edit; });
        if (reverseMap[feature] && !checked) {
            const editFeature = reverseMap[feature];
            $('[data-tier="' + tier + '"][data-feature="' + editFeature + '"]').prop('checked', false);
        }
    });

    // ── Collect current checkbox state ────────────────────────────────────────

    function collectAccess() {
        const data = { subscriber: {}, guest: {} };
        $('.icbfe-perm-toggle').each(function () {
            const tier    = $(this).data('tier');
            const feature = $(this).data('feature');
            if (data[tier]) {
                data[tier][feature] = $(this).is(':checked');
            }
        });
        return data;
    }

    // ── Save ──────────────────────────────────────────────────────────────────

    $('#icbfe-admin-save-btn').on('click', function () {
        const $btn = $(this);
        $btn.prop('disabled', true).text('Saving…');

        $.post(ajaxurl, {
            action: 'icbfe_admin_save_access',
            nonce:  vars.nonce,
            access: JSON.stringify(collectAccess()),
        })
        .done(function (r) {
            if (r.success) {
                showNotice('success', '✔ ' + r.data.message);
            } else {
                showNotice('error', r.data.message || strings.error);
            }
        })
        .fail(function () { showNotice('error', strings.error || 'Save failed.'); })
        .always(function () { $btn.prop('disabled', false).text('Save Access Settings'); });
    });

    // ── Reset ─────────────────────────────────────────────────────────────────

    $('#icbfe-admin-reset-btn').on('click', function () {
        if (!confirm(strings.confirm_reset || 'Reset all permissions to defaults?')) { return; }

        const $btn = $(this);
        $btn.prop('disabled', true);

        $.post(ajaxurl, {
            action: 'icbfe_admin_reset_access',
            nonce:  vars.nonce,
        })
        .done(function (r) {
            if (r.success) {
                // Re-apply defaults to checkboxes
                const access = r.data.access || {};
                $.each(['subscriber', 'guest'], function (_, tier) {
                    $.each(access[tier] || {}, function (feature, val) {
                        $('[data-tier="' + tier + '"][data-feature="' + feature + '"]')
                            .prop('checked', !!val);
                    });
                });
                showNotice('success', '✔ ' + r.data.message);
            }
        })
        .fail(function () { showNotice('error', strings.error || 'Reset failed.'); })
        .always(function () { $btn.prop('disabled', false); });
    });

}(jQuery));
