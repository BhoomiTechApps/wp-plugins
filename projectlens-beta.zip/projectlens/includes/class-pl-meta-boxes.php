<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PL_Meta_Boxes {

    public static function init() {
        add_action( 'add_meta_boxes', [ __CLASS__, 'register_meta_boxes' ] );
        add_action( 'save_post_pl_project', [ __CLASS__, 'save_meta' ], 10, 2 );
    }

    public static function register_meta_boxes() {
        add_meta_box(
            'pl_segments',
            __( 'Project Segments', 'projectlens' ),
            [ __CLASS__, 'render_segments_box' ],
            'pl_project', 'normal', 'high'
        );
        add_meta_box(
            'pl_project_settings',
            __( 'Project Settings & Funding Information', 'projectlens' ),
            [ __CLASS__, 'render_settings_box' ],
            'pl_project', 'normal', 'default'
        );
        add_meta_box(
            'pl_styling',
            __( 'Styling & Appearance', 'projectlens' ),
            [ __CLASS__, 'render_styling_box' ],
            'pl_project', 'side', 'default'
        );
    }

    // -------------------------------------------------------------------------
    // Segments meta box
    // -------------------------------------------------------------------------

    public static function render_segments_box( $post ) {
        wp_nonce_field( 'pl_save_segments', 'pl_segments_nonce' );
        $segments = get_post_meta( $post->ID, '_pl_segments', true ) ?: [];
        $labels   = PL_Segment::get_type_labels();
        ?>
        <div id="pl-segments-wrap">
            <div id="pl-sortable-segments">
                <?php foreach ( $segments as $i => $segment ) :
                    PL_Segment::render_admin_segment( $segment, $i );
                endforeach; ?>
            </div>

            <div id="pl-add-segment-bar">
                <label><?php esc_html_e( 'Add Segment:', 'projectlens' ); ?></label>
                <select id="pl-new-segment-type">
                    <?php foreach ( $labels as $key => $label ) : ?>
                    <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="button" id="pl-btn-add-segment" class="button button-primary">
                    + <?php esc_html_e( 'Add Segment', 'projectlens' ); ?>
                </button>
            </div>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Project settings meta box
    // -------------------------------------------------------------------------

    public static function render_settings_box( $post ) {
        wp_nonce_field( 'pl_save_settings', 'pl_settings_nonce' );
        $settings = get_post_meta( $post->ID, '_pl_project_settings', true ) ?: [];
        $s = $settings;

        $statuses = [
            'concept'      => __( 'Concept',        'projectlens' ),
            'planning'     => __( 'Planning',        'projectlens' ),
            'active'       => __( 'Active / Ongoing','projectlens' ),
            'completed'    => __( 'Completed',       'projectlens' ),
            'certified'    => __( 'Certified',       'projectlens' ),
            'suspended'    => __( 'Suspended',       'projectlens' ),
            'cancelled'    => __( 'Cancelled',       'projectlens' ),
        ];
        $currencies = [ 'USD','EUR','GBP','INR','AUD','CAD','JPY','CNY','CHF','SEK','NOK','DKK' ];
        ?>
        <div class="pl-settings-grid">

            <div class="pl-settings-section">
                <h4><?php esc_html_e( 'Project Identity', 'projectlens' ); ?></h4>
                <table class="pl-form-table">
                    <tr>
                        <th><label><?php esc_html_e( 'Project Code / ID', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[project_code]" value="<?php echo esc_attr($s['project_code'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Project Status', 'projectlens' ); ?></label></th>
                        <td>
                            <select name="pl_settings[project_status]">
                                <?php foreach ( $statuses as $val => $label ) : ?>
                                <option value="<?php echo $val; ?>" <?php selected( $s['project_status'] ?? 'concept', $val ); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Short Description', 'projectlens' ); ?></label></th>
                        <td><textarea name="pl_settings[short_description]" rows="3" class="large-text"><?php echo esc_textarea( $s['short_description'] ?? '' ); ?></textarea></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Project Location', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[location]" value="<?php echo esc_attr($s['location'] ?? ''); ?>" class="regular-text" placeholder="e.g. Assam, India" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Country / Region', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[country]" value="<?php echo esc_attr($s['country'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Website / URL', 'projectlens' ); ?></label></th>
                        <td><input type="url" name="pl_settings[website]" value="<?php echo esc_url($s['website'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                </table>
            </div>

            <div class="pl-settings-section">
                <h4><?php esc_html_e( 'Dates & Duration', 'projectlens' ); ?></h4>
                <table class="pl-form-table">
                    <tr>
                        <th><label><?php esc_html_e( 'Start Date', 'projectlens' ); ?></label></th>
                        <td><input type="date" name="pl_settings[start_date]" value="<?php echo esc_attr($s['start_date'] ?? ''); ?>" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'End Date (Planned)', 'projectlens' ); ?></label></th>
                        <td><input type="date" name="pl_settings[end_date]" value="<?php echo esc_attr($s['end_date'] ?? ''); ?>" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Actual Completion Date', 'projectlens' ); ?></label></th>
                        <td><input type="date" name="pl_settings[completion_date]" value="<?php echo esc_attr($s['completion_date'] ?? ''); ?>" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Reporting Period', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[reporting_period]" value="<?php echo esc_attr($s['reporting_period'] ?? ''); ?>" placeholder="e.g. Q3 2024 / Annual" /></td>
                    </tr>
                </table>
            </div>

            <div class="pl-settings-section">
                <h4><?php esc_html_e( 'Funding & Budget', 'projectlens' ); ?></h4>
                <table class="pl-form-table">
                    <tr>
                        <th><label><?php esc_html_e( 'Funding Agency / Donor', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[funder_name]" value="<?php echo esc_attr($s['funder_name'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Implementing Agency', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[implementing_agency]" value="<?php echo esc_attr($s['implementing_agency'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Executing Agency', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[executing_agency]" value="<?php echo esc_attr($s['executing_agency'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Grant / Contract Number', 'projectlens' ); ?></label></th>
                        <td><input type="text" name="pl_settings[grant_number]" value="<?php echo esc_attr($s['grant_number'] ?? ''); ?>" class="regular-text" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Total Budget', 'projectlens' ); ?></label></th>
                        <td>
                            <select name="pl_settings[budget_currency]" style="width:80px;">
                                <?php foreach ( $currencies as $c ) : ?>
                                <option value="<?php echo $c; ?>" <?php selected( $s['budget_currency'] ?? 'USD', $c ); ?>><?php echo $c; ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="number" name="pl_settings[budget_total]" value="<?php echo esc_attr($s['budget_total'] ?? ''); ?>" placeholder="0.00" step="0.01" style="width:160px;" />
                        </td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Grant Amount', 'projectlens' ); ?></label></th>
                        <td><input type="number" name="pl_settings[grant_amount]" value="<?php echo esc_attr($s['grant_amount'] ?? ''); ?>" placeholder="0.00" step="0.01" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Co-financing Amount', 'projectlens' ); ?></label></th>
                        <td><input type="number" name="pl_settings[cofinancing]" value="<?php echo esc_attr($s['cofinancing'] ?? ''); ?>" placeholder="0.00" step="0.01" /></td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Disbursement to Date', 'projectlens' ); ?></label></th>
                        <td><input type="number" name="pl_settings[disbursement]" value="<?php echo esc_attr($s['disbursement'] ?? ''); ?>" placeholder="0.00" step="0.01" /></td>
                    </tr>
                </table>
            </div>

            <div class="pl-settings-section">
                <h4><?php esc_html_e( 'Display Settings', 'projectlens' ); ?></h4>
                <table class="pl-form-table">
                    <tr>
                        <th><label><?php esc_html_e( 'Word Limit (truncation)', 'projectlens' ); ?></label></th>
                        <td>
                            <input type="number" name="pl_settings[word_limit]" value="<?php echo esc_attr($s['word_limit'] ?? 60); ?>" min="10" max="500" style="width:80px;" />
                            <p class="description"><?php esc_html_e('Number of words shown in summary for Descriptive segments. Default: 60.', 'projectlens'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Show Project Header', 'projectlens' ); ?></label></th>
                        <td>
                            <label>
                                <input type="checkbox" name="pl_settings[show_header]" value="1" <?php checked( $s['show_header'] ?? 1 ); ?> />
                                <?php esc_html_e( 'Display title, featured image and status badge at top of page', 'projectlens' ); ?>
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th><label><?php esc_html_e( 'Default Detail Panel', 'projectlens' ); ?></label></th>
                        <td>
                            <select name="pl_settings[default_detail]">
                                <option value="metadata" <?php selected($s['default_detail'] ?? 'metadata','metadata'); ?>><?php esc_html_e('Project Metadata','projectlens'); ?></option>
                                <option value="first" <?php selected($s['default_detail'] ?? '','first'); ?>><?php esc_html_e('First Segment','projectlens'); ?></option>
                                <option value="empty" <?php selected($s['default_detail'] ?? '','empty'); ?>><?php esc_html_e('Empty / Placeholder','projectlens'); ?></option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Styling meta box
    // -------------------------------------------------------------------------

    public static function render_styling_box( $post ) {
        wp_nonce_field( 'pl_save_styling', 'pl_styling_nonce' );
        $style = get_post_meta( $post->ID, '_pl_styling', true ) ?: [];
        ?>
        <table class="pl-form-table pl-style-table">
            <tr>
                <th><?php esc_html_e('Accent Color', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[accent_color]" value="<?php echo esc_attr($style['accent_color'] ?? '#2563eb'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Heading Color', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[heading_color]" value="<?php echo esc_attr($style['heading_color'] ?? '#111827'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Body Text Color', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[body_color]" value="<?php echo esc_attr($style['body_color'] ?? '#374151'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Background Color', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[bg_color]" value="<?php echo esc_attr($style['bg_color'] ?? '#f9fafb'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Panel Background', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[panel_bg]" value="<?php echo esc_attr($style['panel_bg'] ?? '#ffffff'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Segment Border', 'projectlens'); ?></th>
                <td><input type="text" name="pl_styling[border_color]" value="<?php echo esc_attr($style['border_color'] ?? '#e5e7eb'); ?>" class="pl-color-picker" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Border Radius (px)', 'projectlens'); ?></th>
                <td><input type="number" name="pl_styling[border_radius]" value="<?php echo esc_attr($style['border_radius'] ?? 8); ?>" min="0" max="32" style="width:60px;" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Base Font Size (px)', 'projectlens'); ?></th>
                <td><input type="number" name="pl_styling[font_size_base]" value="<?php echo esc_attr($style['font_size_base'] ?? 15); ?>" min="12" max="22" style="width:60px;" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Heading Font Size (px)', 'projectlens'); ?></th>
                <td><input type="number" name="pl_styling[font_size_heading]" value="<?php echo esc_attr($style['font_size_heading'] ?? 20); ?>" min="14" max="40" style="width:60px;" /></td>
            </tr>
            <tr>
                <th><?php esc_html_e('Button Style', 'projectlens'); ?></th>
                <td>
                    <select name="pl_styling[btn_style]">
                        <option value="filled"   <?php selected($style['btn_style'] ?? 'filled',   'filled'); ?>><?php esc_html_e('Filled',   'projectlens'); ?></option>
                        <option value="outline"  <?php selected($style['btn_style'] ?? '', 'outline');  ?>><?php esc_html_e('Outline',  'projectlens'); ?></option>
                        <option value="ghost"    <?php selected($style['btn_style'] ?? '', 'ghost');    ?>><?php esc_html_e('Ghost',    'projectlens'); ?></option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e('Font Family', 'projectlens'); ?></th>
                <td>
                    <select name="pl_styling[font_family]">
                        <option value="system"   <?php selected($style['font_family'] ?? 'system', 'system'); ?>><?php esc_html_e('System Default',  'projectlens'); ?></option>
                        <option value="inter"    <?php selected($style['font_family'] ?? '', 'inter');    ?>><?php esc_html_e('Inter',       'projectlens'); ?></option>
                        <option value="georgia"  <?php selected($style['font_family'] ?? '', 'georgia');  ?>><?php esc_html_e('Georgia',     'projectlens'); ?></option>
                        <option value="roboto"   <?php selected($style['font_family'] ?? '', 'roboto');   ?>><?php esc_html_e('Roboto',      'projectlens'); ?></option>
                    </select>
                </td>
            </tr>
        </table>
        <?php
    }

    // -------------------------------------------------------------------------
    // Save all meta
    // -------------------------------------------------------------------------

    public static function save_meta( $post_id, $post ) {
        if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Segments
        if ( isset($_POST['pl_segments_nonce']) && wp_verify_nonce( $_POST['pl_segments_nonce'], 'pl_save_segments' ) ) {
            $raw      = $_POST['pl_segments'] ?? [];
            $segments = self::sanitize_segments( $raw );
            update_post_meta( $post_id, '_pl_segments', $segments );
        }

        // Settings
        if ( isset($_POST['pl_settings_nonce']) && wp_verify_nonce( $_POST['pl_settings_nonce'], 'pl_save_settings' ) ) {
            $raw      = $_POST['pl_settings'] ?? [];
            $settings = self::sanitize_settings( $raw );
            update_post_meta( $post_id, '_pl_project_settings', $settings );
        }

        // Styling
        if ( isset($_POST['pl_styling_nonce']) && wp_verify_nonce( $_POST['pl_styling_nonce'], 'pl_save_styling' ) ) {
            $raw    = $_POST['pl_styling'] ?? [];
            $styled = self::sanitize_styling( $raw );
            update_post_meta( $post_id, '_pl_styling', $styled );
        }
    }

    private static function sanitize_segments( $raw ) {
        $out = [];
        if ( ! is_array($raw) ) return $out;
        foreach ( $raw as $seg ) {
            if ( ! is_array($seg) ) continue;
            $type    = sanitize_key( $seg['type'] ?? 'descriptive' );
            $clean   = [
                'id'      => sanitize_text_field( $seg['id']    ?? uniqid('seg_') ),
                'type'    => $type,
                'title'   => sanitize_text_field( $seg['title'] ?? '' ),
                'enabled' => ! empty( $seg['enabled'] ),
            ];
            switch ( $type ) {
                case 'descriptive':
                    $clean['subtitle']       = sanitize_text_field( $seg['subtitle'] ?? '' );
                    $clean['content']        = wp_kses_post( $seg['content'] ?? '' );
                    $clean['detail_content'] = wp_kses_post( $seg['detail_content'] ?? '' );
                    break;
                case 'media':
                    $slides = [];
                    foreach ( (array)($seg['slides'] ?? []) as $slide ) {
                        $slides[] = [
                            'media_id'   => absint( $slide['media_id'] ?? 0 ),
                            'media_type' => sanitize_key( $slide['media_type'] ?? 'image' ),
                            'video_url'  => esc_url_raw( $slide['video_url'] ?? '' ),
                            'caption'    => sanitize_text_field( $slide['caption'] ?? '' ),
                            'description'=> sanitize_textarea_field( $slide['description'] ?? '' ),
                            'geo_lat'    => sanitize_text_field( $slide['geo_lat'] ?? '' ),
                            'geo_lng'    => sanitize_text_field( $slide['geo_lng'] ?? '' ),
                            'geo_label'  => sanitize_text_field( $slide['geo_label'] ?? '' ),
                        ];
                    }
                    $clean['slides'] = $slides;
                    break;
                case 'metadata':
                    $fields = [];
                    foreach ( (array)($seg['fields'] ?? []) as $f ) {
                        $fields[] = [
                            'label' => sanitize_text_field( $f['label'] ?? '' ),
                            'value' => sanitize_text_field( $f['value'] ?? '' ),
                        ];
                    }
                    $clean['fields'] = $fields;
                    break;
                case 'team':
                    $members = [];
                    foreach ( (array)($seg['members'] ?? []) as $m ) {
                        $members[] = [
                            'avatar_id' => absint( $m['avatar_id'] ?? 0 ),
                            'name'      => sanitize_text_field( $m['name']  ?? '' ),
                            'role'      => sanitize_text_field( $m['role']  ?? '' ),
                            'email'     => sanitize_email( $m['email'] ?? '' ),
                            'bio'       => sanitize_textarea_field( $m['bio'] ?? '' ),
                        ];
                    }
                    $clean['members'] = $members;
                    break;
                case 'timeline':
                    $milestones = [];
                    foreach ( (array)($seg['milestones'] ?? []) as $ms ) {
                        $milestones[] = [
                            'title'       => sanitize_text_field( $ms['title']  ?? '' ),
                            'date'        => sanitize_text_field( $ms['date']   ?? '' ),
                            'status'      => sanitize_key( $ms['status'] ?? 'planned' ),
                            'description' => sanitize_textarea_field( $ms['description'] ?? '' ),
                        ];
                    }
                    $clean['milestones'] = $milestones;
                    break;
                case 'documents':
                    $files = [];
                    foreach ( (array)($seg['files'] ?? []) as $f ) {
                        $files[] = [
                            'file_id'     => absint( $f['file_id'] ?? 0 ),
                            'label'       => sanitize_text_field( $f['label'] ?? '' ),
                            'description' => sanitize_textarea_field( $f['description'] ?? '' ),
                        ];
                    }
                    $clean['files'] = $files;
                    break;
            }
            $out[] = $clean;
        }
        return $out;
    }

    private static function sanitize_settings( $raw ) {
        $text_fields = [
            'project_code','short_description','location','country','reporting_period',
            'funder_name','implementing_agency','executing_agency','grant_number','budget_currency',
            'project_status','default_detail',
        ];
        $date_fields   = ['start_date','end_date','completion_date'];
        $number_fields = ['budget_total','grant_amount','cofinancing','disbursement','word_limit'];
        $bool_fields   = ['show_header'];
        $url_fields    = ['website'];

        $out = [];
        foreach ( $text_fields   as $f ) $out[$f] = sanitize_text_field( $raw[$f] ?? '' );
        foreach ( $date_fields    as $f ) $out[$f] = sanitize_text_field( $raw[$f] ?? '' );
        foreach ( $number_fields  as $f ) $out[$f] = floatval( $raw[$f] ?? 0 );
        foreach ( $bool_fields    as $f ) $out[$f] = ! empty( $raw[$f] ) ? 1 : 0;
        foreach ( $url_fields     as $f ) $out[$f] = esc_url_raw( $raw[$f] ?? '' );
        return $out;
    }

    private static function sanitize_styling( $raw ) {
        $color_fields  = ['accent_color','heading_color','body_color','bg_color','panel_bg','border_color'];
        $int_fields    = ['border_radius','font_size_base','font_size_heading'];
        $select_fields = ['btn_style','font_family'];

        $out = [];
        foreach ( $color_fields  as $f ) $out[$f] = sanitize_hex_color( $raw[$f] ?? '' ) ?: '';
        foreach ( $int_fields    as $f ) $out[$f] = absint( $raw[$f] ?? 0 );
        foreach ( $select_fields as $f ) $out[$f] = sanitize_key( $raw[$f] ?? '' );
        return $out;
    }
}
