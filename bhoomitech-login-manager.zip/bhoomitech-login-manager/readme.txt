=== BhoomiTech Login Manager ===
Contributors: bhoomitech
Tags: login, authentication, register, user role, shortcode
Requires at least: 5.8
Tested up to: 7.0
Stable tag: 1.7.0
Requires PHP: 7.4
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Lightweight, native authentication management with a custom Respondents role and a streamlined login/register shortcode.

== Description ==

BhoomiTech Login Manager is a lightweight WordPress plugin that provides:

* **Custom Respondents Role** — Automatically registers an `lvi_respondent` user role on activation with the capabilities needed for the REST file-upload pipeline (`upload_files`, `edit_posts`, `read`). Standard blog publishing is intentionally withheld.
* **Capability Verification** — On every `init`, the plugin ensures the role's required capabilities are intact, protecting against accidental removal.
* **[lvi_auth_toggle] Shortcode** — Renders inline Log In / Register links for guests and a Log Out link for authenticated users. Fully theme-integrated with inline-style overrides. The logout URL includes a redirect back to the current page.

= Shortcode Usage =

Place `[lvi_auth_toggle]` anywhere in a post, page, or widget area.

Optional attributes:

* `login_url` — Override the default WordPress login URL.
* `register_url` — Override the default WordPress registration URL.
* `redirect_to` — Override the post-logout redirect destination (defaults to the current page).

Example:

    [lvi_auth_toggle login_url="https://example.com/login" register_url="https://example.com/join"]

== Installation ==

1. Upload the `bhoomitech-login-manager` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** screen in WordPress.
3. The `lvi_respondent` role is created automatically on activation.
4. Use the `[lvi_auth_toggle]` shortcode on any page or post.

== Frequently Asked Questions ==

= Will this plugin conflict with other authentication plugins? =

BhoomiTech Login Manager uses its own prefixed functions, role slugs, and shortcode names, so conflicts are unlikely. However, if another plugin also manages login/logout links via a shortcode, only one shortcode should be placed per page.

= How do I remove the Respondents role when uninstalling? =

The plugin does not currently include an uninstall hook. To manually remove the role, add the following to your theme's `functions.php` temporarily and then remove it after running:

    remove_role( 'lvi_respondent' );

= Can I style the auth links? =

Yes. The links carry the CSS classes `btlm-auth-link`, `btlm-login`, `btlm-register`, and `btlm-logout` that you can target in your theme stylesheet.

== Screenshots ==

1. The `[lvi_auth_toggle]` shortcode rendered on a page — showing Log In and Register links for a logged-out visitor.
2. The shortcode rendering a Log Out link for an authenticated user.

== Changelog ==

= 1.7.0 =
* Added GPL-2.0-or-later license declaration in plugin header.
* Fixed: `$_SERVER['REQUEST_URI']` now validated, unslashed with `wp_unslash()`, and sanitized with `sanitize_text_field()` before use.
* Added `readme.txt` for WordPress Plugin Directory compliance.

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 1.7.0 =
Security and compliance update. Upgrade recommended for all users.
