<?php
/**
 * Plugin Name: BhoomiTech Login Manager
 * Description: Lightweight, native authentication management. Registers a secure "Respondents" role with custom REST file-upload mapping keys and provisions a streamlined, theme-integrated [lvi_auth_toggle] link manager shortcode.
 * Version: 1.7.0
 * Author: BhoomiTech Heritage and Development Foundation
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 1. AUTOMATICALLY REGISTER RESPONDENTS ROLE ON ACTIVATION
 * Injects core capabilities required by the uploader.js REST pipeline.
 */
register_activation_hook( __FILE__, 'btlm_create_respondent_role' );
function btlm_create_respondent_role() {
    add_role(
        'lvi_respondent',
        'Respondents',
        array(
            'read'                   => true,  // Access frontend viewports
            'upload_files'           => true,  // CRITICAL: Send video chunks to wp/v2/media
            'edit_posts'             => true,  // Required by core REST to manipulate attachments
            'publish_posts'          => false, // Prevent standard blog drafting
            'edit_published_posts'   => false,
        )
    );
}

/**
 * 2. ENSURE EXPLICIT CAPABILITY MAPS EXIST ON INITIALIZATION
 */
add_action('init', 'btlm_verify_respondent_caps');
function btlm_verify_respondent_caps() {
    $role = get_role('lvi_respondent');
    if ( $role && !$role->has_cap('upload_files') ) {
        $role->add_cap('upload_files');
        $role->add_cap('edit_posts');
    }
}

/**
 * 3. CUSTOM SHORTCODE CONFIGURATION MODULE
 * Renders streamlined text links forced strictly inline via non-breaking spaces.
 */
add_shortcode('lvi_auth_toggle', 'btlm_render_auth_toggle_links');
function btlm_render_auth_toggle_links($atts) {
    // Safely validate, unslash, and sanitize REQUEST_URI before use
    $request_uri = isset( $_SERVER['REQUEST_URI'] )
        ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) )
        : '/';

    // Collect attributes while fallback mapping variables to native safe defaults
    $args = shortcode_atts(array(
        'login_url'    => wp_login_url(),
        'register_url' => wp_registration_url(),
        'redirect_to'  => home_url( $request_uri ), // Returns to current workspace on sign-out
    ), $atts);

    ob_start();
    ?>
    <div class="btlm-auth-toggle-container" style="width: 100%; text-align: center; margin: 15px auto; clear: both; display: block !important;">
        <span class="btlm-auth-toggle-wrapper" style="display: inline !important; text-align: center !important;">
            <?php if ( is_user_logged_in() ) : 
                // Wrap native sign-out strings with security nonces to bypass manual user click confirmation warnings
                $final_logout_url = wp_logout_url($args['redirect_to']); 
                ?>
                <a href="<?php echo esc_url($final_logout_url); ?>" 
                   class="btlm-auth-link btlm-logout" 
                   style="display: inline !important; font-weight: bold; text-decoration: underline; padding: 0 !important; margin: 0 !important; border: none !important; background: transparent !important; height: auto !important; width: auto !important;">Log Out</a>
            <?php else : ?>
                <a href="<?php echo esc_url($args['login_url']); ?>" 
                   class="btlm-auth-link btlm-login" 
                   style="display: inline !important; font-weight: bold; text-decoration: underline; padding: 0 !important; margin: 0 !important; border: none !important; background: transparent !important; height: auto !important; width: auto !important;">Log In</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo esc_url($args['register_url']); ?>" 
                   class="btlm-auth-link btlm-register" 
                   style="display: inline !important; font-weight: bold; text-decoration: underline; padding: 0 !important; margin: 0 !important; border: none !important; background: transparent !important; height: auto !important; width: auto !important;">Register</a>
            <?php endif; ?>
        </span>
    </div>
    <?php
    return ob_get_clean();
}
