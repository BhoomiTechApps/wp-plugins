/* ── NGO Query Manager — Public JS ─────────────────────────── */
(function ($) {
    'use strict';

    var NQM = {

        /* ── Init ────────────────────────────────────────────── */
        init: function () {
            this.bindTypeSelector();
            this.bindSubmit();
            this.bindResponseSubmit();
            this.bindStatusCheck();
            this.bindFeedback();
            this.bindRevokeClaim();
            this.updateQuotaUI();
            this.autoStatusCheck();
        },

        /* ── Message type switching ──────────────────────────── */
        bindTypeSelector: function () {
            $(document).on('change', 'input[name="message_type"]', function () {
                var type = $(this).val();
                $('#nqm-panel-text, #nqm-panel-video, #nqm-panel-hybrid').hide();
                $('#nqm-panel-' + type).show();
                if (type === 'hybrid' && typeof tinymce !== 'undefined') {
                    NQM.initTinyMCE('nqm_hybrid_body');
                }
                if (type === 'video') {
                    // Defer slightly so the panel is visible before getUserMedia
                    // attaches the stream — required on iOS/Android Safari.
                    setTimeout(function () { NQM.initVideoRecorder(); }, 50);
                }
            });

            $(document).on('change', 'input[name="res_type"]', function () {
                var type = $(this).val();
                $('#nqm-res-panel-text, #nqm-res-panel-hybrid').hide();
                $('#nqm-res-panel-' + type).show();
                if (type === 'hybrid' && typeof tinymce !== 'undefined') {
                    NQM.initTinyMCE('nqm_res_hybrid');
                }
            });
        },

        /* ── Video quota display ─────────────────────────────── */
        updateQuotaUI: function () {
            var total = nqmData.video_global_allocation || 0;
            var avail = nqmData.available_secs || 0;
            var used  = total - avail;
            var pct   = total > 0 ? Math.min(100, (used / total) * 100) : 0;
            $('#nqm-quota-fill').css('width', pct + '%');
            $('#nqm-quota-text').text(
                avail + 's ' + nqmData.strings.quota_warn.replace('%d', avail)
            );
        },

        /* ── TinyMCE initialiser ─────────────────────────────── */
        initTinyMCE: function (id) {
            // Use wp.editor (WordPress bundled TinyMCE) when available.
            // IMPORTANT: only use plugins that are bundled with WordPress core —
            // never reference the 'code' plugin (not included) or any external URL.
            // Safe WP-bundled plugins: lists, paste, tabfocus, fullscreen,
            // wordpress, wpautoresize, wpeditimage, wplink, wptextpattern, hr,
            // charmap, colorpicker, textcolor, wpgallery, wpemoji.
            var wpOnlyPlugins = 'lists paste tabfocus hr charmap fullscreen wordpress wpautoresize wplink wptextpattern media';
            var wpOnlyToolbar = 'bold italic underline | bullist numlist | link media | hr charmap | formatselect';

            if (window.wp && wp.editor && wp.editor.initialize) {
                if (window.tinymce && tinymce.get(id)) return;
                wp.editor.initialize(id, {
                    tinymce: {
                        wpautop: true,
                        height: 320,
                        menubar: false,
                        plugins: wpOnlyPlugins,
                        toolbar1: wpOnlyToolbar,
                        content_style: 'body{font-family:inherit;font-size:15px;line-height:1.6}',
                    },
                    quicktags: true,
                    mediaButtons: false,
                });
            } else if (window.tinymce) {
                if (tinymce.get(id)) return;
                tinymce.init({
                    selector: '#' + id,
                    height: 320,
                    menubar: false,
                    plugins: 'lists hr',
                    toolbar: 'bold italic underline | bullist numlist | hr',
                    content_style: 'body{font-family:inherit;font-size:15px;line-height:1.6}',
                });
            }
        },

        /* ── MediaRecorder-based video recorder ──────────────── */
        recorder:      null,
        chunks:        [],
        timerInterval: null,
        elapsed:       0,
        videoBlob:     null,

        _availableCameras: [],
        _activeCameraIndex: 0,

        initVideoRecorder: function () {
            if (NQM._recorderInited) return;
            NQM._recorderInited = true;

            var avail = nqmData.available_secs;
            if (avail <= 0) {
                $('#nqm-video-status').text(nqmData.strings.quota_none).css('color', '#dc2626');
                $('#nqm-start-btn').prop('disabled', true);
                return;
            }

            // getUserMedia requires a secure context (HTTPS or localhost).
            // On mobile browsers served over plain HTTP it will always fail —
            // surface a clear message rather than a cryptic "denied" error.
            if (window.isSecureContext === false) {
                $('#nqm-video-status')
                    .text('Camera access requires a secure (HTTPS) connection.')
                    .css('color', '#dc2626');
                $('#nqm-start-btn').prop('disabled', true);
                return;
            }

            var maxSec = Math.min(nqmData.max_duration, avail);

            // On mobile, enumerateDevices() returns devices with empty deviceId
            // strings until the user has granted camera permission at least once.
            // We therefore open the stream first with generic constraints, which
            // triggers the permission prompt, and only then re-enumerate to build
            // the camera list with real deviceIds / labels.
            NQM.openCameraStream({ video: { facingMode: 'user' }, audio: true }, maxSec, function () {
                // Permission granted callback — now enumerate with real deviceIds.
                navigator.mediaDevices.enumerateDevices()
                    .then(function (devices) {
                        NQM._availableCameras = devices.filter(function (d) { return d.kind === 'videoinput'; });

                        if (NQM._availableCameras.length > 1) {
                            var $switchBtn = $('#nqm-switch-camera-btn');
                            $switchBtn.show();
                            $switchBtn.off('click').on('click', function () {
                                NQM._activeCameraIndex = (NQM._activeCameraIndex + 1) % NQM._availableCameras.length;
                                NQM.startCameraStream(maxSec);
                            });
                        } else {
                            $('#nqm-switch-camera-btn').hide();
                        }
                    })
                    .catch(function () { /* non-fatal — switch button stays hidden */ });
            });

            // Confirm button: only now do we upload
            $(document).off('click.nqm-confirm').on('click.nqm-confirm', '#nqm-confirm-btn', function () {
                NQM.uploadVideo();
            });

            // Retake button: discard blob, show live again
            $(document).off('click.nqm-retake').on('click.nqm-retake', '#nqm-retake-btn', function () {
                NQM.videoBlob = null;
                NQM.elapsed   = 0;
                $('#nqm_video_attach_id').val('');
                $('#nqm_video_duration').val('');
                $('#nqm-rec-timer').text('00:00');
                $('#nqm-video-status').text('').css('color', '');
                // Hide preview panel; show live viewfinder
                $('#nqm-preview-panel').hide();
                $('#nqm-recorder-stage').removeClass('nqm-stage-preview');
                $('#nqm-start-btn').show();
                NQM.startCameraStream(maxSec);
            });
        },

        startCameraStream: function (maxSec) {
            var cam = NQM._availableCameras[NQM._activeCameraIndex];
            // On mobile, enumerateDevices() returns empty deviceId strings until
            // permission is granted. Passing { exact: "" } causes getUserMedia to
            // reject, leaving the viewfinder blank. Fall back to facingMode instead.
            var videoConstraint;
            if (cam && cam.deviceId) {
                videoConstraint = { deviceId: { exact: cam.deviceId } };
            } else {
                // Use front camera for index 0, rear for any subsequent index.
                videoConstraint = { facingMode: NQM._activeCameraIndex === 0 ? 'user' : 'environment' };
            }
            var constraints = {
                audio: true,
                video: videoConstraint,
            };

            if (NQM._stream) {
                NQM._stream.getTracks().forEach(function (t) { t.stop(); });
                NQM._stream = null;
            }

            NQM.openCameraStream(constraints, maxSec);
        },

        openCameraStream: function (constraints, maxSec, onGranted) {
            navigator.mediaDevices.getUserMedia(constraints)
                .then(function (stream) {
                    var preview = document.getElementById('nqm-preview');
                    preview.srcObject = stream;
                    NQM._stream = stream;

                    var cam = NQM._availableCameras[NQM._activeCameraIndex];
                    if (cam && cam.label) {
                        var label = cam.label || ('Camera ' + (NQM._activeCameraIndex + 1));
                        $('#nqm-camera-label').text(label).show();
                    }

                    $('#nqm-start-btn').off('click').on('click', function () {
                        NQM.startRecording(stream, maxSec);
                    });

                    if (typeof onGranted === 'function') {
                        onGranted();
                    }
                })
                .catch(function (e) {
                    // On mobile, specific constraints (facingMode, deviceId) can
                    // trigger OverconstrainedError or NotReadableError even when
                    // the user has not denied permission. Retry once with bare
                    // { video: true, audio: true } before surfacing an error.
                    var isPermissionDenied = (e.name === 'NotAllowedError' || e.name === 'PermissionDeniedError');
                    if (!isPermissionDenied && constraints.video !== true) {
                        NQM.openCameraStream({ video: true, audio: true }, maxSec, onGranted);
                        return;
                    }
                    var msg = isPermissionDenied
                        ? 'Camera/microphone access was denied. Please allow access in your browser settings and try again.'
                        : 'Could not access camera/microphone: ' + e.message;
                    $('#nqm-video-status').text(msg).css('color', '#dc2626');
                });
        },

        startRecording: function (stream, maxSec) {
            NQM.chunks  = [];
            NQM.elapsed = 0;
            // iOS Safari does not support video/webm — detect the best supported type.
            var mimeType = MediaRecorder.isTypeSupported('video/webm')
                ? 'video/webm'
                : 'video/mp4';
            var recorder = new MediaRecorder(stream, { mimeType: mimeType });
            NQM.recorder = recorder;

            recorder.ondataavailable = function (e) {
                if (e.data.size > 0) NQM.chunks.push(e.data);
            };
            recorder.onstop = function () {
                // Store blob in memory only — do NOT upload yet
                NQM.videoBlob = new Blob(NQM.chunks, { type: mimeType });
                var url = URL.createObjectURL(NQM.videoBlob);

                // Show playback in the preview panel
                $('#nqm-playback').attr('src', url);
                $('#nqm-preview-panel').show();
                $('#nqm-recorder-stage').addClass('nqm-stage-preview');

                $('#nqm-rec-timer').text(NQM.formatTime(NQM.elapsed));
                $('#nqm-video-status')
                    .text('Preview ready. Confirm to use or Retake to record again.')
                    .css('color', '#2c5f2e');
            };

            recorder.start(500);
            $('#nqm-start-btn').hide();
            $('#nqm-stop-btn').show().off('click').on('click', function () {
                clearInterval(NQM.timerInterval);
                recorder.stop();
                $(this).hide();
            });

            NQM.timerInterval = setInterval(function () {
                NQM.elapsed++;
                $('#nqm-rec-timer').text(NQM.formatTime(NQM.elapsed));
                if (NQM.elapsed >= maxSec) {
                    clearInterval(NQM.timerInterval);
                    recorder.stop();
                    $('#nqm-stop-btn').hide();
                }
            }, 1000);
        },

        uploadVideo: function () {
            if (!NQM.videoBlob) return;
            $('#nqm-video-status').text(nqmData.strings.uploading).css('color', '#2c5f2e');
            $('#nqm-confirm-btn').prop('disabled', true);

            var fd = new FormData();
            fd.append('action',   'nqm_upload_video');
            fd.append('nonce',    nqmData.nonce);
            var ts = Date.now();
            var ext = (NQM.videoBlob.type === 'video/mp4') ? 'mp4' : 'webm';
            fd.append('video',    NQM.videoBlob, 'recording-' + ts + '.' + ext);
            fd.append('duration', NQM.elapsed);

            $.ajax({
                url:         nqmData.ajax_url,
                type:        'POST',
                data:        fd,
                processData: false,
                contentType: false,
                success: function (r) {
                    $('#nqm-confirm-btn').prop('disabled', false);
                    if (r.success) {
                        $('#nqm_video_attach_id').val(r.data.attachment_id);
                        $('#nqm_video_duration').val(r.data.duration);
                        $('#nqm-video-status').text('✅ Video saved (' + r.data.duration + 's). Ready to submit.').css('color', '#065f46');
                        // Hide confirm/retake buttons now that it's locked in
                        $('#nqm-confirm-btn, #nqm-retake-btn').hide();
                    } else {
                        $('#nqm-video-status').text('⚠ ' + r.data.message).css('color', '#dc2626');
                    }
                },
                error: function () {
                    $('#nqm-video-status').text('Upload failed.').css('color', '#dc2626');
                }
            });
        },

        formatTime: function (s) {
            return (Math.floor(s / 60) + '').padStart(2, '0') + ':' + (s % 60 + '').padStart(2, '0');
        },

        /* ── Submit query ────────────────────────────────────── */
        bindSubmit: function () {
            $(document).on('click', '#nqm-submit-btn', function () {
                NQM.submitQuery();
            });
        },

        submitQuery: function () {
            var type = $('input[name="message_type"]:checked').val() || 'text';
            var body = '';

            if (type === 'text') {
                body = $('#nqm_text_body').val();
            } else if (type === 'video') {
                body = $('#nqm_video_note').val();
                if (!$('#nqm_video_attach_id').val()) {
                    NQM.notice('Please record and wait for the video to upload.', 'error');
                    return;
                }
            } else if (type === 'hybrid') {
                if (window.tinymce && tinymce.get('nqm_hybrid_body')) {
                    body = tinymce.get('nqm_hybrid_body').getContent();
                } else {
                    body = $('#nqm_hybrid_body').val();
                }
            }

            if (!body && type !== 'video') {
                NQM.notice('Please enter your message.', 'error');
                return;
            }

            var data = {
                action:          'nqm_submit_query',
                nonce:           nqmData.nonce,
                title:           $('#nqm_title').val(),
                submitter_name:  $('#nqm_name').val(),
                submitter_email: $('#nqm_email').val(),
                submitter_org:   $('#nqm_org').val(),
                submitter_phone: $('#nqm_phone').val(),
                query_source:    $('#nqm_source').val(),
                message_type:    type,
                message_body:    body,
                video_attach_id: $('#nqm_video_attach_id').val() || 0,
                video_duration:  $('#nqm_video_duration').val()  || 0,
            };

            $('#nqm-submit-btn').prop('disabled', true).find('.nqm-spinner').show();

            $.post(nqmData.ajax_url, data, function (r) {
                $('#nqm-submit-btn').prop('disabled', false).find('.nqm-spinner').hide();
                if (r.success) {
                    $('#nqm-submit-form .nqm-form-card').hide();
                    $('#nqm-result-uid').text(r.data.query_uid);
                    $('#nqm-success').show();
                } else {
                    NQM.notice(r.data.message, 'error');
                }
            });
        },

        /* ── Submit response ─────────────────────────────────── */
        bindResponseSubmit: function () {
            $(document).on('click', '#nqm-res-submit-btn', function () {
                NQM.submitResponse($(this).data('query-id'));
            });
        },

        submitResponse: function (queryId) {
            var type = $('input[name="res_type"]:checked').val() || 'text';
            var body = '';

            if (type === 'text') {
                body = $('#nqm_res_text').val();
            } else {
                if (window.tinymce && tinymce.get('nqm_res_hybrid')) {
                    body = tinymce.get('nqm_res_hybrid').getContent();
                } else {
                    body = $('#nqm_res_hybrid').val();
                }
            }

            if (!body) { NQM.resNotice('Please enter a response.', 'error'); return; }

            var fd = new FormData();
            fd.append('action',       'nqm_submit_response');
            fd.append('nonce',        nqmData.nonce);
            fd.append('query_id',     queryId);
            fd.append('message_type', type);
            fd.append('message_body', body);

            if (type === 'hybrid') {
                var files = document.getElementById('nqm_res_files');
                if (files && files.files.length) {
                    $.each(files.files, function (i, f) { fd.append('attachments[]', f); });
                }
            }

            $('#nqm-res-submit-btn').prop('disabled', true);

            $.ajax({
                url:         nqmData.ajax_url,
                type:        'POST',
                data:        fd,
                processData: false,
                contentType: false,
                success: function (r) {
                    $('#nqm-res-submit-btn').prop('disabled', false);
                    if (r.success) {
                        NQM.resNotice(r.data.message, 'success');
                        setTimeout(function () { location.reload(); }, 1500);
                    } else {
                        NQM.resNotice(r.data.message, 'error');
                    }
                }
            });
        },

        /* ── Status lookup (query-track page) ────────────────── */
        bindStatusCheck: function () {
            $(document).on('click', '#nqm-uid-check', function () {
                NQM.checkStatus($('#nqm-uid-input').val().trim());
            });
            $(document).on('keydown', '#nqm-uid-input', function (e) {
                if (e.key === 'Enter') NQM.checkStatus($(this).val().trim());
            });
        },

        autoStatusCheck: function () {
            var uid = $('#nqm-uid-input').val();
            if (uid) NQM.checkStatus(uid);
        },

        checkStatus: function (uid) {
            if (!uid) return;
            $('#nqm-status-result').html('<p>' + nqmData.strings.checking + '</p>');
            $.post(nqmData.ajax_url, { action: 'nqm_get_query_status', nonce: nqmData.nonce, query_uid: uid }, function (r) {
                if (!r.success) {
                    $('#nqm-status-result').html('<p class="nqm-error">' + r.data.message + '</p>');
                    return;
                }
                var q    = r.data.query;
                var resp = r.data.response;
                var html = '<div class="nqm-status-card">';
                html += '<p><strong>' + nqmData.strings.label_id     + '</strong> ' + q.query_uid + '</p>';
                html += '<p><strong>' + nqmData.strings.label_title  + '</strong> ' + q.title + '</p>';
                html += '<p><strong>' + nqmData.strings.label_status + '</strong> <span class="nqm-status nqm-status--' + q.status + '">' + q.status.charAt(0).toUpperCase() + q.status.slice(1) + '</span></p>';

                // Show messenger's own media (video and/or text body)
                if (q.video_url) {
                    html += '<div class="nqm-video-wrap"><video src="' + q.video_url + '" controls style="max-width:100%"></video></div>';
                }
                if (q.message_body) {
                    html += '<div class="nqm-message-body">' + q.message_body + '</div>';
                }
                if (q.attachments && q.attachments.length) {
                    html += '<ul class="nqm-attachments">';
                    $.each(q.attachments, function (i, att) {
                        html += '<li><a href="' + att.url + '" target="_blank">' + att.name + '</a></li>';
                    });
                    html += '</ul>';
                }

                if (resp) {
                    html += '<hr><h4>' + nqmData.strings.label_response + '</h4>';
                    html += '<div class="nqm-message-body">' + resp.message_body + '</div>';
                    if (resp.attachments && resp.attachments.length) {
                        html += '<ul class="nqm-attachments">';
                        $.each(resp.attachments, function (i, att) {
                            html += '<li><a href="' + att.url + '" target="_blank">' + att.name + '</a></li>';
                        });
                        html += '</ul>';
                    }
                }

                // Show feedback comment if present
                var fb = r.data.feedback;
                if (fb && fb.comment) {
                    html += '<hr><div class="nqm-feedback-display">';
                    html += '<strong>' + nqmData.strings.label_your_comment + '</strong>';
                    html += '<blockquote>' + $('<div>').text(fb.comment).html() + '</blockquote>';
                    html += '</div>';
                }

                html += '</div>';
                $('#nqm-status-result').html(html);
            });
        },

        /* ── Star rating / feedback (my-queries page) ────────── */
        bindFeedback: function () {
            $(document).on('mouseenter', '.nqm-star', function () {
                var v = $(this).data('val');
                $(this).closest('.nqm-stars').find('.nqm-star').each(function () {
                    $(this).text($(this).data('val') <= v ? '★' : '☆');
                });
            });
            $(document).on('click', '.nqm-star', function () {
                $(this).closest('.nqm-stars').attr('data-rating', $(this).data('val'));
            });
            $(document).on('click', '.nqm-feedback-btn', function () {
                var $wrap   = $(this).closest('.nqm-feedback-inline');
                var qid     = $wrap.data('qid');
                var rating  = $wrap.find('.nqm-stars').attr('data-rating') || 0;
                var liked   = $wrap.find('.nqm-like').is(':checked') ? 1 : 0;
                var comment = $wrap.find('.nqm-comment-box').val();
                $.post(nqmData.ajax_url, {
                    action:   'nqm_submit_feedback',
                    nonce:    nqmData.nonce,
                    query_id: qid,
                    rating:   rating,
                    liked:    liked,
                    comment:  comment,
                }, function (r) {
                    if (r.success) {
                        $wrap.html('<span class="nqm-rated">✅ ' + nqmData.strings.feedback_saved + '</span>');
                    } else {
                        alert(r.data.message);
                    }
                });
            });
        },

        /* ── Revoke claim (my-queries page) ──────────────────── */
        bindRevokeClaim: function () {
            $(document).on('click', '.nqm-revoke-btn', function () {
                if (!confirm(nqmData.strings.confirm_revoke)) return;
                var id = $(this).data('id');
                $.post(nqmData.ajax_url, {
                    action:   'nqm_revoke_claim',
                    nonce:    nqmData.nonce,
                    query_id: id,
                }, function (r) {
                    if (r.success) { location.reload(); } else { alert(r.data.message); }
                });
            });
        },

        /* ── Utility ─────────────────────────────────────────── */
        notice: function (msg, type) {
            var $el = $('#nqm-notice');
            $el.removeClass('nqm-notice--success nqm-notice--error nqm-notice--info')
               .addClass('nqm-notice--' + (type || 'info'))
               .text(msg).show();
        },
        resNotice: function (msg, type) {
            var $el = $('#nqm-res-notice');
            $el.removeClass('nqm-notice--success nqm-notice--error nqm-notice--info')
               .addClass('nqm-notice--' + (type || 'info'))
               .text(msg).show();
        },
    };

    $(function () { NQM.init(); });

}(jQuery));
