<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Response {

    /* ── Submit a response ───────────────────────────────────── */
    public static function create( $query_id, $data ) {
        global $wpdb;

        $query = NQM_Query::get( $query_id );
        if ( ! $query )                   return new WP_Error( 'not_found',  __( 'Query not found.', 'ngo-query-manager' ) );
        if ( $query->status === 'closed' ) return new WP_Error( 'closed',    __( 'Query is already closed.', 'ngo-query-manager' ) );

        // Only the claimed user (or admin) may respond
        $current = get_current_user_id();
        if ( $query->status === 'claimed' && (int) $query->claimed_by !== $current && ! current_user_can( 'manage_options' ) ) {
            return new WP_Error( 'forbidden', __( 'This query is assigned to another respondent.', 'ngo-query-manager' ) );
        }

        // Check exactly one response
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}nqm_responses WHERE query_id = %d", $query_id
        ) );
        if ( $existing > 0 ) return new WP_Error( 'duplicate', __( 'A response has already been submitted.', 'ngo-query-manager' ) );

        $type        = in_array( $data['message_type'], [ 'text', 'hybrid' ] ) ? $data['message_type'] : 'text';
        $body        = nqm_kses_rich( $data['message_body'] ?? '' );
        $attachments = ! empty( $data['attachments'] ) ? json_encode( array_map( 'absint', (array) $data['attachments'] ) ) : null;

        $result = $wpdb->insert(
            $wpdb->prefix . 'nqm_responses',
            [
                'query_id'     => $query_id,
                'responder_id' => $current,
                'message_type' => $type,
                'message_body' => $body,
                'attachments'  => $attachments,
            ],
            [ '%d', '%d', '%s', '%s', '%s' ]
        );

        if ( ! $result ) return new WP_Error( 'db_error', $wpdb->last_error );

        $response_id = $wpdb->insert_id;

        // Mark query closed
        NQM_Query::close( $query_id );

        // Notify submitter (pass any email-only attachments)
        $response         = self::get( $response_id );
        $email_attachments = $data['email_attachments'] ?? [];
        NQM_Mailer::notify_submitter_response( $query, $response, $email_attachments );

        // Clean up temp files after mail send
        foreach ( $email_attachments as $att ) {
            if ( ! empty( $att['path'] ) && file_exists( $att['path'] ) ) {
                @unlink( $att['path'] );
            }
        }

        return $response_id;
    }

    /* ── Get response ────────────────────────────────────────── */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_responses WHERE id = %d", $id
        ) );
    }

    public static function get_by_query( $query_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_responses WHERE query_id = %d", $query_id
        ) );
    }

    /* ── Save feedback (rating / like / comment) ─────────────── */
    public static function save_feedback( $query_id, $data ) {
        global $wpdb;

        $query = NQM_Query::get( $query_id );
        if ( ! $query ) return new WP_Error( 'not_found', __( 'Query not found.', 'ngo-query-manager' ) );

        // Only the original submitter may rate
        $current = get_current_user_id();
        if ( $current && (int) $query->submitter_user_id !== $current ) {
            // For guest submitters, we check session token instead (handled via nonce)
        }

        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}nqm_feedback WHERE query_id = %d", $query_id
        ) );

        $row = [
            'rating'  => isset( $data['rating'] )  ? max( 1, min( 5, (int) $data['rating'] ) ) : null,
            'liked'   => isset( $data['liked'] )    ? (int) (bool) $data['liked']               : 0,
            'comment' => isset( $data['comment'] )  ? sanitize_textarea_field( $data['comment'] ) : null,
        ];

        if ( $existing ) {
            $wpdb->update( $wpdb->prefix . 'nqm_feedback', $row, [ 'query_id' => $query_id ], [ '%d', '%d', '%s' ], [ '%d' ] );
        } else {
            $row['query_id'] = $query_id;
            $wpdb->insert( $wpdb->prefix . 'nqm_feedback', $row, [ '%d', '%d', '%d', '%s' ] );
        }

        return true;
    }

    public static function get_feedback( $query_id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_feedback WHERE query_id = %d", $query_id
        ) );
    }
}
