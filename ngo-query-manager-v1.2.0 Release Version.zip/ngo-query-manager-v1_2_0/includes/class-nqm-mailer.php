<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Mailer {

    /* ── Notify admin on new submission ────────────────────── */
    public static function notify_admin_new_query( $query ) {
        if ( ! get_option( 'nqm_admin_email_notify', 1 ) ) return;

        $to      = get_option( 'admin_email' );
        $subject = sprintf( __( '[%s] New Query Received – %s', 'ngo-query-manager' ), get_bloginfo( 'name' ), $query->query_uid );
        $body    = self::render( 'admin-new-query', compact( 'query' ) );

        self::send( $to, $subject, $body );
    }

    /* ── Notify submitter when a response is posted ─────────── */
    public static function notify_submitter_response( $query, $response, $email_attachments = [] ) {
        if ( empty( $query->submitter_email ) ) return;

        $to      = $query->submitter_email;
        $subject = sprintf( __( 'Response to Your Query %s', 'ngo-query-manager' ), $query->query_uid );
        $body    = self::render( 'submitter-response', compact( 'query', 'response' ) );

        // Build wp_mail-compatible attachments array (file paths)
        $wp_attachments = [];
        foreach ( $email_attachments as $att ) {
            if ( ! empty( $att['path'] ) && file_exists( $att['path'] ) ) {
                // wp_mail accepts full file paths
                $wp_attachments[] = $att['path'];
            }
        }

        self::send( $to, $subject, $body, $wp_attachments );
    }

    /* ── Core send wrapper ───────────────────────────────────── */
    private static function send( $to, $subject, $body, $attachments = [] ) {
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: ' . get_option( 'nqm_from_name', get_bloginfo( 'name' ) )
                     . ' <' . get_option( 'nqm_from_email', get_option( 'admin_email' ) ) . '>',
        ];
        wp_mail( $to, $subject, $body, $headers, $attachments );
    }

    /* ── Template renderer ───────────────────────────────────── */
    private static function render( $template, $data = [] ) {
        extract( $data );
        $site   = get_bloginfo( 'name' );
        $url    = home_url();

        ob_start();
        $file = NQM_PLUGIN_DIR . "templates/email-{$template}.php";
        if ( file_exists( $file ) ) {
            include $file;
        }
        return ob_get_clean();
    }
}
