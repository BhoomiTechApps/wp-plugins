<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Query {

    /* ── Generate unique query ID ───────────────────────────── */
    public static function generate_uid() {
        global $wpdb;
        do {
            $uid = 'QRY-' . strtoupper( substr( md5( uniqid( mt_rand(), true ) ), 0, 8 ) );
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}nqm_queries WHERE query_uid = %s", $uid
            ) );
        } while ( $exists );
        return $uid;
    }

    /* ── Create ─────────────────────────────────────────────── */
    public static function create( $data ) {
        global $wpdb;

        $uid = self::generate_uid();

        $insert = [
            'query_uid'       => $uid,
            'title'           => sanitize_text_field( $data['title'] ),
            'submitter_name'  => sanitize_text_field( $data['submitter_name'] ),
            'submitter_email' => sanitize_email( $data['submitter_email'] ),
            'submitter_org'   => sanitize_text_field( $data['submitter_org'] ?? '' ),
            'submitter_phone' => sanitize_text_field( $data['submitter_phone'] ?? '' ),
            'query_source'    => sanitize_text_field( $data['query_source'] ),
            'message_type'    => in_array( $data['message_type'], [ 'text', 'video', 'hybrid' ] ) ? $data['message_type'] : 'text',
            'message_body'    => nqm_kses_rich( $data['message_body'] ?? '' ),
            'video_attach_id' => ! empty( $data['video_attach_id'] ) ? (int) $data['video_attach_id'] : null,
            'video_duration'  => ! empty( $data['video_duration'] )  ? (int) $data['video_duration']  : 0,
            'status'          => 'open',
            'submitter_user_id' => get_current_user_id() ?: null,
        ];

        $formats = [ '%s','%s','%s','%s','%s','%s','%s','%s','%s','%d','%d','%s','%d' ];

        $result = $wpdb->insert( $wpdb->prefix . 'nqm_queries', $insert, $formats );
        if ( ! $result ) return new WP_Error( 'db_error', $wpdb->last_error );

        $query_id = $wpdb->insert_id;

        // Log video usage
        if ( $insert['video_duration'] > 0 ) {
            NQM_Video::log_video( $query_id, $insert['video_duration'] );
        }

        // Email admin
        $query = self::get( $query_id );
        NQM_Mailer::notify_admin_new_query( $query );

        return $query_id;
    }

    /* ── Get single ─────────────────────────────────────────── */
    public static function get( $id_or_uid ) {
        global $wpdb;
        $col = is_numeric( $id_or_uid ) ? 'id' : 'query_uid';
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_queries WHERE {$col} = %s", $id_or_uid
        ) );
    }

    /* ── Get all (with filters) ─────────────────────────────── */
    public static function get_all( $args = [] ) {
        global $wpdb;
        $defaults = [
            'status'     => '',
            'claimed_by' => '',
            'per_page'   => 20,
            'page'       => 1,
            'orderby'    => 'created_at',
            'order'      => 'DESC',
        ];
        $args   = wp_parse_args( $args, $defaults );
        $where  = '1=1';
        $values = [];

        if ( $args['status'] ) {
            $where   .= ' AND status = %s';
            $values[] = $args['status'];
        }
        if ( $args['claimed_by'] ) {
            $where   .= ' AND claimed_by = %d';
            $values[] = (int) $args['claimed_by'];
        }

        $orderby = in_array( $args['orderby'], [ 'id', 'created_at', 'status', 'query_uid' ] ) ? $args['orderby'] : 'created_at';
        $order   = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
        $limit   = (int) $args['per_page'];
        $offset  = ( (int) $args['page'] - 1 ) * $limit;

        $sql = "SELECT * FROM {$wpdb->prefix}nqm_queries WHERE $where ORDER BY $orderby $order LIMIT %d OFFSET %d";
        $values[] = $limit;
        $values[] = $offset;

        return $wpdb->get_results( $values ? $wpdb->prepare( $sql, $values ) : $sql );
    }

    /* ── Claim ───────────────────────────────────────────────── */
    public static function claim( $query_id, $user_id ) {
        global $wpdb;
        $query = self::get( $query_id );
        if ( ! $query || $query->status !== 'open' ) {
            return new WP_Error( 'invalid', __( 'Query cannot be claimed.', 'ngo-query-manager' ) );
        }
        return $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'claimed', 'claimed_by' => $user_id, 'claimed_at' => current_time( 'mysql' ) ],
            [ 'id' => $query_id ],
            [ '%s', '%d', '%s' ],
            [ '%d' ]
        );
    }

    /* ── Revoke claim ────────────────────────────────────────── */
    public static function revoke_claim( $query_id, $user_id ) {
        global $wpdb;
        $query = self::get( $query_id );
        if ( ! $query || $query->status !== 'claimed' || (int) $query->claimed_by !== (int) $user_id ) {
            if ( ! current_user_can( 'manage_options' ) ) {
                return new WP_Error( 'invalid', __( 'You cannot revoke this claim.', 'ngo-query-manager' ) );
            }
        }
        return $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'open', 'claimed_by' => null, 'claimed_at' => null ],
            [ 'id' => $query_id ],
            [ '%s', null, null ],
            [ '%d' ]
        );
    }

    /* ── Assign to user ─────────────────────────────────────── */
    public static function assign( $query_id, $user_id ) {
        global $wpdb;
        $query = self::get( $query_id );
        if ( ! $query || $query->status === 'closed' ) {
            return new WP_Error( 'invalid', __( 'Cannot assign a closed query.', 'ngo-query-manager' ) );
        }
        return $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'claimed', 'claimed_by' => $user_id, 'claimed_at' => current_time( 'mysql' ) ],
            [ 'id' => $query_id ],
            [ '%s', '%d', '%s' ],
            [ '%d' ]
        );
    }

    /* ── Mark closed ────────────────────────────────────────── */
    public static function close( $query_id ) {
        global $wpdb;
        return $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'closed', 'responded_at' => current_time( 'mysql' ) ],
            [ 'id' => $query_id ],
            [ '%s', '%s' ],
            [ '%d' ]
        );
    }

    /* ── Count ───────────────────────────────────────────────── */
    public static function count( $status = '' ) {
        global $wpdb;
        if ( $status ) {
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}nqm_queries WHERE status = %s", $status
            ) );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}nqm_queries" );
    }
}
