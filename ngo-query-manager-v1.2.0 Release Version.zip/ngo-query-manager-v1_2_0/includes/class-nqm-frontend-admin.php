<?php
/**
 * NQM_Frontend_Admin
 *
 * Provides the [nqm_admin_panel] shortcode and all AJAX endpoints that
 * power it.  Every action here is gated behind current_user_can('manage_options').
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Frontend_Admin {

    public static function init() {
        add_shortcode( 'nqm_admin_panel', [ __CLASS__, 'shortcode' ] );

        $ajax_actions = [
            'nqm_fadmin_list_queries',
            'nqm_fadmin_get_query',
            'nqm_fadmin_delete_query',
            'nqm_fadmin_reopen_query',
            'nqm_fadmin_change_status',
            'nqm_fadmin_assign_query',
            'nqm_fadmin_revoke_claim',
        ];
        foreach ( $ajax_actions as $action ) {
            // Frontend admin actions are login-required; no nopriv hooks.
            add_action( 'wp_ajax_' . $action, [ __CLASS__, str_replace( 'nqm_fadmin_', 'handle_', $action ) ] );
        }
    }

    /* ── Shortcode ───────────────────────────────────────────── */
    public static function shortcode() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return '<p class="nqm-error">' . esc_html__( 'You do not have permission to view this page.', 'ngo-query-manager' ) . '</p>';
        }
        ob_start();
        include NQM_PLUGIN_DIR . 'templates/frontend-admin.php';
        return ob_get_clean();
    }

    /* ── List queries ────────────────────────────────────────── */
    public static function handle_list_queries() {
        self::require_admin();
        $status   = sanitize_text_field( $_POST['status']   ?? '' );
        $search   = sanitize_text_field( $_POST['search']   ?? '' );
        $per_page = 25;
        $page     = max( 1, (int) ( $_POST['page'] ?? 1 ) );

        global $wpdb;
        $where  = '1=1';
        $values = [];

        if ( $status ) {
            $where   .= ' AND status = %s';
            $values[] = $status;
        }
        if ( $search ) {
            $where   .= ' AND (query_uid LIKE %s OR title LIKE %s OR submitter_name LIKE %s OR submitter_email LIKE %s)';
            $like     = '%' . $wpdb->esc_like( $search ) . '%';
            $values   = array_merge( $values, [ $like, $like, $like, $like ] );
        }

        $table  = $wpdb->prefix . 'nqm_queries';
        $offset = ( $page - 1 ) * $per_page;

        $count_sql = "SELECT COUNT(*) FROM {$table} WHERE {$where}";
        $data_sql  = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";

        if ( $values ) {
            $total   = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$values ) );
            $queries = $wpdb->get_results( $wpdb->prepare( $data_sql, ...array_merge( $values, [ $per_page, $offset ] ) ) );
        } else {
            $total   = (int) $wpdb->get_var( $count_sql );
            $queries = $wpdb->get_results( $wpdb->prepare( $data_sql, $per_page, $offset ) );
        }

        // Counts per status for the stats strip
        $counts = [];
        foreach ( [ 'open', 'claimed', 'closed' ] as $s ) {
            $counts[ $s ] = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status = %s", $s
            ) );
        }
        $counts['all'] = array_sum( $counts );

        // Enrich each row
        $rows = [];
        foreach ( $queries as $q ) {
            $claimer = $q->claimed_by ? get_userdata( $q->claimed_by ) : null;
            $rows[]  = [
                'id'             => (int) $q->id,
                'query_uid'      => $q->query_uid,
                'title'          => $q->title,
                'submitter_name' => $q->submitter_name,
                'submitter_email'=> $q->submitter_email,
                'query_source'   => ucwords( str_replace( '_', ' ', $q->query_source ) ),
                'message_type'   => $q->message_type,
                'status'         => $q->status,
                'claimed_by_name'=> $claimer ? $claimer->display_name : '',
                'created_at'     => date_i18n( get_option( 'date_format' ), strtotime( $q->created_at ) ),
                'has_response'   => (bool) NQM_Response::get_by_query( $q->id ),
            ];
        }

        wp_send_json_success( [
            'queries'    => $rows,
            'total'      => $total,
            'page'       => $page,
            'per_page'   => $per_page,
            'counts'     => $counts,
        ] );
    }

    /* ── Get single query (detail drawer) ────────────────────── */
    public static function handle_get_query() {
        self::require_admin();
        $id    = absint( $_POST['query_id'] ?? 0 );
        $query = NQM_Query::get( $id );
        if ( ! $query ) wp_send_json_error( [ 'message' => __( 'Query not found.', 'ngo-query-manager' ) ] );

        $response = NQM_Response::get_by_query( $query->id );
        $feedback = NQM_Response::get_feedback( $query->id );
        $claimer  = $query->claimed_by ? get_userdata( $query->claimed_by ) : null;

        $q_data = (array) $query;
        $q_data['message_body']  = $query->message_body ? nqm_render_rich( $query->message_body ) : '';
        $q_data['video_url']     = $query->video_attach_id ? wp_get_attachment_url( $query->video_attach_id ) : null;
        $q_data['claimed_by_name'] = $claimer ? $claimer->display_name : '';
        $q_data['created_at_fmt']  = date_i18n(
            get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
            strtotime( $query->created_at )
        );

        $resp_data = null;
        if ( $response ) {
            $responder  = get_userdata( $response->responder_id );
            $att_ids    = $response->attachments ? json_decode( $response->attachments, true ) : [];
            $atts       = [];
            if ( is_array( $att_ids ) ) {
                foreach ( $att_ids as $aid ) {
                    $url  = wp_get_attachment_url( $aid );
                    $name = get_the_title( $aid ) ?: basename( get_attached_file( $aid ) );
                    if ( $url ) $atts[] = [ 'url' => $url, 'name' => $name ];
                }
            }
            $resp_data = [
                'message_body'   => nqm_render_rich( $response->message_body ),
                'attachments'    => $atts,
                'responder_name' => $responder ? $responder->display_name : __( 'Unknown', 'ngo-query-manager' ),
                'created_at_fmt' => date_i18n(
                    get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
                    strtotime( $response->created_at )
                ),
            ];
        }

        // Get respondents for the assign dropdown in the drawer
        $respondent_roles = NQM_Settings::get_respondent_roles();
        $respondents_raw  = get_users( [ 'role__in' => $respondent_roles, 'orderby' => 'display_name' ] );
        $respondents      = array_map( function( $u ) {
            return [ 'id' => $u->ID, 'label' => $u->display_name . ' (' . $u->user_login . ')' ];
        }, $respondents_raw );

        wp_send_json_success( [
            'query'       => $q_data,
            'response'    => $resp_data,
            'feedback'    => $feedback ? (array) $feedback : null,
            'respondents' => $respondents,
        ] );
    }

    /* ── Delete query ────────────────────────────────────────── */
    public static function handle_delete_query() {
        self::require_admin();
        $id = absint( $_POST['query_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( [ 'message' => __( 'Invalid query.', 'ngo-query-manager' ) ] );

        global $wpdb;
        // Remove related rows first
        $wpdb->delete( $wpdb->prefix . 'nqm_responses',    [ 'query_id' => $id ], [ '%d' ] );
        $wpdb->delete( $wpdb->prefix . 'nqm_feedback',     [ 'query_id' => $id ], [ '%d' ] );
        $wpdb->delete( $wpdb->prefix . 'nqm_video_ledger', [ 'query_id' => $id ], [ '%d' ] );
        $wpdb->delete( $wpdb->prefix . 'nqm_queries',      [ 'id'       => $id ], [ '%d' ] );

        wp_send_json_success( [ 'message' => __( 'Query deleted.', 'ngo-query-manager' ) ] );
    }

    /* ── Reopen a closed query ───────────────────────────────── */
    public static function handle_reopen_query() {
        self::require_admin();
        $id    = absint( $_POST['query_id'] ?? 0 );
        $query = NQM_Query::get( $id );
        if ( ! $query ) wp_send_json_error( [ 'message' => __( 'Query not found.', 'ngo-query-manager' ) ] );
        if ( $query->status !== 'closed' ) {
            wp_send_json_error( [ 'message' => __( 'Only closed queries can be reopened.', 'ngo-query-manager' ) ] );
        }

        global $wpdb;
        // Delete the response so a new one can be submitted
        $wpdb->delete( $wpdb->prefix . 'nqm_responses', [ 'query_id' => $id ], [ '%d' ] );
        $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'open', 'claimed_by' => null, 'claimed_at' => null, 'responded_at' => null ],
            [ 'id' => $id ],
            [ '%s', '%s', '%s', '%s' ],
            [ '%d' ]
        );

        wp_send_json_success( [ 'message' => __( 'Query reopened.', 'ngo-query-manager' ) ] );
    }

    /* ── Change status (admin override) ─────────────────────── */
    public static function handle_change_status() {
        self::require_admin();
        $id     = absint( $_POST['query_id'] ?? 0 );
        $status = sanitize_text_field( $_POST['new_status'] ?? '' );
        if ( ! in_array( $status, [ 'open', 'claimed', 'closed' ], true ) ) {
            wp_send_json_error( [ 'message' => __( 'Invalid status.', 'ngo-query-manager' ) ] );
        }
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => $status ],
            [ 'id' => $id ],
            [ '%s' ],
            [ '%d' ]
        );
        wp_send_json_success( [ 'message' => sprintf( __( 'Status changed to %s.', 'ngo-query-manager' ), $status ) ] );
    }

    /* ── Assign query ────────────────────────────────────────── */
    public static function handle_assign_query() {
        self::require_admin();
        $query_id  = absint( $_POST['query_id']   ?? 0 );
        $assignee  = absint( $_POST['assignee_id'] ?? 0 );
        $result    = NQM_Query::assign( $query_id, $assignee );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        $user = get_userdata( $assignee );
        wp_send_json_success( [
            'message'      => __( 'Query assigned.', 'ngo-query-manager' ),
            'assignee_name'=> $user ? $user->display_name : '',
        ] );
    }

    /* ── Revoke claim (admin can revoke any claim) ───────────── */
    public static function handle_revoke_claim() {
        self::require_admin();
        $id    = absint( $_POST['query_id'] ?? 0 );
        $query = NQM_Query::get( $id );
        if ( ! $query || $query->status !== 'claimed' ) {
            wp_send_json_error( [ 'message' => __( 'Query is not currently claimed.', 'ngo-query-manager' ) ] );
        }
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'nqm_queries',
            [ 'status' => 'open', 'claimed_by' => null, 'claimed_at' => null ],
            [ 'id' => $id ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );
        wp_send_json_success( [ 'message' => __( 'Claim revoked. Query is now open.', 'ngo-query-manager' ) ] );
    }

    /* ── Guard ───────────────────────────────────────────────── */
    private static function require_admin() {
        check_ajax_referer( 'nqm_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Administrators only.', 'ngo-query-manager' ) ] );
        }
    }
}
