<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Post_Types {
    public static function init() {
        // No CPT needed – we use custom DB tables.
        // Register a rewrite endpoint for the query-status page if needed.
        add_action( 'init', [ __CLASS__, 'register_rewrite' ] );
    }

    public static function register_rewrite() {
        add_rewrite_endpoint( 'nqm-query', EP_ROOT | EP_PAGES );
    }
}
