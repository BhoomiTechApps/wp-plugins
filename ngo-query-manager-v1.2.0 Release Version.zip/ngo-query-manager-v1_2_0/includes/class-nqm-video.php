<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Handles video recording quota and attaching recorded blobs to the media library.
 */
class NQM_Video {

    public static function init() {
        add_action( 'wp_ajax_nqm_upload_video',        [ __CLASS__, 'handle_upload' ] );
        add_action( 'wp_ajax_nopriv_nqm_upload_video', [ __CLASS__, 'handle_upload' ] );
        add_action( 'wp_ajax_nqm_get_quota',           [ __CLASS__, 'ajax_quota'    ] );
        add_action( 'wp_ajax_nopriv_nqm_get_quota',    [ __CLASS__, 'ajax_quota'    ] );
    }

    /* ── Upload a recorded video blob ──────────────────────── */
    public static function handle_upload() {
        check_ajax_referer( 'nqm_nonce', 'nonce' );

        if ( empty( $_FILES['video'] ) ) {
            wp_send_json_error( [ 'message' => __( 'No video file received.', 'ngo-query-manager' ) ] );
        }

        $duration = isset( $_POST['duration'] ) ? absint( $_POST['duration'] ) : 0;
        $max      = NQM_Settings::video_max_duration();
        $avail    = NQM_Database::get_available_seconds();

        if ( $duration > $max ) {
            wp_send_json_error( [ 'message' => sprintf( __( 'Recording exceeds the maximum allowed duration of %d seconds.', 'ngo-query-manager' ), $max ) ] );
        }
        if ( $duration > $avail ) {
            wp_send_json_error( [
                'message'   => __( 'Insufficient global video quota. Please reduce recording time or choose another message type.', 'ngo-query-manager' ),
                'available' => $avail,
            ] );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $upload_id = media_handle_upload( 'video', 0 );
        if ( is_wp_error( $upload_id ) ) {
            wp_send_json_error( [ 'message' => $upload_id->get_error_message() ] );
        }

        wp_send_json_success( [
            'attachment_id' => $upload_id,
            'url'           => wp_get_attachment_url( $upload_id ),
            'duration'      => $duration,
        ] );
    }

    /* ── Quota status ───────────────────────────────────────── */
    public static function ajax_quota() {
        check_ajax_referer( 'nqm_nonce', 'nonce' );
        wp_send_json_success( [
            'total'     => NQM_Settings::video_global_allocation(),
            'used'      => NQM_Database::get_used_seconds(),
            'available' => NQM_Database::get_available_seconds(),
            'max_clip'  => NQM_Settings::video_max_duration(),
        ] );
    }

    /* ── Add duration to ledger (called after successful submission) */
    public static function log_video( $query_id, $duration_sec ) {
        global $wpdb;
        $wpdb->insert(
            $wpdb->prefix . 'nqm_video_ledger',
            [
                'query_id'     => $query_id,
                'duration_sec' => $duration_sec,
            ],
            [ '%d', '%d' ]
        );
    }

    /* ── Remove from ledger if query is deleted ─────────────── */
    public static function remove_video( $query_id ) {
        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'nqm_video_ledger', [ 'query_id' => $query_id ], [ '%d' ] );
    }
}
