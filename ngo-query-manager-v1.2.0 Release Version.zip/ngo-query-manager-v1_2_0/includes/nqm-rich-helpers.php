<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Sanitise rich-text content that may include YouTube / Vimeo iframes
 * inserted by TinyMCE's media plugin.
 *
 * wp_kses_post() strips <iframe> entirely. This wrapper extends the
 * allowed-tags list to permit iframes whose src comes from a known
 * safe video host, while still blocking arbitrary iframes.
 */
function nqm_kses_rich( $content ) {
    $allowed = wp_kses_allowed_html( 'post' );

    // Allow <iframe> from trusted video hosts only
    $allowed['iframe'] = [
        'src'             => true,
        'width'           => true,
        'height'          => true,
        'frameborder'     => true,
        'allowfullscreen' => true,
        'allow'           => true,
        'title'           => true,
        'loading'         => true,
        'class'           => true,
        'style'           => true,
        'referrerpolicy'  => true,
    ];

    // Sanitise with the extended tag set
    $content = wp_kses( $content, $allowed );

    // Second pass: strip any iframe whose src is not a trusted video host.
    // This prevents iframes that slipped through from arbitrary domains.
    $trusted = [
        'youtube.com',
        'youtu.be',
        'youtube-nocookie.com',
        'vimeo.com',
        'player.vimeo.com',
        'dailymotion.com',
        'dai.ly',
        'facebook.com',
        'drive.google.com',
        'docs.google.com',
    ];

    $content = preg_replace_callback(
        '/<iframe[^>]*src=["\']([^"\']*)["\'][^>]*>.*?<\/iframe>/is',
        function ( $m ) use ( $trusted ) {
            $src  = $m[1];
            $host = strtolower( wp_parse_url( $src, PHP_URL_HOST ) ?? '' );
            $host = preg_replace( '/^www\\./', '', $host );
            foreach ( $trusted as $t ) {
                if ( $host === $t || str_ends_with( $host, '.' . $t ) ) {
                    return $m[0]; // trusted — keep it
                }
            }
            return ''; // not trusted — strip
        },
        $content
    );

    return $content;
}

/**
 * Render stored rich content for display.
 * Runs WordPress's oEmbed + shortcode pipeline so [embed] tags and
 * raw oEmbed URLs are also converted to players.
 */
function nqm_render_rich( $content ) {
    global $wp_embed;
    if ( $wp_embed ) {
        $content = $wp_embed->autoembed( $content );
        $content = $wp_embed->run_shortcode( $content );
    }
    $content = do_shortcode( $content );
    $content = wpautop( $content );
    return $content;
}
