<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Ajax {

    public static function init() {
        $actions = [
            'nqm_submit_query',
            'nqm_submit_response',
            'nqm_claim_query',
            'nqm_revoke_claim',
            'nqm_assign_query',
            'nqm_submit_feedback',
            'nqm_get_query_status',
        ];
        foreach ( $actions as $action ) {
            add_action( "wp_ajax_{$action}",        [ __CLASS__, str_replace( 'nqm_', 'handle_', $action ) ] );
            add_action( "wp_ajax_nopriv_{$action}", [ __CLASS__, str_replace( 'nqm_', 'handle_', $action ) ] );
        }
        // Theme save — admin only
        add_action( 'wp_ajax_nqm_save_theme', [ __CLASS__, 'handle_save_theme' ] );
    }

    /* ── Save theme settings (frontend admin AJAX) ───────────── */
    public static function handle_save_theme() {
        self::verify_nonce();
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Forbidden' ] );
        }

        $color     = isset( $_POST['theme_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['theme_color'] ) ) : '';
        $font_size = isset( $_POST['font_size'] )   ? sanitize_text_field( wp_unslash( $_POST['font_size'] ) )  : '';

        if ( $color )     update_option( 'nqm_theme_color', $color );
        if ( $font_size ) update_option( 'nqm_font_size',   $font_size );

        wp_send_json_success( [ 'message' => __( 'Theme saved.', 'ngo-query-manager' ) ] );
    }

    /* ── Submit query ────────────────────────────────────────── */
    public static function handle_submit_query() {
        self::verify_nonce();

        $required = [ 'title', 'submitter_name', 'submitter_email', 'query_source', 'message_type' ];
        foreach ( $required as $field ) {
            if ( empty( $_POST[ $field ] ) ) {
                wp_send_json_error( [ 'message' => sprintf( __( 'Field "%s" is required.', 'ngo-query-manager' ), $field ) ] );
            }
        }

        $data = [
            'title'           => $_POST['title'],
            'submitter_name'  => $_POST['submitter_name'],
            'submitter_email' => $_POST['submitter_email'],
            'submitter_org'   => $_POST['submitter_org']   ?? '',
            'submitter_phone' => $_POST['submitter_phone'] ?? '',
            'query_source'    => $_POST['query_source'],
            'message_type'    => $_POST['message_type'],
            'message_body'    => $_POST['message_body']    ?? '',
            'video_attach_id' => $_POST['video_attach_id'] ?? 0,
            'video_duration'  => $_POST['video_duration']  ?? 0,
        ];

        $result = NQM_Query::create( $data );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }

        $query = NQM_Query::get( $result );
        wp_send_json_success( [
            'message'   => __( 'Your query has been submitted successfully.', 'ngo-query-manager' ),
            'query_uid' => $query->query_uid,
            'query_id'  => $query->id,
        ] );
    }

    /* ── Submit response ─────────────────────────────────────── */
    public static function handle_submit_response() {
        self::verify_nonce();
        self::require_login();

        $query_id = absint( $_POST['query_id'] ?? 0 );
        if ( ! $query_id ) wp_send_json_error( [ 'message' => __( 'Invalid query.', 'ngo-query-manager' ) ] );

        // Handle file attachments via $_FILES
        // Behaviour depends on whether email notifications are enabled:
        //   – Notifications ON  → keep files as raw temp paths; attach to email, do NOT save to media library.
        //   – Notifications OFF → save to media library, include download links in response body.
        $attachments      = [];      // attachment IDs saved to media library (used when notify is OFF)
        $email_attachments = [];     // [ ['name'=>..., 'tmp'=>..., 'type'=>...] ] for email sending (notify ON)

        $notify_on = (int) get_option( 'nqm_admin_email_notify', 1 );

        if ( ! empty( $_FILES['attachments'] ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';

            $files = $_FILES['attachments'];
            $count = is_array( $files['name'] ) ? count( $files['name'] ) : 1;

            for ( $i = 0; $i < $count; $i++ ) {
                $file_name     = is_array( $files['name'] )     ? $files['name'][ $i ]     : $files['name'];
                $file_type     = is_array( $files['type'] )     ? $files['type'][ $i ]     : $files['type'];
                $file_tmp      = is_array( $files['tmp_name'] ) ? $files['tmp_name'][ $i ] : $files['tmp_name'];
                $file_error    = is_array( $files['error'] )    ? $files['error'][ $i ]    : $files['error'];
                $file_size     = is_array( $files['size'] )     ? $files['size'][ $i ]     : $files['size'];

                if ( $file_error !== UPLOAD_ERR_OK || ! $file_tmp ) continue;

                if ( $notify_on ) {
                    // Move to a safe temp location so we can attach it after the DB write
                    $safe_tmp = wp_tempnam( $file_name );
                    if ( move_uploaded_file( $file_tmp, $safe_tmp ) ) {
                        $email_attachments[] = [
                            'name' => sanitize_file_name( $file_name ),
                            'path' => $safe_tmp,
                            'type' => $file_type,
                        ];
                    }
                } else {
                    $_FILES['attachment_file'] = [
                        'name'     => $file_name,
                        'type'     => $file_type,
                        'tmp_name' => $file_tmp,
                        'error'    => $file_error,
                        'size'     => $file_size,
                    ];
                    $aid = media_handle_upload( 'attachment_file', 0 );
                    if ( ! is_wp_error( $aid ) ) {
                        $attachments[] = $aid;
                    }
                }
            }
        }
        // Also accept already-uploaded IDs (only meaningful when saving to media library)
        if ( ! empty( $_POST['attachment_ids'] ) ) {
            $attachments = array_merge( $attachments, array_map( 'absint', (array) $_POST['attachment_ids'] ) );
        }

        // When saving to media library, append download links to the message body
        $message_body = $_POST['message_body'] ?? '';
        if ( ! $notify_on && ! empty( $attachments ) ) {
            $links = [];
            foreach ( $attachments as $aid ) {
                $url   = wp_get_attachment_url( $aid );
                $fname = basename( get_attached_file( $aid ) );
                if ( $url ) {
                    $links[] = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html( $fname ) . '</a>';
                }
            }
            if ( $links ) {
                $message_body .= '<p><strong>' . __( 'Attachments:', 'ngo-query-manager' ) . '</strong> ' . implode( ' | ', $links ) . '</p>';
            }
        }

        $data = [
            'message_type' => $_POST['message_type'] ?? 'text',
            'message_body' => $message_body,
            'attachments'  => $attachments,
            'email_attachments' => $email_attachments,
        ];

        $result = NQM_Response::create( $query_id, $data );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        wp_send_json_success( [ 'message' => __( 'Response submitted and query marked as closed.', 'ngo-query-manager' ) ] );
    }

    /* ── Claim ───────────────────────────────────────────────── */
    public static function handle_claim_query() {
        self::verify_nonce();
        self::require_login();
        self::require_respondent_role();

        $query_id = absint( $_POST['query_id'] ?? 0 );
        $result   = NQM_Query::claim( $query_id, get_current_user_id() );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        wp_send_json_success( [ 'message' => __( 'Query claimed.', 'ngo-query-manager' ) ] );
    }

    /* ── Revoke claim ────────────────────────────────────────── */
    public static function handle_revoke_claim() {
        self::verify_nonce();
        self::require_login();

        $query_id = absint( $_POST['query_id'] ?? 0 );
        $result   = NQM_Query::revoke_claim( $query_id, get_current_user_id() );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        wp_send_json_success( [ 'message' => __( 'Claim revoked. Query is now open.', 'ngo-query-manager' ) ] );
    }

    /* ── Assign ──────────────────────────────────────────────── */
    public static function handle_assign_query() {
        self::verify_nonce();
        if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'edit_others_posts' ) ) {
            wp_send_json_error( [ 'message' => __( 'Insufficient permissions.', 'ngo-query-manager' ) ] );
        }
        $query_id   = absint( $_POST['query_id']   ?? 0 );
        $assignee   = absint( $_POST['assignee_id'] ?? 0 );
        $result     = NQM_Query::assign( $query_id, $assignee );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        wp_send_json_success( [ 'message' => __( 'Query assigned.', 'ngo-query-manager' ) ] );
    }

    /* ── Feedback ────────────────────────────────────────────── */
    public static function handle_submit_feedback() {
        self::verify_nonce();
        $query_id = absint( $_POST['query_id'] ?? 0 );
        $result   = NQM_Response::save_feedback( $query_id, $_POST );
        if ( is_wp_error( $result ) ) {
            wp_send_json_error( [ 'message' => $result->get_error_message() ] );
        }
        wp_send_json_success( [ 'message' => __( 'Thank you for your feedback.', 'ngo-query-manager' ) ] );
    }

    /* ── Status check ────────────────────────────────────────── */
    public static function handle_get_query_status() {
        self::verify_nonce();
        $uid   = sanitize_text_field( $_POST['query_uid'] ?? '' );
        $query = NQM_Query::get( $uid );
        if ( ! $query ) wp_send_json_error( [ 'message' => __( 'Query not found.', 'ngo-query-manager' ) ] );

        $response = NQM_Response::get_by_query( $query->id );
        $feedback = NQM_Response::get_feedback( $query->id );

        // Build query data with rendered body and media
        $query_data = (array) $query;
        $query_data['message_body'] = $query->message_body ? nqm_render_rich( $query->message_body ) : '';
        $query_data['video_url']    = ( $query->video_attach_id ) ? wp_get_attachment_url( $query->video_attach_id ) : null;

        // Render rich content server-side so iframes/embeds survive JSON transport
        $response_data = null;
        if ( $response ) {
            $response_data = (array) $response;
            $response_data['message_body'] = nqm_render_rich( $response->message_body );
            // Parse attachments into [ { url, name } ] for the JS
            $att_ids = $response->attachments ? json_decode( $response->attachments, true ) : [];
            $atts    = [];
            if ( is_array( $att_ids ) ) {
                foreach ( $att_ids as $aid ) {
                    $url  = wp_get_attachment_url( $aid );
                    $name = get_the_title( $aid ) ?: basename( get_attached_file( $aid ) );
                    if ( $url ) $atts[] = [ 'url' => $url, 'name' => $name ];
                }
            }
            $response_data['attachments'] = $atts;
        }

        wp_send_json_success( [
            'query'    => $query_data,
            'response' => $response_data,
            'feedback' => $feedback,
        ] );
    }

    /* ── Helpers ─────────────────────────────────────────────── */
    private static function verify_nonce() {
        if ( ! check_ajax_referer( 'nqm_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'ngo-query-manager' ) ] );
        }
    }

    private static function require_login() {
        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'You must be logged in to perform this action.', 'ngo-query-manager' ), 'login_required' => true ] );
        }
    }

    private static function require_respondent_role() {
        $user  = wp_get_current_user();
        $roles = NQM_Settings::get_respondent_roles();
        if ( current_user_can( 'manage_options' ) ) return;
        foreach ( $roles as $role ) {
            if ( in_array( $role, (array) $user->roles ) ) return;
        }
        wp_send_json_error( [ 'message' => __( 'Your account does not have permission to claim queries.', 'ngo-query-manager' ) ] );
    }
}
