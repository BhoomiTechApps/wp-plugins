<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Database {

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $pfx     = $wpdb->prefix;

        $sql = [];

        /* ── Queries ─────────────────────────────────────────── */
        $sql[] = "CREATE TABLE IF NOT EXISTS {$pfx}nqm_queries (
            id              BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            query_uid       VARCHAR(20)  NOT NULL,
            title           VARCHAR(255) NOT NULL,
            submitter_name  VARCHAR(150) NOT NULL,
            submitter_email VARCHAR(150) NOT NULL,
            submitter_org   VARCHAR(200) DEFAULT '',
            submitter_phone VARCHAR(50)  DEFAULT '',
            query_source    VARCHAR(80)  NOT NULL,
            message_type    ENUM('text','video','hybrid') NOT NULL DEFAULT 'text',
            message_body    LONGTEXT     DEFAULT NULL,
            video_attach_id BIGINT(20)   DEFAULT NULL,
            video_duration  INT(11)      DEFAULT 0,
            status          ENUM('open','claimed','closed') NOT NULL DEFAULT 'open',
            claimed_by      BIGINT(20)   DEFAULT NULL,
            claimed_at      DATETIME     DEFAULT NULL,
            responded_at    DATETIME     DEFAULT NULL,
            created_at      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            submitter_user_id BIGINT(20) DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY query_uid (query_uid),
            KEY status (status),
            KEY claimed_by (claimed_by)
        ) $charset;";

        /* ── Responses ───────────────────────────────────────── */
        $sql[] = "CREATE TABLE IF NOT EXISTS {$pfx}nqm_responses (
            id              BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            query_id        BIGINT(20) UNSIGNED NOT NULL,
            responder_id    BIGINT(20) NOT NULL,
            message_type    ENUM('text','hybrid') NOT NULL DEFAULT 'text',
            message_body    LONGTEXT NOT NULL,
            attachments     LONGTEXT DEFAULT NULL,
            created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY query_id (query_id)
        ) $charset;";

        /* ── Ratings / Likes / Comments by initiator ─────────── */
        $sql[] = "CREATE TABLE IF NOT EXISTS {$pfx}nqm_feedback (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            query_id     BIGINT(20) UNSIGNED NOT NULL,
            rating       TINYINT(1)   DEFAULT NULL,
            liked        TINYINT(1)   DEFAULT 0,
            comment      TEXT         DEFAULT NULL,
            created_at   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY query_id (query_id)
        ) $charset;";

        /* ── Video time ledger ───────────────────────────────── */
        $sql[] = "CREATE TABLE IF NOT EXISTS {$pfx}nqm_video_ledger (
            id           BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            query_id     BIGINT(20) UNSIGNED NOT NULL,
            duration_sec INT(11)    NOT NULL DEFAULT 0,
            recorded_at  DATETIME   NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY query_id (query_id)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $statement ) {
            dbDelta( $statement );
        }
    }

    /* ── Helper: used seconds ───────────────────────────────── */
    public static function get_used_seconds() {
        global $wpdb;
        $used = $wpdb->get_var(
            "SELECT SUM(duration_sec) FROM {$wpdb->prefix}nqm_video_ledger"
        );
        return (int) $used;
    }

    public static function get_available_seconds() {
        $total = (int) get_option( 'nqm_video_global_allocation', 3600 );
        return max( 0, $total - self::get_used_seconds() );
    }
}
