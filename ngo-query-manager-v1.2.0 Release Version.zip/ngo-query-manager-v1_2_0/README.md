# NGO Query Manager — WordPress Plugin

A comprehensive query submission and response management system for NGO websites.

---

## Installation

1. Upload the `ngo-query-manager` folder to `/wp-content/plugins/`
2. Activate the plugin via **Plugins → Installed Plugins**
3. Visit **NGO Queries → Settings** to configure the plugin
4. Add shortcodes to pages (see below)

---

## Shortcodes

| Shortcode | Purpose | Notes |
|-----------|---------|-------|
| `[nqm_dosubmit]` | Public query submission form | Works for guests and logged-in users |
| `[nqm_qsearch]` | Query status checker by ID | Guests can check using their Query UID |
| `[nqm_qlist]` | List of user's own queries + feedback controls | Logged-in users only |
| `[nqm_dorespond]` | Respond to a specific query | Use with `?qid=N` in the URL; logged-in respondents only |

### Example page setup

| Page | Shortcode |
|------|-----------|
| Submit a Query | `[nqm_dosubmit]` |
| Check My Query | `[nqm_qsearch]` |
| My Queries | `[nqm_qlist]` |
| Respond to Query | `[nqm_dorespond]` |

---

## Admin Panel

### NGO Queries → All Queries
- Filter by status: Open / Claimed / Closed
- View full detail for any query
- Assign queries to registered respondents
- Revoke claims

### NGO Queries → Settings
- Toggle admin email notification on submission
- Set "From" name and email for outgoing notifications
- Set default max video recording duration (seconds)
- Set global video time bank (seconds)
- Define query source options (one per line)
- Select which WordPress roles can claim and respond to queries

### NGO Queries → Video Quota
- Visual dashboard showing total / used / available video time

---

## Feature Summary

### Submission (Step 1 — Identity)
- Full name, email, organisation, phone
- Source selection (configurable: Project Partner, Funding Agency, Beneficiary, etc.)

### Submission (Step 2 — Message)
- **Query Title** (required, becomes the unique reference alongside the auto-generated ID)
- **Text** — plain textarea
- **Video Recording** — in-browser MediaRecorder; uploads to WordPress media library; respects per-clip limit and global quota
- **Hybrid** — TinyMCE editor with media embed and hyperlink support

### Query Lifecycle
```
Open  →  Claimed  →  [Response Submitted]  →  Closed
         ↕
       Revoke Claim → Open
```

- Any respondent-role user may **claim** an open query
- A claimed query can only be responded to by the claimant (or admin)
- Claim can be **revoked** by the claimant or admin, returning it to Open
- Admins can **assign** a query directly to any respondent-role user
- Once responded to, the query is **closed**; no further responses accepted

### Response
- Single response per query (text or hybrid/rich text)
- Hybrid response supports TinyMCE + file attachments (uploaded to media library)

### Notifications
- Email to admin on every new submission (configurable)
- Email to submitter's registered email when a response is posted

### Feedback (by initiator only, once)
- Star rating (1–5)
- Like button
- Comment text

---

## Database Tables

| Table | Purpose |
|-------|---------|
| `{prefix}nqm_queries` | All submitted queries |
| `{prefix}nqm_responses` | One response per query |
| `{prefix}nqm_feedback` | Initiator feedback per query |
| `{prefix}nqm_video_ledger` | Video duration accounting |

---

## Requirements

- WordPress 6.0+
- PHP 7.4+
- Modern browser with MediaDevices API (for video recording)
- TinyMCE (bundled with WordPress) for hybrid editor
