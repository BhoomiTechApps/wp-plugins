<?php
/**
 * Plugin Name: NGO Query Manager
 * Plugin URI:  https://bhoomitechfoundation.org/digital-tools
 * Description: A comprehensive query submission and response management system for NGO websites. Supports text, video and hybrid messaging with role-based assignment, notifications, and response lifecycle tracking.
 * Version:     1.2.0
 * Author:      Bhoomitech Heritage and Development Foundation
 * Text Domain: ngo-query-manager
 * License:     GPL-2.0+
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'NQM_VERSION',     '1.1.0' );
define( 'NQM_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'NQM_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'NQM_PLUGIN_FILE', __FILE__ );

/* ── Autoload ──────────────────────────────────────────────────── */
require_once NQM_PLUGIN_DIR . 'includes/nqm-rich-helpers.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-activator.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-database.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-post-types.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-settings.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-video.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-mailer.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-query.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-response.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-ajax.php';
require_once NQM_PLUGIN_DIR . 'admin/class-nqm-admin.php';
require_once NQM_PLUGIN_DIR . 'public/class-nqm-public.php';
require_once NQM_PLUGIN_DIR . 'includes/class-nqm-frontend-admin.php';

/* ── Activation / Deactivation ─────────────────────────────────── */
register_activation_hook(   __FILE__, [ 'NQM_Activator', 'activate'   ] );
register_deactivation_hook( __FILE__, [ 'NQM_Activator', 'deactivate' ] );

/* ── Bootstrap ─────────────────────────────────────────────────── */
add_action( 'plugins_loaded', function () {
    NQM_Post_Types::init();
    NQM_Settings::init();
    NQM_Video::init();
    NQM_Ajax::init();
    NQM_Admin::init();
    NQM_Public::init();
    NQM_Frontend_Admin::init();
} );
