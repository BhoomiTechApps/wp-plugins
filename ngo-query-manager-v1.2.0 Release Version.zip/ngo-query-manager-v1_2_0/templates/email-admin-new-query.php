<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!DOCTYPE html><html><body style="font-family:sans-serif;color:#333;max-width:600px;margin:auto;padding:20px">
<h2 style="color:#2c5f2e">New Query Received — <?php echo esc_html($query->query_uid); ?></h2>
<table cellpadding="8" style="border-collapse:collapse;width:100%">
    <tr><td style="background:#f5f5f5;font-weight:bold">Query ID</td><td><?php echo esc_html($query->query_uid); ?></td></tr>
    <tr><td style="background:#f5f5f5;font-weight:bold">Title</td><td><?php echo esc_html($query->title); ?></td></tr>
    <tr><td style="background:#f5f5f5;font-weight:bold">From</td><td><?php echo esc_html($query->submitter_name); ?> &lt;<?php echo esc_html($query->submitter_email); ?>&gt;</td></tr>
    <tr><td style="background:#f5f5f5;font-weight:bold">Source</td><td><?php echo esc_html(ucwords(str_replace('_',' ',$query->query_source))); ?></td></tr>
    <tr><td style="background:#f5f5f5;font-weight:bold">Type</td><td><?php echo esc_html(ucfirst($query->message_type)); ?></td></tr>
    <tr><td style="background:#f5f5f5;font-weight:bold">Date</td><td><?php echo esc_html(date_i18n(get_option('date_format').' '.get_option('time_format'), strtotime($query->created_at))); ?></td></tr>
</table>
<?php if ($query->message_body) : ?>
<h3>Message</h3>
<div style="background:#f9f9f9;padding:12px;border-left:4px solid #2c5f2e"><?php echo wp_kses_post($query->message_body); ?></div>
<?php endif; ?>
<p><a href="<?php echo esc_url(admin_url('admin.php?page=nqm-queries&view=detail&qid='.$query->id)); ?>" style="background:#2c5f2e;color:#fff;padding:10px 20px;text-decoration:none;border-radius:4px">View in Dashboard</a></p>
<hr><p style="font-size:12px;color:#999"><?php echo esc_html($site); ?> — <?php echo esc_html($url); ?></p>
</body></html>
