<?php if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
$respond_page_id = (int) get_option( 'nqm_respond_page_id', 0 );
$respond_base    = $respond_page_id ? get_permalink( $respond_page_id ) : '';
?>
<div class="nqm-wrap" id="nqm-myqueries-wrap">

    <?php if ( empty( $my_submitted ) ) : ?>
        <p><?php esc_html_e( 'You have not submitted any queries yet.', 'ngo-query-manager' ); ?></p>
    <?php else : ?>
    <table class="nqm-table">
        <thead><tr>
            <th><?php esc_html_e( 'ID',      'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Title',   'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Status',  'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Date',    'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'ngo-query-manager' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $my_submitted as $q ) :
            $response = NQM_Response::get_by_query( $q->id );
            $feedback = NQM_Response::get_feedback( $q->id );
        ?>
        <tr>
            <td><code><?php echo esc_html( $q->query_uid ); ?></code></td>
            <td><?php echo esc_html( $q->title ); ?></td>
            <td><span class="nqm-status nqm-status--<?php echo esc_attr( $q->status ); ?>"><?php echo esc_html( ucfirst( $q->status ) ); ?></span></td>
            <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $q->created_at ) ) ); ?></td>
            <td>
                <?php if ( $q->status === 'closed' && $response && ! $feedback ) : ?>
                <div class="nqm-feedback-inline" data-qid="<?php echo (int) $q->id; ?>">
                    <strong><?php esc_html_e( 'Rate this response:', 'ngo-query-manager' ); ?></strong>
                    <div class="nqm-stars">
                        <?php for ( $i = 1; $i <= 5; $i++ ) : ?><span class="nqm-star" data-val="<?php echo $i; ?>">☆</span><?php endfor; ?>
                    </div>
                    <label><input type="checkbox" class="nqm-like"> 👍 <?php esc_html_e( 'Like', 'ngo-query-manager' ); ?></label>
                    <textarea class="nqm-comment-box" placeholder="<?php esc_attr_e( 'Optional comment…', 'ngo-query-manager' ); ?>" rows="2"></textarea>
                    <button class="nqm-btn nqm-btn--small nqm-feedback-btn"><?php esc_html_e( 'Submit Feedback', 'ngo-query-manager' ); ?></button>
                </div>
                <?php elseif ( $feedback ) : ?>
                <span class="nqm-rated"><?php echo str_repeat( '★', (int) $feedback->rating ); ?> <?php if ( $feedback->liked ) echo '👍'; ?></span>
                <?php if ( $feedback->comment ) : ?>
                <blockquote class="nqm-feedback-comment"><?php echo esc_html( $feedback->comment ); ?></blockquote>
                <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>

    <?php if ( ! empty( $my_claimed ) ) : ?>

    <?php if ( ! $respond_base ) : ?>
    <div class="nqm-notice nqm-notice--info">
        <?php esc_html_e( 'Note: No respond page configured. Ask your administrator to set the Respond Page in NGO Queries → Settings.', 'ngo-query-manager' ); ?>
    </div>
    <?php endif; ?>

    <table class="nqm-table">
        <thead><tr>
            <th><?php esc_html_e( 'ID',      'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Title',   'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Status',  'ngo-query-manager' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'ngo-query-manager' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $my_claimed as $q ) :
            $respond_url = $respond_base ? add_query_arg( 'qid', $q->id, $respond_base ) : '';
        ?>
        <tr>
            <td><code><?php echo esc_html( $q->query_uid ); ?></code></td>
            <td><?php echo esc_html( $q->title ); ?></td>
            <td><span class="nqm-status nqm-status--<?php echo esc_attr( $q->status ); ?>"><?php echo esc_html( ucfirst( $q->status ) ); ?></span></td>
            <td>
                <?php if ( $q->status !== 'closed' ) : ?>
                    <?php if ( $respond_url ) : ?>
                    <a href="<?php echo esc_url( $respond_url ); ?>" class="nqm-btn nqm-btn--primary nqm-btn--small">
                        <?php esc_html_e( 'Respond', 'ngo-query-manager' ); ?>
                    </a>
                    <?php endif; ?>
                    <button class="nqm-btn nqm-btn--small nqm-revoke-btn" data-id="<?php echo (int) $q->id; ?>">
                        <?php esc_html_e( 'Revoke Claim', 'ngo-query-manager' ); ?>
                    </button>
                <?php else : ?>
                    <span class="nqm-status nqm-status--closed"><?php esc_html_e( 'Responded', 'ngo-query-manager' ); ?></span>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
