<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!DOCTYPE html><html><body style="font-family:sans-serif;color:#333;max-width:600px;margin:auto;padding:20px">
<h2 style="color:#2c5f2e">Response to Your Query</h2>
<p>Dear <?php echo esc_html($query->submitter_name); ?>,</p>
<p>A response has been posted to your query <strong><?php echo esc_html($query->query_uid); ?></strong> — <em><?php echo esc_html($query->title); ?></em>.</p>
<div style="background:#f9f9f9;padding:12px;border-left:4px solid #2c5f2e;margin:16px 0">
    <?php echo wp_kses_post($response->message_body); ?>
</div>
<p>You may visit the website to view the full response and leave feedback.</p>
<hr><p style="font-size:12px;color:#999"><?php echo esc_html($site); ?> — <?php echo esc_html($url); ?></p>
</body></html>
