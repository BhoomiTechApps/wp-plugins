<?php if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
?>
<div class="nqm-wrap" id="nqm-respond-wrap">
<?php if ( ! $query ) : ?>
    <p><?php esc_html_e( 'No query selected. Add ?qid=N to the URL.', 'ngo-query-manager' ); ?></p>
<?php elseif ( $query->status === 'closed' ) : ?>
    <div class="nqm-notice nqm-notice--info">
        <strong><?php esc_html_e( 'Query Closed', 'ngo-query-manager' ); ?></strong> — <?php esc_html_e( 'This query has already been responded to.', 'ngo-query-manager' ); ?>
    </div>
    <?php if ( $response ) : ?>
    <div class="nqm-card">
        <h3><?php esc_html_e('Existing Response','ngo-query-manager'); ?></h3>
        <div class="nqm-message-body"><?php echo nqm_render_rich($response->message_body); ?></div>
    </div>
    <?php endif; ?>
<?php else : ?>
    <!-- Query summary -->
    <div class="nqm-card nqm-query-summary">
        <h3><?php echo esc_html($query->query_uid); ?> — <?php echo esc_html($query->title); ?></h3>
        <p><strong><?php esc_html_e('From:','ngo-query-manager'); ?></strong> <?php echo esc_html($query->submitter_name); ?> (<?php echo esc_html(ucwords(str_replace('_',' ',$query->query_source))); ?>)</p>
        <?php if ($query->message_body) : ?><div class="nqm-message-body"><?php echo nqm_render_rich($query->message_body); ?></div><?php endif; ?>
        <?php if ($query->video_attach_id) : ?><?php echo wp_video_shortcode(['src' => wp_get_attachment_url($query->video_attach_id)]); ?><?php endif; ?>
    </div>

    <div class="nqm-form-card">
        <div class="nqm-notice" id="nqm-res-notice" style="display:none"></div>

        <!-- Message type -->
        <div class="nqm-field">
            <label><?php esc_html_e('Response Type','ngo-query-manager'); ?></label>
            <div class="nqm-type-selector nqm-type-selector--small">
                <label class="nqm-type-card">
                    <input type="radio" name="res_type" value="text" checked>
                    <span class="nqm-type-label"><?php esc_html_e('Text','ngo-query-manager'); ?></span>
                </label>
                <label class="nqm-type-card">
                    <input type="radio" name="res_type" value="hybrid">
                    <span class="nqm-type-label"><?php esc_html_e('Hybrid (Rich Text + Attachments)','ngo-query-manager'); ?></span>
                </label>
            </div>
        </div>

        <!-- Text panel -->
        <div class="nqm-panel" id="nqm-res-panel-text">
            <div class="nqm-field">
                <label for="nqm_res_text"><?php esc_html_e('Response','ngo-query-manager'); ?> <span class="req">*</span></label>
                <textarea id="nqm_res_text" rows="8" placeholder="<?php esc_attr_e('Write your response here…','ngo-query-manager'); ?>"></textarea>
            </div>
        </div>

        <!-- Hybrid panel (TinyMCE) -->
        <div class="nqm-panel" id="nqm-res-panel-hybrid" style="display:none">
            <div class="nqm-field">
                <label for="nqm_res_hybrid"><?php esc_html_e('Rich Response','ngo-query-manager'); ?> <span class="req">*</span></label>
                <textarea id="nqm_res_hybrid" class="nqm-tinymce"
                          data-tinymce='{"plugins":"link media image code","toolbar":"bold italic underline | link media image | bullist numlist | code"}'
                          rows="10"></textarea>
            </div>
            <div class="nqm-field">
                <label for="nqm_res_files"><?php esc_html_e('Attach Files','ngo-query-manager'); ?></label>
                <input type="file" id="nqm_res_files" name="attachments[]" multiple>
                <p class="description"><?php esc_html_e('Multiple files allowed.','ngo-query-manager'); ?></p>
            </div>
        </div>

        <div class="nqm-submit-row">
            <button type="button" class="nqm-btn nqm-btn--primary" id="nqm-res-submit-btn"
                    data-query-id="<?php echo (int)$query->id; ?>">
                <?php esc_html_e('Submit Response','ngo-query-manager'); ?>
            </button>
        </div>
    </div>
<?php endif; ?>
</div>
