<?php
/**
 * Frontend admin panel — visible only to administrators.
 * Shortcode: [nqm_admin_panel]
 */
if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
?>
<div class="nqm-wrap" id="nqm-fadmin-wrap">

    <div class="nqm-fadmin-header">
        <p class="description"><?php esc_html_e( 'Manage all queries from the frontend.', 'ngo-query-manager' ); ?></p>
        <!-- Compact theme controls (frontend admin only — full settings in WP Admin) -->
        <div class="nqm-fadmin-theme-bar" id="nqm-fadmin-theme-bar">
            <label for="nqm-fadmin-color" class="nqm-fadmin-theme-label"><?php esc_html_e( 'Theme Colour', 'ngo-query-manager' ); ?></label>
            <input type="color" id="nqm-fadmin-color" value="<?php echo esc_attr( get_option( 'nqm_theme_color', '#2c5f2e' ) ); ?>" title="<?php esc_attr_e( 'Primary colour', 'ngo-query-manager' ); ?>">
            <label for="nqm-fadmin-fontsize" class="nqm-fadmin-theme-label" style="margin-left:.75rem"><?php esc_html_e( 'Text Size', 'ngo-query-manager' ); ?></label>
            <select id="nqm-fadmin-fontsize">
                <?php
                $sizes = ['0.65rem'=>'XS','0.75rem'=>'S','0.8rem'=>'SM','.85rem'=>'M','1rem'=>'ML','1.1rem'=>'L','1.2rem'=>'XL'];
                $cur   = get_option( 'nqm_font_size', '.85rem' );
                foreach ( $sizes as $v => $l ) :
                ?><option value="<?php echo esc_attr($v); ?>" <?php selected( $cur, $v ); ?>><?php echo esc_html($l); ?></option><?php
                endforeach; ?>
            </select>
            <button type="button" class="nqm-btn nqm-btn--small nqm-btn--primary" id="nqm-fadmin-theme-save"><?php esc_html_e( 'Save', 'ngo-query-manager' ); ?></button>
            <span id="nqm-fadmin-theme-msg" style="font-size:.8rem;margin-left:.5rem;"></span>
        </div>
        <script>
        (function(){
            var col  = document.getElementById('nqm-fadmin-color');
            var fs   = document.getElementById('nqm-fadmin-fontsize');
            var save = document.getElementById('nqm-fadmin-theme-save');
            var msg  = document.getElementById('nqm-fadmin-theme-msg');

            function applyVars(color, fontSize) {
                var r = parseInt(color.slice(1,3),16), g = parseInt(color.slice(3,5),16), b = parseInt(color.slice(5,7),16);
                var light = 'rgb('+Math.min(255,Math.round(r*.12+255*.88))+','+Math.min(255,Math.round(g*.12+255*.88))+','+Math.min(255,Math.round(b*.12+255*.88))+')';
                var dark  = 'rgb('+Math.max(0,Math.round(r*.68))+','+Math.max(0,Math.round(g*.68))+','+Math.max(0,Math.round(b*.68))+')';
                var root  = document.documentElement;
                root.style.setProperty('--nqm-green', color);
                root.style.setProperty('--nqm-green-light', light);
                root.style.setProperty('--nqm-primary', color);
                root.style.setProperty('--nqm-primary-dark', dark);
                root.style.setProperty('--nqm-font-size-base', fontSize);
            }

            // Live preview
            col.addEventListener('input', function(){ applyVars(col.value, fs.value); });
            fs.addEventListener('change', function(){ applyVars(col.value, fs.value); });

            // Apply saved values on load
            applyVars(col.value, fs.value);

            // Save via AJAX
            save.addEventListener('click', function(){
                msg.textContent = '<?php esc_html_e( 'Saving…', 'ngo-query-manager' ); ?>';
                msg.style.color = '#555';
                var data = new FormData();
                data.append('action',      'nqm_save_theme');
                data.append('nonce',       typeof nqmFadmin !== 'undefined' ? nqmFadmin.nonce : '');
                data.append('theme_color', col.value);
                data.append('font_size',   fs.value);
                fetch(typeof nqmFadmin !== 'undefined' ? nqmFadmin.ajax_url : '<?php echo esc_js( admin_url('admin-ajax.php') ); ?>', { method:'POST', body:data })
                    .then(function(r){ return r.json(); })
                    .then(function(r){
                        if (r.success) { msg.textContent = '✓ <?php esc_html_e( 'Saved', 'ngo-query-manager' ); ?>'; msg.style.color = '#059669'; }
                        else           { msg.textContent = '✗ <?php esc_html_e( 'Error', 'ngo-query-manager' ); ?>'; msg.style.color = '#dc2626'; }
                        setTimeout(function(){ msg.textContent = ''; }, 2500);
                    })
                    .catch(function(){ msg.textContent = '✗'; msg.style.color = '#dc2626'; });
            });
        })();
        </script>
    </div>

    <!-- Filters -->
    <div class="nqm-fadmin-filters">
        <select id="nqm-fadmin-status-filter">
            <option value=""><?php esc_html_e( 'All Statuses', 'ngo-query-manager' ); ?></option>
            <option value="open"><?php esc_html_e( 'Open', 'ngo-query-manager' ); ?></option>
            <option value="claimed"><?php esc_html_e( 'Claimed', 'ngo-query-manager' ); ?></option>
            <option value="closed"><?php esc_html_e( 'Closed', 'ngo-query-manager' ); ?></option>
        </select>
        <input type="search" id="nqm-fadmin-search" placeholder="<?php esc_attr_e( 'Search ID, title or submitter…', 'ngo-query-manager' ); ?>">
        <button class="nqm-btn nqm-btn--secondary" id="nqm-fadmin-filter-btn">
            <?php esc_html_e( 'Filter', 'ngo-query-manager' ); ?>
        </button>
    </div>

    <!-- Stats strip -->
    <div class="nqm-fadmin-stats" id="nqm-fadmin-stats"></div>

    <!-- Notice -->
    <div class="nqm-notice" id="nqm-fadmin-notice" style="display:none"></div>

    <!-- Table -->
    <div id="nqm-fadmin-table-wrap">
        <p><?php esc_html_e( 'Loading…', 'ngo-query-manager' ); ?></p>
    </div>

    <!-- Detail drawer -->
    <div id="nqm-fadmin-drawer" class="nqm-fadmin-drawer" style="display:none">
        <div class="nqm-fadmin-drawer-inner">
            <button class="nqm-fadmin-close" id="nqm-fadmin-close-btn" aria-label="<?php esc_attr_e( 'Close', 'ngo-query-manager' ); ?>">✕</button>
            <div id="nqm-fadmin-detail-content"></div>
        </div>
    </div>
    <div id="nqm-fadmin-overlay" class="nqm-fadmin-overlay" style="display:none"></div>

    <!-- Assign modal -->
    <div id="nqm-fadmin-assign-modal" class="nqm-fadmin-modal" style="display:none">
        <div class="nqm-fadmin-modal-inner">
            <h3><?php esc_html_e( 'Assign Query', 'ngo-query-manager' ); ?></h3>
            <input type="hidden" id="nqm-fadmin-assign-qid">
            <select id="nqm-fadmin-assignee">
                <option value=""><?php esc_html_e( '— select user —', 'ngo-query-manager' ); ?></option>
                <?php
                $respondent_roles = NQM_Settings::get_respondent_roles();
                $respondents = get_users( [ 'role__in' => $respondent_roles, 'orderby' => 'display_name' ] );
                foreach ( $respondents as $u ) :
                ?>
                <option value="<?php echo (int) $u->ID; ?>">
                    <?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div class="nqm-fadmin-modal-actions">
                <button class="nqm-btn nqm-btn--primary" id="nqm-fadmin-assign-confirm">
                    <?php esc_html_e( 'Assign', 'ngo-query-manager' ); ?>
                </button>
                <button class="nqm-btn nqm-btn--secondary" id="nqm-fadmin-assign-cancel">
                    <?php esc_html_e( 'Cancel', 'ngo-query-manager' ); ?>
                </button>
            </div>
        </div>
    </div>

</div><!-- .nqm-fadmin-wrap -->
