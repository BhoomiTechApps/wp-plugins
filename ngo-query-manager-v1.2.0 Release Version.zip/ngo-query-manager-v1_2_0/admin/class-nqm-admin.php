<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Admin {

    public static function init() {
        add_action( 'admin_menu',            [ __CLASS__, 'add_menus'      ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue'        ] );
        add_action( 'admin_post_nqm_save_settings', [ __CLASS__, 'save_settings' ] );
    }

    /* ── Menus ───────────────────────────────────────────────── */
    public static function add_menus() {
        add_menu_page(
            __( 'NGO Queries', 'ngo-query-manager' ),
            __( 'NGO Queries', 'ngo-query-manager' ),
            'edit_posts',
            'nqm-queries',
            [ __CLASS__, 'page_queries' ],
            'dashicons-format-chat',
            30
        );
        add_submenu_page( 'nqm-queries', __( 'All Queries', 'ngo-query-manager' ), __( 'All Queries', 'ngo-query-manager' ), 'edit_posts',     'nqm-queries',  [ __CLASS__, 'page_queries'  ] );
        add_submenu_page( 'nqm-queries', __( 'Settings',    'ngo-query-manager' ), __( 'Settings',    'ngo-query-manager' ), 'manage_options', 'nqm-settings', [ __CLASS__, 'page_settings' ] );
        add_submenu_page( 'nqm-queries', __( 'Video Quota', 'ngo-query-manager' ), __( 'Video Quota', 'ngo-query-manager' ), 'manage_options', 'nqm-video',    [ __CLASS__, 'page_video'    ] );
    }

    /* ── Enqueue ─────────────────────────────────────────────── */
    public static function enqueue( $hook ) {
        // Valid hooks for our pages:
        // toplevel_page_nqm-queries
        // ngo-queries_page_nqm-settings
        // ngo-queries_page_nqm-video
        $our_pages = [
            'toplevel_page_nqm-queries',
            'ngo-queries_page_nqm-queries',
            'ngo-queries_page_nqm-settings',
            'ngo-queries_page_nqm-video',
        ];
        if ( ! in_array( $hook, $our_pages, true ) ) return;

        wp_enqueue_style(  'nqm-admin', NQM_PLUGIN_URL . 'assets/css/admin.css', [], NQM_VERSION );
        // Inject theme vars into admin backend too (affects any nqm-* classes used in admin views)
        wp_add_inline_style( 'nqm-admin', NQM_Settings::build_css_vars() );
        wp_enqueue_script( 'nqm-admin', NQM_PLUGIN_URL . 'assets/js/admin.js',  [ 'jquery' ], NQM_VERSION, true );
        wp_localize_script( 'nqm-admin', 'nqmAdmin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'nqm_nonce' ),
            'strings'  => [
                'select_user'    => __( 'Please select a user to assign.',                    'ngo-query-manager' ),
                'confirm_revoke' => __( 'Revoke this claim? The query will become open again.', 'ngo-query-manager' ),
            ],
        ] );
    }

    /* ── Queries list page ───────────────────────────────────── */
    public static function page_queries() {
        $status = sanitize_text_field( $_GET['nqm_status'] ?? '' );
        $paged  = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $view   = sanitize_text_field( $_GET['view'] ?? '' );

        if ( $view === 'detail' && ! empty( $_GET['qid'] ) ) {
            self::render_query_detail( (int) $_GET['qid'] );
            return;
        }

        $queries = NQM_Query::get_all( [ 'status' => $status, 'page' => $paged ] );
        $counts  = [
            'all'     => NQM_Query::count(),
            'open'    => NQM_Query::count( 'open' ),
            'claimed' => NQM_Query::count( 'claimed' ),
            'closed'  => NQM_Query::count( 'closed' ),
        ];
        include NQM_PLUGIN_DIR . 'admin/views/queries-list.php';
    }

    private static function render_query_detail( $qid ) {
        $query    = NQM_Query::get( $qid );
        $response = $query ? NQM_Response::get_by_query( $qid ) : null;
        $feedback = $query ? NQM_Response::get_feedback( $qid )  : null;

        $respondent_roles = NQM_Settings::get_respondent_roles();
        $respondents      = get_users( [ 'role__in' => $respondent_roles ] );

        include NQM_PLUGIN_DIR . 'admin/views/query-detail.php';
    }

    /* ── Settings page ───────────────────────────────────────── */
    public static function page_settings() {
        $all_roles = wp_roles()->get_names();
        include NQM_PLUGIN_DIR . 'admin/views/settings.php';
    }

    /* ── Video quota page ────────────────────────────────────── */
    public static function page_video() {
        $total     = NQM_Settings::video_global_allocation();
        $used      = NQM_Database::get_used_seconds();
        $available = NQM_Database::get_available_seconds();
        include NQM_PLUGIN_DIR . 'admin/views/video-quota.php';
    }

    /* ── Save settings ───────────────────────────────────────── */
    public static function save_settings() {
        check_admin_referer( 'nqm_save_settings' );
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );

        // Checkbox fields are absent from $_POST when unchecked, so default to 0 explicitly.
        foreach ( [ 'nqm_admin_email_notify', 'nqm_notify_response_attach', 'nqm_delete_data_on_uninstall' ] as $key ) {
            update_option( $key, isset( $_POST[ $key ] ) ? 1 : 0 );
        }

        $fields = [
            'nqm_from_email'              => 'sanitize_email',
            'nqm_from_name'               => 'sanitize_text_field',
            'nqm_video_max_duration'      => 'absint',
            'nqm_video_global_allocation' => 'absint',
            'nqm_respond_page_id'         => 'absint',
            'nqm_page_admin'              => 'absint',
            'nqm_font_size'               => 'sanitize_text_field',
        ];
        foreach ( $fields as $key => $cb ) {
            if ( isset( $_POST[ $key ] ) ) update_option( $key, $cb( $_POST[ $key ] ) );
        }

        // Colour picker: sanitize_hex_color returns '' on invalid value — keep current in that case
        if ( isset( $_POST['nqm_theme_color'] ) ) {
            $colour = sanitize_hex_color( wp_unslash( $_POST['nqm_theme_color'] ) );
            if ( $colour ) update_option( 'nqm_theme_color', $colour );
        }

        if ( isset( $_POST['nqm_query_sources'] ) ) {
            update_option( 'nqm_query_sources', NQM_Settings::sanitize_array( $_POST['nqm_query_sources'] ) );
        }
        if ( isset( $_POST['nqm_respondent_roles'] ) ) {
            update_option( 'nqm_respondent_roles', NQM_Settings::sanitize_array( $_POST['nqm_respondent_roles'] ) );
        }

        wp_redirect( admin_url( 'admin.php?page=nqm-settings&saved=1' ) );
        exit;
    }
}
