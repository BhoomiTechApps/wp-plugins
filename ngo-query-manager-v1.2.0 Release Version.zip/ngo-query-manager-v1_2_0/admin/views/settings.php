<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap nqm-admin">
    <h1><?php esc_html_e('NGO Query Manager – Settings','ngo-query-manager'); ?></h1>
    <?php if ( isset($_GET['saved']) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e('Settings saved.','ngo-query-manager'); ?></p></div><?php endif; ?>

    <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
        <?php wp_nonce_field('nqm_save_settings'); ?>
        <input type="hidden" name="action" value="nqm_save_settings">

        <h2><?php esc_html_e('Theme & Appearance','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_theme_color"><?php esc_html_e('Primary Colour','ngo-query-manager'); ?></label></th>
                <td>
                    <input type="color" id="nqm_theme_color" name="nqm_theme_color"
                           value="<?php echo esc_attr(get_option('nqm_theme_color','#798ea9')); ?>">
                    <button type="button" class="button" id="nqm-reset-color">
                        <?php esc_html_e('Reset to Default','ngo-query-manager'); ?>
                    </button>
                    <p class="description"><?php esc_html_e('Applies to nav bar, buttons, and accents on the frontend forms.','ngo-query-manager'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="nqm_font_size"><?php esc_html_e('Base Font Size','ngo-query-manager'); ?></label></th>
                <td>
                    <select id="nqm_font_size" name="nqm_font_size">
                        <?php
                        $sizes = ['0.65rem'=>'Extra Small (0.65 rem)','0.75rem'=>'Small (0.75 rem)','0.8rem'=>'Small-Medium (0.8 rem)','.85rem'=>'Normal / Default (.85 rem)','1rem'=>'Medium (1 rem)','1.1rem'=>'Large (1.1 rem)','1.2rem'=>'Extra Large (1.2 rem)'];
                        $cur   = get_option('nqm_font_size','.85rem');
                        foreach ($sizes as $v=>$l) :
                        ?><option value="<?php echo esc_attr($v); ?>" <?php selected($cur,$v); ?>><?php echo esc_html($l); ?></option><?php
                        endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e('Controls the base font size of all frontend query form text.','ngo-query-manager'); ?></p>
                </td>
            </tr>
            <tr>
                <th><?php esc_html_e('Live Preview','ngo-query-manager'); ?></th>
                <td>
                    <div id="nqm-theme-preview" style="border:1px solid #ddd;border-radius:6px;overflow:hidden;max-width:480px;">
                        <div id="nqm-preview-nav" style="display:flex;gap:0;border-bottom:2px solid #798ea9;background:#f8faf8;padding:0;">
                            <span style="padding:.45rem 1rem;font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;background:#798ea9;color:#fff;">SUBMIT</span>
                            <span style="padding:.45rem 1rem;font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#798ea9;">CHECK STATUS</span>
                            <span style="padding:.45rem 1rem;font-size:.78rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#798ea9;">LIST ALL</span>
                        </div>
                        <div style="padding:14px 16px;background:#fff;">
                            <p id="nqm-preview-text" style="margin:0 0 10px;font-size:1rem;">Sample body text at the selected size.</p>
                            <button id="nqm-preview-btn" style="background:##798ea9;color:#fff;border:none;border-radius:5px;padding:8px 18px;font-size:.9rem;font-weight:600;cursor:default;">Primary Button</button>
                        </div>
                    </div>
                    <p class="description" style="margin-top:6px"><?php esc_html_e('Updates instantly as you change the controls above. Save Settings to apply.','ngo-query-manager'); ?></p>
                </td>
            </tr>
        </table>
        <script>
        (function(){
            var colorPicker = document.getElementById('nqm_theme_color');
            var fontSelect  = document.getElementById('nqm_font_size');
            var resetBtn    = document.getElementById('nqm-reset-color');
            var previewNav  = document.getElementById('nqm-preview-nav');
            var previewBtn  = document.getElementById('nqm-preview-btn');
            var previewText = document.getElementById('nqm-preview-text');
            var navBorder   = previewNav ? previewNav.parentElement : null;

            function updatePreview() {
                var c = colorPicker.value;
                var fs = fontSelect.options[fontSelect.selectedIndex].value;
                if (previewNav) {
                    // active tab
                    previewNav.children[0].style.background = c;
                    previewNav.children[0].style.color = '#fff';
                    // inactive tabs
                    previewNav.children[1].style.color = c;
                    previewNav.children[2].style.color = c;
                    // nav border
                    previewNav.style.borderBottomColor = c;
                }
                if (previewBtn)  previewBtn.style.background = c;
                if (previewText) previewText.style.fontSize = fs;
            }

            if (colorPicker) colorPicker.addEventListener('input', updatePreview);
            if (fontSelect)  fontSelect.addEventListener('change', updatePreview);
            if (resetBtn)    resetBtn.addEventListener('click', function(){ colorPicker.value = '#798ea9'; updatePreview(); });

            // run once on load to sync with saved values
            updatePreview();
        })();
        </script>

        <h2><?php esc_html_e('Email Notifications','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Notify Admin on Submission','ngo-query-manager'); ?></th>
                <td><label><input type="checkbox" name="nqm_admin_email_notify" value="1" <?php checked(1, get_option('nqm_admin_email_notify',1)); ?>> <?php esc_html_e('Send email to site admin when a query is submitted','ngo-query-manager'); ?></label></td>
            </tr>
        <tr>
            <th><?php esc_html_e('Notify Submitter on Response','ngo-query-manager'); ?></th>
            <td><label><input type="checkbox" name="nqm_notify_response_attach" value="1" <?php checked(1, get_option('nqm_notify_response_attach',1)); ?>> <?php esc_html_e('Send email notification to submitter when a response is posted','ngo-query-manager'); ?></label></td>
        </tr>
        <tr>
            <th><?php esc_html_e('Response Attachments via Email','ngo-query-manager'); ?></th>
            <td>
                <p class="description"><?php esc_html_e('When submitter email notifications are enabled, any files attached to a response will be sent as email attachments. When notifications are disabled, files are uploaded to the Media Library and a download link is included in the response.','ngo-query-manager'); ?></p>
            </td>
        </tr>
            <tr>
                <th><label for="nqm_from_name"><?php esc_html_e('From Name','ngo-query-manager'); ?></label></th>
                <td><input type="text" id="nqm_from_name" name="nqm_from_name" class="regular-text" value="<?php echo esc_attr(get_option('nqm_from_name', get_bloginfo('name'))); ?>"></td>
            </tr>
            <tr>
                <th><label for="nqm_from_email"><?php esc_html_e('From Email','ngo-query-manager'); ?></label></th>
                <td><input type="email" id="nqm_from_email" name="nqm_from_email" class="regular-text" value="<?php echo esc_attr(get_option('nqm_from_email', get_option('admin_email'))); ?>"></td>
            </tr>
        </table>

        <h2><?php esc_html_e('Video Recording','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_video_max_duration"><?php esc_html_e('Max Recording Duration (seconds)','ngo-query-manager'); ?></label></th>
                <td><input type="number" id="nqm_video_max_duration" name="nqm_video_max_duration" min="10" max="600" value="<?php echo (int)get_option('nqm_video_max_duration',60); ?>">
                <p class="description"><?php esc_html_e('Default clip length limit per submission.','ngo-query-manager'); ?></p></td>
            </tr>
            <tr>
                <th><label for="nqm_video_global_allocation"><?php esc_html_e('Global Video Bank (seconds)','ngo-query-manager'); ?></label></th>
                <td><input type="number" id="nqm_video_global_allocation" name="nqm_video_global_allocation" min="60" value="<?php echo (int)get_option('nqm_video_global_allocation',3600); ?>">
                <p class="description"><?php printf( esc_html__('Total seconds available. Currently used: %d s, Available: %d s','ngo-query-manager'), NQM_Database::get_used_seconds(), NQM_Database::get_available_seconds() ); ?></p></td>
            </tr>
        </table>

        <h2><?php esc_html_e('Query Sources','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_query_sources"><?php esc_html_e('Sources (one per line)','ngo-query-manager'); ?></label></th>
                <td><textarea id="nqm_query_sources" name="nqm_query_sources" rows="6" class="large-text"><?php
                    echo esc_textarea( implode("\n", (array)get_option('nqm_query_sources',[])) );
                ?></textarea>
                <p class="description"><?php esc_html_e('Use underscore for spaces, e.g. project_partner','ngo-query-manager'); ?></p></td>
            </tr>
        </table>

        <h2><?php esc_html_e( 'Page Configuration', 'ngo-query-manager' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="nqm_respond_page_id"><?php esc_html_e( 'Respond Page', 'ngo-query-manager' ); ?></label></th>
                <td>
                    <?php
                    wp_dropdown_pages( [
                        'name'              => 'nqm_respond_page_id',
                        'id'                => 'nqm_respond_page_id',
                        'selected'          => (int) get_option( 'nqm_respond_page_id', 0 ),
                        'show_option_none'  => __( '— select a page —', 'ngo-query-manager' ),
                        'option_none_value' => '0',
                    ] );
                    ?>
                    <p class="description"><?php esc_html_e( 'The page containing the [nqm_dorespond] shortcode. Respondents are linked here from their query list.', 'ngo-query-manager' ); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="nqm_page_admin"><?php esc_html_e( 'Frontend Admin Page', 'ngo-query-manager' ); ?></label></th>
                <td>
                    <?php
                    wp_dropdown_pages( [
                        'name'              => 'nqm_page_admin',
                        'id'                => 'nqm_page_admin',
                        'selected'          => (int) get_option( 'nqm_page_admin', 0 ),
                        'show_option_none'  => __( '— select a page —', 'ngo-query-manager' ),
                        'option_none_value' => '0',
                    ] );
                    ?>
                    <p class="description"><?php esc_html_e( 'The page containing the [nqm_admin_panel] shortcode. Only visible to administrators.', 'ngo-query-manager' ); ?></p>
                </td>
            </tr>
        </table>

        <h2><?php esc_html_e('Respondent Roles','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Roles that may claim and respond to queries','ngo-query-manager'); ?></th>
                <td>
                <?php
                $saved_roles = (array) get_option('nqm_respondent_roles', []);
                // Administrator is always a respondent — show it first, locked.
                ?>
                <label style="display:block; margin-bottom:4px;">
                    <input type="checkbox" checked disabled>
                    <input type="hidden" name="nqm_respondent_roles[]" value="administrator">
                    <?php echo esc_html( translate_user_role( 'Administrator' ) ); ?>
                    <span style="color:#888; font-size:0.9em;"><?php esc_html_e('(always enabled)', 'ngo-query-manager'); ?></span>
                </label>
                <?php
                foreach ($all_roles as $slug => $name) :
                    if ($slug === 'administrator') continue;
                ?>
                <label style="display:block; margin-bottom:4px;">
                    <input type="checkbox" name="nqm_respondent_roles[]" value="<?php echo esc_attr($slug); ?>" <?php checked(in_array($slug,$saved_roles)); ?>>
                    <?php echo esc_html(translate_user_role($name)); ?>
                </label>
                <?php endforeach; ?>
                </td>
            </tr>
        </table>


        <h2><?php esc_html_e('Uninstall Options','ngo-query-manager'); ?></h2>
        <table class="form-table">
            <tr>
                <th><?php esc_html_e('Delete All Data on Uninstall','ngo-query-manager'); ?></th>
                <td>
                    <label>
                        <input type="checkbox" name="nqm_delete_data_on_uninstall" value="1" <?php checked(1, get_option('nqm_delete_data_on_uninstall',1)); ?>>
                        <?php esc_html_e('Remove all query data, tables, and settings when the plugin is deleted','ngo-query-manager'); ?>
                    </label>
                    <p class="description" style="color:#b32d2e;"><?php esc_html_e('Warning: if unchecked, your data will be preserved when the plugin is uninstalled, but it will not be automatically cleaned up.','ngo-query-manager'); ?></p>
                </td>
            </tr>
        </table>

        <?php submit_button( __('Save Settings','ngo-query-manager') ); ?>
    </form>
</div>
