<?php if ( ! defined( 'ABSPATH' ) ) exit;
$pct_used = $total > 0 ? round( ($used / $total) * 100, 1 ) : 0;
$color    = $pct_used > 80 ? '#dc3232' : ( $pct_used > 50 ? '#f0a500' : '#46b450' );
?>
<div class="wrap nqm-admin">
    <h1><?php esc_html_e('Video Recording Quota','ngo-query-manager'); ?></h1>

    <div class="nqm-card" style="max-width:500px;margin-top:20px;">
        <table class="form-table">
            <tr><th><?php esc_html_e('Global Bank','ngo-query-manager'); ?></th><td><?php echo esc_html(gmdate('H:i:s',$total)); ?> <em>(<?php echo (int)$total; ?> s)</em></td></tr>
            <tr><th><?php esc_html_e('Used','ngo-query-manager'); ?></th><td><?php echo esc_html(gmdate('H:i:s',$used)); ?> <em>(<?php echo (int)$used; ?> s)</em></td></tr>
            <tr><th><?php esc_html_e('Available','ngo-query-manager'); ?></th><td><?php echo esc_html(gmdate('H:i:s',$available)); ?> <em>(<?php echo (int)$available; ?> s)</em></td></tr>
        </table>

        <!-- Progress bar -->
        <div style="background:#eee;border-radius:4px;height:20px;overflow:hidden;margin-top:12px;">
            <div style="width:<?php echo $pct_used; ?>%;background:<?php echo $color; ?>;height:100%;transition:width .4s;"></div>
        </div>
        <p style="text-align:center;color:<?php echo $color; ?>;font-weight:600;"><?php echo $pct_used; ?>% <?php esc_html_e('used','ngo-query-manager'); ?></p>

        <p><a href="<?php echo admin_url('admin.php?page=nqm-settings'); ?>" class="button"><?php esc_html_e('Manage Allocation','ngo-query-manager'); ?></a></p>
    </div>
</div>
