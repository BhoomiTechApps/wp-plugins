<?php if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! $query ) { echo '<div class="wrap"><p>' . esc_html__( 'Query not found.', 'ngo-query-manager' ) . '</p></div>'; return; }
?>
<div class="wrap nqm-admin nqm-detail">
    <h1><?php printf( esc_html__( 'Query: %s', 'ngo-query-manager' ), esc_html( $query->query_uid ) ); ?></h1>
    <a href="<?php echo esc_url( admin_url( 'admin.php?page=nqm-queries' ) ); ?>" class="button">&larr; <?php esc_html_e( 'Back to List', 'ngo-query-manager' ); ?></a>
    <hr>

    <div class="nqm-detail-grid">
        <!-- Meta -->
        <div class="nqm-card">
            <h3><?php esc_html_e( 'Submission Details', 'ngo-query-manager' ); ?></h3>
            <table class="form-table">
                <tr><th><?php esc_html_e( 'Query ID',  'ngo-query-manager' ); ?></th><td><code><?php echo esc_html( $query->query_uid ); ?></code></td></tr>
                <tr><th><?php esc_html_e( 'Title',     'ngo-query-manager' ); ?></th><td><?php echo esc_html( $query->title ); ?></td></tr>
                <tr><th><?php esc_html_e( 'Status',    'ngo-query-manager' ); ?></th><td><span class="nqm-status nqm-status--<?php echo esc_attr( $query->status ); ?>"><?php echo esc_html( ucfirst( $query->status ) ); ?></span></td></tr>
                <tr><th><?php esc_html_e( 'Source',    'ngo-query-manager' ); ?></th><td><?php echo esc_html( ucwords( str_replace( '_', ' ', $query->query_source ) ) ); ?></td></tr>
                <tr><th><?php esc_html_e( 'Type',      'ngo-query-manager' ); ?></th><td><?php echo esc_html( ucfirst( $query->message_type ) ); ?></td></tr>
                <tr><th><?php esc_html_e( 'Submitted', 'ngo-query-manager' ); ?></th><td><?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $query->created_at ) ) ); ?></td></tr>
            </table>
        </div>

        <!-- Submitter -->
        <div class="nqm-card">
            <h3><?php esc_html_e( 'Submitter', 'ngo-query-manager' ); ?></h3>
            <table class="form-table">
                <tr><th><?php esc_html_e( 'Name',  'ngo-query-manager' ); ?></th><td><?php echo esc_html( $query->submitter_name ); ?></td></tr>
                <tr><th><?php esc_html_e( 'Email', 'ngo-query-manager' ); ?></th><td><a href="mailto:<?php echo esc_attr( $query->submitter_email ); ?>"><?php echo esc_html( $query->submitter_email ); ?></a></td></tr>
                <?php if ( $query->submitter_org ) : ?>
                <tr><th><?php esc_html_e( 'Organisation', 'ngo-query-manager' ); ?></th><td><?php echo esc_html( $query->submitter_org ); ?></td></tr>
                <?php endif; ?>
                <?php if ( $query->submitter_phone ) : ?>
                <tr><th><?php esc_html_e( 'Phone', 'ngo-query-manager' ); ?></th><td><?php echo esc_html( $query->submitter_phone ); ?></td></tr>
                <?php endif; ?>
            </table>
        </div>
    </div>

    <!-- Message body -->
    <div class="nqm-card">
        <h3><?php esc_html_e( 'Message', 'ngo-query-manager' ); ?></h3>
        <?php if ( in_array( $query->message_type, [ 'video', 'hybrid' ] ) && $query->video_attach_id ) : ?>
            <div class="nqm-video-wrap">
                <?php echo wp_video_shortcode( [ 'src' => wp_get_attachment_url( $query->video_attach_id ) ] ); ?>
            </div>
        <?php endif; ?>
        <?php if ( $query->message_body ) : ?>
            <div class="nqm-message-body"><?php echo nqm_render_rich( $query->message_body ); ?></div>
        <?php endif; ?>
    </div>

    <!-- Assignment -->
    <?php if ( $query->status !== 'closed' ) : ?>
    <div class="nqm-card">
        <h3><?php esc_html_e( 'Assignment', 'ngo-query-manager' ); ?></h3>

        <?php if ( $query->status === 'claimed' ) :
            $claimer = get_userdata( $query->claimed_by ); ?>
            <p><?php printf(
                esc_html__( 'Claimed by %s on %s', 'ngo-query-manager' ),
                '<strong>' . esc_html( $claimer ? $claimer->display_name : '#' . $query->claimed_by ) . '</strong>',
                esc_html( date_i18n( get_option( 'date_format' ), strtotime( $query->claimed_at ) ) )
            ); ?></p>
            <button class="button nqm-revoke-btn" data-id="<?php echo (int) $query->id; ?>">
                <?php esc_html_e( 'Revoke Claim', 'ngo-query-manager' ); ?>
            </button>
            <hr>
        <?php endif; ?>

        <?php if ( current_user_can( 'manage_options' ) || current_user_can( 'edit_others_posts' ) ) : ?>
        <h4><?php esc_html_e( 'Assign To', 'ngo-query-manager' ); ?></h4>
        <p>
            <select id="nqm-assignee" style="min-width:220px">
                <option value=""><?php esc_html_e( '— select user —', 'ngo-query-manager' ); ?></option>
                <?php foreach ( $respondents as $u ) : ?>
                <option value="<?php echo (int) $u->ID; ?>"><?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?></option>
                <?php endforeach; ?>
            </select>
            <button class="button button-primary nqm-assign-btn" data-id="<?php echo (int) $query->id; ?>">
                <?php esc_html_e( 'Assign', 'ngo-query-manager' ); ?>
            </button>
        </p>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Response -->
    <?php if ( $response ) : ?>
    <div class="nqm-card nqm-response-card">
        <h3><?php esc_html_e( 'Response', 'ngo-query-manager' ); ?></h3>
        <?php $responder = get_userdata( $response->responder_id ); ?>
        <p>
            <strong><?php esc_html_e( 'By:', 'ngo-query-manager' ); ?></strong>
            <?php echo esc_html( $responder ? $responder->display_name : __( 'Unknown', 'ngo-query-manager' ) ); ?>
            &nbsp;|&nbsp;
            <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $response->created_at ) ) ); ?>
        </p>
        <div class="nqm-message-body"><?php echo nqm_render_rich( $response->message_body ); ?></div>
        <?php if ( $response->attachments ) :
            $att_ids = json_decode( $response->attachments, true );
            if ( $att_ids ) : ?>
            <h4><?php esc_html_e( 'Attachments', 'ngo-query-manager' ); ?></h4>
            <ul class="nqm-attachments">
                <?php foreach ( $att_ids as $aid ) :
                    $url   = wp_get_attachment_url( $aid );
                    $title = get_the_title( $aid ); ?>
                <li><a href="<?php echo esc_url( $url ); ?>" target="_blank"><?php echo esc_html( $title ?: basename( $url ) ); ?></a></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Feedback -->
    <?php if ( $feedback ) : ?>
    <div class="nqm-card">
        <h3><?php esc_html_e( 'Initiator Feedback', 'ngo-query-manager' ); ?></h3>
        <?php if ( $feedback->rating ) : ?>
        <p><?php esc_html_e( 'Rating:', 'ngo-query-manager' ); ?>
           <?php echo esc_html( str_repeat( '★', (int) $feedback->rating ) . str_repeat( '☆', 5 - (int) $feedback->rating ) ); ?></p>
        <?php endif; ?>
        <?php if ( $feedback->liked ) : ?><p>👍 <?php esc_html_e( 'Liked', 'ngo-query-manager' ); ?></p><?php endif; ?>
        <?php if ( $feedback->comment ) : ?><blockquote><?php echo esc_html( $feedback->comment ); ?></blockquote><?php endif; ?>
    </div>
    <?php endif; ?>

</div>
