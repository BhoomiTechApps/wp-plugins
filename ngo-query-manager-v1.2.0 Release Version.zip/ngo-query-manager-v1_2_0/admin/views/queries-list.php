<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap nqm-admin">
    <h1 class="wp-heading-inline"><?php esc_html_e( 'NGO Queries', 'ngo-query-manager' ); ?></h1>
    <hr class="wp-header-end">

    <!-- Status tabs -->
    <ul class="subsubsub">
        <?php foreach ( [ '' => __('All','ngo-query-manager'), 'open' => __('Open','ngo-query-manager'), 'claimed' => __('Claimed','ngo-query-manager'), 'closed' => __('Closed','ngo-query-manager') ] as $s => $label ) :
            $url   = admin_url( 'admin.php?page=nqm-queries' . ( $s ? '&nqm_status=' . $s : '' ) );
            $class = ( $status === $s ) ? 'current' : '';
            $key   = $s ?: 'all';
        ?>
        <li><a href="<?php echo esc_url($url); ?>" class="<?php echo $class; ?>"><?php echo esc_html($label); ?> <span class="count">(<?php echo (int)$counts[$key]; ?>)</span></a> | </li>
        <?php endforeach; ?>
    </ul>

    <table class="wp-list-table widefat fixed striped nqm-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'ID',          'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Title',       'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Submitter',   'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Source',      'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Type',        'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Status',      'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Claimed By',  'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Date',        'ngo-query-manager' ); ?></th>
                <th><?php esc_html_e( 'Actions',     'ngo-query-manager' ); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php if ( empty( $queries ) ) : ?>
            <tr><td colspan="9"><?php esc_html_e( 'No queries found.', 'ngo-query-manager' ); ?></td></tr>
        <?php else : ?>
            <?php foreach ( $queries as $q ) :
                $claimer = $q->claimed_by ? get_userdata( $q->claimed_by ) : null;
                $detail_url = admin_url( 'admin.php?page=nqm-queries&view=detail&qid=' . $q->id );
            ?>
            <tr>
                <td><code><?php echo esc_html( $q->query_uid ); ?></code></td>
                <td><strong><a href="<?php echo esc_url($detail_url); ?>"><?php echo esc_html( $q->title ); ?></a></strong></td>
                <td><?php echo esc_html( $q->submitter_name ); ?><br><small><?php echo esc_html( $q->submitter_email ); ?></small></td>
                <td><?php echo esc_html( ucwords( str_replace('_',' ', $q->query_source ) ) ); ?></td>
                <td><span class="nqm-badge nqm-badge--<?php echo esc_attr($q->message_type); ?>"><?php echo esc_html( ucfirst($q->message_type) ); ?></span></td>
                <td><span class="nqm-status nqm-status--<?php echo esc_attr($q->status); ?>"><?php echo esc_html( ucfirst($q->status) ); ?></span></td>
                <td><?php echo $claimer ? esc_html( $claimer->display_name ) : '—'; ?></td>
                <td><?php echo esc_html( date_i18n( 'd M Y', strtotime( $q->created_at ) ) ); ?></td>
                <td>
                    <a href="<?php echo esc_url($detail_url); ?>" class="button button-small"><?php esc_html_e('View','ngo-query-manager'); ?></a>
                    <?php if ( $q->status === 'claimed' ) : ?>
                    <button class="button button-small nqm-revoke-btn" data-id="<?php echo (int)$q->id; ?>"><?php esc_html_e('Revoke Claim','ngo-query-manager'); ?></button>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
