<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Public {

    public static function init() {
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue' ] );

        add_shortcode( 'nqm_dosubmit',  [ __CLASS__, 'shortcode_submit'     ] );
        add_shortcode( 'nqm_qlist',     [ __CLASS__, 'shortcode_my_queries' ] );
        add_shortcode( 'nqm_dorespond', [ __CLASS__, 'shortcode_respond'    ] );
        add_shortcode( 'nqm_qsearch',   [ __CLASS__, 'shortcode_status'     ] );
    }

    /* ── Enqueue ─────────────────────────────────────────────── */
    public static function enqueue() {
        wp_enqueue_style( 'nqm-public', NQM_PLUGIN_URL . 'assets/css/public.css', [], NQM_VERSION );

        // Inject theme CSS variables as inline style appended directly after the stylesheet.
        // wp_add_inline_style guarantees it comes after the <link> tag, so it correctly
        // overrides the static fallback :root values in public.css.
        wp_add_inline_style( 'nqm-public', NQM_Settings::build_css_vars() );

        // Enqueue WordPress's built-in TinyMCE so the rich-text editor works on the front end.
        wp_enqueue_editor();
        wp_enqueue_media();  // needed for the media-embed button inside TinyMCE

        wp_enqueue_script( 'nqm-public', NQM_PLUGIN_URL . 'assets/js/public.js',  [ 'jquery' ], NQM_VERSION, true );

        // Enqueue frontend admin script only for administrators
        if ( current_user_can( 'manage_options' ) ) {
            wp_enqueue_script( 'nqm-frontend-admin', NQM_PLUGIN_URL . 'assets/js/frontend-admin.js', [ 'jquery' ], NQM_VERSION, true );
            wp_localize_script( 'nqm-frontend-admin', 'nqmFadmin', [
                'ajax_url' => admin_url( 'admin-ajax.php' ),
                'nonce'    => wp_create_nonce( 'nqm_nonce' ),
                'strings'  => [
                    'loading'        => __( 'Loading…',                                    'ngo-query-manager' ),
                    'no_results'     => __( 'No queries found.',                            'ngo-query-manager' ),
                    'view'           => __( 'View',                                         'ngo-query-manager' ),
                    'assign'         => __( 'Assign',                                       'ngo-query-manager' ),
                    'revoke'         => __( 'Revoke Claim',                                 'ngo-query-manager' ),
                    'reopen'         => __( 'Reopen',                                       'ngo-query-manager' ),
                    'del'            => __( 'Delete',                                       'ngo-query-manager' ),
                    'total'          => __( 'queries',                                      'ngo-query-manager' ),
                    'select_user'    => __( 'Please select a user to assign.',              'ngo-query-manager' ),
                    'confirm_delete' => __( 'Permanently delete this query? This cannot be undone.', 'ngo-query-manager' ),
                    'confirm_reopen' => __( 'Reopen this query? The existing response will be deleted.', 'ngo-query-manager' ),
                    'confirm_revoke' => __( 'Revoke this claim? The query will become open again.', 'ngo-query-manager' ),
                ],
            ] );
        }

        wp_localize_script( 'nqm-public', 'nqmData', [
            'ajax_url'               => admin_url( 'admin-ajax.php' ),
            'nonce'                  => wp_create_nonce( 'nqm_nonce' ),
            'max_duration'           => NQM_Settings::video_max_duration(),
            'available_secs'         => NQM_Database::get_available_seconds(),
            'video_global_allocation'=> NQM_Settings::video_global_allocation(),
            'strings'                => [
                'recording'       => __( 'Recording…',                                          'ngo-query-manager' ),
                'stop'            => __( 'Stop Recording',                                       'ngo-query-manager' ),
                'start'           => __( 'Start Recording',                                      'ngo-query-manager' ),
                'uploading'       => __( 'Uploading video…',                                     'ngo-query-manager' ),
                'quota_warn'      => __( 'Only %d seconds available in the video bank.',         'ngo-query-manager' ),
                'quota_none'      => __( 'No video time available. Choose text or hybrid.',      'ngo-query-manager' ),
                'success'         => __( 'Query submitted! Your reference ID is: ',             'ngo-query-manager' ),
                'error'           => __( 'An error occurred. Please try again.',                 'ngo-query-manager' ),
                'checking'        => __( 'Checking…',                                            'ngo-query-manager' ),
                'label_id'        => __( 'ID:',                                                  'ngo-query-manager' ),
                'label_title'     => __( 'Title:',                                               'ngo-query-manager' ),
                'label_status'    => __( 'Status:',                                              'ngo-query-manager' ),
                'label_response'  => __( 'Response',                                             'ngo-query-manager' ),
                'label_your_comment' => __( 'Your Comment:',                                     'ngo-query-manager' ),
                'feedback_saved'  => __( 'Feedback saved',                                       'ngo-query-manager' ),
                'confirm_revoke'  => __( 'Revoke claim? The query will return to Open.',         'ngo-query-manager' ),
            ],
        ] );
    }

    /* ── [nqm_dosubmit] ──────────────────────────────────────── */
    public static function shortcode_submit( $atts ) {
        $atts    = shortcode_atts( [ 'title' => '' ], $atts );
        $sources = NQM_Settings::get_query_sources();
        ob_start();
        include NQM_PLUGIN_DIR . 'templates/submit-form.php';
        return ob_get_clean();
    }

    /* ── [nqm_qlist] ─────────────────────────────────────────── */
    public static function shortcode_my_queries( $atts ) {
        if ( ! is_user_logged_in() ) {
            ob_start();
            include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
            echo '<p>' . esc_html__( 'Please log in to view your queries.', 'ngo-query-manager' ) . '</p>';
            return ob_get_clean();
        }

        global $wpdb;
        $uid = get_current_user_id();

        $my_submitted = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_queries WHERE submitter_user_id = %d ORDER BY created_at DESC", $uid
        ) );
        $my_claimed = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}nqm_queries WHERE claimed_by = %d ORDER BY created_at DESC", $uid
        ) );

        ob_start();
        include NQM_PLUGIN_DIR . 'templates/my-queries.php';
        return ob_get_clean();
    }

    /* ── [nqm_dorespond] ─────────────────────────────────────── */
    public static function shortcode_respond( $atts ) {
        if ( ! is_user_logged_in() ) {
            ob_start();
            include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
            echo '<p>' . esc_html__( 'Please log in to respond to queries.', 'ngo-query-manager' ) . '</p>';
            return ob_get_clean();
        }

        $atts     = shortcode_atts( [ 'query_id' => 0 ], $atts );
        $query_id = ! empty( $_GET['qid'] ) ? (int) $_GET['qid'] : (int) $atts['query_id'];
        $query    = $query_id ? NQM_Query::get( $query_id ) : null;
        $response = $query   ? NQM_Response::get_by_query( $query->id ) : null;

        ob_start();
        include NQM_PLUGIN_DIR . 'templates/respond-form.php';
        return ob_get_clean();
    }

    /* ── [nqm_qsearch] ───────────────────────────────────────── */
    public static function shortcode_status( $atts ) {
        $uid   = isset( $_GET['uid'] ) ? sanitize_text_field( wp_unslash( $_GET['uid'] ) ) : '';
        $query = $uid ? NQM_Query::get( $uid ) : null;

        ob_start();
        include NQM_PLUGIN_DIR . 'templates/query-track.php';
        return ob_get_clean();
    }
}
