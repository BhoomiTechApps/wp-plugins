/* ── NGO Query Manager — Admin JS ───────────────────────────── */
(function ($) {
    'use strict';

    $(function () {

        /* ── Assign query to a user ──────────────────────────── */
        $(document).on('click', '.nqm-assign-btn', function () {
            var uid = $('#nqm-assignee').val();
            if (!uid) {
                alert(nqmAdmin.strings.select_user);
                return;
            }
            var qid = $(this).data('id');
            $.post(nqmAdmin.ajax_url, {
                action:      'nqm_assign_query',
                nonce:       nqmAdmin.nonce,
                query_id:    qid,
                assignee_id: uid,
            }, function (r) {
                if (r.success) {
                    location.reload();
                } else {
                    alert(r.data.message);
                }
            });
        });

        /* ── Revoke claim (admin detail page) ────────────────── */
        $(document).on('click', '.nqm-revoke-btn', function () {
            if (!confirm(nqmAdmin.strings.confirm_revoke)) return;
            var qid = $(this).data('id');
            $.post(nqmAdmin.ajax_url, {
                action:   'nqm_revoke_claim',
                nonce:    nqmAdmin.nonce,
                query_id: qid,
            }, function (r) {
                if (r.success) {
                    location.reload();
                } else {
                    alert(r.data.message);
                }
            });
        });

    });

}(jQuery));
