/**
 * NQM Frontend Admin Panel
 * Handles all interactions on the [nqm_admin_panel] shortcode page.
 */
(function ($) {
    'use strict';

    var FADMIN = {

        currentPage:   1,
        currentStatus: '',
        currentSearch: '',

        /* ── Init ────────────────────────────────────────────── */
        init: function () {
            if ( ! $('#nqm-fadmin-wrap').length ) return;
            this.bindEvents();
            this.load();
        },

        /* ── Event bindings ──────────────────────────────────── */
        bindEvents: function () {
            var self = this;

            // Filter button
            $(document).on('click', '#nqm-fadmin-filter-btn', function () {
                self.currentStatus = $('#nqm-fadmin-status-filter').val();
                self.currentSearch = $('#nqm-fadmin-search').val().trim();
                self.currentPage   = 1;
                self.load();
            });

            // Search on Enter
            $(document).on('keydown', '#nqm-fadmin-search', function (e) {
                if (e.key === 'Enter') $('#nqm-fadmin-filter-btn').trigger('click');
            });

            // Quick status filter from stats strip
            $(document).on('click', '.nqm-fadmin-stat-btn', function () {
                self.currentStatus = $(this).data('status');
                self.currentSearch = '';
                self.currentPage   = 1;
                $('#nqm-fadmin-status-filter').val(self.currentStatus);
                $('#nqm-fadmin-search').val('');
                self.load();
            });

            // Pagination
            $(document).on('click', '.nqm-fadmin-page-btn', function () {
                self.currentPage = parseInt($(this).data('page'), 10);
                self.load();
            });

            // View detail
            $(document).on('click', '.nqm-fadmin-view-btn', function () {
                self.openDetail($(this).data('id'));
            });

            // Close drawer
            $(document).on('click', '#nqm-fadmin-close-btn, #nqm-fadmin-overlay', function () {
                self.closeDetail();
            });

            // Delete
            $(document).on('click', '.nqm-fadmin-delete-btn', function () {
                var id = $(this).data('id');
                if (!confirm(nqmFadmin.strings.confirm_delete)) return;
                self.post('nqm_fadmin_delete_query', { query_id: id }, function (r) {
                    self.notice(r.data.message, 'success');
                    self.closeDetail();
                    self.load();
                });
            });

            // Reopen
            $(document).on('click', '.nqm-fadmin-reopen-btn', function () {
                var id = $(this).data('id');
                if (!confirm(nqmFadmin.strings.confirm_reopen)) return;
                self.post('nqm_fadmin_reopen_query', { query_id: id }, function (r) {
                    self.notice(r.data.message, 'success');
                    self.closeDetail();
                    self.load();
                });
            });

            // Revoke claim (table row)
            $(document).on('click', '.nqm-fadmin-revoke-btn', function () {
                var id = $(this).data('id');
                if (!confirm(nqmFadmin.strings.confirm_revoke)) return;
                self.post('nqm_fadmin_revoke_claim', { query_id: id }, function (r) {
                    self.notice(r.data.message, 'success');
                    self.closeDetail();
                    self.load();
                });
            });

            // Assign — open modal
            $(document).on('click', '.nqm-fadmin-assign-open-btn', function () {
                $('#nqm-fadmin-assign-qid').val($(this).data('id'));
                $('#nqm-fadmin-assign-modal').show();
            });
            $(document).on('click', '#nqm-fadmin-assign-cancel', function () {
                $('#nqm-fadmin-assign-modal').hide();
            });
            $(document).on('click', '#nqm-fadmin-assign-confirm', function () {
                var qid      = $('#nqm-fadmin-assign-qid').val();
                var assignee = $('#nqm-fadmin-assignee').val();
                if (!assignee) { alert(nqmFadmin.strings.select_user); return; }
                self.post('nqm_fadmin_assign_query', { query_id: qid, assignee_id: assignee }, function (r) {
                    $('#nqm-fadmin-assign-modal').hide();
                    self.notice(r.data.message, 'success');
                    self.load();
                });
            });
        },

        /* ── Load table ──────────────────────────────────────── */
        load: function () {
            var self = this;
            $('#nqm-fadmin-table-wrap').html('<p>' + nqmFadmin.strings.loading + '</p>');
            self.post('nqm_fadmin_list_queries', {
                status: self.currentStatus,
                search: self.currentSearch,
                page:   self.currentPage,
            }, function (r) {
                self.renderStats(r.data.counts);
                self.renderTable(r.data.queries, r.data.total, r.data.page, r.data.per_page);
            });
        },

        /* ── Render stats strip ──────────────────────────────── */
        renderStats: function (counts) {
            var labels = { all: 'All', open: 'Open', claimed: 'Claimed', closed: 'Closed' };
            var html   = '';
            $.each(labels, function (key, label) {
                html += '<button class="nqm-fadmin-stat-btn" data-status="' + (key === 'all' ? '' : key) + '">'
                      + label + ' <span class="nqm-fadmin-count">' + (counts[key] || 0) + '</span></button>';
            });
            $('#nqm-fadmin-stats').html(html);
        },

        /* ── Render table ────────────────────────────────────── */
        renderTable: function (queries, total, page, perPage) {
            if (!queries.length) {
                $('#nqm-fadmin-table-wrap').html('<p>' + nqmFadmin.strings.no_results + '</p>');
                return;
            }

            var html = '<table class="nqm-table nqm-fadmin-table">'
                     + '<thead><tr>'
                     + '<th>ID</th><th>Title</th><th>Submitter</th>'
                     + '<th>Source</th><th>Type</th><th>Status</th><th>Claimed By</th><th>Date</th><th>Actions</th>'
                     + '</tr></thead><tbody>';

            $.each(queries, function (i, q) {
                html += '<tr>'
                      + '<td><code>' + q.query_uid + '</code></td>'
                      + '<td>' + self._esc(q.title) + '</td>'
                      + '<td>' + self._esc(q.submitter_name) + '<br><small>' + self._esc(q.submitter_email) + '</small></td>'
                      + '<td>' + self._esc(q.query_source) + '</td>'
                      + '<td><span class="nqm-badge nqm-badge--' + q.message_type + '">' + q.message_type + '</span></td>'
                      + '<td><span class="nqm-status nqm-status--' + q.status + '">' + q.status.charAt(0).toUpperCase() + q.status.slice(1) + '</span></td>'
                      + '<td>' + (q.claimed_by_name ? self._esc(q.claimed_by_name) : '—') + '</td>'
                      + '<td>' + q.created_at + '</td>'
                      + '<td class="nqm-fadmin-actions">'
                      + '<button class="nqm-btn nqm-btn--small nqm-fadmin-view-btn" data-id="' + q.id + '">' + nqmFadmin.strings.view + '</button>'
                      + '<button class="nqm-btn nqm-btn--small nqm-fadmin-assign-open-btn" data-id="' + q.id + '">' + nqmFadmin.strings.assign + '</button>'
                      + ( q.status === 'claimed' ? '<button class="nqm-btn nqm-btn--small nqm-btn--warn nqm-fadmin-revoke-btn" data-id="' + q.id + '">' + nqmFadmin.strings.revoke + '</button>' : '' )
                      + '<button class="nqm-btn nqm-btn--small nqm-btn--danger nqm-fadmin-delete-btn" data-id="' + q.id + '">' + nqmFadmin.strings.del + '</button>'
                      + '</td>'
                      + '</tr>';
            });
            html += '</tbody></table>';

            // Pagination
            var totalPages = Math.ceil(total / perPage);
            if (totalPages > 1) {
                html += '<div class="nqm-fadmin-pagination">';
                for (var p = 1; p <= totalPages; p++) {
                    var active = (p === page) ? ' nqm-fadmin-page-current' : '';
                    html += '<button class="nqm-btn nqm-btn--small nqm-fadmin-page-btn' + active + '" data-page="' + p + '">' + p + '</button>';
                }
                html += '<span class="nqm-fadmin-total">' + total + ' ' + nqmFadmin.strings.total + '</span></div>';
            }

            $('#nqm-fadmin-table-wrap').html(html);
        },

        /* ── Open detail drawer ──────────────────────────────── */
        openDetail: function (id) {
            var self = this;
            $('#nqm-fadmin-detail-content').html('<p>' + nqmFadmin.strings.loading + '</p>');
            $('#nqm-fadmin-drawer, #nqm-fadmin-overlay').show();
            $('body').addClass('nqm-drawer-open');

            self.post('nqm_fadmin_get_query', { query_id: id }, function (r) {
                var q    = r.data.query;
                var resp = r.data.response;
                var fb   = r.data.feedback;
                var respondents = r.data.respondents;

                var html = '<h3>' + self._esc(q.query_uid) + ' — ' + self._esc(q.title) + '</h3>';
                html += '<table class="nqm-detail-meta">'
                      + '<tr><th>Status</th><td><span class="nqm-status nqm-status--' + q.status + '">' + q.status.charAt(0).toUpperCase() + q.status.slice(1) + '</span></td></tr>'
                      + '<tr><th>Submitter</th><td>' + self._esc(q.submitter_name) + ' &lt;' + self._esc(q.submitter_email) + '&gt;</td></tr>'
                      + ( q.submitter_org  ? '<tr><th>Organisation</th><td>' + self._esc(q.submitter_org)  + '</td></tr>' : '' )
                      + ( q.submitter_phone ? '<tr><th>Phone</th><td>' + self._esc(q.submitter_phone) + '</td></tr>' : '' )
                      + '<tr><th>Source</th><td>' + self._esc(q.query_source || '') + '</td></tr>'
                      + '<tr><th>Type</th><td>' + q.message_type + '</td></tr>'
                      + '<tr><th>Submitted</th><td>' + q.created_at_fmt + '</td></tr>'
                      + ( q.claimed_by_name ? '<tr><th>Claimed By</th><td>' + self._esc(q.claimed_by_name) + '</td></tr>' : '' )
                      + '</table>';

                // Query media / body
                if (q.video_url) {
                    html += '<div class="nqm-video-wrap"><video src="' + q.video_url + '" controls style="max-width:100%"></video></div>';
                }
                if (q.message_body) {
                    html += '<div class="nqm-message-body">' + q.message_body + '</div>';
                }

                // Response
                if (resp) {
                    html += '<hr><h4>Response <small>by ' + self._esc(resp.responder_name) + ' on ' + resp.created_at_fmt + '</small></h4>';
                    html += '<div class="nqm-message-body">' + resp.message_body + '</div>';
                    if (resp.attachments && resp.attachments.length) {
                        html += '<ul class="nqm-attachments">';
                        $.each(resp.attachments, function (i, a) {
                            html += '<li><a href="' + a.url + '" target="_blank">' + self._esc(a.name) + '</a></li>';
                        });
                        html += '</ul>';
                    }
                }

                // Feedback
                if (fb) {
                    html += '<hr><h4>Initiator Feedback</h4>';
                    if (fb.rating) html += '<p>' + '★'.repeat(fb.rating) + '☆'.repeat(5 - fb.rating) + '</p>';
                    if (fb.liked)  html += '<p>👍 Liked</p>';
                    if (fb.comment) html += '<blockquote>' + self._esc(fb.comment) + '</blockquote>';
                }

                // Admin action buttons
                html += '<hr><div class="nqm-fadmin-drawer-actions">';

                // Assign dropdown
                html += '<div class="nqm-fadmin-inline-assign">';
                html += '<select id="nqm-fadmin-drawer-assignee">';
                html += '<option value="">' + nqmFadmin.strings.select_user + '</option>';
                $.each(respondents, function (i, u) {
                    html += '<option value="' + u.id + '">' + self._esc(u.label) + '</option>';
                });
                html += '</select>';
                html += '<button class="nqm-btn nqm-btn--primary nqm-btn--small" id="nqm-fadmin-drawer-assign-btn" data-id="' + q.id + '">' + nqmFadmin.strings.assign + '</button>';
                html += '</div>';

                if (q.status === 'claimed') {
                    html += '<button class="nqm-btn nqm-btn--small nqm-btn--warn nqm-fadmin-revoke-btn" data-id="' + q.id + '">' + nqmFadmin.strings.revoke + '</button>';
                }
                if (q.status === 'closed') {
                    html += '<button class="nqm-btn nqm-btn--small nqm-fadmin-reopen-btn" data-id="' + q.id + '">' + nqmFadmin.strings.reopen + '</button>';
                }
                html += '<button class="nqm-btn nqm-btn--small nqm-btn--danger nqm-fadmin-delete-btn" data-id="' + q.id + '">' + nqmFadmin.strings.del + '</button>';
                html += '</div>';

                $('#nqm-fadmin-detail-content').html(html);

                // Inline assign from drawer
                $(document).off('click.drawer').on('click.drawer', '#nqm-fadmin-drawer-assign-btn', function () {
                    var qid      = $(this).data('id');
                    var assignee = $('#nqm-fadmin-drawer-assignee').val();
                    if (!assignee) { alert(nqmFadmin.strings.select_user); return; }
                    self.post('nqm_fadmin_assign_query', { query_id: qid, assignee_id: assignee }, function (r) {
                        self.notice(r.data.message, 'success');
                        self.openDetail(qid); // refresh drawer
                        self.load();
                    });
                });
            });
        },

        /* ── Close drawer ────────────────────────────────────── */
        closeDetail: function () {
            $('#nqm-fadmin-drawer, #nqm-fadmin-overlay').hide();
            $('body').removeClass('nqm-drawer-open');
        },

        /* ── Helpers ─────────────────────────────────────────── */
        post: function (action, data, success) {
            var payload = $.extend({ action: action, nonce: nqmFadmin.nonce }, data);
            $.post(nqmFadmin.ajax_url, payload, function (r) {
                if (!r.success) {
                    FADMIN.notice(r.data.message, 'error');
                } else {
                    success(r);
                }
            }).fail(function () {
                FADMIN.notice('Request failed. Please try again.', 'error');
            });
        },

        notice: function (msg, type) {
            var $n = $('#nqm-fadmin-notice');
            $n.removeClass('nqm-notice--success nqm-notice--error')
              .addClass(type === 'success' ? 'nqm-notice--success' : 'nqm-notice--error')
              .text(msg).show();
            setTimeout(function () { $n.fadeOut(); }, 4000);
        },

        _esc: function (str) {
            return $('<div>').text(String(str || '')).html();
        },
    };

    // Keep `self` pointing to FADMIN inside renderTable
    var self = FADMIN;

    $(document).ready(function () {
        FADMIN.init();
    });

}(jQuery));
