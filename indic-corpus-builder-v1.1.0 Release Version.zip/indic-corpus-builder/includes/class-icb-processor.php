<?php
/**
 * ICB_Processor – tokenisation and similarity scoring.
 *
 * All tuneable parameters are read from ICB_Config so that changes made in
 * the admin Parser Configuration tab take effect immediately without any
 * code edits.
 */
class ICB_Processor {

    /**
     * Normalise and split text into an array of unique clean words.
     *
     * Steps:
     *  1. Optional NFC normalisation (config: normalize_unicode)
     *  2. Strip hasanta from word-final position (config: strip_hasanta)
     *  3. Remove all characters outside the configured unicode ranges,
     *     optionally preserving anusvara / visarga
     *  4. Split on whitespace
     *  5. Discard words shorter than min_word_length
     *  6. Deduplicate
     *
     * @param  string $text Raw input text.
     * @return string[]
     */
    public static function tokenize_indic_text( string $text ): array {
        $cfg = ICB_Config::all();

        // 1. NFC normalisation
        if ( $cfg['normalize_unicode'] && class_exists( 'Normalizer' ) ) {
            $text = normalizer_normalize( $text, Normalizer::FORM_C );
        }

        // 2. Strip word-final hasanta (্ U+09CD) when enabled
        if ( $cfg['strip_hasanta'] ) {
            $text = preg_replace( '/\x{09CD}(\s|$)/u', '$1', $text );
        }

        // 3. Build character-class from configured unicode ranges
        $range_class = ICB_Config::build_unicode_regex();

        // Optionally extend the class with diacritics
        $extras = '';
        if ( $cfg['preserve_anusvara'] ) {
            $extras .= '\\x{0981}\\x{0982}';   // chandrabindu + anusvara
        }
        if ( $cfg['preserve_visarga'] ) {
            $extras .= '\\x{0983}';             // visarga
        }

        $pattern = '/[^' . $range_class . $extras . '\\s]+/u';
        $text    = preg_replace( $pattern, ' ', $text );

        // 4. Split on whitespace
        $words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

        // 5. Minimum length filter (grapheme clusters, not bytes)
        $min = max( 1, (int) $cfg['min_word_length'] );
        $words = array_filter( $words, function( $w ) use ( $min ) {
            $clusters = preg_split( '//u', $w, -1, PREG_SPLIT_NO_EMPTY );
            return count( $clusters ) >= $min;
        });

        // 6. Deduplicate
        return array_values( array_unique( $words ) );
    }

    /**
     * Grapheme-cluster-aware Levenshtein similarity (0–100 %).
     *
     * Native levenshtein() is byte-based and breaks on multibyte scripts.
     * We convert each string to an array of grapheme clusters first.
     *
     * @return float Percentage similarity, 0.0–100.0
     */
    public static function get_grapheme_similarity( string $word1, string $word2 ): float {
        $arr1 = preg_split( '//u', $word1, -1, PREG_SPLIT_NO_EMPTY );
        $arr2 = preg_split( '//u', $word2, -1, PREG_SPLIT_NO_EMPTY );

        $len1 = count( $arr1 );
        $len2 = count( $arr2 );

        if ( $len1 === 0 && $len2 === 0 ) return 100.0;
        if ( $len1 === 0 || $len2 === 0 ) return 0.0;

        // Levenshtein matrix
        $matrix = [];
        for ( $i = 0; $i <= $len1; $i++ ) $matrix[ $i ][0] = $i;
        for ( $j = 0; $j <= $len2; $j++ ) $matrix[0][ $j ] = $j;

        for ( $i = 1; $i <= $len1; $i++ ) {
            for ( $j = 1; $j <= $len2; $j++ ) {
                $cost = ( $arr1[ $i - 1 ] === $arr2[ $j - 1 ] ) ? 0 : 1;
                $matrix[ $i ][ $j ] = min(
                    $matrix[ $i - 1 ][ $j ] + 1,
                    $matrix[ $i ][ $j - 1 ] + 1,
                    $matrix[ $i - 1 ][ $j - 1 ] + $cost
                );
            }
        }

        $distance = $matrix[ $len1 ][ $len2 ];
        $max_len  = max( $len1, $len2 );

        return (1 - ( $distance / $max_len )) * 100;
    }
}
