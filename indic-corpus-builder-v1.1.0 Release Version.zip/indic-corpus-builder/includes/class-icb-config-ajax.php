<?php
/**
 * AJAX handlers for the Parser Configuration tab.
 *
 *  wp_ajax_icb_save_config  – save user-edited settings via ICB_Config::save()
 *  wp_ajax_icb_reset_config – call ICB_Config::reset() and return DEFAULTS
 */
class ICB_Config_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_icb_save_config',    [ $this, 'handle_save'          ] );
        add_action( 'wp_ajax_icb_reset_config',   [ $this, 'handle_reset'         ] );
        add_action( 'wp_ajax_icb_save_lexicon',   [ $this, 'handle_save_lexicon'  ] );
        add_action( 'wp_ajax_icb_reset_lexicon',  [ $this, 'handle_reset_lexicon' ] );
    }

    // ── Save ──────────────────────────────────────────────────────────────────
    public function handle_save() {
        check_ajax_referer( 'icb_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ] );
        }

        // The JS posts the settings as a JSON string in $_POST['config']
        $raw = isset( $_POST['config'] ) ? stripslashes( $_POST['config'] ) : '';
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Invalid config payload.' ] );
        }

        ICB_Config::save( $data );

        wp_send_json_success( [
            'message'  => 'Parser configuration saved.',
            'settings' => ICB_Config::all(),
        ] );
    }

    // ── Reset ─────────────────────────────────────────────────────────────────
    public function handle_reset() {
        check_ajax_referer( 'icb_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ] );
        }

        ICB_Config::reset();

        wp_send_json_success( [
            'message'  => 'Parser configuration reset to defaults.',
            'settings' => ICB_Config::all(),
        ] );
    }

    // ── Lexicon Save ──────────────────────────────────────────────────────────
    public function handle_save_lexicon() {
        check_ajax_referer( 'icb_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ] );
        }

        $raw  = isset( $_POST['lexicon'] ) ? stripslashes( $_POST['lexicon'] ) : '';
        $data = json_decode( $raw, true );

        if ( ! is_array( $data ) ) {
            wp_send_json_error( [ 'message' => 'Invalid lexicon payload.' ] );
        }

        ICB_Config::save_lexicon( $data );

        wp_send_json_success( [
            'message' => 'Custom lexicon saved.',
            'lexicon' => ICB_Config::get_lexicon(),
        ] );
    }

    // ── Lexicon Reset ─────────────────────────────────────────────────────────
    public function handle_reset_lexicon() {
        check_ajax_referer( 'icb_admin_nonce', 'security' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => 'Insufficient privileges.' ] );
        }

        ICB_Config::reset_lexicon();

        wp_send_json_success( [
            'message' => 'Custom lexicon reset to defaults.',
            'lexicon' => ICB_Config::DEFAULT_LEXICON,
        ] );
    }
}
