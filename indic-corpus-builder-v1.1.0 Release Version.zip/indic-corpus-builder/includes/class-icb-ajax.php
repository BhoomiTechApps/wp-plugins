<?php
/**
 * AJAX handler for the main corpus-processing pipeline.
 * Reads similarity_threshold from ICB_Config instead of a hardcoded literal.
 */
class ICB_Ajax_Handler {

    public function __construct() {
        add_action( 'wp_ajax_icb_process_text', [ $this, 'handle_text_processing' ] );
    }

    public function handle_text_processing() {
        global $wpdb;
        check_ajax_referer( 'icb_admin_nonce', 'security' );

        $raw_text = isset( $_POST['text'] ) ? sanitize_textarea_field( $_POST['text'] ) : '';
        if ( empty( $raw_text ) ) {
            wp_send_json_error( [ 'message' => 'Empty text submitted.' ] );
        }

        $input_words = ICB_Processor::tokenize_indic_text( $raw_text );
        $table_name  = $wpdb->prefix . 'custom_corpus';

        // Read conflict threshold from saved config (falls back to default 75)
        $threshold = (float) ICB_Config::get( 'similarity_threshold' );

        $conflicts   = [];
        $clean_saves = [];

        $existing_words = $wpdb->get_col( "SELECT word FROM $table_name" );

        foreach ( $input_words as $new_word ) {
            // Exact duplicate → skip silently
            if ( in_array( $new_word, $existing_words, true ) ) {
                continue;
            }

            $has_conflict = false;

            foreach ( $existing_words as $old_word ) {
                $similarity = ICB_Processor::get_grapheme_similarity( $new_word, $old_word );

                if ( $similarity >= $threshold && $similarity < 100 ) {
                    $conflicts[] = [
                        'new_word'   => $new_word,
                        'old_word'   => $old_word,
                        'percentage' => round( $similarity, 1 ),
                    ];
                    $has_conflict = true;
                    break;
                }
            }

            if ( ! $has_conflict ) {
                $clean_saves[] = $new_word;
            }
        }

        // No conflicts: auto-save and return
        if ( empty( $conflicts ) && ! empty( $clean_saves ) ) {
            foreach ( $clean_saves as $word ) {
                $wpdb->insert( $table_name, [ 'word' => $word, 'added_at' => current_time( 'mysql' ) ] );
            }
            wp_send_json_success( [ 'status' => 'completed', 'inserted' => count( $clean_saves ) ] );
        }

        // Conflicts found: send back for human review
        wp_send_json_success( [
            'status'     => 'requires_review',
            'conflicts'  => $conflicts,
            'safe_words' => $clean_saves,
        ] );
    }
}
