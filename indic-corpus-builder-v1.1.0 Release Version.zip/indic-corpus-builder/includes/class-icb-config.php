<?php
/**
 * ICB_Config – single source of truth for all parser settings.
 *
 * Settings are stored in wp_options under 'icb_parser_config' as a JSON-encoded
 * associative array.  Any key not present in saved options falls back to the
 * corresponding default defined in self::DEFAULTS.
 *
 * Usage:
 *   ICB_Config::get('similarity_threshold')  // → 75
 *   ICB_Config::all()                         // → merged full settings array
 *   ICB_Config::save($array)                  // → true|false
 *   ICB_Config::reset()                       // wipes saved option
 */
class ICB_Config {

    const OPTION_KEY = 'icb_parser_config';

    /**
     * Canonical defaults – these are the values that ship with the plugin and
     * are also pre-filled in the admin configurator.
     *
     * unicode_ranges   – array of [hex_start, hex_end] pairs (as strings) that
     *                    define which codepoint blocks are preserved during
     *                    tokenisation. Add more pairs for extra scripts.
     *
     * min_word_length  – words shorter than this (in grapheme clusters) are
     *                    discarded after tokenisation.
     *
     * similarity_threshold – lower bound (inclusive, 0–100) at which two words
     *                        are considered a conflict requiring human review.
     *                        100 = exact duplicate (always silently skipped).
     *
     * normalize_unicode – whether to run NFC normalisation before tokenising.
     *
     * strip_hasanta     – whether to remove the hasanta (্ / U+09CD) character
     *                     from word-final position (common in OCR noise).
     *
     * preserve_anusvara – when true, anusvara (ঁ U+0981, ং U+0982) is kept as
     *                     part of the word rather than stripped as punctuation.
     *
     * preserve_visarga  – when true, visarga (ঃ U+0983) is kept.
     */
    /**
     * Default Roman → Indic lexicon map, mirrored from avro-parser.js.
     * Stored as four flat sub-maps: vowels, modifiers, consonants, numerics_specials.
     * Each entry is [ roman_key => indic_value ].
     */
    // Mappings ported from phoneticMap.js (IME PWA) – follows Avro Keyboard layout.
    const DEFAULT_LEXICON = [
        'vowels' => [
            'o'   => 'অ', 'a'   => 'আ', 'aa'  => 'আ', 'A'   => 'আ',
            'i'   => 'ই', 'ee'  => 'ই', 'ii'  => 'ঈ', 'I'   => 'ঈ',
            'u'   => 'উ', 'oo'  => 'উ', 'uu'  => 'ঊ', 'U'   => 'ঊ',
            'rri' => 'ঋ', 'e'   => 'এ', 'OI'  => 'ঐ', 'O'   => 'ও',
            'OU'  => 'ঔ',
        ],
        'modifiers' => [
            'aa'  => 'া', 'A'   => 'া', 'a'   => 'া',
            'i'   => 'ি', 'ii'  => 'ী', 'I'   => 'ী',
            'u'   => 'ু', 'uu'  => 'ূ', 'U'   => 'ূ',
            'e'   => 'ে', 'OI'  => 'ৈ', 'O'   => 'ো', 'OU'  => 'ৌ',
            'rri' => 'ৃ',
            'o'   => '',  // inherent vowel – suppresses Halanta
            'y'   => '্য', 'Y'  => '্য',
        ],
        'consonants' => [
            // Trigraphs / special clusters
            'ssh'  => 'ষ',  'kkh'  => 'ক্ষ',
            // Digraphs
            'kh'   => 'খ',  'gh'   => 'ঘ',  'ch'   => 'ছ',  'jh'   => 'ঝ',
            'Th'   => 'ঠ',  'Dh'   => 'ঢ',  'th'   => 'থ',  'dh'   => 'ধ',
            'ph'   => 'ফ',  'bh'   => 'ভ',  'sh'   => 'শ',  'Sh'   => 'ষ',
            'NG'   => 'ঞ',  'Ng'   => 'ঙ',  'ng'   => 'ং',  'Rh'   => 'ঢ়',
            // Khanda Ta alternatives
            't``'  => 'ৎ',  "t''"  => 'ৎ',
            // Singles
            'f'    => 'ফ',  'k'    => 'ক',  'g'    => 'গ',  'c'    => 'চ',
            'j'    => 'জ',  'T'    => 'ট',  'D'    => 'ড',  'N'    => 'ণ',
            't'    => 'ত',  'd'    => 'দ',  'n'    => 'ন',  'p'    => 'প',
            'b'    => 'ব',  'v'    => 'ভ',  'm'    => 'ম',  'y'    => 'য়',
            'z'    => 'য',  'r'    => 'ৰ',  'R'    => 'ড়', 'l'    => 'ল',
            'w'    => 'ৱ',  'S'    => 'স',  's'    => 'ছ',  'h'    => 'হ',
        ],
        'numerics_specials' => [
            // Digits: ASCII → Assamese/Bengali Indic digits
            '0'  => '০', '1'  => '১', '2'  => '২', '3'  => '৩', '4'  => '৪',
            '5'  => '৫', '6'  => '৬', '7'  => '৭', '8'  => '৮', '9'  => '৯',
            // Punctuation / special symbols
            '.'  => '।',   // daṇḍa (sentence end)
            '..' => '॥',   // double daṇḍa
        ],
    ];

    /**
     * Parser / transliterator engine defaults.
     *
     * android_autocap_fix     – when true, a leading uppercase letter that has
     *                           no uppercase rule but whose lowercase does is
     *                           silently lowercased before parsing (fixes Android
     *                           auto-capitalisation of the first character).
     *
     * nonlinking_consonants   – Roman keys whose corresponding consonants must
     *                           never form a left-side ligature (hasanta + ZWJ
     *                           is suppressed).  Typically the anusvara digraphs.
     *
     * hosonto_key             – Roman key that forces an explicit hasanta / stop
     *                           (outputs consonant + ZWNJ).  Default apostrophe.
     *
     * cluster_breaker_key     – Roman key that acts as the inherent-vowel /
     *                           cluster-breaker; at word-end it appends ZWNJ to
     *                           prevent accidental ো formation.  Default 'o'.
     *
     * similarity_threshold    – lower bound (inclusive, 0–100) at which two words
     *                           are considered a conflict requiring human review.
     *                           100 = exact duplicate (always silently skipped).
     *
     * normalize_unicode       – whether to run NFC normalisation before tokenising.
     *
     * strip_hasanta            – whether to remove the hasanta (্ / U+09CD) from
     *                           word-final position (common in OCR noise).
     *
     * preserve_anusvara       – when true, anusvara (ঁ U+0981, ং U+0982) is kept
     *                           as part of the word rather than stripped as punct.
     *
     * preserve_visarga        – when true, visarga (ঃ U+0983) is kept.
     *
     * min_word_length         – words shorter than this (in grapheme clusters) are
     *                           discarded after tokenisation.
     *
     * unicode_ranges          – array of [hex_start, hex_end] pairs that define
     *                           which codepoint blocks are preserved during
     *                           tokenisation.  Default: Bengali/Assamese block.
     */
    const DEFAULTS = [
        // ── Conflict detection ────────────────────────────────────────────────
        'similarity_threshold'          => 75,

        // ── Tokenisation ──────────────────────────────────────────────────────
        'normalize_unicode'             => true,
        'strip_hasanta'                 => true,
        'preserve_anusvara'             => true,
        'preserve_visarga'              => false,
        'min_word_length'               => 2,
        'unicode_ranges'                => [['0980', '09FF']],  // Bengali / Assamese block

        // ── Transliterator engine ─────────────────────────────────────────────
        'android_autocap_fix'           => true,
        'nonlinking_consonants'         => ['ng', 'NG', 'Ng'],
        'hosonto_key'                   => "'",
        'cluster_breaker_key'           => 'o',
        // Roman keys that resolve to a different Indic consonant when
        // immediately followed by a vowel matra.
        // Key   = Roman input key  (must exist in the consonants map)
        // Value = Indic substitute (UTF-8 string)
        'vowel_context_substitutions'   => [
            'ng' => 'ঙ',   // ং → ঙ before a vowel  (thaitangaita → থাইতাঙাইতা)
            'NG' => 'ঞ',   // ঞ before a vowel
        ],
    ];

    // ── Public API ────────────────────────────────────────────────────────────

    /** Return a single setting, merged with defaults. */
    public static function get( string $key ) {
        $all = self::all();
        return $all[ $key ] ?? null;
    }

    /**
     * Return the full merged settings array (saved values override defaults).
     */
    public static function all(): array {
        $saved = get_option( self::OPTION_KEY, null );

        if ( $saved === null ) {
            return self::DEFAULTS;
        }

        $decoded = json_decode( $saved, true );
        if ( ! is_array( $decoded ) ) {
            return self::DEFAULTS;
        }

        // For each key: saved value wins outright (direct replacement, not concat/merge).
        // Saved value wins outright for every known key; missing keys fall back
        // to DEFAULTS. json_decode( $saved, true ) always converts JSON objects
        // to PHP associative arrays, so is_array() is a reliable guard here.
        $merged = self::DEFAULTS;
        foreach ( $decoded as $key => $value ) {
            if ( ! array_key_exists( $key, self::DEFAULTS ) ) continue;

            if ( $key === 'vowel_context_substitutions' ) {
                // Must be an associative array (JSON object). If it decoded as a
                // stdClass (shouldn't happen with assoc=true but be defensive) or
                // as an empty indexed array, fall back to defaults so the VCS table
                // always has rows to show on first load after a save.
                if ( $value instanceof stdClass ) {
                    $value = (array) $value;
                }
                $merged[ $key ] = ( is_array( $value ) && ! empty( $value ) )
                    ? $value
                    : self::DEFAULTS['vowel_context_substitutions'];
            } else {
                $merged[ $key ] = $value;
            }
        }
        return $merged;
    }

    // ── Lexicon API ───────────────────────────────────────────────────────────

    const LEXICON_KEY = 'icb_custom_lexicon';

    /**
     * Return the active lexicon map.
     * If a custom map has been saved it is returned; otherwise DEFAULT_LEXICON.
     */
    public static function get_lexicon(): array {
        $saved = get_option( self::LEXICON_KEY, null );
        if ( $saved === null ) {
            return self::DEFAULT_LEXICON;
        }
        $decoded = json_decode( $saved, true );
        if ( ! is_array( $decoded ) ) {
            return self::DEFAULT_LEXICON;
        }
        // Merge each sub-map so new default entries always exist.
        // If a saved sub-map is empty (e.g. numerics_specials was saved before
        // the card existed and stored as []), fall back to DEFAULT_LEXICON for
        // that group so the UI always has something to show.
        $merged = [];
        foreach ( ['vowels', 'modifiers', 'consonants', 'numerics_specials'] as $group ) {
            $saved_group = $decoded[ $group ] ?? [];
            if ( ! is_array( $saved_group ) || empty( $saved_group ) ) {
                $merged[ $group ] = self::DEFAULT_LEXICON[ $group ];
            } else {
                $merged[ $group ] = array_merge(
                    self::DEFAULT_LEXICON[ $group ],
                    $saved_group
                );
            }
        }
        return $merged;
    }

    /**
     * Persist a custom lexicon map.
     * Validates that every roman key is a non-empty string ≤ 10 chars,
     * and every indic value is a string (empty string allowed for modifier 'a').
     *
     * @param array $data  Array with keys vowels, modifiers, consonants.
     * @return true|WP_Error
     */
    public static function save_lexicon( array $data ) {
        $clean = [];
        foreach ( ['vowels', 'modifiers', 'consonants', 'numerics_specials'] as $group ) {
            $clean[ $group ] = [];
            if ( ! isset( $data[ $group ] ) || ! is_array( $data[ $group ] ) ) continue;
            foreach ( $data[ $group ] as $roman => $indic ) {
                $roman = (string) $roman;
                $indic = (string) $indic;
                if ( $roman === '' || mb_strlen( $roman ) > 10 ) continue;
                $clean[ $group ][ $roman ] = $indic;
            }
        }
        return update_option( self::LEXICON_KEY, wp_json_encode( $clean ) );
    }

    /** Delete custom lexicon – next call to get_lexicon() returns DEFAULT_LEXICON. */
    public static function reset_lexicon(): void {
        delete_option( self::LEXICON_KEY );
    }

    /**
     * Persist a settings array.
     * Validates each key before storing; unknown keys are silently dropped.
     *
     * @param array $data Associative array of settings to save.
     * @return true|WP_Error
     */
    public static function save( array $data ) {
        $clean = [];

        // android_autocap_fix: boolean
        if ( isset( $data['android_autocap_fix'] ) ) {
            $clean['android_autocap_fix'] = (bool) $data['android_autocap_fix'];
        }

        // nonlinking_consonants: array of short strings (≤ 6 chars each)
        if ( isset( $data['nonlinking_consonants'] ) && is_array( $data['nonlinking_consonants'] ) ) {
            $keys = [];
            foreach ( $data['nonlinking_consonants'] as $k ) {
                $k = (string) $k;
                if ( $k !== '' && mb_strlen( $k ) <= 6 ) {
                    $keys[] = $k;
                }
            }
            $clean['nonlinking_consonants'] = array_values( array_unique( $keys ) );
        }

        // hosonto_key: 1–3 chars
        if ( isset( $data['hosonto_key'] ) ) {
            $v = (string) $data['hosonto_key'];
            if ( $v !== '' && mb_strlen( $v ) <= 3 ) {
                $clean['hosonto_key'] = $v;
            }
        }

        // cluster_breaker_key: 1–3 chars
        if ( isset( $data['cluster_breaker_key'] ) ) {
            $v = (string) $data['cluster_breaker_key'];
            if ( $v !== '' && mb_strlen( $v ) <= 3 ) {
                $clean['cluster_breaker_key'] = $v;
            }
        }

        // vowel_context_substitutions: object of { roman_key => indic_string }
        // Roman key ≤ 6 chars; Indic value is a string (empty allowed to remove).
        if ( isset( $data['vowel_context_substitutions'] ) && is_array( $data['vowel_context_substitutions'] ) ) {
            $vcs = [];
            foreach ( $data['vowel_context_substitutions'] as $roman => $indic ) {
                $roman = (string) $roman;
                $indic = (string) $indic;
                if ( $roman !== '' && mb_strlen( $roman ) <= 6 ) {
                    $vcs[ $roman ] = $indic;
                }
            }
            // Cast to stdClass so wp_json_encode always produces {} (never []) when
            // empty. An empty PHP indexed array encodes as '[]' which wp_localize_script
            // would deliver to JS as an array, breaking Object.entries() in renderVcsTable.
            $clean['vowel_context_substitutions'] = (object) $vcs;
        }

        // ── Tokenisation settings ─────────────────────────────────────────────

        // similarity_threshold: integer 0–100
        if ( isset( $data['similarity_threshold'] ) ) {
            $v = (int) $data['similarity_threshold'];
            if ( $v >= 0 && $v <= 100 ) {
                $clean['similarity_threshold'] = $v;
            }
        }

        // normalize_unicode: boolean
        if ( isset( $data['normalize_unicode'] ) ) {
            $clean['normalize_unicode'] = (bool) $data['normalize_unicode'];
        }

        // strip_hasanta: boolean
        if ( isset( $data['strip_hasanta'] ) ) {
            $clean['strip_hasanta'] = (bool) $data['strip_hasanta'];
        }

        // preserve_anusvara: boolean
        if ( isset( $data['preserve_anusvara'] ) ) {
            $clean['preserve_anusvara'] = (bool) $data['preserve_anusvara'];
        }

        // preserve_visarga: boolean
        if ( isset( $data['preserve_visarga'] ) ) {
            $clean['preserve_visarga'] = (bool) $data['preserve_visarga'];
        }

        // min_word_length: positive integer
        if ( isset( $data['min_word_length'] ) ) {
            $v = (int) $data['min_word_length'];
            if ( $v >= 1 ) {
                $clean['min_word_length'] = $v;
            }
        }

        // unicode_ranges: array of [hex_start, hex_end] pairs
        if ( isset( $data['unicode_ranges'] ) && is_array( $data['unicode_ranges'] ) ) {
            $ranges = [];
            foreach ( $data['unicode_ranges'] as $pair ) {
                if (
                    is_array( $pair ) && isset( $pair[0], $pair[1] ) &&
                    preg_match( '/^[0-9A-Fa-f]{4,6}$/', $pair[0] ) &&
                    preg_match( '/^[0-9A-Fa-f]{4,6}$/', $pair[1] )
                ) {
                    $ranges[] = [ strtoupper( $pair[0] ), strtoupper( $pair[1] ) ];
                }
            }
            if ( ! empty( $ranges ) ) {
                $clean['unicode_ranges'] = $ranges;
            }
        }

        return update_option( self::OPTION_KEY, wp_json_encode( $clean ) );
    }

    /** Delete saved settings – next call to all() returns DEFAULTS. */
    public static function reset(): void {
        delete_option( self::OPTION_KEY );
    }

    /**
     * Build a regex character-class fragment from the configured unicode_ranges.
     *
     * Returns a string like '\x{0980}-\x{09FF}' that can be embedded directly
     * inside a bracket expression, e.g. '/[^' . build_unicode_regex() . '\s]+/u'.
     */
    public static function build_unicode_regex(): string {
        $cfg    = self::all();
        $ranges = $cfg['unicode_ranges'] ?? [['0980', '09FF']];
        $parts  = [];
        foreach ( $ranges as $pair ) {
            if ( isset( $pair[0], $pair[1] ) ) {
                $parts[] = '\\x{' . strtoupper( $pair[0] ) . '}-\\x{' . strtoupper( $pair[1] ) . '}';
            }
        }
        return implode( '', $parts );
    }


}
