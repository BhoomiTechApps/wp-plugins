<?php
/**
 * Indic Corpus Builder Uninstall Cleanup
 *
 * Executed automatically by WordPress when the plugin is uninstalled.
 * Removes ALL data written by this plugin: the custom corpus table and
 * every wp_options entry, so no orphan rows remain after removal.
 *
 * @package IndicCorpusBuilder
 */

// Guard: only run when WordPress triggers uninstall, never directly.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// ── 1. Drop the corpus table ──────────────────────────────────────────────────
$table_name = $wpdb->prefix . 'custom_corpus';
$wpdb->query( "DROP TABLE IF EXISTS `{$table_name}`" );

// ── 2. Remove plugin options from wp_options ──────────────────────────────────
// These keys match ICB_Config::OPTION_KEY and ICB_Config::LEXICON_KEY.
// They must be listed here explicitly (we cannot load the plugin class during
// uninstall) so that no orphan rows are left in the database after removal.
delete_option( 'icb_parser_config' );   // parser / transliterator settings
delete_option( 'icb_custom_lexicon' );  // custom Roman → Indic lexicon map
