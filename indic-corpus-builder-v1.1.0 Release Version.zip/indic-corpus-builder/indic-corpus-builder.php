<?php
/**
 * Plugin Name: Indic Corpus Builder
 * Plugin URI:  https://bhoomitechfoundation.org/apps/indic-corpus-builder
 * Description: Interactive tool to build Bishnupriya Manipuri, Assamese and Bengali corpora from copy-pasted texts.
 * Version:     1.2.0
 * Author:      BhoomiTech Heritage and Development Foundation
 * License:     GPL-2.0+
 * Requires at least:  6.0
 * Tested up to:       7.0
 * Requires PHP:       8.0
 * Text Domain: indic-corpus-builder
 */
 
if (!defined('ABSPATH')) exit;

// ── Autoload ──────────────────────────────────────────────────────────────────
require_once plugin_dir_path(__FILE__) . 'includes/class-icb-config.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-icb-processor.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-icb-ajax.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-icb-config-ajax.php';

// ── Boot AJAX handlers ────────────────────────────────────────────────────────
new ICB_Ajax_Handler();
new ICB_Config_Ajax();

// ── Activation ────────────────────────────────────────────────────────────────
register_activation_hook(__FILE__, 'icb_activate');

function icb_activate() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'custom_corpus';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id       BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        word     VARCHAR(255)        NOT NULL,
        added_at DATETIME            NOT NULL,
        PRIMARY KEY  (id),
        UNIQUE KEY uq_word (word)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// ── Admin menu ────────────────────────────────────────────────────────────────
add_action('admin_menu', 'icb_register_admin_page');

function icb_register_admin_page() {
    add_menu_page(
        'Indic Corpus Builder',
        'Corpus Builder',
        'manage_options',
        'indic-corpus-builder',
        'icb_render_admin_page',
        'dashicons-editor-spellcheck',
        75
    );
}

// ── Enqueue assets ────────────────────────────────────────────────────────────
add_action('admin_enqueue_scripts', 'icb_enqueue_admin_assets', 20);

function icb_enqueue_admin_assets($hook) {
    if (strpos($hook, 'indic-corpus-builder') === false) return;

    wp_enqueue_script(
        'icb-avro-parser',
        plugins_url('assets/js/avro-parser.js', __FILE__),
        ['jquery'],
        '2.3.0',
        true
    );

    wp_enqueue_script(
        'icb-admin-ui',
        plugins_url('assets/js/admin-script.js', __FILE__),
        ['jquery', 'icb-avro-parser'],
        '2.3.0',
        true
    );

    wp_enqueue_script(
        'icb-config-ui',
        plugins_url('assets/js/config-ui.js', __FILE__),
        ['jquery', 'icb-admin-ui'],   // icb-admin-ui must load first so icb_vars is defined
        '2.3.0',
        true
    );

    // Pass nonce + current config + lexicon to JS
    // Use wp_add_inline_script instead of wp_localize_script so that nested
    // arrays and objects (parser_config, lexicon) are always encoded as proper
    // JSON regardless of WordPress version. wp_localize_script casts all values
    // to strings on older WP, which silently corrupts nested structures.
    $icb_vars = [
        'nonce'          => wp_create_nonce( 'icb_admin_nonce' ),
        'parser_config'  => ICB_Config::all(),
        'lexicon'        => ICB_Config::get_lexicon(),
        'defaultLexicon' => ICB_Config::DEFAULT_LEXICON,
    ];
    wp_add_inline_script(
        'icb-admin-ui',
        'var icb_vars = ' . wp_json_encode( $icb_vars ) . ';',
        'before'
    );

    wp_enqueue_style(
        'icb-admin-style',
        plugins_url('assets/css/admin-style.css', __FILE__),
        [],
        '2.3.0'
    );
}

// ── Admin page (tab shell) ────────────────────────────────────────────────────
function icb_render_admin_page() {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'custom_corpus';
    $total_words = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    $active_tab  = isset($_GET['icb_tab']) ? sanitize_key($_GET['icb_tab']) : 'workspace';
    ?>
    <div class="wrap icb-page-wrap">

        <h1 class="icb-page-title">
            Indic Corpus Builder
            <span class="icb-lang-badge">অ · ক · ব</span>
        </h1>
        <p class="icb-subtitle">
            Paste Assamese or Bengali social-media text, resolve near-duplicate conflicts,
            and grow your lexical corpus — one batch at a time.
        </p>

        <!-- Tab Navigation -->
        <div class="icb-tab-nav">
            <button class="icb-tab-btn <?php echo $active_tab === 'workspace' ? 'icb-tab-active' : ''; ?>"
                    data-tab="workspace">
                ✏️ Corpus Workspace
            </button>
            <button class="icb-tab-btn <?php echo $active_tab === 'config' ? 'icb-tab-active' : ''; ?>"
                    data-tab="config">
                ⚙️ Parser Configuration
            </button>
            <button class="icb-tab-btn <?php echo $active_tab === 'lexicon' ? 'icb-tab-active' : ''; ?>"
                    data-tab="lexicon">
                🔡 Lexicon Mapping
            </button>
            <button class="icb-tab-btn <?php echo $active_tab === 'manage' ? 'icb-tab-active' : ''; ?>" data-tab="manage">
                🗄️ Corpus Management
            </button>
        </div>

        <!-- ── Tab: Workspace ────────────────────────────────────────────── -->
        <div id="icb-tab-workspace" class="icb-tab-pane <?php echo $active_tab === 'workspace' ? 'icb-tab-pane--active' : ''; ?>">

            <div class="icb-stats-bar" style="margin-top:20px;">
                <span class="icb-stat-chip">📚 Corpus size: <strong><?php echo number_format($total_words); ?> words</strong></span>
                <span class="icb-stat-chip">🎯 Conflict threshold: <strong><?php echo esc_html(ICB_Config::get('similarity_threshold')); ?>%</strong></span>
            </div>

            <div id="icb-notice-area"></div>

            <div class="icb-workspace">
                <div class="icb-panel">
                    <label for="icb-input-container">Input (Roman / Native)</label>
                    <textarea
                        id="icb-input-container"
                        placeholder="Paste text here — Roman transliteration or native Assamese/Bengali script…"
                    ></textarea>
                </div>
                <div class="icb-panel">
                    <label for="icb-preview-container">Preview (Native Script)</label>
                    <textarea
                        id="icb-preview-container"
                        placeholder="Converted script will appear here…"
                        readonly
                    ></textarea>
                </div>
            </div>

            <div class="icb-action-bar">
                <label class="icb-toggle-wrap" for="icb-transliterate-toggle">
                    <input type="checkbox" id="icb-transliterate-toggle" checked>
                    Enable live Roman → Indic transliteration
                </label>
                <button type="button" id="icb-process-btn" class="button button-primary">
                    Analyse &amp; Save
                </button>
            </div>
        </div>

        <!-- ── Tab: Parser Configuration ────────────────────────────────── -->
        <div id="icb-tab-config" class="icb-tab-pane <?php echo $active_tab === 'config' ? 'icb-tab-pane--active' : ''; ?>">

            <div id="icb-config-notice-area" style="margin-top:20px;"></div>

            <div class="icb-config-grid">

                <!-- ── Card 1: Android Auto-Capitalisation Fix ──────────── -->
                <div class="icb-config-card">
                    <div class="icb-config-card-header">
                        <h3>Input Corrections</h3>
                        <p>Fixes applied to raw input before phonetic parsing begins.</p>
                    </div>
                    <div class="icb-config-card-body icb-cfg-checks">
                        <label class="icb-cfg-row">
                            <div class="icb-cfg-row-left">
                                <input type="checkbox" id="icb-cfg-android-autocap">
                                <span class="icb-cfg-row-title">Android auto-capitalisation fix</span>
                            </div>
                            <span class="icb-cfg-row-desc">
                                When the first character is uppercase and no uppercase rule exists for it,
                                silently lowercase it before parsing. Prevents Android soft-keyboard
                                auto-cap from breaking the first consonant/vowel match
                                (e.g. <code>Korbo</code> → treated as <code>korbo</code>).
                            </span>
                        </label>
                    </div>
                </div>

                <!-- ── Card 2: Special Keys ─────────────────────────────── -->
                <div class="icb-config-card">
                    <div class="icb-config-card-header">
                        <h3>Special Keys</h3>
                        <p>Roman sequences that trigger structural Unicode characters rather than a plain matra.</p>
                    </div>
                    <div class="icb-config-card-body">

                        <div class="icb-cfg-field-row">
                            <label for="icb-cfg-hosonto-key" class="icb-cfg-field-label">
                                Explicit hosonto / stop key
                            </label>
                            <input type="text" id="icb-cfg-hosonto-key"
                                   class="small-text" maxlength="3" placeholder="'">
                            <span class="icb-cfg-field-hint">
                                Appends ZWNJ after the consonant to suppress the inherent vowel
                                and prevent ligature formation.  Default: <code>'</code> (apostrophe).
                            </span>
                        </div>

                        <div class="icb-cfg-field-row" style="margin-top:14px;">
                            <label for="icb-cfg-cluster-breaker" class="icb-cfg-field-label">
                                Cluster-breaker / inherent-vowel key
                            </label>
                            <input type="text" id="icb-cfg-cluster-breaker"
                                   class="small-text" maxlength="3" placeholder="o">
                            <span class="icb-cfg-field-hint">
                                Acts as the inherent <em>অ</em> vowel.  At word-end it appends ZWNJ
                                to avoid accidental <em>ো</em> formation; mid-word it breaks cluster
                                linking so the next consonant starts fresh.  Default: <code>o</code>.
                            </span>
                        </div>

                    </div>
                </div>

                <!-- ── Card 3: Non-Linking Consonants ───────────────────── -->
                <div class="icb-config-card icb-config-card--wide">
                    <div class="icb-config-card-header">
                        <h3>Non-Linking Consonants</h3>
                        <p>
                            Roman keys listed here will <strong>never</strong> form a left-side ligature
                            (হসন্ত + ZWJ is suppressed before them).  Typically the anusvara / nasal
                            digraphs (<code>ng</code>, <code>NG</code>, <code>Ng</code>) that should
                            appear as standalone diacritics rather than cluster members.
                        </p>
                    </div>
                    <div class="icb-config-card-body">
                        <div id="icb-nonlinking-tags" class="icb-tag-list">
                            <!-- populated by config-ui.js -->
                        </div>
                        <div class="icb-tag-add-row" style="margin-top:10px; display:flex; gap:6px;">
                            <input type="text" id="icb-nonlinking-input"
                                   class="small-text" maxlength="6"
                                   placeholder="e.g. ng">
                            <button type="button" id="icb-nonlinking-add-btn" class="button">
                                + Add
                            </button>
                        </div>
                        <p class="icb-cfg-hint" style="margin-top:8px;">
                            Type a Roman key and press <kbd>Enter</kbd> or click Add.
                            Click <strong>×</strong> on a tag to remove it.
                        </p>
                    </div>
                </div>

                <!-- ── Card 4: Vowel-Context Substitutions ───────────────── -->
                <div class="icb-config-card icb-config-card--wide">
                    <div class="icb-config-card-header">
                        <h3>Vowel-Context Substitutions</h3>
                        <p>
                            When a Roman key is immediately followed by a vowel, use the Indic character
                            in the <em>Before-vowel form</em> column instead of the default consonant
                            from the Lexicon. The canonical example:
                            <code>ng</code> normally maps to <strong>ং</strong> (anusvara, a pure diacritic)
                            but must become <strong>ঙ</strong> (a full consonant) when a vowel follows —
                            so <em>thaitangaita</em> → <strong>থাইতাঙাইতা</strong> without the user
                            having to type <code>thaita<u>Ng</u>aita</code>.
                        </p>
                    </div>
                    <div class="icb-config-card-body">
                        <table class="icb-vcs-table" data-no-datatables="1">
                            <thead>
                                <tr>
                                    <th>Roman key</th>
                                    <th>Before-vowel form</th>
                                    <th style="width:50px;"></th>
                                </tr>
                            </thead>
                            <tbody id="icb-vcs-tbody">
                                <!-- populated by config-ui.js -->
                            </tbody>
                        </table>
                        <div class="icb-tag-add-row" style="margin-top:10px; display:flex; gap:6px; align-items:center;">
                            <input type="text" id="icb-vcs-input-roman"
                                   class="small-text" maxlength="6"
                                   placeholder="e.g. ng">
                            <input type="text" id="icb-vcs-input-indic"
                                   class="small-text icb-lex-indic-input" maxlength="6"
                                   placeholder="e.g. ঙ">
                            <button type="button" id="icb-vcs-add-btn" class="button">
                                + Add Row
                            </button>
                        </div>
                        <p class="icb-cfg-hint" style="margin-top:8px;">
                            Enter a Roman key and its before-vowel Indic form, then click Add Row.
                        </p>
                    </div>
                </div>

                <!-- ── Card 5: Live Test ─────────────────────────────────── -->
                <div class="icb-config-card icb-config-card--wide">
                    <div class="icb-config-card-header">
                        <h3>Live Transliteration Test</h3>
                        <p>Preview how the <em>current (unsaved)</em> settings convert Roman input — useful for verifying key changes before saving.</p>
                    </div>
                    <div class="icb-config-card-body" style="display:flex; gap:12px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="flex:1; min-width:200px;">
                            <label for="icb-cfg-test-input" class="icb-cfg-field-label">Roman input</label>
                            <input type="text" id="icb-cfg-test-input"
                                   class="regular-text"
                                   placeholder="e.g. amar sonar bangla">
                        </div>
                        <div style="flex:1; min-width:200px;">
                            <span class="icb-cfg-field-label">Output</span>
                            <div id="icb-cfg-test-output" class="icb-live-test-output">—</div>
                        </div>
                    </div>
                </div>

            </div><!-- .icb-config-grid -->

            <!-- Action bar -->
            <div class="icb-config-action-bar">
                <button type="button" id="icb-reset-config-btn" class="button button-secondary">
                    ↺ Reset to Defaults
                </button>
                <button type="button" id="icb-save-config-btn" class="button button-primary">
                    Save Configuration
                </button>
            </div>

        </div><!-- #icb-tab-config -->

        <!-- ── Tab: Lexicon Mapping ──────────────────────────────────────── -->
        <div id="icb-tab-lexicon" class="icb-tab-pane <?php echo $active_tab === 'lexicon' ? 'icb-tab-pane--active' : ''; ?>">

            <div id="icb-lexicon-notice-area" style="margin-top:20px;"></div>

            <p class="icb-subtitle" style="margin-top:12px;">
                Customise the Roman → Bengali/Assamese transliteration table.
                Both the <strong>Roman key</strong> and the <strong>Indic value</strong> are editable.
                This saved map is the primary reference; the hardcoded defaults in
                <code>avro-parser.js</code> act as a fallback only when no custom map exists.
            </p>

            <div class="icb-lexicon-accordion">

                <!-- Vowels -->
                <div class="icb-accordion-item icb-accordion-item--open" data-accordion-group="vowels">
                    <button type="button" class="icb-accordion-trigger" aria-expanded="true">
                        <span class="icb-accordion-title">
                            Vowels
                            <span class="icb-lexicon-count" id="icb-lex-count-vowels"></span>
                        </span>
                        <span class="icb-accordion-desc">Standalone vowel characters used when not attached to a consonant</span>
                        <span class="icb-accordion-chevron" aria-hidden="true"></span>
                    </button>
                    <div class="icb-accordion-body">
                        <table class="icb-lexicon-table" data-no-datatables="1">
                            <thead><tr><th>Roman key</th><th>Indic glyph</th><th></th></tr></thead>
                            <tbody id="icb-lex-tbody-vowels"></tbody>
                        </table>
                        <button type="button" class="button icb-lex-add-row" data-group="vowels" style="margin-top:10px;">
                            + Add Row
                        </button>
                    </div>
                </div>

                <!-- Modifiers -->
                <div class="icb-accordion-item" data-accordion-group="modifiers">
                    <button type="button" class="icb-accordion-trigger" aria-expanded="false">
                        <span class="icb-accordion-title">
                            Vowel Modifiers <em style="font-weight:400;">(Maatraa)</em>
                            <span class="icb-lexicon-count" id="icb-lex-count-modifiers"></span>
                        </span>
                        <span class="icb-accordion-desc">Diacritic forms attached to consonants — inherent <em>a</em> maps to empty string</span>
                        <span class="icb-accordion-chevron" aria-hidden="true"></span>
                    </button>
                    <div class="icb-accordion-body" hidden>
                        <table class="icb-lexicon-table" data-no-datatables="1">
                            <thead><tr><th>Roman key</th><th>Indic diacritic</th><th></th></tr></thead>
                            <tbody id="icb-lex-tbody-modifiers"></tbody>
                        </table>
                        <button type="button" class="button icb-lex-add-row" data-group="modifiers" style="margin-top:10px;">
                            + Add Row
                        </button>
                    </div>
                </div>

                <!-- Consonants -->
                <div class="icb-accordion-item" data-accordion-group="consonants">
                    <button type="button" class="icb-accordion-trigger" aria-expanded="false">
                        <span class="icb-accordion-title">
                            Consonants
                            <span class="icb-lexicon-count" id="icb-lex-count-consonants"></span>
                        </span>
                        <span class="icb-accordion-desc">All consonant mappings — multi-character keys (kh, dh-) matched greedily</span>
                        <span class="icb-accordion-chevron" aria-hidden="true"></span>
                    </button>
                    <div class="icb-accordion-body" hidden>
                        <table class="icb-lexicon-table" data-no-datatables="1">
                            <thead><tr><th>Roman key</th><th>Indic glyph</th><th></th></tr></thead>
                            <tbody id="icb-lex-tbody-consonants"></tbody>
                        </table>
                        <button type="button" class="button icb-lex-add-row" data-group="consonants" style="margin-top:10px;">
                            + Add Row
                        </button>
                    </div>
                </div>

                <!-- Numerics & Special Characters -->
                <div class="icb-accordion-item" data-accordion-group="numerics_specials">
                    <button type="button" class="icb-accordion-trigger" aria-expanded="false">
                        <span class="icb-accordion-title">
                            Numerics &amp; Special Characters
                            <span class="icb-lexicon-count" id="icb-lex-count-numerics_specials"></span>
                        </span>
                        <span class="icb-accordion-desc">ASCII digits 0–9 → Indic equivalents, plus punctuation like । daṇḍa and ॥ double daṇḍa</span>
                        <span class="icb-accordion-chevron" aria-hidden="true"></span>
                    </button>
                    <div class="icb-accordion-body" hidden>
                        <table class="icb-lexicon-table" data-no-datatables="1">
                            <thead><tr><th>Roman key</th><th>Indic glyph</th><th></th></tr></thead>
                            <tbody id="icb-lex-tbody-numerics_specials"></tbody>
                        </table>
                        <button type="button" class="button icb-lex-add-row" data-group="numerics_specials" style="margin-top:10px;">
                            + Add Row
                        </button>
                    </div>
                </div>

            </div><!-- .icb-lexicon-accordion -->

            <!-- Action bar -->
            <div class="icb-config-action-bar">
                <button type="button" id="icb-reset-lexicon-btn" class="button button-secondary">
                    ↺ Reset to Defaults
                </button>
                <button type="button" id="icb-save-lexicon-btn" class="button button-primary">
                    Save Lexicon
                </button>
            </div>

        </div><!-- #icb-tab-lexicon -->

        <!-- ── Tab: Corpus Management ──────────────────────────────────── -->
        <div id="icb-tab-manage" class="icb-tab-pane <?php echo $active_tab === 'manage' ? 'icb-tab-pane--active' : ''; ?>">

            <div id="icb-manage-notice-area" style="margin-top:20px;"></div>

            <div class="icb-config-grid">

                <!-- Download Corpus Card -->
                <div class="icb-config-card">
                    <div class="icb-config-card-header">
                        <h3>📥 Download Corpus</h3>
                        <p>Export the entire corpus as a UTF-8 CSV file — one word per row.</p>
                    </div>
                    <div class="icb-config-card-body">
                        <p style="margin-bottom:16px;">The exported file will contain all <strong><?php echo number_format($total_words); ?> word(s)</strong> currently stored in the corpus, with their save timestamps.</p>
                        <button type="button" id="icb-download-corpus-btn" class="button button-primary">
                            ⬇ Download as CSV
                        </button>
                    </div>
                </div>

                <!-- Clear Corpus Card -->
                <div class="icb-config-card">
                    <div class="icb-config-card-header">
                        <h3>🗑️ Clear Corpus</h3>
                        <p>Permanently delete all words from the corpus. This action cannot be undone.</p>
                    </div>
                    <div class="icb-config-card-body">
                        <p style="margin-bottom:16px; color:#a00;">⚠️ This will erase all <strong><?php echo number_format($total_words); ?> word(s)</strong> from the database. Download a backup first.</p>
                        <button type="button" id="icb-clear-corpus-btn" class="button button-secondary" style="border-color:#a00; color:#a00;">
                            🗑 Clear All Words
                        </button>
                    </div>
                </div>

            </div>

        </div><!-- #icb-tab-manage -->

    </div><!-- .wrap -->
    <?php
}

// ── Hidden conflict-resolution modal ─────────────────────────────────────────
add_action('admin_footer', 'icb_render_hidden_modal_html');

function icb_render_hidden_modal_html() {
    $screen = get_current_screen();
    if (!$screen || strpos($screen->id, 'indic-corpus-builder') === false) return;
    ?>
    <div id="icb-conflict-modal" class="icb-modal-wrapper" style="display:none;">
        <div class="icb-modal-content">
            <div class="icb-modal-header">
                <h2>Linguistic Conflict Resolution</h2>
                <p>These incoming words closely match existing entries. Review each pair to maintain corpus integrity.</p>
            </div>
            <div class="icb-modal-body">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th style="width:22%;">New Word</th>
                            <th style="width:22%;">Existing Match</th>
                            <th style="width:12%;">Similarity</th>
                            <th style="width:44%;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="icb-conflict-rows"></tbody>
                </table>
            </div>
            <div class="icb-modal-footer">
                <span class="icb-footer-info" id="icb-modal-conflict-count"></span>
                <div class="icb-footer-actions">
                    <button type="button" id="icb-cancel-modal-btn" class="button button-secondary">Discard Batch</button>
                    <button type="button" id="icb-submit-resolution-btn" class="button button-primary" disabled>Commit Approved Selections</button>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// ── AJAX: save resolved corpus ────────────────────────────────────────────────
add_action('wp_ajax_icb_save_resolved_corpus', 'icb_ajax_save_resolved_corpus');

function icb_ajax_save_resolved_corpus() {
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'icb_admin_nonce')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient privileges.']);
    }

    global $wpdb;
    $table_name   = $wpdb->prefix . 'custom_corpus';
    $resolutions  = isset($_POST['resolutions']) ? (array) $_POST['resolutions'] : [];
    $safe_words   = isset($_POST['safe_words'])  ? (array) $_POST['safe_words']  : [];
    $current_time = current_time('mysql');

    $inserted_count = 0;
    $updated_count  = 0;

    foreach ($safe_words as $clean_word) {
        $clean_word = sanitize_text_field(trim($clean_word));
        if (empty($clean_word)) continue;
        $rows = $wpdb->query($wpdb->prepare(
            "INSERT IGNORE INTO $table_name (word, added_at) VALUES (%s, %s)",
            $clean_word, $current_time
        ));
        if ($rows) $inserted_count++;
    }

    foreach ($resolutions as $packet) {
        if (!isset($packet['decision'])) continue;
        $decision = sanitize_key($packet['decision']);
        $new_word = sanitize_text_field(trim($packet['new_word']));
        $old_word = sanitize_text_field(trim($packet['old_word']));

        switch ($decision) {
            case 'keep_old': break;

            case 'replace_with_new':
                $rows = $wpdb->update(
                    $table_name,
                    ['word' => $new_word, 'added_at' => $current_time],
                    ['word' => $old_word],
                    ['%s', '%s'], ['%s']
                );
                if ($rows !== false) $updated_count++;
                break;

            case 'keep_both':
                $rows = $wpdb->query($wpdb->prepare(
                    "INSERT IGNORE INTO $table_name (word, added_at) VALUES (%s, %s)",
                    $new_word, $current_time
                ));
                if ($rows) $inserted_count++;
                break;
        }
    }

    wp_send_json_success([
        'message'  => 'Corpus updated successfully.',
        'inserted' => $inserted_count,
        'updated'  => $updated_count,
    ]);
}

// ── AJAX: download corpus as CSV ──────────────────────────────────────────────
add_action('wp_ajax_icb_download_corpus', 'icb_ajax_download_corpus');

function icb_ajax_download_corpus() {
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'icb_admin_nonce')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient privileges.']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_corpus';
    $rows = $wpdb->get_results("SELECT word, added_at FROM $table_name ORDER BY added_at ASC", ARRAY_A);

    $lines = ["word,added_at"];
    foreach ($rows as $row) {
        $word     = str_replace('"', '""', $row['word']);
        $added_at = str_replace('"', '""', $row['added_at']);
        $lines[]  = '"' . $word . '","' . $added_at . '"';
    }

    wp_send_json_success([
        'csv'      => implode("\n", $lines),
        'filename' => 'indic-corpus-' . date('Y-m-d') . '.csv',
        'count'    => count($rows),
    ]);
}

// ── AJAX: clear corpus ────────────────────────────────────────────────────────
add_action('wp_ajax_icb_clear_corpus', 'icb_ajax_clear_corpus');

function icb_ajax_clear_corpus() {
    if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'icb_admin_nonce')) {
        wp_send_json_error(['message' => 'Security check failed.']);
    }
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['message' => 'Insufficient privileges.']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'custom_corpus';
    $deleted    = $wpdb->query("DELETE FROM $table_name");

    if ($deleted === false) {
        wp_send_json_error(['message' => 'Database error — corpus could not be cleared.']);
    }

    wp_send_json_success([
        'message' => 'Corpus cleared successfully.',
        'deleted' => $deleted,
    ]);
}
