// assets/js/avro-parser.js — v2.0
// Transliterator engine ported from modules/ime/transliterator.js (v1.4).
// Replaces the old greedy-map parser with the full IME logic:
//   · Reph (র্) and ligature (হসন্ত) formation
//   · Multi-matra sequences (ya-fola + vowel)
//   · 'o' as cluster-breaker / ZWNJ at word-end
//   · Explicit hosonto via apostrophe (')
//   · Android auto-capitalisation fix
//
// The phonetic map is read from icb_vars.lexicon (saved custom map) or falls
// back to ICB_Default_Lexicon defined below, exactly mirroring phoneticMap.js.
(function (window) {
    'use strict';

    // ── Default phonetic map (mirrors phoneticMap.js) ─────────────────────────
    const ICB_Default_Lexicon = {
        vowels: {
            'o': 'অ', 'a': 'আ', 'aa': 'আ', 'A': 'আ',
            'i': 'ই', 'ee': 'ই', 'ii': 'ঈ', 'I': 'ঈ',
            'u': 'উ', 'oo': 'উ', 'uu': 'ঊ', 'U': 'ঊ',
            'rri': 'ঋ', 'e': 'এ', 'OI': 'ঐ', 'O': 'ও', 'OU': 'ঔ'
        },
        // 'matras' in the IME are called 'modifiers' here for back-compat
        modifiers: {
            'aa': 'া', 'A': 'া', 'a': 'া',
            'i': 'ি', 'ii': 'ী', 'I': 'ী',
            'u': 'ু', 'uu': 'ূ', 'U': 'ূ',
            'e': 'ে', 'OI': 'ৈ', 'O': 'ো', 'OU': 'ৌ',
            'rri': 'ৃ',
            'o': '',          // inherent vowel – suppresses Halanta
            'y': '্য', 'Y': '্য',
            "'": null         // explicit hosonto marker – handled in logic
        },
        consonants: {
            // Trigraphs / special clusters first
            'ssh': 'ষ', 'kkh': 'ক্ষ',
            // Digraphs
            'kh': 'খ', 'gh': 'ঘ', 'ch': 'ছ', 'jh': 'ঝ',
            'Th': 'ঠ', 'Dh': 'ঢ', 'th': 'থ', 'dh': 'ধ',
            'ph': 'ফ', 'bh': 'ভ', 'sh': 'শ', 'Sh': 'ষ',
            'NG': 'ঞ', 'Ng': 'ঙ', 'ng': 'ং', 'Rh': 'ঢ়',
            // Khanda Ta alternatives
            't``': 'ৎ', "t''": 'ৎ',
            // Singles
            'f': 'ফ', 'k': 'ক', 'g': 'গ', 'c': 'চ',
            'j': 'জ', 'T': 'ট', 'D': 'ড', 'N': 'ণ',
            't': 'ত', 'd': 'দ', 'n': 'ন', 'p': 'প',
            'b': 'ব', 'v': 'ভ', 'm': 'ম', 'y': 'য়',
            'z': 'য', 'r': 'ৰ', 'R': 'ড়', 'l': 'ল',
            'w': 'ৱ', 'S': 'স', 's': 'ছ', 'h': 'হ'
        },
        numerics_specials: {
            '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
            '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
            '.':  '।',   // daṇḍa
            '..': '॥'    // double daṇḍa
        }
    };

    // ── Unicode joiners ───────────────────────────────────────────────────────
    const HALANTA = '্';
    const ZWJ     = '\u200D';
    const ZWNJ    = '\u200C';

    // ── Active lexicon ────────────────────────────────────────────────────────
    function getActiveLexicon() {
        if (
            typeof icb_vars !== 'undefined' &&
            icb_vars.lexicon &&
            typeof icb_vars.lexicon === 'object' &&
            icb_vars.lexicon.consonants &&
            Object.keys(icb_vars.lexicon.consonants).length > 0
        ) {
            return icb_vars.lexicon;
        }
        return ICB_Default_Lexicon;
    }

    // ── Active parser config ──────────────────────────────────────────────────
    function getParserConfig() {
        const defaults = {
            android_autocap_fix:        true,
            nonlinking_consonants:      ['ng', 'NG', 'Ng'],
            hosonto_key:                "'",
            cluster_breaker_key:        'o',
            // Consonants that resolve to a different Indic character when
            // immediately followed by a vowel matra.
            // e.g. 'ng' → ং normally, but ঙ before a vowel ('thaitangaita').
            vowel_context_substitutions: { 'ng': 'ঙ', 'NG': 'ঞ' }
        };
        if (typeof icb_vars !== 'undefined' && icb_vars.parser_config) {
            const saved = icb_vars.parser_config;
            // Use saved VCS if it exists AND is a non-empty plain object.
            // An empty {} means no substitutions were ever saved (e.g. first
            // install) — fall back to defaults so the VCS table always shows rows.
            const rawVcs = Object.prototype.hasOwnProperty.call(saved, 'vowel_context_substitutions')
                ? saved.vowel_context_substitutions
                : null;
            const hasEntries = rawVcs && !Array.isArray(rawVcs)
                && typeof rawVcs === 'object'
                && Object.keys(rawVcs).length > 0;
            return Object.assign({}, defaults, saved, {
                vowel_context_substitutions: hasEntries
                    ? rawVcs
                    : defaults.vowel_context_substitutions
            });
        }
        return defaults;
    }

    // ── Core transliterate function ───────────────────────────────────────────
    function transliterate(input) {
        if (!input) return '';

        const lex    = getActiveLexicon();
        const cfg    = getParserConfig();

        // The IME uses separate vowels / matras / consonants maps.
        // 'modifiers' in ICB_Default_Lexicon ≡ 'matras' in the IME.
        const vowels    = lex.vowels    || {};
        const matras    = lex.modifiers || {};
        const consonantMap = lex.consonants || {};

        // Sorted keys (longest-first for greedy match)
        const sortedVowelKeys    = Object.keys(vowels).sort((a, b) => b.length - a.length);
        const sortedMatraKeys    = Object.keys(matras).sort((a, b) => b.length - a.length);
        const sortedConsonantKeys= Object.keys(consonantMap).sort((a, b) => b.length - a.length);

        // Numerics & special characters — read from lex.numerics_specials,
        // checked before the legacy symbol/number hooks so user-configured
        // mappings always take priority.
        const numericSpecialsMap = lex.numerics_specials || {};
        const sortedNumericSpecialsKeys = Object.keys(numericSpecialsMap).sort((a, b) => b.length - a.length);

        // Legacy symbol / number pass-through hooks (kept for back-compat).
        const symbolMap  = lex.symbols || {};
        const numberMap  = lex.numbers || {};
        const sortedSymbolKeys = Object.keys(symbolMap).sort((a, b) => b.length - a.length);
        const sortedNumberKeys = Object.keys(numberMap).sort((a, b) => b.length - a.length);

        // Non-linking consonants (don't form ligatures to the left)
        const nonlinking = cfg.nonlinking_consonants || [];

        // ── Android auto-capitalisation fix ───────────────────────────────────
        if (cfg.android_autocap_fix && input.length > 0) {
            const firstChar = input[0];
            if (/[A-Z]/.test(firstChar)) {
                const lowerChar = firstChar.toLowerCase();
                const hasUpperRule = sortedConsonantKeys.includes(firstChar) ||
                                     sortedVowelKeys.includes(firstChar);
                const hasLowerRule = sortedConsonantKeys.includes(lowerChar) ||
                                     sortedVowelKeys.includes(lowerChar);
                if (!hasUpperRule && hasLowerRule) {
                    input = lowerChar + input.slice(1);
                }
            }
        }

        let output = '';
        let i = 0;

        while (i < input.length) {

            // 1. NUMERICS & SPECIAL CHARACTERS
            const nsKey = sortedNumericSpecialsKeys.find(k => input.startsWith(k, i));
            if (nsKey) {
                output += numericSpecialsMap[nsKey];
                i += nsKey.length;
                continue;
            }

            // 1b. SYMBOLS (legacy hook)
            const sKey = sortedSymbolKeys.find(k => input.startsWith(k, i));
            if (sKey) {
                output += symbolMap[sKey];
                i += sKey.length;
                continue;
            }

            // 2. INDEPENDENT VOWELS
            const isStart      = (i === 0 || /[^a-zA-Z]/.test(input[i - 1]));
            const isAfterVowel = i > 0 && sortedVowelKeys.some(v => input.slice(0, i).endsWith(v));
            const vKey = sortedVowelKeys.find(k => input.startsWith(k, i));

            if (vKey && (isStart || isAfterVowel)) {
                output += vowels[vKey];
                i += vKey.length;
                continue;
            }

            // 3. CONSONANTS & MATRAS
            const cKey = sortedConsonantKeys.find(k => input.startsWith(k, i));
            if (cKey) {
                const nextPos = i + cKey.length;
                const mKey    = sortedMatraKeys.find(k => input.startsWith(k, nextPos));

                // ── Vowel-context substitution ─────────────────────────────
                // If a matra follows and this Roman key has a substitution
                // defined (e.g. ng→ঙ before a vowel vs ং elsewhere), use it.
                const vcsMap = cfg.vowel_context_substitutions || {};
                const char = (mKey !== undefined && vcsMap[cKey])
                    ? vcsMap[cKey]
                    : consonantMap[cKey];

                if (mKey !== undefined) {
                    const matraValue    = matras[mKey] || '';
                    const afterMatraPos = nextPos + mKey.length;

                    // ── Multi-matra: only when first matra is a modifier (y/Y)
                    const secondMKey = (mKey === 'y' || mKey === 'Y')
                        ? sortedMatraKeys.find(k => input.startsWith(k, afterMatraPos))
                        : undefined;

                    if (secondMKey !== undefined) {
                        // ya-fola + 'o' at word-end → ZWNJ to prevent ো formation
                        if (secondMKey === cfg.cluster_breaker_key) {
                            const charAfterO = input[afterMatraPos + secondMKey.length];
                            const isEndOfWord = !charAfterO || /[^a-zA-Z]/.test(charAfterO);
                            output += char + matraValue + (isEndOfWord ? ZWNJ : '');
                        } else {
                            output += char + matraValue + (matras[secondMKey] || '');
                        }
                        i = afterMatraPos + secondMKey.length;

                    } else if (mKey === cfg.cluster_breaker_key) {
                        // ── 'o' cluster-breaker
                        const nextChar    = input[nextPos + 1];
                        const isEndOfWord = !nextChar || /[^a-zA-Z]/.test(nextChar);
                        output += isEndOfWord ? (char + ZWNJ) : char;
                        i = nextPos + mKey.length;

                    } else if (mKey === cfg.hosonto_key) {
                        // ── Explicit hosonto / stop
                        output += char + ZWNJ;
                        i = nextPos + mKey.length;

                    } else {
                        // ── Standard matra
                        output += char + matraValue;
                        i = nextPos + mKey.length;
                    }

                } else {
                    // ── Ligature / Reph logic (no matra follows)
                    const nextCKey = sortedConsonantKeys.find(k => input.startsWith(k, nextPos));

                    if (nextCKey && !nonlinking.includes(cKey)) {
                        if (cKey === 'r' && input.startsWith('r', nextPos)) {
                            // rr → র + হসন্ত (no ZWJ – avoids reph on the second র)
                            output += char + HALANTA;
                            i = nextPos + 1;
                            continue;
                        }
                        // র before consonant → reph (র্ + ZWJ); others → plain হসন্ত
                        output += (cKey === 'r') ? (char + HALANTA + ZWJ) : (char + HALANTA);
                    } else {
                        output += char;
                    }
                    i = nextPos;
                }
                continue;
            }

            // 4. FALLBACK (numbers, then pass-through)
            const nKey = sortedNumberKeys.find(k => input.startsWith(k, i));
            if (nKey) {
                output += numberMap[nKey];
                i += nKey.length;
            } else {
                output += input[i];
                i++;
            }
        }

        return output;
    }

    // ── Public API ────────────────────────────────────────────────────────────
    window.ICB_Transliterator = {
        convert: function (romanText) {
            return transliterate(romanText);
        }
    };

    // Expose default lexicon for config-ui.js reset
    window.ICB_Default_Lexicon = ICB_Default_Lexicon;

})(window);
