/**
 * Parser Configuration Tab – config-ui.js  v2.0
 *
 * Manages the transliterator engine settings that correspond to the
 * logic in avro-parser.js (ported from transliterator.js v1.4):
 *
 *   · Android auto-capitalisation fix toggle
 *   · Non-linking consonants (consonants that never form left-side ligatures)
 *   · Cluster-breaker key (default 'o')
 *   · Explicit hosonto / stop key (default "'")
 *   · Live test panel
 *
 * Reads initial state from icb_vars.parser_config (PHP-localized).
 * Communicates with wp_ajax_icb_save_config / wp_ajax_icb_reset_config.
 */
jQuery(document).ready(function ($) {
    'use strict';

    // ── TablePress / DataTables conflict guard ────────────────────────────────
    // TablePress loads DataTables on all admin pages and may auto-initialise any
    // table it finds — including ICB's config tables. If DataTables takes ownership
    // of an ICB table before we populate it, it caches 0 rows and then overwrites
    // any rows we append. Destroy any DataTables instance on ICB tables up-front.
    if ( $.fn.DataTable ) {
        $('table[data-no-datatables]').each(function () {
            if ( $.fn.DataTable.isDataTable( this ) ) {
                $(this).DataTable().destroy();
            }
        });
    }

    // ── Tab switching ─────────────────────────────────────────────────────────
    $(document).on('click', '.icb-tab-btn', function () {
        const target = $(this).data('tab');
        $('.icb-tab-btn').removeClass('icb-tab-active');
        $(this).addClass('icb-tab-active');
        $('.icb-tab-pane').removeClass('icb-tab-pane--active');
        $('#icb-tab-' + target).addClass('icb-tab-pane--active');
    });

    // ── Helpers ───────────────────────────────────────────────────────────────
    function showConfigNotice(type, msg) {
        const $n = $('<div class="icb-notice icb-notice-' + type + '">' + msg + '</div>');
        $('#icb-config-notice-area').html($n);
        setTimeout(() => $n.fadeOut(400, function () { $(this).remove(); }), 5000);
    }

    // ── Non-linking consonants tag UI ─────────────────────────────────────────
    function renderNonlinkingTags(list) {
        const $wrap = $('#icb-nonlinking-tags');
        $wrap.empty();
        (list || []).forEach(function (key) {
            $wrap.append(buildTag(key));
        });
    }

    function buildTag(key) {
        return $('<span class="icb-tag">')
            .text(key)
            .append(
                $('<button type="button" class="icb-tag-remove" aria-label="Remove">&times;</button>')
                    .data('key', key)
            );
    }

    function collectNonlinking() {
        const keys = [];
        $('#icb-nonlinking-tags .icb-tag').each(function () {
            const text = $(this).clone().find('button').remove().end().text().trim();
            if (text) keys.push(text);
        });
        return keys;
    }

    // ── Populate form from a settings object ──────────────────────────────────
    function populateForm(s) {
        $('#icb-cfg-android-autocap').prop('checked', !!s.android_autocap_fix);
        $('#icb-cfg-hosonto-key').val(s.hosonto_key || "'");
        $('#icb-cfg-cluster-breaker').val(s.cluster_breaker_key || 'o');
        renderNonlinkingTags(s.nonlinking_consonants || []);
        renderVcsTable(s.vowel_context_substitutions || {});
        runLiveTest();
    }

    // ── Vowel-context substitution table ─────────────────────────────────────
    function renderVcsTable(map) {
        const $tbody = $('#icb-vcs-tbody');
        $tbody.empty();
        Object.entries(map).forEach(function ([roman, indic]) {
            $tbody.append(buildVcsRow(roman, indic));
        });
    }

    function buildVcsRow(roman, indic) {
        return $('<tr>').append(
            $('<td>').append(
                $('<input type="text">').addClass('icb-vcs-roman small-text')
                    .attr('maxlength', 6).attr('placeholder', 'ng').val(roman)
            ),
            $('<td>').append(
                $('<input type="text">').addClass('icb-vcs-indic icb-lex-indic-input')
                    .attr('maxlength', 6).attr('placeholder', 'ঙ').val(indic)
            ),
            $('<td>').append(
                $('<button type="button" class="button icb-vcs-remove" title="Remove">✕</button>')
            )
        );
    }

    function collectVcs() {
        const map = {};
        $('#icb-vcs-tbody tr').each(function () {
            const roman = $(this).find('.icb-vcs-roman').val().trim();
            const indic = $(this).find('.icb-vcs-indic').val();
            if (roman !== '') map[roman] = indic;
        });
        return map;
    }

    // ── Collect current form state ────────────────────────────────────────────
    function collectSettings() {
        return {
            android_autocap_fix:          $('#icb-cfg-android-autocap').is(':checked'),
            hosonto_key:                  $('#icb-cfg-hosonto-key').val().trim() || "'",
            cluster_breaker_key:          $('#icb-cfg-cluster-breaker').val().trim() || 'o',
            nonlinking_consonants:        collectNonlinking(),
            vowel_context_substitutions:  collectVcs()
        };
    }

    // ── Live test panel ───────────────────────────────────────────────────────
    function runLiveTest() {
        const input = $('#icb-cfg-test-input').val();
        if (!input || !window.ICB_Transliterator) {
            $('#icb-cfg-test-output').text('—');
            return;
        }
        // Push the current unsaved config into icb_vars temporarily so the
        // transliterator picks it up for the preview.
        const prev = (typeof icb_vars !== 'undefined') ? icb_vars.parser_config : undefined;
        if (typeof icb_vars !== 'undefined') {
            icb_vars.parser_config = collectSettings();
        }
        $('#icb-cfg-test-output').text(window.ICB_Transliterator.convert(input));
        if (typeof icb_vars !== 'undefined') {
            icb_vars.parser_config = prev;
        }
    }

    // ── Live events ───────────────────────────────────────────────────────────

    // Add non-linking consonant via input + Enter or Add button
    function addNonlinkingKey() {
        const val = $('#icb-nonlinking-input').val().trim();
        if (!val) return;
        const existing = collectNonlinking();
        if (!existing.includes(val)) {
            $('#icb-nonlinking-tags').append(buildTag(val));
        }
        $('#icb-nonlinking-input').val('');
    }

    $(document).on('click', '#icb-nonlinking-add-btn', addNonlinkingKey);

    $(document).on('keydown', '#icb-nonlinking-input', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); addNonlinkingKey(); }
    });

    // Remove non-linking tag
    $(document).on('click', '.icb-tag-remove', function () {
        $(this).closest('.icb-tag').remove();
    });

    // Add VCS row
    $(document).on('click', '#icb-vcs-add-btn', function () {
        var roman = $('#icb-vcs-input-roman').val().trim();
        var indic = $('#icb-vcs-input-indic').val().trim();
        if (!roman) {
            $('#icb-vcs-input-roman').focus();
            return;
        }
        var $tbody = $('#icb-vcs-tbody');
        var $row   = buildVcsRow(roman, indic);
        $tbody.append($row);
        $('#icb-vcs-input-roman').val('').focus();
        $('#icb-vcs-input-indic').val('');
    });

    // Remove VCS row
    $(document).on('click', '.icb-vcs-remove', function () {
        $(this).closest('tr').remove();
    });

    // Live test
    $(document).on('input', '#icb-cfg-test-input', runLiveTest);
    $(document).on('change input', '#icb-cfg-android-autocap, #icb-cfg-hosonto-key, #icb-cfg-cluster-breaker', runLiveTest);
    $(document).on('input', '.icb-vcs-roman, .icb-vcs-indic', runLiveTest);

    // ── Save config ───────────────────────────────────────────────────────────
    $(document).on('click', '#icb-save-config-btn', function () {
        const $btn     = $(this);
        const settings = collectSettings();

        // Validate single-character keys
        if (settings.hosonto_key.length > 3) {
            showConfigNotice('error', 'Hosonto key must be 1–3 characters.');
            return;
        }
        if (settings.cluster_breaker_key.length > 3) {
            showConfigNotice('error', 'Cluster-breaker key must be 1–3 characters.');
            return;
        }

        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Saving…');

        $.post(ajaxurl, {
            action:   'icb_save_config',
            config:   JSON.stringify(settings),
            security: icb_vars.nonce,
        })
        .done(function (response) {
            if (response.success) {
                // Persist to icb_vars so the live transliterator is in sync
                if (response.data.settings) {
                    icb_vars.parser_config = response.data.settings;
                    // Re-render the form from the confirmed server response so
                    // the displayed state always matches what was actually stored.
                    populateForm(response.data.settings);
                }
                showConfigNotice('success', '✔ ' + response.data.message);
            } else {
                showConfigNotice('error', response.data.message || 'Save failed.');
            }
        })
        .fail(function () {
            showConfigNotice('error', 'Network error – please try again.');
        })
        .always(function () {
            $btn.prop('disabled', false).text('Save Configuration');
        });
    });

    // ── Reset to defaults ─────────────────────────────────────────────────────
    $(document).on('click', '#icb-reset-config-btn', function () {
        if (!confirm('Reset all parser settings to their factory defaults? This cannot be undone.')) return;

        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Resetting…');

        $.post(ajaxurl, {
            action:   'icb_reset_config',
            security: icb_vars.nonce,
        })
        .done(function (response) {
            if (response.success) {
                if (response.data.settings) {
                    icb_vars.parser_config = response.data.settings;
                    populateForm(response.data.settings);
                }
                showConfigNotice('info', '↺ ' + response.data.message);
            } else {
                showConfigNotice('error', response.data.message || 'Reset failed.');
            }
        })
        .fail(function () {
            showConfigNotice('error', 'Network error – please try again.');
        })
        .always(function () {
            $btn.prop('disabled', false).text('Reset to Defaults');
        });
    });

    // ── Boot ──────────────────────────────────────────────────────────────────
    // Always populate — fall back to JS-side defaults if PHP didn't pass config
    // (e.g. first install before any save has been made).
    const _defaultConfig = {
        android_autocap_fix:         true,
        hosonto_key:                 "'",
        cluster_breaker_key:         'o',
        nonlinking_consonants:       ['ng', 'NG', 'Ng'],
        vowel_context_substitutions: { 'ng': 'ঙ', 'NG': 'ঞ' }
    };
    let bootConfig = _defaultConfig;
    if (typeof icb_vars !== 'undefined' && icb_vars.parser_config) {
        const saved    = icb_vars.parser_config;
        const rawVcs   = saved.vowel_context_substitutions;
        const hasVcs   = rawVcs && typeof rawVcs === 'object'
                         && !Array.isArray(rawVcs)
                         && Object.keys(rawVcs).length > 0;
        bootConfig = Object.assign({}, _defaultConfig, saved, {
            vowel_context_substitutions: hasVcs ? rawVcs : _defaultConfig.vowel_context_substitutions
        });
    }
    populateForm(bootConfig);
});

/* ============================================================
   Lexicon Mapping Tab – appended to config-ui.js
   ============================================================ */
jQuery(document).ready(function ($) {
    'use strict';

    function showLexiconNotice(type, msg) {
        const $n = $('<div class="icb-notice icb-notice-' + type + '">' + msg + '</div>');
        $('#icb-lexicon-notice-area').html($n);
        setTimeout(() => $n.fadeOut(400, function () { $(this).remove(); }), 5000);
    }

    function updateCount(group) {
        const count = $('#icb-lex-tbody-' + group + ' tr').length;
        $('#icb-lex-count-' + group).text('(' + count + ')');
    }

    function buildLexRow(roman, indic) {
        const $romanInput = $('<input type="text">')
            .addClass('icb-lex-roman small-text')
            .attr('maxlength', 10)
            .attr('placeholder', 'roman')
            .val(roman);

        const $indicInput = $('<input type="text">')
            .addClass('icb-lex-indic icb-lex-indic-input')
            .attr('maxlength', 6)
            .attr('placeholder', 'গ')
            .val(indic);

        const $removeBtn = $('<button type="button" class="button icb-lex-remove" title="Remove">✕</button>');

        return $('<tr>').append(
            $('<td>').append($romanInput),
            $('<td>').append($indicInput),
            $('<td>').append($removeBtn)
        );
    }

    function renderLexGroup(group, map) {
        const $tbody = $('#icb-lex-tbody-' + group);
        $tbody.empty();
        Object.entries(map).forEach(function ([roman, indic]) {
            $tbody.append(buildLexRow(roman, indic));
        });
        updateCount(group);
    }

    function populateLexicon(lex) {
        ['vowels', 'modifiers', 'consonants', 'numerics_specials'].forEach(function (group) {
            renderLexGroup(group, lex[group] || {});
        });
    }

    function collectLexicon() {
        const result = { vowels: {}, modifiers: {}, consonants: {}, numerics_specials: {} };
        ['vowels', 'modifiers', 'consonants', 'numerics_specials'].forEach(function (group) {
            $('#icb-lex-tbody-' + group + ' tr').each(function () {
                const roman = $(this).find('.icb-lex-roman').val().trim();
                const indic = $(this).find('.icb-lex-indic').val();
                if (roman !== '') result[group][roman] = indic;
            });
        });
        return result;
    }

    $(document).on('click', '.icb-lex-add-row', function () {
        const group  = $(this).data('group');
        const $tbody = $('#icb-lex-tbody-' + group);
        $tbody.append(buildLexRow('', ''));
        updateCount(group);
        $tbody.find('tr:last .icb-lex-roman').focus();
    });

    $(document).on('click', '.icb-lex-remove', function () {
        const $tr    = $(this).closest('tr');
        const $tbody = $tr.closest('tbody');
        const group  = $tbody.attr('id').replace('icb-lex-tbody-', '');
        $tr.remove();
        updateCount(group);
    });

    $(document).on('click', '#icb-save-lexicon-btn', function () {
        const $btn    = $(this);
        const lexicon = collectLexicon();

        for (const group of ['vowels', 'modifiers', 'consonants']) {
            if (Object.keys(lexicon[group]).length === 0) {
                showLexiconNotice('error', 'The "' + group + '" group must have at least one mapping.');
                return;
            }
        }

        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Saving…');

        $.post(ajaxurl, {
            action:   'icb_save_lexicon',
            lexicon:  JSON.stringify(lexicon),
            security: icb_vars.nonce,
        })
        .done(function (response) {
            if (response.success) {
                if (response.data.lexicon) icb_vars.lexicon = response.data.lexicon;
                showLexiconNotice('success', '✔ ' + response.data.message);
            } else {
                showLexiconNotice('error', response.data.message || 'Save failed.');
            }
        })
        .fail(function () {
            showLexiconNotice('error', 'Network error – please try again.');
        })
        .always(function () {
            $btn.prop('disabled', false).text('Save Lexicon');
        });
    });

    $(document).on('click', '#icb-reset-lexicon-btn', function () {
        if (!confirm('Reset the custom lexicon to factory defaults? Unsaved changes will be lost.')) return;

        const $btn = $(this);
        $btn.prop('disabled', true).html('<span class="icb-spinner"></span> Resetting…');

        $.post(ajaxurl, {
            action:   'icb_reset_lexicon',
            security: icb_vars.nonce,
        })
        .done(function (response) {
            if (response.success) {
                populateLexicon(response.data.lexicon);
                icb_vars.lexicon = response.data.lexicon;
                showLexiconNotice('info', '↺ ' + response.data.message);
            } else {
                showLexiconNotice('error', response.data.message || 'Reset failed.');
            }
        })
        .fail(function () {
            showLexiconNotice('error', 'Network error – please try again.');
        })
        .always(function () {
            $btn.prop('disabled', false).text('↺ Reset to Defaults');
        });
    });

    // ── Accordion toggle ──────────────────────────────────────────────────────
    $(document).on('click', '.icb-accordion-trigger', function () {
        const $item = $(this).closest('.icb-accordion-item');
        const isOpen = $item.hasClass('icb-accordion-item--open');

        if (isOpen) {
            // Collapse
            $item.removeClass('icb-accordion-item--open');
            $(this).attr('aria-expanded', 'false');
            $item.find('.icb-accordion-body').slideUp(180, function () {
                $(this).attr('hidden', true);
            });
        } else {
            // Expand
            $item.addClass('icb-accordion-item--open');
            $(this).attr('aria-expanded', 'true');
            $item.find('.icb-accordion-body').removeAttr('hidden').hide().slideDown(180);
        }
    });

    // ── Boot ─────────────────────────────────────────────────────────────────
    if (typeof icb_vars !== 'undefined' && icb_vars.lexicon) {
        populateLexicon(icb_vars.lexicon);
    }
});
