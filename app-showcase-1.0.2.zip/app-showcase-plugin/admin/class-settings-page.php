<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Settings_Page {

    const OPTION_GROUP = 'asc_settings_group';
    const OPTION_NAME  = 'asc_settings';
    const PAGE_SLUG    = 'app-showcase-settings';

    /* ── Register menu ─────────────────────────────────────────────── */
    public static function add_menu() {
        add_submenu_page(
            'edit.php?post_type=showcase_app',
            __( 'App Showcase Settings', 'app-showcase' ),
            __( 'Settings',              'app-showcase' ),
            'manage_options',
            self::PAGE_SLUG,
            [ __CLASS__, 'render_page' ]
        );
    }

    /* ── Register settings & fields ───────────────────────────────── */
    public static function register_settings() {
        register_setting( self::OPTION_GROUP, self::OPTION_NAME, [ __CLASS__, 'sanitize' ] );

        /* ── Section: Display ──── */
        add_settings_section( 'asc_display', __( 'Display Settings', 'app-showcase' ), '__return_false', self::PAGE_SLUG );
        $display_fields = [
            'default_layout'  => [ 'label' => __( 'Default Layout',      'app-showcase' ), 'type' => 'select',   'options' => [ 'grid' => 'Grid', 'list' => 'List' ] ],
            'default_columns' => [ 'label' => __( 'Default Columns',     'app-showcase' ), 'type' => 'select',   'options' => [ '1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6' ] ],
            'per_page'        => [ 'label' => __( 'Apps Per Page',        'app-showcase' ), 'type' => 'number',   'default' => 12 ],
            'default_orderby' => [ 'label' => __( 'Default Order By',    'app-showcase' ), 'type' => 'select',   'options' => [ 'date'=>'Date','title'=>'Title','sort_order'=>'Custom Order','rand'=>'Random' ] ],
            'default_order'   => [ 'label' => __( 'Default Order',       'app-showcase' ), 'type' => 'select',   'options' => [ 'DESC'=>'Descending','ASC'=>'Ascending' ] ],
        ];
        foreach ( $display_fields as $id => $field ) {
            add_settings_field( $id, $field['label'], [ __CLASS__, 'render_field' ], self::PAGE_SLUG, 'asc_display', array_merge( $field, ['id'=>$id] ) );
        }

        /* ── Section: Appearance ── */
        add_settings_section( 'asc_appearance', __( 'Appearance', 'app-showcase' ), '__return_false', self::PAGE_SLUG );
        $appearance_fields = [
            'accent_color'     => [ 'label' => __( 'Accent Color',           'app-showcase' ), 'type' => 'color',    'default' => '#4f46e5' ],
            'card_radius'      => [ 'label' => __( 'Card Border Radius (px)','app-showcase' ), 'type' => 'number',   'default' => 12 ],
            'card_shadow'      => [ 'label' => __( 'Card Shadow',            'app-showcase' ), 'type' => 'select',   'options' => [ 'none'=>'None','soft'=>'Soft','medium'=>'Medium','strong'=>'Strong' ] ],
            'card_style'       => [ 'label' => __( 'Card Style',             'app-showcase' ), 'type' => 'select',   'options' => [ 'default'=>'Default','bordered'=>'Bordered','minimal'=>'Minimal','glass'=>'Glass' ] ],
            'image_ratio'      => [ 'label' => __( 'Image Aspect Ratio',     'app-showcase' ), 'type' => 'select',   'options' => [ '16/9'=>'16:9','4/3'=>'4:3','1/1'=>'1:1','3/2'=>'3:2' ] ],
            'custom_css'       => [ 'label' => __( 'Custom CSS',             'app-showcase' ), 'type' => 'textarea', 'default' => '' ],
        ];
        foreach ( $appearance_fields as $id => $field ) {
            add_settings_field( $id, $field['label'], [ __CLASS__, 'render_field' ], self::PAGE_SLUG, 'asc_appearance', array_merge( $field, ['id'=>$id] ) );
        }

        /* ── Section: Card Fields ── */
        add_settings_section( 'asc_card_components', __( 'Card Fields', 'app-showcase' ), '__return_false', self::PAGE_SLUG );
        foreach ( ASC_Shortcode::card_fields() as $id => $cfg ) {
            add_settings_field(
                $id,
                __( $cfg['label'], 'app-showcase' ),
                [ __CLASS__, 'render_field' ],
                self::PAGE_SLUG,
                'asc_card_components',
                [ 'id' => $id, 'type' => 'toggle', 'default' => $cfg['default'] ]
            );
        }

        /* ── Section: SEO / Single Page ── */
        add_settings_section( 'asc_single', __( 'Single App Page', 'app-showcase' ), '__return_false', self::PAGE_SLUG );
        $single_fields = [
            'single_template' => [ 'label' => __( 'Use Plugin Template', 'app-showcase' ), 'type' => 'toggle',   'default' => '1' ],
            'single_sidebar'  => [ 'label' => __( 'Show Sidebar',        'app-showcase' ), 'type' => 'toggle',   'default' => '0' ],
        ];
        foreach ( $single_fields as $id => $field ) {
            add_settings_field( $id, $field['label'], [ __CLASS__, 'render_field' ], self::PAGE_SLUG, 'asc_single', array_merge( $field, ['id'=>$id] ) );
        }
    }

    /* ── Render settings page ──────────────────────────────────────── */
    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $opts = get_option( self::OPTION_NAME, [] );
        ?>
        <div class="wrap asc-settings-wrap">
            <div class="asc-settings-header">
                <div class="asc-settings-logo">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
                </div>
                <div>
                    <h1><?php _e( 'App Showcase Settings', 'app-showcase' ); ?></h1>
                    <p class="asc-settings-subtitle"><?php _e( 'Configure global defaults for all [app_showcase] shortcodes.', 'app-showcase' ); ?></p>
                </div>
            </div>

            <?php settings_errors(); ?>

            <!-- Shortcode Reference -->
            <div class="asc-shortcode-ref">
                <h3><?php _e( '📋 Shortcode Reference', 'app-showcase' ); ?></h3>
                <code>[app_showcase]</code> — Use global defaults<br>
                <code>[app_showcase layout="list" columns="2" per_page="6"]</code><br>
                <code>[app_showcase category="web-apps" show_filter="false"]</code><br>
                <code>[app_showcase orderby="title" order="ASC" featured="true"]</code><br>
                <strong><?php _e( 'Per-field overrides (override global Card Fields settings):', 'app-showcase' ); ?></strong><br>
                <code>[app_showcase show_author="false" show_screenshots="true" show_tech_stack="false"]</code><br>
                <code>[app_showcase show_buttons="true" show_app_url="true" show_repo_url="false" show_demo_url="false"]</code>
                <p class="description"><?php _e( 'All attributes are optional. Per-field show_* attributes accept "true" or "false" and override the global Card Fields settings only for that shortcode instance.', 'app-showcase' ); ?></p>
            </div>

            <form method="post" action="options.php" class="asc-settings-form">
                <?php settings_fields( self::OPTION_GROUP ); ?>

                <div class="asc-settings-tabs">
                    <button type="button" class="asc-tab active" data-tab="display"><?php _e( 'Display',    'app-showcase' ); ?></button>
                    <button type="button" class="asc-tab"        data-tab="appearance"><?php _e( 'Appearance','app-showcase' ); ?></button>
                    <button type="button" class="asc-tab"        data-tab="components"><?php _e( 'Card Fields', 'app-showcase' ); ?></button>
                    <button type="button" class="asc-tab"        data-tab="single"><?php _e( 'Single Page','app-showcase' ); ?></button>
                </div>

                <div id="asc-tab-display" class="asc-tab-panel active">
                    <table class="form-table" role="presentation">
                        <?php do_settings_fields( self::PAGE_SLUG, 'asc_display' ); ?>
                    </table>
                </div>

                <div id="asc-tab-appearance" class="asc-tab-panel">
                    <table class="form-table" role="presentation">
                        <?php do_settings_fields( self::PAGE_SLUG, 'asc_appearance' ); ?>
                    </table>
                </div>

                <div id="asc-tab-components" class="asc-tab-panel">
                    <p class="description"><?php _e( 'Toggle individual fields shown on each app card. These are global defaults — individual <code>[app_showcase]</code> shortcodes can override any field with <code>show_fieldname="true|false"</code>.', 'app-showcase' ); ?></p>
                    <table class="form-table" role="presentation">
                        <?php do_settings_fields( self::PAGE_SLUG, 'asc_card_components' ); ?>
                    </table>
                </div>

                <div id="asc-tab-single" class="asc-tab-panel">
                    <table class="form-table" role="presentation">
                        <?php do_settings_fields( self::PAGE_SLUG, 'asc_single' ); ?>
                    </table>
                </div>

                <?php submit_button( __( 'Save Settings', 'app-showcase' ) ); ?>
            </form>
        </div>
        <?php
    }

    /* ── Render individual setting field ───────────────────────────── */
    public static function render_field( $args ) {
        $opts    = get_option( self::OPTION_NAME, [] );
        $id      = $args['id'];
        $type    = $args['type'];
        $default = $args['default'] ?? '';
        $value   = $opts[ $id ] ?? $default;
        $name    = self::OPTION_NAME . '[' . $id . ']';

        switch ( $type ) {
            case 'select':
                echo '<select name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" class="regular-text">';
                foreach ( $args['options'] as $val => $label ) {
                    echo '<option value="' . esc_attr( $val ) . '"' . selected( $value, $val, false ) . '>' . esc_html( $label ) . '</option>';
                }
                echo '</select>';
                break;
            case 'color':
                echo '<input type="text" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $value ?: $default ) . '" class="asc-color-picker">';
                break;
            case 'toggle':
                echo '<label class="asc-toggle"><input type="checkbox" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="1"' . checked( $value, '1', false ) . '><span class="asc-toggle-slider"></span></label>';
                break;
            case 'textarea':
                echo '<textarea name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" class="large-text code" rows="8">' . esc_textarea( $value ) . '</textarea>';
                break;
            case 'number':
                echo '<input type="number" name="' . esc_attr( $name ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $value ?: $default ) . '" class="small-text" min="1">';
                break;
        }
    }

    /* ── Sanitize on save ──────────────────────────────────────────── */
    public static function sanitize( $input ) {
        $output = [];
        if ( ! is_array( $input ) ) return $output;

        // All show_* field keys are toggles
        $toggle_keys = array_keys( ASC_Shortcode::card_fields() );
        $toggle_keys = array_merge( $toggle_keys, [ 'single_template', 'single_sidebar' ] );

        foreach ( $input as $key => $value ) {
            if ( in_array( $key, $toggle_keys ) ) {
                $output[ $key ] = $value === '1' ? '1' : '0';
            } elseif ( $key === 'accent_color' ) {
                $output[ $key ] = sanitize_hex_color( $value );
            } elseif ( $key === 'custom_css' ) {
                $output[ $key ] = wp_strip_all_tags( $value );
            } else {
                $output[ $key ] = sanitize_text_field( $value );
            }
        }

        // Ensure every toggle that was unchecked is saved as '0'
        foreach ( $toggle_keys as $toggle ) {
            if ( ! isset( $output[ $toggle ] ) ) {
                $output[ $toggle ] = '0';
            }
        }

        return $output;
    }
}
