<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_App_List_Columns {

    public static function init() {
        add_filter( 'manage_showcase_app_posts_columns',       [ __CLASS__, 'add_columns' ] );
        add_action( 'manage_showcase_app_posts_custom_column', [ __CLASS__, 'render_column' ], 10, 2 );
        add_filter( 'manage_edit-showcase_app_sortable_columns', [ __CLASS__, 'sortable_columns' ] );
    }

    public static function add_columns( $columns ) {
        $new = [];
        foreach ( $columns as $key => $label ) {
            $new[ $key ] = $label;
            if ( $key === 'title' ) {
                $new['asc_thumbnail'] = __( 'Thumbnail',   'app-showcase' );
                $new['asc_version']   = __( 'Version',     'app-showcase' );
                $new['asc_featured']  = __( 'Featured',    'app-showcase' );
                $new['asc_app_url']   = __( 'Live URL',    'app-showcase' );
                $new['asc_order']     = __( 'Sort Order',  'app-showcase' );
            }
        }
        return $new;
    }

    public static function render_column( $column, $post_id ) {
        switch ( $column ) {
            case 'asc_thumbnail':
                $url = get_the_post_thumbnail_url( $post_id, 'thumbnail' );
                if ( $url ) {
                    echo '<img src="' . esc_url( $url ) . '" style="width:60px;height:45px;object-fit:cover;border-radius:4px;">';
                } else {
                    echo '<span style="color:#ccc;">—</span>';
                }
                break;
            case 'asc_version':
                $v = get_post_meta( $post_id, 'asc_version', true );
                echo $v ? '<code>' . esc_html( $v ) . '</code>' : '—';
                break;
            case 'asc_featured':
                $f = get_post_meta( $post_id, 'asc_featured', true );
                echo $f === '1' ? '<span style="color:#f59e0b;font-size:18px;">&#9733;</span>' : '<span style="color:#e5e7eb;font-size:18px;">&#9733;</span>';
                break;
            case 'asc_app_url':
                $u = get_post_meta( $post_id, 'asc_app_url', true );
                echo $u ? '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">&#128279; ' . esc_html( parse_url( $u, PHP_URL_HOST ) ) . '</a>' : '—';
                break;
            case 'asc_order':
                $o = get_post_meta( $post_id, 'asc_sort_order', true );
                echo $o !== '' ? intval( $o ) : '—';
                break;
        }
    }

    public static function sortable_columns( $columns ) {
        $columns['asc_order']   = 'asc_sort_order';
        $columns['asc_version'] = 'asc_version';
        return $columns;
    }
}

ASC_App_List_Columns::init();
