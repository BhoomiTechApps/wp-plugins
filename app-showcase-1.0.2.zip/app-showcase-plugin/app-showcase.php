<?php
/**
 * Plugin Name: App Showcase
 * Plugin URI:  https://example.com/app-showcase
 * Description: Display custom-developed applications in a configurable card grid or list with search, sort, and filter options.
 * Version:     1.0.0
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: app-showcase
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ASC_VERSION',     '1.0.0' );
define( 'ASC_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'ASC_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'ASC_PLUGIN_FILE', __FILE__ );

require_once ASC_PLUGIN_DIR . 'includes/class-post-type.php';
require_once ASC_PLUGIN_DIR . 'includes/class-taxonomy.php';
require_once ASC_PLUGIN_DIR . 'includes/class-meta-boxes.php';
require_once ASC_PLUGIN_DIR . 'includes/class-shortcode.php';
require_once ASC_PLUGIN_DIR . 'includes/class-ajax.php';
require_once ASC_PLUGIN_DIR . 'admin/class-settings-page.php';
require_once ASC_PLUGIN_DIR . 'admin/class-app-list-columns.php';
require_once ASC_PLUGIN_DIR . 'includes/class-template-loader.php';

register_activation_hook( __FILE__, 'asc_activate' );
register_deactivation_hook( __FILE__, 'asc_deactivate' );

function asc_activate() {
    ASC_Post_Type::register();
    ASC_Taxonomy::register();
    flush_rewrite_rules();
}

function asc_deactivate() {
    flush_rewrite_rules();
}

add_action( 'init', [ 'ASC_Post_Type', 'register' ] );
add_action( 'init', [ 'ASC_Taxonomy', 'register' ] );
add_action( 'add_meta_boxes', [ 'ASC_Meta_Boxes', 'add' ] );
add_action( 'save_post', [ 'ASC_Meta_Boxes', 'save' ] );
add_action( 'admin_menu', [ 'ASC_Settings_Page', 'add_menu' ] );
add_action( 'admin_init', [ 'ASC_Settings_Page', 'register_settings' ] );
add_action( 'wp_enqueue_scripts', 'asc_enqueue_public_assets' );
add_action( 'admin_enqueue_scripts', 'asc_enqueue_admin_assets' );
add_shortcode( 'app_showcase', [ 'ASC_Shortcode', 'render' ] );
add_action( 'wp_ajax_asc_filter_apps',        [ 'ASC_Ajax', 'filter_apps' ] );
add_action( 'wp_ajax_nopriv_asc_filter_apps', [ 'ASC_Ajax', 'filter_apps' ] );

/* ── Enqueue public assets ─────────────────────────────────────────── */
function asc_enqueue_public_assets() {
    wp_enqueue_style(
        'asc-public',
        ASC_PLUGIN_URL . 'public/css/public.css',
        [],
        ASC_VERSION
    );

    // Inject CSS custom properties from global settings
    $opts       = get_option( 'asc_settings', [] );
    $accent     = sanitize_hex_color( $opts['accent_color'] ?? '#4f46e5' );
    $radius     = intval( $opts['card_radius'] ?? 12 );
    $img_ratio  = sanitize_text_field( $opts['image_ratio'] ?? '16/9' );
    $custom_css = wp_strip_all_tags( $opts['custom_css'] ?? '' );

    $inline = "
        .asc-showcase {
            --asc-accent: {$accent};
            --asc-accent-hover: {$accent};
            --asc-radius: {$radius}px;
        }
        .asc-card__thumbnail { aspect-ratio: {$img_ratio}; }
    ";
    if ( $custom_css ) {
        $inline .= "\n" . $custom_css;
    }
    wp_add_inline_style( 'asc-public', $inline );

    wp_enqueue_script(
        'asc-public',
        ASC_PLUGIN_URL . 'public/js/public.js',
        [ 'jquery' ],
        ASC_VERSION,
        true
    );
    wp_localize_script( 'asc-public', 'ascData', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'asc_nonce' ),
    ]);
}

/* ── Enqueue admin assets ──────────────────────────────────────────── */
function asc_enqueue_admin_assets( $hook ) {
    $allowed_hooks = [
        'post.php', 'post-new.php',
        'toplevel_page_app-showcase-settings',
        'app-showcase_page_app-showcase-settings',
    ];
    // Also allow on showcase_app edit screens
    $screen = get_current_screen();
    if ( ! $screen ) return;
    if ( $screen->post_type !== 'showcase_app' && strpos( $hook, 'app-showcase' ) === false ) return;

    wp_enqueue_style(  'wp-color-picker' );
    wp_enqueue_style(
        'asc-admin',
        ASC_PLUGIN_URL . 'admin/css/admin.css',
        [ 'wp-color-picker' ],
        ASC_VERSION
    );
    wp_enqueue_media();
    wp_enqueue_script(
        'asc-admin',
        ASC_PLUGIN_URL . 'admin/js/admin.js',
        [ 'jquery', 'wp-color-picker' ],
        ASC_VERSION,
        true
    );
}
