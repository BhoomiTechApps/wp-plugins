=== App Showcase ===
Contributors: yourname
Tags: portfolio, apps, showcase, grid, filter
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Display custom-developed applications in a configurable card grid or list with search, sort, and filter options.

== Description ==

**App Showcase** lets you display your software portfolio with a polished, filterable card grid or list — no coding required.

= Features =

* **Custom Post Type** — `showcase_app` with rich metadata fields
* **Taxonomies** — Categories, Tags, and Statuses (hierarchical)
* **Card Display** — Grid or list layout with live toggle
* **Search** — Real-time AJAX search with debounce
* **Filter Panel** — Chip-based filters by category, status, and tag
* **Sort** — Newest, oldest, A→Z, Z→A, custom order
* **Load More** — AJAX pagination (no page reload)
* **Single App Page** — Optional plugin-managed single template with hero, meta pills, screenshots gallery
* **Global Settings** — Accent color, card radius, shadow, image ratio, per-page count, default layout, and more
* **Shortcode** with per-instance attribute overrides

= Shortcode Usage =

Basic:
`[app_showcase]`

With options:
`[app_showcase layout="list" columns="2" per_page="6" category="web-apps"]`

Featured only:
`[app_showcase featured="true" show_filter="false"]`

= Shortcode Attributes =

| Attribute | Values | Default |
|---|---|---|
| layout | grid, list | global setting |
| columns | 1–6 | global setting |
| per_page | number | global setting |
| orderby | date, title, sort_order, rand | global setting |
| order | ASC, DESC | global setting |
| category | slug(s), comma-separated | — |
| tag | slug(s), comma-separated | — |
| status | slug(s), comma-separated | — |
| featured | true, false | — |
| show_search | true, false | true |
| show_filter | true, false | true |
| show_sort | true, false | true |
| show_layout_toggle | true, false | true |

= App Fields =

Each app post supports:
- Title, Description (editor), Featured Image
- Live App URL, Repository URL, Demo/Video URL
- Version, Tech Stack, Release Date
- Author Name & URL
- Badge Text & Badge Color
- Screenshots Gallery
- Featured toggle
- Custom Sort Order

== Installation ==

1. Upload the `app-showcase` folder to `/wp-content/plugins/`
2. Activate via **Plugins → Installed Plugins**
3. Go to **App Showcase → Add New App** to create your first app
4. Use `[app_showcase]` on any page or post
5. Configure defaults under **App Showcase → Settings**

== Changelog ==

= 1.0.0 =
* Initial release
