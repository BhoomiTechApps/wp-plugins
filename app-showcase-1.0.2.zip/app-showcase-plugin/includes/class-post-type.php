<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Post_Type {

    public static function register() {
        $labels = [
            'name'               => __( 'Applications',          'app-showcase' ),
            'singular_name'      => __( 'Application',           'app-showcase' ),
            'menu_name'          => __( 'App Showcase',          'app-showcase' ),
            'add_new'            => __( 'Add New App',           'app-showcase' ),
            'add_new_item'       => __( 'Add New Application',   'app-showcase' ),
            'edit_item'          => __( 'Edit Application',      'app-showcase' ),
            'new_item'           => __( 'New Application',       'app-showcase' ),
            'view_item'          => __( 'View Application',      'app-showcase' ),
            'search_items'       => __( 'Search Applications',   'app-showcase' ),
            'not_found'          => __( 'No applications found', 'app-showcase' ),
            'not_found_in_trash' => __( 'No applications in trash', 'app-showcase' ),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'menu_icon'          => 'dashicons-layout',
            'menu_position'      => 25,
            'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
            'has_archive'        => true,
            'rewrite'            => [ 'slug' => 'apps' ],
            'show_in_rest'       => true,
        ];

        register_post_type( 'showcase_app', $args );
    }
}
