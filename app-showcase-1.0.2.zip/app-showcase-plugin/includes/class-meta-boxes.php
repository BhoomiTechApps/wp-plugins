<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Meta_Boxes {

    /* ── Field definitions ─────────────────────────────────────────── */
    public static function fields() {
        return [
            'asc_app_url'         => [ 'label' => 'Live App URL',        'type' => 'url',      'placeholder' => 'https://' ],
            'asc_repo_url'        => [ 'label' => 'Repository URL',      'type' => 'url',      'placeholder' => 'https://github.com/…' ],
            'asc_demo_url'        => [ 'label' => 'Demo / Video URL',    'type' => 'url',      'placeholder' => 'https://' ],
            'asc_version'         => [ 'label' => 'Version',             'type' => 'text',     'placeholder' => '1.0.0' ],
            'asc_tech_stack'      => [ 'label' => 'Tech Stack',          'type' => 'text',     'placeholder' => 'React, Node.js, PostgreSQL' ],
            'asc_release_date'    => [ 'label' => 'Release Date',        'type' => 'date',     'placeholder' => '' ],
            'asc_author_name'     => [ 'label' => 'Author / Team',       'type' => 'text',     'placeholder' => 'Your Name' ],
            'asc_author_url'      => [ 'label' => 'Author URL',          'type' => 'url',      'placeholder' => 'https://' ],
            'asc_badge_text'      => [ 'label' => 'Badge Text',          'type' => 'text',     'placeholder' => 'New, Popular, Beta…' ],
            'asc_badge_color'     => [ 'label' => 'Badge Color',         'type' => 'color',    'placeholder' => '' ],
            'asc_screenshots'     => [ 'label' => 'Screenshots Gallery', 'type' => 'gallery',  'placeholder' => '' ],
            'asc_featured'        => [ 'label' => 'Featured App',        'type' => 'checkbox', 'placeholder' => '' ],
            'asc_sort_order'      => [ 'label' => 'Sort Order',          'type' => 'number',   'placeholder' => '0' ],
            'asc_short_desc'      => [ 'label' => 'Short Description',   'type' => 'textarea', 'placeholder' => 'One-liner shown on card…' ],
        ];
    }

    /* ── Register meta boxes ───────────────────────────────────────── */
    public static function add() {
        add_meta_box(
            'asc_app_details',
            __( 'Application Details', 'app-showcase' ),
            [ __CLASS__, 'render_details' ],
            'showcase_app',
            'normal',
            'high'
        );
        add_meta_box(
            'asc_app_media',
            __( 'Screenshots Gallery', 'app-showcase' ),
            [ __CLASS__, 'render_gallery' ],
            'showcase_app',
            'normal',
            'default'
        );
    }

    /* ── Render details box ────────────────────────────────────────── */
    public static function render_details( $post ) {
        wp_nonce_field( 'asc_save_meta', 'asc_nonce' );
        $fields = self::fields();
        unset( $fields['asc_screenshots'] ); // handled in gallery box
        echo '<div class="asc-meta-grid">';
        foreach ( $fields as $key => $field ) {
            $value = get_post_meta( $post->ID, $key, true );
            self::render_field( $key, $field, $value );
        }
        echo '</div>';
    }

    /* ── Render gallery box ────────────────────────────────────────── */
    public static function render_gallery( $post ) {
        $ids = get_post_meta( $post->ID, 'asc_screenshots', true );
        ?>
        <div class="asc-gallery-wrap">
            <input type="hidden" name="asc_screenshots" id="asc_screenshots" value="<?php echo esc_attr( $ids ); ?>">
            <div id="asc-gallery-preview" class="asc-gallery-preview">
                <?php
                if ( $ids ) {
                    foreach ( explode( ',', $ids ) as $img_id ) {
                        $img_id = (int) $img_id;
                        $url    = wp_get_attachment_image_url( $img_id, 'thumbnail' );
                        if ( $url ) {
                            echo '<div class="asc-gallery-thumb" data-id="' . $img_id . '"><img src="' . esc_url( $url ) . '"><span class="asc-remove-img dashicons dashicons-no-alt"></span></div>';
                        }
                    }
                }
                ?>
            </div>
            <button type="button" class="button" id="asc-gallery-add">
                <span class="dashicons dashicons-plus-alt2"></span> <?php _e( 'Add Screenshots', 'app-showcase' ); ?>
            </button>
        </div>
        <?php
    }

    /* ── Render individual field ───────────────────────────────────── */
    private static function render_field( $key, $field, $value ) {
        $type        = $field['type'];
        $label       = $field['label'];
        $placeholder = $field['placeholder'];

        echo '<div class="asc-field asc-field--' . esc_attr( $type ) . '">';
        echo '<label for="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</label>';

        switch ( $type ) {
            case 'textarea':
                echo '<textarea name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" rows="3" placeholder="' . esc_attr( $placeholder ) . '">' . esc_textarea( $value ) . '</textarea>';
                break;
            case 'checkbox':
                echo '<label class="asc-toggle"><input type="checkbox" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="1"' . checked( $value, '1', false ) . '><span class="asc-toggle-slider"></span></label>';
                break;
            case 'color':
                echo '<input type="text" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" class="asc-color-picker">';
                break;
            default:
                echo '<input type="' . esc_attr( $type ) . '" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" placeholder="' . esc_attr( $placeholder ) . '">';
        }

        echo '</div>';
    }

    /* ── Save meta ─────────────────────────────────────────────────── */
    public static function save( $post_id ) {
        if ( ! isset( $_POST['asc_nonce'] ) || ! wp_verify_nonce( $_POST['asc_nonce'], 'asc_save_meta' ) ) return;
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        foreach ( self::fields() as $key => $field ) {
            if ( ! array_key_exists( $key, $_POST ) ) {
                if ( $field['type'] === 'checkbox' ) {
                    update_post_meta( $post_id, $key, '0' );
                }
                continue;
            }
            $raw = $_POST[ $key ];
            if ( $field['type'] === 'url' ) {
                $value = esc_url_raw( $raw );
            } elseif ( $field['type'] === 'number' ) {
                $value = intval( $raw );
            } elseif ( $field['type'] === 'checkbox' ) {
                $value = '1';
            } elseif ( $field['type'] === 'textarea' ) {
                $value = sanitize_textarea_field( $raw );
            } elseif ( $field['type'] === 'gallery' ) {
                $value = sanitize_text_field( $raw );
            } else {
                $value = sanitize_text_field( $raw );
            }
            update_post_meta( $post_id, $key, $value );
        }

        // Screenshots (gallery) is not in fields() — save separately
        if ( isset( $_POST['asc_screenshots'] ) ) {
            update_post_meta( $post_id, 'asc_screenshots', sanitize_text_field( $_POST['asc_screenshots'] ) );
        }
    }
}
