<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Template_Loader {

    public static function init() {
        add_filter( 'single_template', [ __CLASS__, 'load_single_template' ] );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'enqueue_single_styles' ] );
        add_action( 'widgets_init', [ __CLASS__, 'register_sidebar' ] );
    }

    /**
     * Override single template with plugin version if setting enabled.
     */
    public static function load_single_template( $template ) {
        global $post;

        if ( $post->post_type !== 'showcase_app' ) {
            return $template;
        }

        $opts = get_option( 'asc_settings', [] );
        if ( ( $opts['single_template'] ?? '1' ) !== '1' ) {
            return $template;
        }

        $plugin_template = ASC_PLUGIN_DIR . 'templates/single-showcase_app.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }

        return $template;
    }

    /**
     * Enqueue single-page stylesheet only on single app pages.
     */
    public static function enqueue_single_styles() {
        if ( ! is_singular( 'showcase_app' ) ) return;

        $opts = get_option( 'asc_settings', [] );
        if ( ( $opts['single_template'] ?? '1' ) !== '1' ) return;

        wp_enqueue_style(
            'asc-single',
            ASC_PLUGIN_URL . 'public/css/single.css',
            [ 'asc-public' ],
            ASC_VERSION
        );

        // Inject custom CSS & CSS vars from global settings
        $accent     = sanitize_hex_color( $opts['accent_color']  ?? '#4f46e5' );
        $radius     = intval( $opts['card_radius'] ?? 12 );
        $img_ratio  = sanitize_text_field( $opts['image_ratio']  ?? '16/9' );
        $custom_css = wp_strip_all_tags( $opts['custom_css']     ?? '' );

        $inline = "
            .asc-showcase, .asc-single {
                --asc-accent: {$accent};
                --asc-radius: {$radius}px;
                --asc-img-ratio: {$img_ratio};
            }
        ";

        if ( $custom_css ) {
            $inline .= "\n" . $custom_css;
        }

        wp_add_inline_style( 'asc-single', $inline );
    }

    /**
     * Register optional sidebar for single app pages.
     */
    public static function register_sidebar() {
        register_sidebar([
            'name'          => __( 'App Showcase Sidebar', 'app-showcase' ),
            'id'            => 'asc-sidebar',
            'description'   => __( 'Widgets appear in the sidebar on single app pages (when sidebar is enabled in App Showcase Settings).', 'app-showcase' ),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ]);
    }
}

ASC_Template_Loader::init();
