<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Shortcode {

    /**
     * All card field keys and their defaults.
     * Used for both shortcode atts and global settings.
     */
    public static function card_fields() {
        return [
            'show_thumbnail'    => [ 'label' => 'Thumbnail / Feature Image',  'default' => '1' ],
            'show_description'  => [ 'label' => 'Short Description',          'default' => '1' ],
            'show_full_content' => [ 'label' => 'Full Content (editor)',       'default' => '0' ],
            'show_categories'   => [ 'label' => 'Categories',                 'default' => '1' ],
            'show_tags'         => [ 'label' => 'Tags',                       'default' => '1' ],
            'show_status'       => [ 'label' => 'Status Pills',               'default' => '1' ],
            'show_version'      => [ 'label' => 'Version',                    'default' => '1' ],
            'show_tech_stack'   => [ 'label' => 'Tech Stack',                 'default' => '1' ],
            'show_release_date' => [ 'label' => 'Release Date',               'default' => '1' ],
            'show_author'       => [ 'label' => 'Author / Developer',         'default' => '1' ],
            'show_screenshots'  => [ 'label' => 'Screenshots (card preview)', 'default' => '0' ],
            'show_badge'        => [ 'label' => 'Badge',                      'default' => '1' ],
            'show_buttons'      => [ 'label' => 'Action Buttons',             'default' => '1' ],
            'show_app_url'      => [ 'label' => '→ Live App Button',          'default' => '1' ],
            'show_demo_url'     => [ 'label' => '→ Demo Button',              'default' => '1' ],
            'show_repo_url'     => [ 'label' => '→ Source Code Button',       'default' => '1' ],
        ];
    }

    /**
     * [app_showcase] shortcode
     *
     * Layout / query atts:
     *   layout, columns, per_page, category, tag, status, featured,
     *   orderby, order, show_search, show_filter, show_sort, show_layout_toggle
     *
     * Per-field visibility (override global settings):
     *   show_thumbnail, show_description, show_full_content, show_categories,
     *   show_tags, show_status, show_version, show_tech_stack, show_release_date,
     *   show_author, show_screenshots, show_badge, show_buttons,
     *   show_app_url, show_demo_url, show_repo_url
     *
     * All per-field atts accept: "true" | "false" | "" (empty = use global setting)
     */
    public static function render( $atts ) {
        $opts = get_option( 'asc_settings', [] );

        // Build field defaults: empty string means "inherit from global"
        $field_defaults = array_fill_keys( array_keys( self::card_fields() ), '' );

        $atts = shortcode_atts( array_merge([
            'layout'             => '',   // empty = use global
            'columns'            => '',   // empty = use global
            'per_page'           => '',
            'category'           => '',
            'tag'                => '',
            'status'             => '',
            'featured'           => '',
            'orderby'            => '',
            'order'              => '',
            'show_search'        => 'true',
            'show_filter'        => 'true',
            'show_sort'          => 'true',
            'show_layout_toggle' => 'true',
        ], $field_defaults ), $atts, 'app_showcase' );

        // Resolve layout: shortcode → global → hardcoded default
        $layout  = $atts['layout']  !== '' ? $atts['layout']  : ( $opts['default_layout']  ?? 'grid' );
        $columns = $atts['columns'] !== '' ? $atts['columns'] : ( $opts['default_columns'] ?? '3' );
        $layout  = in_array( $layout, ['grid','list'] ) ? $layout : 'grid';
        $columns = max( 1, min( 6, intval( $columns ) ) );

        $per_page = $atts['per_page'] !== '' ? intval( $atts['per_page'] ) : intval( $opts['per_page'] ?? 12 );
        $per_page = max( 1, $per_page );

        $orderby = $atts['orderby'] !== '' ? sanitize_key( $atts['orderby'] ) : sanitize_key( $opts['default_orderby'] ?? 'date' );
        $order   = $atts['order']   !== '' ? strtoupper( $atts['order'] )     : strtoupper( $opts['default_order']   ?? 'DESC' );
        $order   = ( $order === 'ASC' ) ? 'ASC' : 'DESC';

        // Resolve per-field visibility: shortcode → global → field default
        $vis = [];
        foreach ( self::card_fields() as $key => $cfg ) {
            if ( $atts[ $key ] !== '' ) {
                // Shortcode explicitly sets it
                $vis[ $key ] = ( $atts[ $key ] === 'true' || $atts[ $key ] === '1' );
            } else {
                // Fall back to global settings, then field default
                $global_val = $opts[ $key ] ?? $cfg['default'];
                $vis[ $key ] = ( $global_val === '1' || $global_val === 1 || $global_val === true );
            }
        }

        // Query
        $query_args = [
            'post_type'      => 'showcase_app',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => 1,
        ];
        if ( $orderby === 'sort_order' ) {
            $query_args['meta_key'] = 'asc_sort_order';
            $query_args['orderby']  = 'meta_value_num';
        } elseif ( $orderby === 'rand' ) {
            $query_args['orderby'] = 'rand';
        } else {
            $query_args['orderby'] = in_array( $orderby, ['date','title','modified'] ) ? $orderby : 'date';
        }
        $query_args['order'] = $order;

        $tax_query = [];
        if ( $atts['category'] ) {
            $tax_query[] = [ 'taxonomy' => 'app_category', 'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $atts['category'] ) ) ];
        }
        if ( $atts['tag'] ) {
            $tax_query[] = [ 'taxonomy' => 'app_tag',      'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $atts['tag'] ) ) ];
        }
        if ( $atts['status'] ) {
            $tax_query[] = [ 'taxonomy' => 'app_status',   'field' => 'slug', 'terms' => array_map( 'trim', explode( ',', $atts['status'] ) ) ];
        }
        if ( count( $tax_query ) > 1 ) $tax_query['relation'] = 'AND';
        if ( $tax_query ) $query_args['tax_query'] = $tax_query;
        if ( $atts['featured'] === 'true' ) {
            $query_args['meta_query'] = [[ 'key' => 'asc_featured', 'value' => '1' ]];
        }

        $query      = new WP_Query( $query_args );
        $categories = get_terms([ 'taxonomy' => 'app_category', 'hide_empty' => true ]);
        $tags        = get_terms([ 'taxonomy' => 'app_tag',      'hide_empty' => true ]);
        $statuses    = get_terms([ 'taxonomy' => 'app_status',   'hide_empty' => true ]);

        // Encode vis map + columns for JS/AJAX use
        $vis_json     = esc_attr( json_encode( $vis ) );
        $accent_color = sanitize_hex_color( $opts['accent_color'] ?? '#4f46e5' );
        $card_radius  = intval( $opts['card_radius'] ?? 12 );
        $img_ratio    = esc_attr( $opts['image_ratio'] ?? '16/9' );
        $card_style   = esc_attr( $opts['card_style']  ?? 'default' );
        $card_shadow  = esc_attr( $opts['card_shadow'] ?? 'soft' );

        ob_start();
        ?>
        <div class="asc-showcase asc-layout-<?php echo esc_attr( $layout ); ?> asc-card-style-<?php echo $card_style; ?> asc-shadow-<?php echo $card_shadow; ?>"
             data-layout="<?php echo esc_attr( $layout ); ?>"
             data-columns="<?php echo esc_attr( $columns ); ?>"
             data-per-page="<?php echo esc_attr( $per_page ); ?>"
             data-orderby="<?php echo esc_attr( $orderby ); ?>"
             data-order="<?php echo esc_attr( $order ); ?>"
             data-vis="<?php echo $vis_json; ?>"
             style="--asc-columns:<?php echo $columns; ?>;--asc-accent:<?php echo $accent_color; ?>;--asc-radius:<?php echo $card_radius; ?>px;">

            <?php // ── Toolbar ────────────────────────────────────────── ?>
            <div class="asc-toolbar">
                <?php if ( $atts['show_search'] === 'true' ) : ?>
                <div class="asc-search-wrap">
                    <span class="asc-search-icon">&#128269;</span>
                    <input type="search" class="asc-search" placeholder="<?php esc_attr_e( 'Search applications…', 'app-showcase' ); ?>">
                </div>
                <?php endif; ?>
                <div class="asc-toolbar-right">
                    <?php if ( $atts['show_filter'] === 'true' && ( $categories || $tags || $statuses ) ) : ?>
                    <button class="asc-btn asc-filter-toggle">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
                        <?php _e( 'Filter', 'app-showcase' ); ?>
                    </button>
                    <?php endif; ?>

                    <?php if ( $atts['show_sort'] === 'true' ) : ?>
                    <select class="asc-sort-select">
                        <option value="date-DESC"      <?php selected( "$orderby-$order", 'date-DESC'      ); ?>><?php _e( 'Newest First',  'app-showcase' ); ?></option>
                        <option value="date-ASC"       <?php selected( "$orderby-$order", 'date-ASC'       ); ?>><?php _e( 'Oldest First',  'app-showcase' ); ?></option>
                        <option value="title-ASC"      <?php selected( "$orderby-$order", 'title-ASC'      ); ?>><?php _e( 'A → Z',         'app-showcase' ); ?></option>
                        <option value="title-DESC"     <?php selected( "$orderby-$order", 'title-DESC'     ); ?>><?php _e( 'Z → A',         'app-showcase' ); ?></option>
                        <option value="sort_order-ASC" <?php selected( "$orderby-$order", 'sort_order-ASC' ); ?>><?php _e( 'Custom Order',  'app-showcase' ); ?></option>
                    </select>
                    <?php endif; ?>

                    <?php if ( $atts['show_layout_toggle'] === 'true' ) : ?>
                    <div class="asc-layout-toggle">
                        <button class="asc-layout-btn <?php echo $layout === 'grid' ? 'active' : ''; ?>" data-layout="grid" title="Grid">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
                        </button>
                        <button class="asc-layout-btn <?php echo $layout === 'list' ? 'active' : ''; ?>" data-layout="list" title="List">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="5" width="18" height="2"/><rect x="3" y="11" width="18" height="2"/><rect x="3" y="17" width="18" height="2"/></svg>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php // ── Filter Panel ───────────────────────────────────── ?>
            <?php if ( $atts['show_filter'] === 'true' ) : ?>
            <div class="asc-filter-panel" style="display:none;">
                <?php if ( $categories ) : ?>
                <div class="asc-filter-group">
                    <h4><?php _e( 'Category', 'app-showcase' ); ?></h4>
                    <div class="asc-filter-chips">
                        <button class="asc-chip active" data-tax="app_category" data-term=""><?php _e( 'All', 'app-showcase' ); ?></button>
                        <?php foreach ( $categories as $cat ) : ?>
                        <button class="asc-chip" data-tax="app_category" data-term="<?php echo esc_attr( $cat->slug ); ?>"><?php echo esc_html( $cat->name ); ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ( $statuses ) : ?>
                <div class="asc-filter-group">
                    <h4><?php _e( 'Status', 'app-showcase' ); ?></h4>
                    <div class="asc-filter-chips">
                        <button class="asc-chip active" data-tax="app_status" data-term=""><?php _e( 'All', 'app-showcase' ); ?></button>
                        <?php foreach ( $statuses as $st ) : ?>
                        <button class="asc-chip" data-tax="app_status" data-term="<?php echo esc_attr( $st->slug ); ?>"><?php echo esc_html( $st->name ); ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <?php if ( $tags ) : ?>
                <div class="asc-filter-group">
                    <h4><?php _e( 'Tags', 'app-showcase' ); ?></h4>
                    <div class="asc-filter-chips">
                        <?php foreach ( $tags as $tag ) : ?>
                        <button class="asc-chip" data-tax="app_tag" data-term="<?php echo esc_attr( $tag->slug ); ?>"><?php echo esc_html( $tag->name ); ?></button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                <div class="asc-filter-actions">
                    <button class="asc-btn asc-btn--primary asc-apply-filter"><?php _e( 'Apply', 'app-showcase' ); ?></button>
                    <button class="asc-btn asc-clear-filter"><?php _e( 'Clear All', 'app-showcase' ); ?></button>
                </div>
            </div>
            <?php endif; ?>

            <div class="asc-results-meta">
                <span class="asc-count"><?php printf( _n( '%d app', '%d apps', $query->found_posts, 'app-showcase' ), $query->found_posts ); ?></span>
                <span class="asc-active-filters"></span>
            </div>

            <?php // ── Cards ──────────────────────────────────────────── ?>
            <div class="asc-grid">
                <?php if ( $query->have_posts() ) : ?>
                    <?php while ( $query->have_posts() ) : $query->the_post(); ?>
                        <?php self::render_card( get_the_ID(), $layout, $opts, $vis ); ?>
                    <?php endwhile; wp_reset_postdata(); ?>
                <?php else : ?>
                    <div class="asc-no-results">
                        <span class="asc-no-results-icon">&#128269;</span>
                        <p><?php _e( 'No applications found.', 'app-showcase' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <div class="asc-pagination">
                <?php if ( $query->max_num_pages > 1 ) : ?>
                <button class="asc-btn asc-load-more" data-page="2" data-max="<?php echo $query->max_num_pages; ?>">
                    <?php _e( 'Load More', 'app-showcase' ); ?>
                </button>
                <?php endif; ?>
            </div>
            <div class="asc-spinner" style="display:none;"><div class="asc-spinner-ring"></div></div>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ── Single card renderer ──────────────────────────────────────── */
    public static function render_card( $post_id, $layout = 'grid', $opts = [], $vis = [] ) {
        $post        = get_post( $post_id );
        $meta        = self::get_meta( $post_id );
        $thumbnail   = get_the_post_thumbnail_url( $post_id, 'medium_large' );
        $placeholder = ASC_PLUGIN_URL . 'public/images/placeholder.svg';
        $img         = $thumbnail ?: $placeholder;
        $badge_color = $meta['asc_badge_color'] ?: ( $opts['accent_color'] ?? '#4f46e5' );
        $is_featured = $meta['asc_featured'] === '1';
        $cats        = wp_get_post_terms( $post_id, 'app_category', [ 'fields' => 'names' ] ) ?: [];
        $tags        = wp_get_post_terms( $post_id, 'app_tag',      [ 'fields' => 'names' ] ) ?: [];
        $statuses    = wp_get_post_terms( $post_id, 'app_status',   [ 'fields' => 'all'   ] ) ?: [];

        // Resolve $vis: merge global settings defaults → passed $vis
        if ( empty( $vis ) ) {
            foreach ( self::card_fields() as $key => $cfg ) {
                $global_val = $opts[ $key ] ?? $cfg['default'];
                $vis[ $key ] = ( $global_val === '1' || $global_val === 1 || $global_val === true );
            }
        }

        $short_desc = $meta['asc_short_desc'] ?: wp_trim_words( get_the_excerpt(), 20 );

        // Screenshots preview (first 3 images)
        $screenshots = [];
        if ( $vis['show_screenshots'] && $meta['asc_screenshots'] ) {
            $ids = array_slice( explode( ',', $meta['asc_screenshots'] ), 0, 3 );
            foreach ( $ids as $id ) {
                $url = wp_get_attachment_image_url( (int) $id, 'thumbnail' );
                if ( $url ) $screenshots[] = $url;
            }
        }
        ?>
        <article class="asc-card <?php echo $is_featured ? 'asc-card--featured' : ''; ?> asc-layout-<?php echo esc_attr( $layout ); ?>"
                 data-id="<?php echo $post_id; ?>"
                 data-categories="<?php echo esc_attr( implode( ',', wp_list_pluck( get_the_terms( $post_id, 'app_category' ) ?: [], 'slug' ) ) ); ?>"
                 data-tags="<?php echo esc_attr( implode( ',', wp_list_pluck( get_the_terms( $post_id, 'app_tag' ) ?: [], 'slug' ) ) ); ?>"
                 data-status="<?php echo esc_attr( implode( ',', wp_list_pluck( get_the_terms( $post_id, 'app_status' ) ?: [], 'slug' ) ) ); ?>">

            <?php // ── Thumbnail ──────────────────────────────────────── ?>
            <?php if ( $vis['show_thumbnail'] ) : ?>
            <div class="asc-card__thumbnail">
                <img src="<?php echo esc_url( $img ); ?>" alt="<?php echo esc_attr( get_the_title( $post_id ) ); ?>" loading="lazy">
                <?php if ( $vis['show_badge'] && $meta['asc_badge_text'] ) : ?>
                <span class="asc-badge" style="background:<?php echo esc_attr( $badge_color ); ?>"><?php echo esc_html( $meta['asc_badge_text'] ); ?></span>
                <?php endif; ?>
                <?php if ( $is_featured ) : ?>
                <span class="asc-featured-star">&#9733;</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php // ── Screenshots strip (below thumbnail) ──────────── ?>
            <?php if ( $vis['show_screenshots'] && $screenshots ) : ?>
            <div class="asc-card__screenshots">
                <?php foreach ( $screenshots as $surl ) : ?>
                <img src="<?php echo esc_url( $surl ); ?>" alt="" loading="lazy">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php // ── Body ───────────────────────────────────────────── ?>
            <div class="asc-card__body">
                <?php if ( $vis['show_categories'] && $cats ) : ?>
                <div class="asc-card__cats"><?php echo esc_html( implode( ' · ', $cats ) ); ?></div>
                <?php endif; ?>

                <h3 class="asc-card__title">
                    <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>"><?php echo esc_html( get_the_title( $post_id ) ); ?></a>
                </h3>

                <?php if ( $vis['show_description'] && $short_desc ) : ?>
                <p class="asc-card__desc"><?php echo esc_html( $short_desc ); ?></p>
                <?php endif; ?>

                <?php if ( $vis['show_full_content'] ) : ?>
                <div class="asc-card__content"><?php echo wp_kses_post( apply_filters( 'the_content', $post->post_content ) ); ?></div>
                <?php endif; ?>

                <?php // ── Meta row ──────────────────────────────────── ?>
                <?php
                $has_meta = ( $vis['show_version']      && $meta['asc_version'] )
                          || ( $vis['show_tech_stack']   && $meta['asc_tech_stack'] )
                          || ( $vis['show_release_date'] && $meta['asc_release_date'] )
                          || ( $vis['show_author']       && $meta['asc_author_name'] )
                          || ( $vis['show_status']       && $statuses );
                ?>
                <?php if ( $has_meta ) : ?>
                <div class="asc-card__meta">
                    <?php if ( $vis['show_version'] && $meta['asc_version'] ) : ?>
                    <span class="asc-meta-item"><span class="asc-meta-icon">📦</span> v<?php echo esc_html( $meta['asc_version'] ); ?></span>
                    <?php endif; ?>
                    <?php if ( $vis['show_tech_stack'] && $meta['asc_tech_stack'] ) : ?>
                    <span class="asc-meta-item"><span class="asc-meta-icon">🔧</span> <?php echo esc_html( $meta['asc_tech_stack'] ); ?></span>
                    <?php endif; ?>
                    <?php if ( $vis['show_release_date'] && $meta['asc_release_date'] ) : ?>
                    <span class="asc-meta-item"><span class="asc-meta-icon">📅</span> <?php echo esc_html( date_i18n( get_option('date_format'), strtotime( $meta['asc_release_date'] ) ) ); ?></span>
                    <?php endif; ?>
                    <?php if ( $vis['show_author'] && $meta['asc_author_name'] ) : ?>
                    <span class="asc-meta-item">
                        <span class="asc-meta-icon">👤</span>
                        <?php if ( $meta['asc_author_url'] ) : ?>
                        <a href="<?php echo esc_url( $meta['asc_author_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $meta['asc_author_name'] ); ?></a>
                        <?php else : ?>
                        <?php echo esc_html( $meta['asc_author_name'] ); ?>
                        <?php endif; ?>
                    </span>
                    <?php endif; ?>
                    <?php if ( $vis['show_status'] ) : ?>
                    <?php foreach ( $statuses as $st ) : ?>
                    <span class="asc-status-pill asc-status-<?php echo esc_attr( $st->slug ); ?>"><?php echo esc_html( $st->name ); ?></span>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php if ( $vis['show_tags'] && $tags ) : ?>
                <div class="asc-card__tags">
                    <?php foreach ( $tags as $tag ) : ?>
                    <span class="asc-tag"><?php echo esc_html( $tag ); ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php // ── Footer buttons ─────────────────────────────────── ?>
            <?php
            $show_footer = $vis['show_buttons'] && (
                ( $vis['show_app_url']  && $meta['asc_app_url']  ) ||
                ( $vis['show_demo_url'] && $meta['asc_demo_url'] ) ||
                ( $vis['show_repo_url'] && $meta['asc_repo_url'] )
            );
            ?>
            <?php if ( $show_footer ) : ?>
            <div class="asc-card__footer">
                <?php if ( $vis['show_app_url'] && $meta['asc_app_url'] ) : ?>
                <a href="<?php echo esc_url( $meta['asc_app_url'] ); ?>" class="asc-btn asc-btn--primary" target="_blank" rel="noopener"><?php _e( 'View App', 'app-showcase' ); ?></a>
                <?php endif; ?>
                <?php if ( $vis['show_demo_url'] && $meta['asc_demo_url'] ) : ?>
                <a href="<?php echo esc_url( $meta['asc_demo_url'] ); ?>" class="asc-btn" target="_blank" rel="noopener"><?php _e( 'Demo', 'app-showcase' ); ?></a>
                <?php endif; ?>
                <?php if ( $vis['show_repo_url'] && $meta['asc_repo_url'] ) : ?>
                <a href="<?php echo esc_url( $meta['asc_repo_url'] ); ?>" class="asc-btn asc-btn--ghost" target="_blank" rel="noopener">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12c0 5.3 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577v-2.165c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0 1 12 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.63-5.37-12-12-12z"/></svg>
                    <?php _e( 'Code', 'app-showcase' ); ?>
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </article>
        <?php
    }

    /* ── Helper: get all meta for a post ───────────────────────────── */
    public static function get_meta( $post_id ) {
        $defaults = array_fill_keys( array_keys( ASC_Meta_Boxes::fields() ), '' );
        foreach ( $defaults as $key => $_ ) {
            $defaults[ $key ] = get_post_meta( $post_id, $key, true );
        }
        return $defaults;
    }
}
