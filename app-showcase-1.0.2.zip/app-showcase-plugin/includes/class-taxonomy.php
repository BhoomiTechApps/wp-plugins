<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class ASC_Taxonomy {

    public static function register() {

        // ── Category taxonomy ────────────────────────────────────────
        register_taxonomy( 'app_category', 'showcase_app', [
            'labels' => [
                'name'              => __( 'App Categories',    'app-showcase' ),
                'singular_name'     => __( 'App Category',      'app-showcase' ),
                'search_items'      => __( 'Search Categories', 'app-showcase' ),
                'all_items'         => __( 'All Categories',    'app-showcase' ),
                'edit_item'         => __( 'Edit Category',     'app-showcase' ),
                'add_new_item'      => __( 'Add New Category',  'app-showcase' ),
                'menu_name'         => __( 'Categories',        'app-showcase' ),
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-category' ],
            'show_in_rest'      => true,
        ]);

        // ── Tag taxonomy ─────────────────────────────────────────────
        register_taxonomy( 'app_tag', 'showcase_app', [
            'labels' => [
                'name'          => __( 'App Tags',    'app-showcase' ),
                'singular_name' => __( 'App Tag',     'app-showcase' ),
                'search_items'  => __( 'Search Tags', 'app-showcase' ),
                'all_items'     => __( 'All Tags',    'app-showcase' ),
                'edit_item'     => __( 'Edit Tag',    'app-showcase' ),
                'add_new_item'  => __( 'Add New Tag', 'app-showcase' ),
                'menu_name'     => __( 'Tags',        'app-showcase' ),
            ],
            'hierarchical'      => false,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-tag' ],
            'show_in_rest'      => true,
        ]);

        // ── Status taxonomy ──────────────────────────────────────────
        register_taxonomy( 'app_status', 'showcase_app', [
            'labels' => [
                'name'          => __( 'App Statuses', 'app-showcase' ),
                'singular_name' => __( 'App Status',   'app-showcase' ),
                'all_items'     => __( 'All Statuses', 'app-showcase' ),
                'add_new_item'  => __( 'Add Status',   'app-showcase' ),
                'menu_name'     => __( 'Statuses',     'app-showcase' ),
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => [ 'slug' => 'app-status' ],
            'show_in_rest'      => true,
        ]);
    }
}
