<?php if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
?>
<div class="nqm-wrap" id="nqm-status-wrap">
    <div class="nqm-card">
        <h2><?php esc_html_e( 'Check Query Status', 'ngo-query-manager' ); ?></h2>
        <div class="nqm-field nqm-uid-lookup">
            <label for="nqm-uid-input"><?php esc_html_e( 'Enter your Query ID:', 'ngo-query-manager' ); ?></label>
            <div class="nqm-uid-row">
                <input type="text" id="nqm-uid-input"
                       value="<?php echo esc_attr( isset( $_GET['uid'] ) ? sanitize_text_field( wp_unslash( $_GET['uid'] ) ) : '' ); ?>"
                       placeholder="QRY-XXXXXXXX">
                <button class="nqm-btn nqm-btn--primary" id="nqm-uid-check"><?php esc_html_e( 'Check', 'ngo-query-manager' ); ?></button>
            </div>
        </div>
        <div id="nqm-status-result"></div>
    </div>
</div>
