<?php
/**
 * Horizontal navigation bar shared across all 4 NQM front-end pages.
 * Shown at the top of every shortcode output.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

$nqm_nav_pages = [
    'nqm_page_submit' => __( 'SUBMIT',      'ngo-query-manager' ),
    'nqm_page_status' => __( 'CHECK STATUS','ngo-query-manager' ),
    'nqm_page_list'   => __( 'LIST ALL',    'ngo-query-manager' ),
    'nqm_page_respond'=> __( 'RESPOND',     'ngo-query-manager' ),
];

$current_id = get_queried_object_id();
$is_admin   = current_user_can( 'manage_options' );
?>
<nav class="nqm-top-nav" aria-label="<?php esc_attr_e( 'Query Manager Navigation', 'ngo-query-manager' ); ?>">
    <?php foreach ( $nqm_nav_pages as $option_key => $label ) :
        $pid  = (int) get_option( $option_key, 0 );
        // Fallback: look up by slug if the option isn't stored yet
        if ( ! $pid ) {
            $slug_map = [
                'nqm_page_submit'  => 'submit-query',
                'nqm_page_status'  => 'check-query-status',
                'nqm_page_list'    => 'my-queries',
                'nqm_page_respond' => 'respond-to-query',
            ];
            if ( isset( $slug_map[ $option_key ] ) ) {
                $by_slug = get_page_by_path( $slug_map[ $option_key ] );
                if ( $by_slug ) {
                    $pid = $by_slug->ID;
                    update_option( $option_key, $pid );
                }
            }
        }
        $href = $pid ? get_permalink( $pid ) : '';
        if ( ! $href ) continue; // skip nav item entirely if page doesn't exist yet
        $active = ( $pid && $pid === $current_id ) ? ' nqm-nav-active' : '';
    ?>
    <a href="<?php echo esc_url( $href ); ?>" class="nqm-nav-link<?php echo esc_attr( $active ); ?>">
        <?php echo esc_html( $label ); ?>
    </a>
    <?php endforeach; ?>

    <?php if ( $is_admin ) :
        $admin_pid  = (int) get_option( 'nqm_page_admin', 0 );
        // Fallback: look up by slug if option isn't stored yet
        if ( ! $admin_pid ) {
            $by_slug = get_page_by_path( 'query-manager-admin' );
            if ( $by_slug ) {
                $admin_pid = $by_slug->ID;
                update_option( 'nqm_page_admin', $admin_pid );
            }
        }
        $admin_href = $admin_pid ? get_permalink( $admin_pid ) : '';
        if ( $admin_href ) :
        $admin_active = ( $admin_pid && $admin_pid === $current_id ) ? ' nqm-nav-active' : '';
    ?>
    <a href="<?php echo esc_url( $admin_href ); ?>"
       class="nqm-nav-link nqm-nav-link--admin<?php echo esc_attr( $admin_active ); ?>">
        <?php esc_html_e( 'ADMIN', 'ngo-query-manager' ); ?>
    </a>
    <?php endif; // $admin_href ?>
    <?php endif; // $is_admin ?>
</nav>
