<?php if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
?>
<div class="nqm-wrap" id="nqm-submit-form">
    <div class="nqm-form-card">
        <h2 class="nqm-form-title"><?php esc_html_e( 'Submit a Query', 'ngo-query-manager' ); ?></h2>
        <div class="nqm-notice" id="nqm-notice" style="display:none"></div>

        <!-- Step 1: Identity -->
        <fieldset class="nqm-fieldset" id="nqm-step-identity">
            <legend><?php esc_html_e( 'Step 1 — Identify Yourself', 'ngo-query-manager' ); ?></legend>

            <div class="nqm-field-row">
                <div class="nqm-field">
                    <label for="nqm_name"><?php esc_html_e( 'Full Name', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                    <input type="text" id="nqm_name" name="submitter_name" required autocomplete="name">
                </div>
                <div class="nqm-field">
                    <label for="nqm_email"><?php esc_html_e( 'Email Address', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                    <input type="email" id="nqm_email" name="submitter_email" required autocomplete="email">
                </div>
            </div>
            <div class="nqm-field-row">
                <div class="nqm-field">
                    <label for="nqm_org"><?php esc_html_e( 'Organisation / Institution', 'ngo-query-manager' ); ?></label>
                    <input type="text" id="nqm_org" name="submitter_org" autocomplete="organization">
                </div>
                <div class="nqm-field">
                    <label for="nqm_phone"><?php esc_html_e( 'Phone (optional)', 'ngo-query-manager' ); ?></label>
                    <input type="tel" id="nqm_phone" name="submitter_phone" autocomplete="tel">
                </div>
            </div>
            <div class="nqm-field">
                <label for="nqm_source"><?php esc_html_e( 'You are a / an', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                <select id="nqm_source" name="query_source" required>
                    <option value=""><?php esc_html_e( '— please select —', 'ngo-query-manager' ); ?></option>
                    <?php foreach ( $sources as $s ) : ?>
                    <option value="<?php echo esc_attr($s); ?>"><?php echo esc_html( ucwords( str_replace('_',' ', $s) ) ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </fieldset>

        <!-- Step 2: Query details -->
        <fieldset class="nqm-fieldset" id="nqm-step-message">
            <legend><?php esc_html_e( 'Step 2 — Your Query', 'ngo-query-manager' ); ?></legend>

            <div class="nqm-field">
                <label for="nqm_title"><?php esc_html_e( 'Query Title', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                <input type="text" id="nqm_title" name="title" required maxlength="255" placeholder="<?php esc_attr_e( 'A short descriptive title for your query', 'ngo-query-manager' ); ?>">
            </div>

            <div class="nqm-field">
                <label><?php esc_html_e( 'Message Type', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                <div class="nqm-type-selector">
                    <label class="nqm-type-card">
                        <input type="radio" name="message_type" value="text" checked>
                        <span class="nqm-type-icon">✏️</span>
                        <span class="nqm-type-label"><?php esc_html_e( 'Text Message', 'ngo-query-manager' ); ?></span>
                        <span class="nqm-type-desc"><?php esc_html_e( 'Plain text message', 'ngo-query-manager' ); ?></span>
                    </label>
                    <label class="nqm-type-card">
                        <input type="radio" name="message_type" value="video">
                        <span class="nqm-type-icon">🎥</span>
                        <span class="nqm-type-label"><?php esc_html_e( 'Video Recording', 'ngo-query-manager' ); ?></span>
                        <span class="nqm-type-desc"><?php printf( esc_html__( 'Up to %d seconds', 'ngo-query-manager' ), NQM_Settings::video_max_duration() ); ?></span>
                    </label>
                    <label class="nqm-type-card">
                        <input type="radio" name="message_type" value="hybrid">
                        <span class="nqm-type-icon">🔀</span>
                        <span class="nqm-type-label"><?php esc_html_e( 'Hybrid', 'ngo-query-manager' ); ?></span>
                        <span class="nqm-type-desc"><?php esc_html_e( 'Rich text + video embed', 'ngo-query-manager' ); ?></span>
                    </label>
                </div>
            </div>

            <!-- Text panel -->
            <div class="nqm-panel" id="nqm-panel-text">
                <div class="nqm-field">
                    <label for="nqm_text_body"><?php esc_html_e( 'Your Message', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                    <textarea id="nqm_text_body" name="message_body_text" rows="8" placeholder="<?php esc_attr_e( 'Write your query here…', 'ngo-query-manager' ); ?>"></textarea>
                </div>
            </div>

            <!-- Video panel -->
            <div class="nqm-panel" id="nqm-panel-video" style="display:none">
                <div class="nqm-video-quota-bar">
                    <div class="nqm-video-quota-inner" id="nqm-quota-fill"></div>
                </div>
                <p id="nqm-quota-text" class="nqm-quota-text"></p>

                <div class="nqm-recorder-wrap">
                    <div class="nqm-video-ratio">
                        <video id="nqm-preview" autoplay muted playsinline></video>
                        <video id="nqm-playback" controls style="display:none"></video>
                    </div>
                    <p id="nqm-camera-label" class="nqm-camera-label" style="display:none; font-size:.85em; color:#555; margin:4px 0;"></p>
                    <div class="nqm-recorder-controls">
                        <span class="nqm-timer" id="nqm-rec-timer">00:00</span>
                        <button type="button" class="nqm-btn nqm-btn--record" id="nqm-start-btn"><?php esc_html_e( 'Start Recording', 'ngo-query-manager' ); ?></button>
                        <button type="button" class="nqm-btn nqm-btn--stop"   id="nqm-stop-btn"  style="display:none"><?php esc_html_e( 'Stop', 'ngo-query-manager' ); ?></button>
                        <button type="button" class="nqm-btn nqm-btn--retake" id="nqm-retake-btn" style="display:none"><?php esc_html_e( 'Retake', 'ngo-query-manager' ); ?></button>
                        <button type="button" class="nqm-btn nqm-btn--small" id="nqm-switch-camera-btn" style="display:none"><?php esc_html_e( 'Switch Camera', 'ngo-query-manager' ); ?></button>
                    </div>
                    <p id="nqm-video-status" class="nqm-video-status"></p>
                </div>
                <input type="hidden" id="nqm_video_attach_id"  name="video_attach_id">
                <input type="hidden" id="nqm_video_duration"   name="video_duration">

                <!-- Optional text for video submissions -->
                <div class="nqm-field" style="margin-top:16px">
                    <label for="nqm_video_note"><?php esc_html_e( 'Additional Note (optional)', 'ngo-query-manager' ); ?></label>
                    <textarea id="nqm_video_note" name="message_body_video" rows="3"></textarea>
                </div>
            </div>

            <!-- Hybrid panel (TinyMCE) -->
            <div class="nqm-panel" id="nqm-panel-hybrid" style="display:none">
                <div class="nqm-field">
                    <label for="nqm_hybrid_body"><?php esc_html_e( 'Rich Message', 'ngo-query-manager' ); ?> <span class="req">*</span></label>
                    <textarea id="nqm_hybrid_body" name="message_body_hybrid" rows="10"
                              class="nqm-tinymce"
                              data-tinymce='{"plugins":"link media code","toolbar":"bold italic link media code"}'></textarea>
                    <p class="description"><?php esc_html_e( 'You may embed video links and add hyperlinks in this editor.', 'ngo-query-manager' ); ?></p>
                </div>
            </div>
        </fieldset>

        <div class="nqm-submit-row">
            <button type="button" class="nqm-btn nqm-btn--primary" id="nqm-submit-btn">
                <?php esc_html_e( 'Submit Query', 'ngo-query-manager' ); ?>
                <span class="nqm-spinner" style="display:none">⏳</span>
            </button>
        </div>
    </div>

    <!-- Success panel -->
    <div class="nqm-success-card" id="nqm-success" style="display:none">

        <div class="nqm-success-icon-wrap">
            <svg class="nqm-checkmark" viewBox="0 0 52 52" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                <circle class="nqm-checkmark-circle" cx="26" cy="26" r="25" fill="none"/>
                <path  class="nqm-checkmark-check"  fill="none" d="M14 27 l8 8 l16-16"/>
            </svg>
        </div>

        <h2 class="nqm-success-title"><?php esc_html_e( 'Thank You — Query Received!', 'ngo-query-manager' ); ?></h2>

        <p class="nqm-success-lead"><?php esc_html_e( 'Your query has been successfully submitted to our team. We acknowledge receipt and want you to know that it is in safe hands.', 'ngo-query-manager' ); ?></p>

        <div class="nqm-ref-box">
            <span class="nqm-ref-label"><?php esc_html_e( 'Your Reference ID', 'ngo-query-manager' ); ?></span>
            <div class="nqm-query-uid" id="nqm-result-uid"></div>
            <p class="nqm-ref-hint"><?php esc_html_e( 'Please save or note down this ID — you can use it to check the status of your query at any time.', 'ngo-query-manager' ); ?></p>
        </div>

        <div class="nqm-assurance-steps">
            <div class="nqm-assurance-step">
                <span class="nqm-step-icon">📋</span>
                <div>
                    <strong><?php esc_html_e( 'Reviewed promptly', 'ngo-query-manager' ); ?></strong>
                    <p><?php esc_html_e( 'A member of our team will review your query and assign it to the right person as soon as possible.', 'ngo-query-manager' ); ?></p>
                </div>
            </div>
            <div class="nqm-assurance-step">
                <span class="nqm-step-icon">✉️</span>
                <div>
                    <strong><?php esc_html_e( 'You will be notified', 'ngo-query-manager' ); ?></strong>
                    <p><?php esc_html_e( 'Once a response is ready, you will receive an email notification at the address you provided.', 'ngo-query-manager' ); ?></p>
                </div>
            </div>
            <div class="nqm-assurance-step">
                <span class="nqm-step-icon">🔍</span>
                <div>
                    <strong><?php esc_html_e( 'Track your query', 'ngo-query-manager' ); ?></strong>
                    <p><?php esc_html_e( 'Use your reference ID on the Check Status page to follow progress at any time.', 'ngo-query-manager' ); ?></p>
                </div>
            </div>
        </div>

        <p class="nqm-success-closing"><?php esc_html_e( 'We value your engagement and are committed to providing a thoughtful and timely response. Thank you for reaching out to us.', 'ngo-query-manager' ); ?></p>

        <?php
        $status_page_id = (int) get_option( 'nqm_page_status', 0 );
        if ( $status_page_id ) : ?>
        <a href="<?php echo esc_url( get_permalink( $status_page_id ) ); ?>" class="nqm-btn nqm-btn--outline nqm-btn--small" style="margin-top:1rem">
            <?php esc_html_e( 'Check Query Status', 'ngo-query-manager' ); ?>
        </a>
        <?php endif; ?>

    </div>
</div>
