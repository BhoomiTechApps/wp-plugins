<?php
/**
 * Frontend admin panel — visible only to administrators.
 * Shortcode: [nqm_admin_panel]
 */
if ( ! defined( 'ABSPATH' ) ) exit;
include NQM_PLUGIN_DIR . 'templates/nav-menu.php';
?>
<div class="nqm-wrap" id="nqm-fadmin-wrap">

    <div class="nqm-fadmin-header">
        <h2><?php esc_html_e( 'Admin Panel', 'ngo-query-manager' ); ?></h2>
        <p class="description"><?php esc_html_e( 'Manage all queries from the frontend.', 'ngo-query-manager' ); ?></p>
    </div>

    <!-- Filters -->
    <div class="nqm-fadmin-filters">
        <select id="nqm-fadmin-status-filter">
            <option value=""><?php esc_html_e( 'All Statuses', 'ngo-query-manager' ); ?></option>
            <option value="open"><?php esc_html_e( 'Open', 'ngo-query-manager' ); ?></option>
            <option value="claimed"><?php esc_html_e( 'Claimed', 'ngo-query-manager' ); ?></option>
            <option value="closed"><?php esc_html_e( 'Closed', 'ngo-query-manager' ); ?></option>
        </select>
        <input type="search" id="nqm-fadmin-search" placeholder="<?php esc_attr_e( 'Search ID, title or submitter…', 'ngo-query-manager' ); ?>">
        <button class="nqm-btn nqm-btn--secondary" id="nqm-fadmin-filter-btn">
            <?php esc_html_e( 'Filter', 'ngo-query-manager' ); ?>
        </button>
    </div>

    <!-- Stats strip -->
    <div class="nqm-fadmin-stats" id="nqm-fadmin-stats"></div>

    <!-- Notice -->
    <div class="nqm-notice" id="nqm-fadmin-notice" style="display:none"></div>

    <!-- Table -->
    <div id="nqm-fadmin-table-wrap">
        <p><?php esc_html_e( 'Loading…', 'ngo-query-manager' ); ?></p>
    </div>

    <!-- Detail drawer -->
    <div id="nqm-fadmin-drawer" class="nqm-fadmin-drawer" style="display:none">
        <div class="nqm-fadmin-drawer-inner">
            <button class="nqm-fadmin-close" id="nqm-fadmin-close-btn" aria-label="<?php esc_attr_e( 'Close', 'ngo-query-manager' ); ?>">✕</button>
            <div id="nqm-fadmin-detail-content"></div>
        </div>
    </div>
    <div id="nqm-fadmin-overlay" class="nqm-fadmin-overlay" style="display:none"></div>

    <!-- Assign modal -->
    <div id="nqm-fadmin-assign-modal" class="nqm-fadmin-modal" style="display:none">
        <div class="nqm-fadmin-modal-inner">
            <h3><?php esc_html_e( 'Assign Query', 'ngo-query-manager' ); ?></h3>
            <input type="hidden" id="nqm-fadmin-assign-qid">
            <select id="nqm-fadmin-assignee">
                <option value=""><?php esc_html_e( '— select user —', 'ngo-query-manager' ); ?></option>
                <?php
                $respondent_roles = NQM_Settings::get_respondent_roles();
                $respondents = get_users( [ 'role__in' => $respondent_roles, 'orderby' => 'display_name' ] );
                foreach ( $respondents as $u ) :
                ?>
                <option value="<?php echo (int) $u->ID; ?>">
                    <?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?>
                </option>
                <?php endforeach; ?>
            </select>
            <div class="nqm-fadmin-modal-actions">
                <button class="nqm-btn nqm-btn--primary" id="nqm-fadmin-assign-confirm">
                    <?php esc_html_e( 'Assign', 'ngo-query-manager' ); ?>
                </button>
                <button class="nqm-btn nqm-btn--secondary" id="nqm-fadmin-assign-cancel">
                    <?php esc_html_e( 'Cancel', 'ngo-query-manager' ); ?>
                </button>
            </div>
        </div>
    </div>

</div><!-- .nqm-fadmin-wrap -->
