<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class NQM_Settings {

    public static function init() {
        add_action( 'admin_init', [ __CLASS__, 'register' ] );
    }

    public static function register() {
        /* General */
        register_setting( 'nqm_general', 'nqm_delete_data_on_uninstall', [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_notify_response_attach',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_admin_email_notify',      [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_from_email',               [ 'type' => 'string',  'sanitize_callback' => 'sanitize_email' ] );
        register_setting( 'nqm_general', 'nqm_from_name',                [ 'type' => 'string',  'sanitize_callback' => 'sanitize_text_field' ] );
        register_setting( 'nqm_general', 'nqm_query_sources',            [ 'sanitize_callback' => [ __CLASS__, 'sanitize_array' ] ] );
        register_setting( 'nqm_general', 'nqm_respond_page_id',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_page_admin',         [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_general', 'nqm_respondent_roles',         [ 'sanitize_callback' => [ __CLASS__, 'sanitize_array' ] ] );

        /* Video */
        register_setting( 'nqm_video',   'nqm_video_max_duration',       [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
        register_setting( 'nqm_video',   'nqm_video_global_allocation',  [ 'type' => 'integer', 'sanitize_callback' => 'absint' ] );
    }

    public static function sanitize_array( $input ) {
        if ( ! is_array( $input ) ) {
            $input = array_map( 'trim', explode( "\n", $input ) );
        }
        return array_filter( array_map( 'sanitize_text_field', $input ) );
    }

    /* ── Getters ──────────────────────────────────────────────── */
    public static function get( $key, $default = '' ) {
        return get_option( $key, $default );
    }

    public static function get_query_sources() {
        $sources = get_option( 'nqm_query_sources', [] );
        if ( empty( $sources ) ) {
            $sources = [ 'project_partner', 'funding_agency', 'beneficiary', 'government_body', 'general_public' ];
        }
        return $sources;
    }

    public static function get_respondent_roles() {
        $roles = get_option( 'nqm_respondent_roles', [] );
        if ( empty( $roles ) ) {
            $roles = [ 'editor', 'author' ];
        }
        // Administrators can always respond from the frontend regardless of saved roles.
        $roles = (array) $roles;
        if ( ! in_array( 'administrator', $roles, true ) ) {
            $roles[] = 'administrator';
        }
        return $roles;
    }

    public static function video_max_duration() {
        return (int) get_option( 'nqm_video_max_duration', 60 );
    }

    public static function video_global_allocation() {
        return (int) get_option( 'nqm_video_global_allocation', 3600 );
    }
}
